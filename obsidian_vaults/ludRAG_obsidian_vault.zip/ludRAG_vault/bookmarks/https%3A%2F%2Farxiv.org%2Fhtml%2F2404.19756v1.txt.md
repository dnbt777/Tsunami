







KAN: Kolmogorov–Arnold Networks
































1 
Introduction




2 
Kolmogorov–Arnold Networks (KAN)




2.1 
Kolmogorov-Arnold Representation theorem


2.2 
KAN architecture


2.3 
KAN’s Approximation Abilities and Scaling Laws


2.4 
For accuracy: Grid Extension




2.5 
For Interpretability: Simplifying KANs and Making them interactive




2.5.1 
Simplification techniques


2.5.2 
A toy example: how humans can interact with KANs












3 
KANs are accurate




3.1 
Toy datasets


3.2 
Special functions


3.3 
Feynman datasets


3.4 
Solving partial differential equations


3.5 
Continual Learning








4 
KANs are interpretable




4.1 
Supervised toy datasets


4.2 
Unsupervised toy dataset


4.3 
Application to Mathematics: Knot Theory


4.4 
Application to Physics: Anderson localization






5 
Related works


6 
Discussion


A 
KAN Functionalities




B 
Learnable activation networks (LANs)




B.1 
Architecture


B.2 
LAN interpretability results


B.3 
Fitting Images (LAN)






C 
Dependence on hyperparameters


D 
Feynman KANs


E 
Remark on grid size


F 
KANs for special functions












KAN: Kolmogorov–Arnold Networks






Ziming Liu
1,4
  Yixuan Wang
2
  Sachin Vaidya
1
  Fabian Ruehle
3,4


 
James Halverson
3,4
  
Marin Soljačić
1,4
  
Thomas Y. Hou
2
  
Max Tegmark
1,4


1
 Massachusetts Institute of Technology

2
 California Institute of Technology

3
 Northeastern University

4
 The NSF Institute for Artificial Intelligence and Fundamental Interactions

zmliu@mit.edu






Abstract


Inspired by the Kolmogorov-Arnold representation theorem, we propose Kolmogorov-Arnold Networks (KANs) as promising alternatives to Multi-Layer Perceptrons (MLPs). While MLPs have 
fixed
 activation functions on 
nodes
 (“neurons”), KANs have 
learnable
 activation functions on 
edges
 (“weights”). KANs have no linear weights at all – every weight parameter is replaced by a univariate function parametrized as a spline. We show that this seemingly simple change makes KANs outperform MLPs in terms of accuracy and interpretability. For accuracy, much smaller KANs can achieve comparable or better accuracy than much larger MLPs in data fitting and PDE solving. Theoretically and empirically, KANs possess faster neural scaling laws than MLPs. For interpretability, KANs can be intuitively visualized and can easily interact with human users. Through two examples in mathematics and physics, KANs are shown to be useful “collaborators” helping scientists (re)discover mathematical and physical laws. In summary, KANs are promising alternatives for MLPs, opening opportunities for further improving today’s deep learning models which rely heavily on MLPs.




Figure 0.1: 
Multi-Layer Perceptrons (MLPs) vs. Kolmogorov-Arnold Networks (KANs)










1 
Introduction




Multi-layer perceptrons (MLPs) 
[
1
, 
2
, 
3
]
, also known as fully-connected feedforward neural networks, are foundational building blocks of today’s deep learning models. The importance of MLPs can never be overstated, since they are the default models in machine learning for approximating nonlinear functions, due to their expressive power guaranteed by the universal approximation theorem 
[
3
]
. However, are MLPs the best nonlinear regressors we can build? Despite the prevalent use of MLPs, they have significant drawbacks. In transformers 
[
4
]
 for example, MLPs consume almost all non-embedding parameters and are typically less interpretable (relative to attention layers) without post-analysis tools 
[
5
]
.






We propose a promising alternative to MLPs, called Kolmogorov-Arnold Networks (KANs). Whereas MLPs are inspired by the universal approximation theorem, KANs are inspired by the Kolmogorov-Arnold representation theorem 
[
6
, 
7
]
. Like MLPs, KANs have fully-connected structures. However, while MLPs place fixed activation functions on 
nodes
 (“neurons”), KANs place learnable activation functions on 
edges
 (“weights”), as illustrated in Figure 
0.1
. As a result, KANs have no linear weight matrices at all: instead, each weight parameter is replaced by a learnable 1D function parametrized as a spline. KANs’ nodes simply sum incoming signals without applying any non-linearities. One might worry that KANs are hopelessly expensive, since each MLP’s weight parameter becomes KAN’s spline function. Fortunately, KANs usually allow much smaller computation graphs than MLPs. For example, we show that for PDE solving, a 2-Layer width-10 KAN is 
100 times more accurate
 than a 4-Layer width-100 MLP (
10
−
7
superscript
10
7
10^{-7}
10 start_POSTSUPERSCRIPT - 7 end_POSTSUPERSCRIPT
 vs 
10
−
5
superscript
10
5
10^{-5}
10 start_POSTSUPERSCRIPT - 5 end_POSTSUPERSCRIPT
 MSE) and 
100 times more parameter efficient
 (
10
2
superscript
10
2
10^{2}
10 start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT
 vs 
10
4
superscript
10
4
10^{4}
10 start_POSTSUPERSCRIPT 4 end_POSTSUPERSCRIPT
 parameters).






Unsurprisingly, the possibility of using Kolmogorov-Arnold representation theorem to build neural networks has been studied 
[
8
, 
9
, 
10
, 
11
, 
12
, 
13
]
. However, most work has stuck with the original depth-2 width-(
2
⁢
n
+
1
2
𝑛
1
2n+1
2 italic_n + 1
) representation, and did not have the chance to leverage more modern techniques (e.g., back propagation) to train the networks. Our contribution lies in generalizing the original Kolmogorov-Arnold representation to arbitrary widths and depths, revitalizing and contextualizing it in today’s deep learning world, as well as using extensive empirical experiments to highlight its potential role as a foundation model for AI + Science due to its accuracy and interpretability.






Despite their elegant mathematical interpretation, KANs are nothing more than combinations of splines and MLPs, leveraging their respective strengths and avoiding their respective weaknesses. Splines are accurate for low-dimensional functions, easy to adjust locally, and able to switch between different resolutions. However, splines have a serious curse of dimensionality (COD) problem, because of their inability to exploit compositional structures. MLPs, On the other hand, suffer less from COD thanks to their feature learning, but are less accurate than splines in low dimensions, because of their inability to optimize univariate functions. To learn a function accurately, a model should not only learn the compositional structure (
external
 degrees of freedom), but should also approximate well the univariate functions (
internal
 degrees of freedom). KANs are such models since they have MLPs on the outside and splines on the inside. As a result, KANs can not only learn features (thanks to their external similarity to MLPs), but can also optimize these learned features to great accuracy (thanks to their internal similarity to splines). For example, given a high dimensional function








f
⁢
(
x
1
,
⋯
,
x
N
)
=
exp
⁡
(
1
N
⁢
∑
i
=
1
N
sin
2
⁢
(
x
i
)
)
,
𝑓
subscript
𝑥
1
⋯
subscript
𝑥
𝑁
1
𝑁
superscript
subscript
𝑖
1
𝑁
superscript
sin
2
subscript
𝑥
𝑖
\displaystyle f(x_{1},\cdots,x_{N})=\exp\left(\frac{1}{N}\sum_{i=1}^{N}{\rm sin%
}^{2}(x_{i})\right),
italic_f ( italic_x start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT , ⋯ , italic_x start_POSTSUBSCRIPT italic_N end_POSTSUBSCRIPT ) = roman_exp ( divide start_ARG 1 end_ARG start_ARG italic_N end_ARG ∑ start_POSTSUBSCRIPT italic_i = 1 end_POSTSUBSCRIPT start_POSTSUPERSCRIPT italic_N end_POSTSUPERSCRIPT roman_sin start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT ( italic_x start_POSTSUBSCRIPT italic_i end_POSTSUBSCRIPT ) ) ,




(1.1)






splines would fail for large 
N
𝑁
N
italic_N
 due to COD; MLPs can potentially learn the the generalized additive structure, but they are very inefficient for approximating the exponential and sine functions with say, ReLU activations. In contrast, KANs can learn both the compositional structure and the univariate functions quite well, hence outperforming MLPs by a large margin (see Figure 
3.1
).






Throughout this paper, we will use extensive numerical experiments to show that KANs can lead to remarkable accuracy and interpretability improvement over MLPs. The organization of the paper is illustrated in Figure 
2.1
. In Section 
2
, we introduce the KAN architecture and its mathematical foundation, introduce network simplification techniques to make KANs interpretable, and introduce a grid extension technique to make KANs increasingly more accurate. In Section 
3
, we show that KANs are more accurate than MLPs for data fitting and PDE solving: KANs can beat the curse of dimensionality when there is a compositional structure in data, achieving much better scaling laws than MLPs. In Section 
4
, we show that KANs are interpretable and can be used for scientific discoveries. We use two examples from mathematics (knot theory) and physics (Anderson localization) to demonstrate that KANs can be helpful “collaborators” for scientists to (re)discover math and physical laws. Section 
5
 summarizes related works. In Section 
6
, we conclude by discussing broad impacts and future directions. Codes are available at 
https://github.com/KindXiaoming/pykan
 and can also be installed via 
pip install pykan
.










2 
Kolmogorov–Arnold Networks (KAN)




Figure 2.1: 
Our proposed Kolmogorov-Arnold networks are in honor of two great late mathematicians, Andrey Kolmogorov and Vladimir Arnold. KANs are mathematically sound, accurate and interpretable.







Multi-Layer Perceptrons (MLPs) are inspired by the universal approximation theorem. We instead focus on the Kolmogorov-Arnold representation theorem, which can be realized by a new type of neural network called Kolmogorov-Arnold networks (KAN). We review the Kolmogorov-Arnold theorem in Section 
2.1
, to inspire the design of Kolmogorov-Arnold Networks in Section 
2.2
. In Section 
2.3
, we provide theoretical guarantees for the expressive power of KANs and their neural scaling laws. In Section 
2.4
, we propose a grid extension technique to make KANs increasingly more accurate. In Section 
2.5
, we propose simplification techniques to make KANs interpretable.








2.1 
Kolmogorov-Arnold Representation theorem




Vladimir Arnold and Andrey Kolmogorov established that if 
f
𝑓
f
italic_f
 is a multivariate continuous function on a bounded domain, then 
f
𝑓
f
italic_f
 can be written as a finite composition of continuous functions of a single variable and the binary operation of addition. More specifically, for a smooth 
f
:
[
0
,
1
]
n
→
ℝ
:
𝑓
→
superscript
0
1
𝑛
ℝ
f:[0,1]^{n}\to\mathbb{R}
italic_f : [ 0 , 1 ] start_POSTSUPERSCRIPT italic_n end_POSTSUPERSCRIPT → blackboard_R
,








f
⁢
(
𝐱
)
=
f
⁢
(
x
1
,
⋯
,
x
n
)
=
∑
q
=
1
2
⁢
n
+
1
Φ
q
⁢
(
∑
p
=
1
n
ϕ
q
,
p
⁢
(
x
p
)
)
,
𝑓
𝐱
𝑓
subscript
𝑥
1
⋯
subscript
𝑥
𝑛
superscript
subscript
𝑞
1
2
𝑛
1
subscript
Φ
𝑞
superscript
subscript
𝑝
1
𝑛
subscript
italic-ϕ
𝑞
𝑝
subscript
𝑥
𝑝
f(\mathbf{x})=f(x_{1},\cdots,x_{n})=\sum_{q=1}^{2n+1}\Phi_{q}\left(\sum_{p=1}^%
{n}\phi_{q,p}(x_{p})\right),
italic_f ( bold_x ) = italic_f ( italic_x start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT , ⋯ , italic_x start_POSTSUBSCRIPT italic_n end_POSTSUBSCRIPT ) = ∑ start_POSTSUBSCRIPT italic_q = 1 end_POSTSUBSCRIPT start_POSTSUPERSCRIPT 2 italic_n + 1 end_POSTSUPERSCRIPT roman_Φ start_POSTSUBSCRIPT italic_q end_POSTSUBSCRIPT ( ∑ start_POSTSUBSCRIPT italic_p = 1 end_POSTSUBSCRIPT start_POSTSUPERSCRIPT italic_n end_POSTSUPERSCRIPT italic_ϕ start_POSTSUBSCRIPT italic_q , italic_p end_POSTSUBSCRIPT ( italic_x start_POSTSUBSCRIPT italic_p end_POSTSUBSCRIPT ) ) ,




(2.1)






where 
ϕ
q
,
p
:
[
0
,
1
]
→
ℝ
:
subscript
italic-ϕ
𝑞
𝑝
→
0
1
ℝ
\phi_{q,p}:[0,1]\to\mathbb{R}
italic_ϕ start_POSTSUBSCRIPT italic_q , italic_p end_POSTSUBSCRIPT : [ 0 , 1 ] → blackboard_R
 and 
Φ
q
:
ℝ
→
ℝ
:
subscript
Φ
𝑞
→
ℝ
ℝ
\Phi_{q}:\mathbb{R}\to\mathbb{R}
roman_Φ start_POSTSUBSCRIPT italic_q end_POSTSUBSCRIPT : blackboard_R → blackboard_R
. In a sense, they showed that the only true multivariate function is addition, since every other function can be written using univariate functions and sum. One might naively consider this great news for machine learning: learning a high-dimensional function boils down to learning a polynomial number of 1D functions. However, these 1D functions can be non-smooth and even fractal, so they may not be learnable in practice 
[
14
]
. Because of this pathological behavior, the Kolmogorov-Arnold representation theorem was basically sentenced to death in machine learning, regarded as theoretically sound but practically useless 
[
14
]
.






However, we are more optimistic about the usefulness of the Kolmogorov-Arnold theorem for machine learning. First of all, we need not stick to the original Eq. (
2.1
) which has only two-layer non-linearities and a small number of terms (
2
⁢
n
+
1
2
𝑛
1
2n+1
2 italic_n + 1
) in the hidden layer: we will generalize the network to arbitrary widths and depths. Secondly, most functions in science and daily life are often smooth and have sparse compositional structures, potentially facilitating smooth Kolmogorov-Arnold representations. The philosophy here is close to the mindset of physicists, who often care more about typical cases rather than worst cases. After all, our physical world and machine learning tasks must have structures to make physics and machine learning useful or generalizable at all 
[
15
]
.










2.2 
KAN architecture




Figure 2.2: 
Left: Notations of activations that flow through the network. Right: an activation function is parameterized as a B-spline, which allows switching between coarse-grained and fine-grained grids.






Suppose we have a supervised learning task consisting of input-output pairs 
{
𝐱
i
,
y
i
}
subscript
𝐱
𝑖
subscript
𝑦
𝑖
\{\mathbf{x}_{i},y_{i}\}
{ bold_x start_POSTSUBSCRIPT italic_i end_POSTSUBSCRIPT , italic_y start_POSTSUBSCRIPT italic_i end_POSTSUBSCRIPT }
, where we want to find 
f
𝑓
f
italic_f
 such that 
y
i
≈
f
⁢
(
𝐱
i
)
subscript
𝑦
𝑖
𝑓
subscript
𝐱
𝑖
y_{i}\approx f(\mathbf{x}_{i})
italic_y start_POSTSUBSCRIPT italic_i end_POSTSUBSCRIPT ≈ italic_f ( bold_x start_POSTSUBSCRIPT italic_i end_POSTSUBSCRIPT )
 for all data points.
Eq. (
2.1
) implies that we are done if we can find appropriate univariate functions 
ϕ
q
,
p
subscript
italic-ϕ
𝑞
𝑝
\phi_{q,p}
italic_ϕ start_POSTSUBSCRIPT italic_q , italic_p end_POSTSUBSCRIPT
 and 
Φ
q
subscript
Φ
𝑞
\Phi_{q}
roman_Φ start_POSTSUBSCRIPT italic_q end_POSTSUBSCRIPT
. This inspires us to design a neural network which explicitly parametrizes Eq. (
2.1
). Since all functions to be learned are univariate functions, we can parametrize each 1D function as a B-spline curve, with learnable coefficients of local B-spline basis functions (see Figure 
2.2
 right). Now we have a prototype of KAN, whose computation graph is exactly specified by Eq. (
2.1
) and illustrated in Figure 
0.1
 (b) (with the input dimension 
n
=
2
𝑛
2
n=2
italic_n = 2
), appearing as a two-layer neural network with activation functions placed on edges instead of nodes (simple summation is performed on nodes), and with width 
2
⁢
n
+
1
2
𝑛
1
2n+1
2 italic_n + 1
 in the middle layer.






As mentioned, such a network is known to be too simple to approximate any function arbitrarily well in practice with smooth splines! We therefore generalize our KAN to be wider and deeper. It is not immediately clear how to make KANs deeper, since Kolmogorov-Arnold representations correspond to two-layer KANs. To the best of our knowledge, there is not yet a “generalized” version of the theorem that corresponds to deeper KANs.







The breakthrough occurs when we notice the analogy between MLPs and KANs. In MLPs, once we define a layer (which is composed of a linear transformation and nonlinearties), we can stack more layers to make the network deeper. To build deep KANs, we should first answer: “what is a KAN layer?” It turns out that a KAN layer with 
n
in
subscript
𝑛
in
n_{\rm in}
italic_n start_POSTSUBSCRIPT roman_in end_POSTSUBSCRIPT
-dimensional inputs and 
n
out
subscript
𝑛
out
n_{\rm out}
italic_n start_POSTSUBSCRIPT roman_out end_POSTSUBSCRIPT
-dimensional outputs can be defined as a matrix of 1D functions








𝚽
=
{
ϕ
q
,
p
}
,
p
=
1
,
2
,
⋯
,
n
in
,
q
=
1
,
2
⁢
⋯
,
n
out
,
formulae-sequence
𝚽
subscript
italic-ϕ
𝑞
𝑝
formulae-sequence
𝑝
1
2
⋯
subscript
𝑛
in
𝑞
1
2
⋯
subscript
𝑛
out
\displaystyle{\mathbf{\Phi}}=\{\phi_{q,p}\},\qquad p=1,2,\cdots,n_{\rm in},%
\qquad q=1,2\cdots,n_{\rm out},
bold_Φ = { italic_ϕ start_POSTSUBSCRIPT italic_q , italic_p end_POSTSUBSCRIPT } , italic_p = 1 , 2 , ⋯ , italic_n start_POSTSUBSCRIPT roman_in end_POSTSUBSCRIPT , italic_q = 1 , 2 ⋯ , italic_n start_POSTSUBSCRIPT roman_out end_POSTSUBSCRIPT ,




(2.2)






where the functions 
ϕ
q
,
p
subscript
italic-ϕ
𝑞
𝑝
\phi_{q,p}
italic_ϕ start_POSTSUBSCRIPT italic_q , italic_p end_POSTSUBSCRIPT
 have trainable parameters, as detaild below. In the Kolmogov-Arnold theorem, the inner functions form a KAN layer with 
n
in
=
n
subscript
𝑛
in
𝑛
n_{\rm in}=n
italic_n start_POSTSUBSCRIPT roman_in end_POSTSUBSCRIPT = italic_n
 and 
n
out
=
2
⁢
n
+
1
subscript
𝑛
out
2
𝑛
1
n_{\rm out}=2n+1
italic_n start_POSTSUBSCRIPT roman_out end_POSTSUBSCRIPT = 2 italic_n + 1
, and the outer functions form a KAN layer with 
n
in
=
2
⁢
n
+
1
subscript
𝑛
in
2
𝑛
1
n_{\rm in}=2n+1
italic_n start_POSTSUBSCRIPT roman_in end_POSTSUBSCRIPT = 2 italic_n + 1
 and 
n
out
=
1
subscript
𝑛
out
1
n_{\rm out}=1
italic_n start_POSTSUBSCRIPT roman_out end_POSTSUBSCRIPT = 1
. So the Kolmogorov-Arnold representations in Eq. (
2.1
) are simply compositions of two KAN layers. Now it becomes clear what it means to have deeper Kolmogorov-Arnold representations: simply stack more KAN layers!






Let us introduce some notation. This paragraph will be a bit technical, but readers can refer to Figure 
2.2
 (left) for a concrete example and intuitive understanding. The shape of a KAN is represented by an integer array








[
n
0
,
n
1
,
⋯
,
n
L
]
,
subscript
𝑛
0
subscript
𝑛
1
⋯
subscript
𝑛
𝐿
\displaystyle[n_{0},n_{1},\cdots,n_{L}],
[ italic_n start_POSTSUBSCRIPT 0 end_POSTSUBSCRIPT , italic_n start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT , ⋯ , italic_n start_POSTSUBSCRIPT italic_L end_POSTSUBSCRIPT ] ,




(2.3)






where 
n
i
subscript
𝑛
𝑖
n_{i}
italic_n start_POSTSUBSCRIPT italic_i end_POSTSUBSCRIPT
 is the number of nodes in the 
i
th
superscript
𝑖
th
i^{\rm th}
italic_i start_POSTSUPERSCRIPT roman_th end_POSTSUPERSCRIPT
 layer of the computational graph. We denote the 
i
th
superscript
𝑖
th
i^{\rm th}
italic_i start_POSTSUPERSCRIPT roman_th end_POSTSUPERSCRIPT
 neuron in the 
l
th
superscript
𝑙
th
l^{\rm th}
italic_l start_POSTSUPERSCRIPT roman_th end_POSTSUPERSCRIPT
 layer by 
(
l
,
i
)
𝑙
𝑖
(l,i)
( italic_l , italic_i )
, and the activation value of the 
(
l
,
i
)
𝑙
𝑖
(l,i)
( italic_l , italic_i )
-neuron by 
x
l
,
i
subscript
𝑥
𝑙
𝑖
x_{l,i}
italic_x start_POSTSUBSCRIPT italic_l , italic_i end_POSTSUBSCRIPT
. Between layer 
l
𝑙
l
italic_l
 and layer 
l
+
1
𝑙
1
l+1
italic_l + 1
, there are 
n
l
⁢
n
l
+
1
subscript
𝑛
𝑙
subscript
𝑛
𝑙
1
n_{l}n_{l+1}
italic_n start_POSTSUBSCRIPT italic_l end_POSTSUBSCRIPT italic_n start_POSTSUBSCRIPT italic_l + 1 end_POSTSUBSCRIPT
 activation functions: the activation function that connects 
(
l
,
j
)
𝑙
𝑗
(l,j)
( italic_l , italic_j )
 and 
(
l
+
1
,
i
)
𝑙
1
𝑖
(l+1,i)
( italic_l + 1 , italic_i )
 is denoted by








ϕ
l
,
i
,
j
,
l
=
0
,
⋯
,
L
−
1
,
i
=
1
,
⋯
,
n
l
+
1
,
j
=
1
,
⋯
,
n
l
.
formulae-sequence
subscript
italic-ϕ
𝑙
𝑖
𝑗
𝑙
0
⋯
𝐿
1
𝑖
1
⋯
subscript
𝑛
𝑙
1
𝑗
1
⋯
subscript
𝑛
𝑙
\displaystyle\phi_{l,i,j},\quad l=0,\cdots,L-1,\quad i=1,\cdots,n_{l+1},\quad j%
=1,\cdots,n_{l}.
italic_ϕ start_POSTSUBSCRIPT italic_l , italic_i , italic_j end_POSTSUBSCRIPT , italic_l = 0 , ⋯ , italic_L - 1 , italic_i = 1 , ⋯ , italic_n start_POSTSUBSCRIPT italic_l + 1 end_POSTSUBSCRIPT , italic_j = 1 , ⋯ , italic_n start_POSTSUBSCRIPT italic_l end_POSTSUBSCRIPT .




(2.4)






The pre-activation of 
ϕ
l
,
i
,
j
subscript
italic-ϕ
𝑙
𝑖
𝑗
\phi_{l,i,j}
italic_ϕ start_POSTSUBSCRIPT italic_l , italic_i , italic_j end_POSTSUBSCRIPT
 is simply 
x
l
,
i
subscript
𝑥
𝑙
𝑖
x_{l,i}
italic_x start_POSTSUBSCRIPT italic_l , italic_i end_POSTSUBSCRIPT
; the post-activation of 
ϕ
l
,
i
,
j
subscript
italic-ϕ
𝑙
𝑖
𝑗
\phi_{l,i,j}
italic_ϕ start_POSTSUBSCRIPT italic_l , italic_i , italic_j end_POSTSUBSCRIPT
 is denoted by 
x
~
l
,
i
,
j
≡
ϕ
l
,
i
,
j
⁢
(
x
l
,
i
)
subscript
~
𝑥
𝑙
𝑖
𝑗
subscript
italic-ϕ
𝑙
𝑖
𝑗
subscript
𝑥
𝑙
𝑖
\tilde{x}_{l,i,j}\equiv\phi_{l,i,j}(x_{l,i})
over~ start_ARG italic_x end_ARG start_POSTSUBSCRIPT italic_l , italic_i , italic_j end_POSTSUBSCRIPT ≡ italic_ϕ start_POSTSUBSCRIPT italic_l , italic_i , italic_j end_POSTSUBSCRIPT ( italic_x start_POSTSUBSCRIPT italic_l , italic_i end_POSTSUBSCRIPT )
. The activation value of the 
(
l
+
1
,
j
)
𝑙
1
𝑗
(l+1,j)
( italic_l + 1 , italic_j )
 neuron is simply the sum of all incoming post-activations:








x
l
+
1
,
j
=
∑
i
=
1
n
l
x
~
l
,
i
,
j
=
∑
i
=
1
n
l
ϕ
l
,
i
,
j
⁢
(
x
l
,
i
)
,
j
=
1
,
⋯
,
n
l
+
1
.
formulae-sequence
subscript
𝑥
𝑙
1
𝑗
superscript
subscript
𝑖
1
subscript
𝑛
𝑙
subscript
~
𝑥
𝑙
𝑖
𝑗
superscript
subscript
𝑖
1
subscript
𝑛
𝑙
subscript
italic-ϕ
𝑙
𝑖
𝑗
subscript
𝑥
𝑙
𝑖
𝑗
1
⋯
subscript
𝑛
𝑙
1
x_{l+1,j}=\sum_{i=1}^{n_{l}}\tilde{x}_{l,i,j}=\sum_{i=1}^{n_{l}}\phi_{l,i,j}(x%
_{l,i}),\qquad j=1,\cdots,n_{l+1}.
italic_x start_POSTSUBSCRIPT italic_l + 1 , italic_j end_POSTSUBSCRIPT = ∑ start_POSTSUBSCRIPT italic_i = 1 end_POSTSUBSCRIPT start_POSTSUPERSCRIPT italic_n start_POSTSUBSCRIPT italic_l end_POSTSUBSCRIPT end_POSTSUPERSCRIPT over~ start_ARG italic_x end_ARG start_POSTSUBSCRIPT italic_l , italic_i , italic_j end_POSTSUBSCRIPT = ∑ start_POSTSUBSCRIPT italic_i = 1 end_POSTSUBSCRIPT start_POSTSUPERSCRIPT italic_n start_POSTSUBSCRIPT italic_l end_POSTSUBSCRIPT end_POSTSUPERSCRIPT italic_ϕ start_POSTSUBSCRIPT italic_l , italic_i , italic_j end_POSTSUBSCRIPT ( italic_x start_POSTSUBSCRIPT italic_l , italic_i end_POSTSUBSCRIPT ) , italic_j = 1 , ⋯ , italic_n start_POSTSUBSCRIPT italic_l + 1 end_POSTSUBSCRIPT .




(2.5)






In matrix form, this reads








𝐱
l
+
1
=
(
ϕ
l
,
1
,
1
⁢
(
⋅
)
ϕ
l
,
1
,
2
⁢
(
⋅
)
⋯
ϕ
l
,
1
,
n
l
⁢
(
⋅
)
ϕ
l
,
2
,
1
⁢
(
⋅
)
ϕ
l
,
2
,
2
⁢
(
⋅
)
⋯
ϕ
l
,
2
,
n
l
⁢
(
⋅
)
⋮
⋮
⋮
ϕ
l
,
n
l
+
1
,
1
⁢
(
⋅
)
ϕ
l
,
n
l
+
1
,
2
⁢
(
⋅
)
⋯
ϕ
l
,
n
l
+
1
,
n
l
⁢
(
⋅
)
)
⏟
𝚽
l
⁢
𝐱
l
,
subscript
𝐱
𝑙
1
subscript
⏟
matrix
subscript
italic-ϕ
𝑙
1
1
⋅
subscript
italic-ϕ
𝑙
1
2
⋅
⋯
subscript
italic-ϕ
𝑙
1
subscript
𝑛
𝑙
⋅
subscript
italic-ϕ
𝑙
2
1
⋅
subscript
italic-ϕ
𝑙
2
2
⋅
⋯
subscript
italic-ϕ
𝑙
2
subscript
𝑛
𝑙
⋅
⋮
⋮
missing-subexpression
⋮
subscript
italic-ϕ
𝑙
subscript
𝑛
𝑙
1
1
⋅
subscript
italic-ϕ
𝑙
subscript
𝑛
𝑙
1
2
⋅
⋯
subscript
italic-ϕ
𝑙
subscript
𝑛
𝑙
1
subscript
𝑛
𝑙
⋅
subscript
𝚽
𝑙
subscript
𝐱
𝑙
\mathbf{x}_{l+1}=\underbrace{\begin{pmatrix}\phi_{l,1,1}(\cdot)&\phi_{l,1,2}(%
\cdot)&\cdots&\phi_{l,1,n_{l}}(\cdot)\\
\phi_{l,2,1}(\cdot)&\phi_{l,2,2}(\cdot)&\cdots&\phi_{l,2,n_{l}}(\cdot)\\
\vdots&\vdots&&\vdots\\
\phi_{l,n_{l+1},1}(\cdot)&\phi_{l,n_{l+1},2}(\cdot)&\cdots&\phi_{l,n_{l+1},n_{%
l}}(\cdot)\\
\end{pmatrix}}_{\mathbf{\Phi}_{l}}\mathbf{x}_{l},
bold_x start_POSTSUBSCRIPT italic_l + 1 end_POSTSUBSCRIPT = under⏟ start_ARG ( start_ARG start_ROW start_CELL italic_ϕ start_POSTSUBSCRIPT italic_l , 1 , 1 end_POSTSUBSCRIPT ( ⋅ ) end_CELL start_CELL italic_ϕ start_POSTSUBSCRIPT italic_l , 1 , 2 end_POSTSUBSCRIPT ( ⋅ ) end_CELL start_CELL ⋯ end_CELL start_CELL italic_ϕ start_POSTSUBSCRIPT italic_l , 1 , italic_n start_POSTSUBSCRIPT italic_l end_POSTSUBSCRIPT end_POSTSUBSCRIPT ( ⋅ ) end_CELL end_ROW start_ROW start_CELL italic_ϕ start_POSTSUBSCRIPT italic_l , 2 , 1 end_POSTSUBSCRIPT ( ⋅ ) end_CELL start_CELL italic_ϕ start_POSTSUBSCRIPT italic_l , 2 , 2 end_POSTSUBSCRIPT ( ⋅ ) end_CELL start_CELL ⋯ end_CELL start_CELL italic_ϕ start_POSTSUBSCRIPT italic_l , 2 , italic_n start_POSTSUBSCRIPT italic_l end_POSTSUBSCRIPT end_POSTSUBSCRIPT ( ⋅ ) end_CELL end_ROW start_ROW start_CELL ⋮ end_CELL start_CELL ⋮ end_CELL start_CELL end_CELL start_CELL ⋮ end_CELL end_ROW start_ROW start_CELL italic_ϕ start_POSTSUBSCRIPT italic_l , italic_n start_POSTSUBSCRIPT italic_l + 1 end_POSTSUBSCRIPT , 1 end_POSTSUBSCRIPT ( ⋅ ) end_CELL start_CELL italic_ϕ start_POSTSUBSCRIPT italic_l , italic_n start_POSTSUBSCRIPT italic_l + 1 end_POSTSUBSCRIPT , 2 end_POSTSUBSCRIPT ( ⋅ ) end_CELL start_CELL ⋯ end_CELL start_CELL italic_ϕ start_POSTSUBSCRIPT italic_l , italic_n start_POSTSUBSCRIPT italic_l + 1 end_POSTSUBSCRIPT , italic_n start_POSTSUBSCRIPT italic_l end_POSTSUBSCRIPT end_POSTSUBSCRIPT ( ⋅ ) end_CELL end_ROW end_ARG ) end_ARG start_POSTSUBSCRIPT bold_Φ start_POSTSUBSCRIPT italic_l end_POSTSUBSCRIPT end_POSTSUBSCRIPT bold_x start_POSTSUBSCRIPT italic_l end_POSTSUBSCRIPT ,




(2.6)






where 
𝚽
l
subscript
𝚽
𝑙
{\mathbf{\Phi}}_{l}
bold_Φ start_POSTSUBSCRIPT italic_l end_POSTSUBSCRIPT
 is the function matrix corresponding to the 
l
th
superscript
𝑙
th
l^{\rm th}
italic_l start_POSTSUPERSCRIPT roman_th end_POSTSUPERSCRIPT
 KAN layer. A general KAN network is a composition of 
L
𝐿
L
italic_L
 layers: given an input vector 
𝐱
0
∈
ℝ
n
0
subscript
𝐱
0
superscript
ℝ
subscript
𝑛
0
\mathbf{x}_{0}\in\mathbb{R}^{n_{0}}
bold_x start_POSTSUBSCRIPT 0 end_POSTSUBSCRIPT ∈ blackboard_R start_POSTSUPERSCRIPT italic_n start_POSTSUBSCRIPT 0 end_POSTSUBSCRIPT end_POSTSUPERSCRIPT
, the output of KAN is








KAN
⁢
(
𝐱
)
=
(
𝚽
L
−
1
∘
𝚽
L
−
2
∘
⋯
∘
𝚽
1
∘
𝚽
0
)
⁢
𝐱
.
KAN
𝐱
subscript
𝚽
𝐿
1
subscript
𝚽
𝐿
2
⋯
subscript
𝚽
1
subscript
𝚽
0
𝐱
{\rm KAN}(\mathbf{x})=(\mathbf{\Phi}_{L-1}\circ\mathbf{\Phi}_{L-2}\circ\cdots%
\circ\mathbf{\Phi}_{1}\circ\mathbf{\Phi}_{0})\mathbf{x}.
roman_KAN ( bold_x ) = ( bold_Φ start_POSTSUBSCRIPT italic_L - 1 end_POSTSUBSCRIPT ∘ bold_Φ start_POSTSUBSCRIPT italic_L - 2 end_POSTSUBSCRIPT ∘ ⋯ ∘ bold_Φ start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT ∘ bold_Φ start_POSTSUBSCRIPT 0 end_POSTSUBSCRIPT ) bold_x .




(2.7)






We can also rewrite the above equation to make it more analogous to Eq. (
2.1
), assuming output dimension 
n
L
=
1
subscript
𝑛
𝐿
1
n_{L}=1
italic_n start_POSTSUBSCRIPT italic_L end_POSTSUBSCRIPT = 1
, and define 
f
⁢
(
𝐱
)
≡
KAN
⁢
(
𝐱
)
𝑓
𝐱
KAN
𝐱
f(\mathbf{x})\equiv{\rm KAN}(\mathbf{x})
italic_f ( bold_x ) ≡ roman_KAN ( bold_x )
:








f
⁢
(
𝐱
)
=
∑
i
L
−
1
=
1
n
L
−
1
ϕ
L
−
1
,
i
L
,
i
L
−
1
⁢
(
∑
i
L
−
2
=
1
n
L
−
2
⋯
⁢
(
∑
i
2
=
1
n
2
ϕ
2
,
i
3
,
i
2
⁢
(
∑
i
1
=
1
n
1
ϕ
1
,
i
2
,
i
1
⁢
(
∑
i
0
=
1
n
0
ϕ
0
,
i
1
,
i
0
⁢
(
x
i
0
)
)
)
)
⁢
⋯
)
,
𝑓
𝐱
superscript
subscript
subscript
𝑖
𝐿
1
1
subscript
𝑛
𝐿
1
subscript
italic-ϕ
𝐿
1
subscript
𝑖
𝐿
subscript
𝑖
𝐿
1
superscript
subscript
subscript
𝑖
𝐿
2
1
subscript
𝑛
𝐿
2
⋯
superscript
subscript
subscript
𝑖
2
1
subscript
𝑛
2
subscript
italic-ϕ
2
subscript
𝑖
3
subscript
𝑖
2
superscript
subscript
subscript
𝑖
1
1
subscript
𝑛
1
subscript
italic-ϕ
1
subscript
𝑖
2
subscript
𝑖
1
superscript
subscript
subscript
𝑖
0
1
subscript
𝑛
0
subscript
italic-ϕ
0
subscript
𝑖
1
subscript
𝑖
0
subscript
𝑥
subscript
𝑖
0
⋯
f(\mathbf{x})=\sum_{i_{L-1}=1}^{n_{L-1}}\phi_{L-1,i_{L},i_{L-1}}\left(\sum_{i_%
{L-2}=1}^{n_{L-2}}\cdots\left(\sum_{i_{2}=1}^{n_{2}}\phi_{2,i_{3},i_{2}}\left(%
\sum_{i_{1}=1}^{n_{1}}\phi_{1,i_{2},i_{1}}\left(\sum_{i_{0}=1}^{n_{0}}\phi_{0,%
i_{1},i_{0}}(x_{i_{0}})\right)\right)\right)\cdots\right),
italic_f ( bold_x ) = ∑ start_POSTSUBSCRIPT italic_i start_POSTSUBSCRIPT italic_L - 1 end_POSTSUBSCRIPT = 1 end_POSTSUBSCRIPT start_POSTSUPERSCRIPT italic_n start_POSTSUBSCRIPT italic_L - 1 end_POSTSUBSCRIPT end_POSTSUPERSCRIPT italic_ϕ start_POSTSUBSCRIPT italic_L - 1 , italic_i start_POSTSUBSCRIPT italic_L end_POSTSUBSCRIPT , italic_i start_POSTSUBSCRIPT italic_L - 1 end_POSTSUBSCRIPT end_POSTSUBSCRIPT ( ∑ start_POSTSUBSCRIPT italic_i start_POSTSUBSCRIPT italic_L - 2 end_POSTSUBSCRIPT = 1 end_POSTSUBSCRIPT start_POSTSUPERSCRIPT italic_n start_POSTSUBSCRIPT italic_L - 2 end_POSTSUBSCRIPT end_POSTSUPERSCRIPT ⋯ ( ∑ start_POSTSUBSCRIPT italic_i start_POSTSUBSCRIPT 2 end_POSTSUBSCRIPT = 1 end_POSTSUBSCRIPT start_POSTSUPERSCRIPT italic_n start_POSTSUBSCRIPT 2 end_POSTSUBSCRIPT end_POSTSUPERSCRIPT italic_ϕ start_POSTSUBSCRIPT 2 , italic_i start_POSTSUBSCRIPT 3 end_POSTSUBSCRIPT , italic_i start_POSTSUBSCRIPT 2 end_POSTSUBSCRIPT end_POSTSUBSCRIPT ( ∑ start_POSTSUBSCRIPT italic_i start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT = 1 end_POSTSUBSCRIPT start_POSTSUPERSCRIPT italic_n start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT end_POSTSUPERSCRIPT italic_ϕ start_POSTSUBSCRIPT 1 , italic_i start_POSTSUBSCRIPT 2 end_POSTSUBSCRIPT , italic_i start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT end_POSTSUBSCRIPT ( ∑ start_POSTSUBSCRIPT italic_i start_POSTSUBSCRIPT 0 end_POSTSUBSCRIPT = 1 end_POSTSUBSCRIPT start_POSTSUPERSCRIPT italic_n start_POSTSUBSCRIPT 0 end_POSTSUBSCRIPT end_POSTSUPERSCRIPT italic_ϕ start_POSTSUBSCRIPT 0 , italic_i start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT , italic_i start_POSTSUBSCRIPT 0 end_POSTSUBSCRIPT end_POSTSUBSCRIPT ( italic_x start_POSTSUBSCRIPT italic_i start_POSTSUBSCRIPT 0 end_POSTSUBSCRIPT end_POSTSUBSCRIPT ) ) ) ) ⋯ ) ,




(2.8)






which is quite cumbersome. In contrast, our abstraction of KAN layers and their visualizations are cleaner and intuitive. The original Kolmogorov-Arnold representation Eq. (
2.1
) corresponds to a 2-Layer KAN with shape 
[
n
,
2
⁢
n
+
1
,
1
]
𝑛
2
𝑛
1
1
[n,2n+1,1]
[ italic_n , 2 italic_n + 1 , 1 ]
. Notice that all the operations are differentiable, so we can train KANs with back propagation. For comparison, an MLP can be written as interleaving of affine transformations 
𝐖
𝐖
\mathbf{W}
bold_W
 and non-linearities 
σ
𝜎
\sigma
italic_σ
:








MLP
⁢
(
𝐱
)
=
(
𝐖
L
−
1
∘
σ
∘
𝐖
L
−
2
∘
σ
∘
⋯
∘
𝐖
1
∘
σ
∘
𝐖
0
)
⁢
𝐱
.
MLP
𝐱
subscript
𝐖
𝐿
1
𝜎
subscript
𝐖
𝐿
2
𝜎
⋯
subscript
𝐖
1
𝜎
subscript
𝐖
0
𝐱
{\rm MLP}(\mathbf{x})=(\mathbf{W}_{L-1}\circ\sigma\circ\mathbf{W}_{L-2}\circ%
\sigma\circ\cdots\circ\mathbf{W}_{1}\circ\sigma\circ\mathbf{W}_{0})\mathbf{x}.
roman_MLP ( bold_x ) = ( bold_W start_POSTSUBSCRIPT italic_L - 1 end_POSTSUBSCRIPT ∘ italic_σ ∘ bold_W start_POSTSUBSCRIPT italic_L - 2 end_POSTSUBSCRIPT ∘ italic_σ ∘ ⋯ ∘ bold_W start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT ∘ italic_σ ∘ bold_W start_POSTSUBSCRIPT 0 end_POSTSUBSCRIPT ) bold_x .




(2.9)






It is clear that MLPs treat linear transformations and nonlinearities separately as 
𝐖
𝐖
\mathbf{W}
bold_W
 and 
σ
𝜎
\sigma
italic_σ
, while KANs treat them all together in 
𝚽
𝚽
\mathbf{\Phi}
bold_Φ
. In Figure 
0.1
 (c) and (d), we visualize a three-layer MLP and a three-layer KAN, to clarify their differences.






Implementation details.

Although a KAN layer Eq. (
2.5
) looks extremely simple, it is non-trivial to make it well optimizable. The key tricks are:






(1)




Residual activation functions. We include a basis function 
b
⁢
(
x
)
𝑏
𝑥
b(x)
italic_b ( italic_x )
 (similar to residual connections) such that the activation function 
ϕ
⁢
(
x
)
italic-ϕ
𝑥
\phi(x)
italic_ϕ ( italic_x )
 is the sum of the basis function 
b
⁢
(
x
)
𝑏
𝑥
b(x)
italic_b ( italic_x )
 and the spline function:








ϕ
⁢
(
x
)
=
w
⁢
(
b
⁢
(
x
)
+
spline
⁢
(
x
)
)
.
italic-ϕ
𝑥
𝑤
𝑏
𝑥
spline
𝑥
\displaystyle\phi(x)=w\left(b(x)+{\rm spline}(x)\right).
italic_ϕ ( italic_x ) = italic_w ( italic_b ( italic_x ) + roman_spline ( italic_x ) ) .




(2.10)






We set








b
⁢
(
x
)
=
silu
⁢
(
x
)
=
x
/
(
1
+
e
−
x
)
𝑏
𝑥
silu
𝑥
𝑥
1
superscript
𝑒
𝑥
\displaystyle b(x)={\rm silu}(x)=x/(1+e^{-x})
italic_b ( italic_x ) = roman_silu ( italic_x ) = italic_x / ( 1 + italic_e start_POSTSUPERSCRIPT - italic_x end_POSTSUPERSCRIPT )




(2.11)






in most cases. 
spline
⁢
(
x
)
spline
𝑥
{\rm spline}(x)
roman_spline ( italic_x )
 is parametrized as a linear combination of B-splines such that








spline
⁢
(
x
)
=
∑
i
c
i
⁢
B
i
⁢
(
x
)
spline
𝑥
subscript
𝑖
subscript
𝑐
𝑖
subscript
𝐵
𝑖
𝑥
\displaystyle{\rm spline}(x)=\sum_{i}c_{i}B_{i}(x)
roman_spline ( italic_x ) = ∑ start_POSTSUBSCRIPT italic_i end_POSTSUBSCRIPT italic_c start_POSTSUBSCRIPT italic_i end_POSTSUBSCRIPT italic_B start_POSTSUBSCRIPT italic_i end_POSTSUBSCRIPT ( italic_x )




(2.12)






where 
c
i
subscript
𝑐
𝑖
c_{i}
italic_c start_POSTSUBSCRIPT italic_i end_POSTSUBSCRIPT
s are trainable. In principle 
w
𝑤
w
italic_w
 is redundant since it can be absorbed into 
b
⁢
(
x
)
𝑏
𝑥
b(x)
italic_b ( italic_x )
 and 
spline
⁢
(
x
)
spline
𝑥
{\rm spline}(x)
roman_spline ( italic_x )
. However, we still include this 
w
𝑤
w
italic_w
 factor to better control the overall magnitude of the activation function.








(2)




Initialization scales. Each activation function is initialized to have 
spline
⁢
(
x
)
≈
0
spline
𝑥
0
{\rm spline}(x)\approx 0
roman_spline ( italic_x ) ≈ 0
 
1
1
1
This is done by drawing B-spline coefficients 
c
i
∼
𝒩
⁢
(
0
,
σ
2
)
similar-to
subscript
𝑐
𝑖
𝒩
0
superscript
𝜎
2
c_{i}\sim\mathcal{N}(0,\sigma^{2})
italic_c start_POSTSUBSCRIPT italic_i end_POSTSUBSCRIPT ∼ caligraphic_N ( 0 , italic_σ start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT )
 with a small 
σ
𝜎
\sigma
italic_σ
, typically we set 
σ
=
0.1
𝜎
0.1
\sigma=0.1
italic_σ = 0.1
.
. 
w
𝑤
w
italic_w
 is initialized according to the Xavier initialization, which has been used to initialize linear layers in MLPs.








(3)




Update of spline grids. We update each grid on the fly according to its input activations, to address the issue that splines are defined on bounded regions but activation values can evolve out of the fixed region during training 
2
2
2
Other possibilities are: (a) the grid is learnable with gradient descent, e.g., 
[
16
]
; (b) use normalization such that the input range is fixed. We tried (b) at first but its performance is inferior to our current approach.
.












Parameter count.
 For simplicity, let us assume a network






(1)




of depth 
L
𝐿
L
italic_L
,








(2)




with layers of equal width 
n
0
=
n
1
=
⋯
=
n
L
=
N
subscript
𝑛
0
subscript
𝑛
1
⋯
subscript
𝑛
𝐿
𝑁
n_{0}=n_{1}=\cdots=n_{L}=N
italic_n start_POSTSUBSCRIPT 0 end_POSTSUBSCRIPT = italic_n start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT = ⋯ = italic_n start_POSTSUBSCRIPT italic_L end_POSTSUBSCRIPT = italic_N
,








(3)




with each spline of order 
k
𝑘
k
italic_k
 (usually 
k
=
3
𝑘
3
k=3
italic_k = 3
) on 
G
𝐺
G
italic_G
 intervals (for 
G
+
1
𝐺
1
G+1
italic_G + 1
 grid points).








Then there are in total 
O
⁢
(
N
2
⁢
L
⁢
(
G
+
k
)
)
∼
O
⁢
(
N
2
⁢
L
⁢
G
)
similar-to
𝑂
superscript
𝑁
2
𝐿
𝐺
𝑘
𝑂
superscript
𝑁
2
𝐿
𝐺
O(N^{2}L(G+k))\sim O(N^{2}LG)
italic_O ( italic_N start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT italic_L ( italic_G + italic_k ) ) ∼ italic_O ( italic_N start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT italic_L italic_G )
 parameters. In contrast, an MLP with depth 
L
𝐿
L
italic_L
 and width 
N
𝑁
N
italic_N
 only needs 
O
⁢
(
N
2
⁢
L
)
𝑂
superscript
𝑁
2
𝐿
O(N^{2}L)
italic_O ( italic_N start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT italic_L )
 parameters, which appears to be more efficient than KAN. Fortunately, KANs usually require much smaller 
N
𝑁
N
italic_N
 than MLPs, which not only saves parameters, but also achieves better generalization (see e.g., Figure 
3.1
 and 
3.3
) and facilitates interpretability. We characterize the generalization behavior of KANs with a theorem below.










2.3 
KAN’s Approximation Abilities and Scaling Laws








Paper


Idea


Scaling exponent 
α
𝛼
\alpha
italic_α








Sharma & Kaplan 
[
17
]




Intrinsic dimensionality


(
k
+
1
)
/
d
𝑘
1
𝑑
(k+1)/d
( italic_k + 1 ) / italic_d






Michaud et al. 
[
18
]




maximum arity


(
k
+
1
)
/
2
𝑘
1
2
(k+1)/2
( italic_k + 1 ) / 2






Poggio et al. 
[
14
]




compositional sparsity


m
/
2
𝑚
2
m/2
italic_m / 2






Ours


K-A representation


k
+
1
𝑘
1
k+1
italic_k + 1






Table 1: 
Scaling exponents from different theories 
ℓ
∝
N
−
α
proportional-to
ℓ
superscript
𝑁
𝛼
\ell\propto N^{-\alpha}
roman_ℓ ∝ italic_N start_POSTSUPERSCRIPT - italic_α end_POSTSUPERSCRIPT
. 
ℓ
ℓ
\ell
roman_ℓ
: test RMSE loss, 
N
𝑁
N
italic_N
: number of model parameters, 
d
𝑑
d
italic_d
: input intrinsic dimension, 
k
𝑘
k
italic_k
: order of piecewise polynomial, 
m
𝑚
m
italic_m
: derivative order as in function class 
W
m
subscript
𝑊
𝑚
W_{m}
italic_W start_POSTSUBSCRIPT italic_m end_POSTSUBSCRIPT
.






Recall that in Eq. (
2.1
), the 2-Layer width-
(
2
⁢
n
+
1
)
2
𝑛
1
(2n+1)
( 2 italic_n + 1 )
 representation may be non-smooth. However, deeper representations may bring the advantages of smoother activations. For example, the 4-variable function








f
⁢
(
x
1
,
x
2
,
x
3
,
x
4
)
=
exp
⁡
(
sin
⁡
(
x
1
2
+
x
2
2
)
+
sin
⁡
(
x
3
2
+
x
4
2
)
)
𝑓
subscript
𝑥
1
subscript
𝑥
2
subscript
𝑥
3
subscript
𝑥
4
superscript
subscript
𝑥
1
2
superscript
subscript
𝑥
2
2
superscript
subscript
𝑥
3
2
superscript
subscript
𝑥
4
2
\displaystyle f(x_{1},x_{2},x_{3},x_{4})=\exp\left({\sin}(x_{1}^{2}+x_{2}^{2})%
+{\sin}(x_{3}^{2}+x_{4}^{2})\right)
italic_f ( italic_x start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT , italic_x start_POSTSUBSCRIPT 2 end_POSTSUBSCRIPT , italic_x start_POSTSUBSCRIPT 3 end_POSTSUBSCRIPT , italic_x start_POSTSUBSCRIPT 4 end_POSTSUBSCRIPT ) = roman_exp ( roman_sin ( italic_x start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT + italic_x start_POSTSUBSCRIPT 2 end_POSTSUBSCRIPT start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT ) + roman_sin ( italic_x start_POSTSUBSCRIPT 3 end_POSTSUBSCRIPT start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT + italic_x start_POSTSUBSCRIPT 4 end_POSTSUBSCRIPT start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT ) )




(2.13)






can be smoothly represented by a 
[
4
,
2
,
1
,
1
]
4
2
1
1
[4,2,1,1]
[ 4 , 2 , 1 , 1 ]
 KAN which is 3-Layer, but may not admit a 2-Layer KAN with smooth activations. To facilitate an approximation analysis, we still assume smoothness of activations, but allow the representations to be arbitrarily wide and deep, as in Eq. (
2.7
).
To emphasize the dependence of our KAN on the finite set of grid points, we use 
𝚽
l
G
superscript
subscript
𝚽
𝑙
𝐺
\mathbf{\Phi}_{l}^{G}
bold_Φ start_POSTSUBSCRIPT italic_l end_POSTSUBSCRIPT start_POSTSUPERSCRIPT italic_G end_POSTSUPERSCRIPT
 and 
Φ
l
,
i
,
j
G
superscript
subscript
Φ
𝑙
𝑖
𝑗
𝐺
\Phi_{l,i,j}^{G}
roman_Φ start_POSTSUBSCRIPT italic_l , italic_i , italic_j end_POSTSUBSCRIPT start_POSTSUPERSCRIPT italic_G end_POSTSUPERSCRIPT
 below to replace the notation 
𝚽
l
subscript
𝚽
𝑙
\mathbf{\Phi}_{l}
bold_Φ start_POSTSUBSCRIPT italic_l end_POSTSUBSCRIPT
 and 
Φ
l
,
i
,
j
subscript
Φ
𝑙
𝑖
𝑗
\Phi_{l,i,j}
roman_Φ start_POSTSUBSCRIPT italic_l , italic_i , italic_j end_POSTSUBSCRIPT
 used in Eq. (
2.5
) and (
2.6
).








Theorem 2.1
 
(Approximation theory, KAT)
.






Let 
𝐱
=
(
x
1
,
x
2
,
⋯
,
x
n
)
𝐱
subscript
𝑥
1
subscript
𝑥
2
⋯
subscript
𝑥
𝑛
\mathbf{x}=(x_{1},x_{2},\cdots,x_{n})
bold_x = ( italic_x start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT , italic_x start_POSTSUBSCRIPT 2 end_POSTSUBSCRIPT , ⋯ , italic_x start_POSTSUBSCRIPT italic_n end_POSTSUBSCRIPT )
.
Suppose that a function 
f
⁢
(
𝐱
)
𝑓
𝐱
f(\mathbf{x})
italic_f ( bold_x )
 admits a representation








f
=
(
𝚽
L
−
1
∘
𝚽
L
−
2
∘
⋯
∘
𝚽
1
∘
𝚽
0
)
⁢
𝐱
,
𝑓
subscript
𝚽
𝐿
1
subscript
𝚽
𝐿
2
⋯
subscript
𝚽
1
subscript
𝚽
0
𝐱
f=(\mathbf{\Phi}_{L-1}\circ\mathbf{\Phi}_{L-2}\circ\cdots\circ\mathbf{\Phi}_{1%
}\circ\mathbf{\Phi}_{0})\mathbf{x}\,,
italic_f = ( bold_Φ start_POSTSUBSCRIPT italic_L - 1 end_POSTSUBSCRIPT ∘ bold_Φ start_POSTSUBSCRIPT italic_L - 2 end_POSTSUBSCRIPT ∘ ⋯ ∘ bold_Φ start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT ∘ bold_Φ start_POSTSUBSCRIPT 0 end_POSTSUBSCRIPT ) bold_x ,




(2.14)






as in Eq. (
2.7
), where each one of the 
Φ
l
,
i
,
j
subscript
Φ
𝑙
𝑖
𝑗
\Phi_{l,i,j}
roman_Φ start_POSTSUBSCRIPT italic_l , italic_i , italic_j end_POSTSUBSCRIPT
 are 
(
k
+
1
)
𝑘
1
(k+1)
( italic_k + 1 )
-times continuously differentiable. Then there exists a constant 
C
𝐶
C
italic_C
 depending on 
f
𝑓
f
italic_f
 and its representation, such that we have the following approximation bound in terms of the grid size 
G
𝐺
G
italic_G
: there exist 
k
𝑘
k
italic_k
-th order B-spline functions 
Φ
l
,
i
,
j
G
superscript
subscript
Φ
𝑙
𝑖
𝑗
𝐺
\Phi_{l,i,j}^{G}
roman_Φ start_POSTSUBSCRIPT italic_l , italic_i , italic_j end_POSTSUBSCRIPT start_POSTSUPERSCRIPT italic_G end_POSTSUPERSCRIPT
 such that for any 
0
≤
m
≤
k
0
𝑚
𝑘
0\leq m\leq k
0 ≤ italic_m ≤ italic_k
, we have the bound








‖
f
−
(
𝚽
L
−
1
G
∘
𝚽
L
−
2
G
∘
⋯
∘
𝚽
1
G
∘
𝚽
0
G
)
⁢
𝐱
‖
C
m
≤
C
⁢
G
−
k
−
1
+
m
.
subscript
norm
𝑓
subscript
superscript
𝚽
𝐺
𝐿
1
subscript
superscript
𝚽
𝐺
𝐿
2
⋯
subscript
superscript
𝚽
𝐺
1
subscript
superscript
𝚽
𝐺
0
𝐱
superscript
𝐶
𝑚
𝐶
superscript
𝐺
𝑘
1
𝑚
\|f-(\mathbf{\Phi}^{G}_{L-1}\circ\mathbf{\Phi}^{G}_{L-2}\circ\cdots\circ%
\mathbf{\Phi}^{G}_{1}\circ\mathbf{\Phi}^{G}_{0})\mathbf{x}\|_{C^{m}}\leq CG^{-%
k-1+m}\,.
∥ italic_f - ( bold_Φ start_POSTSUPERSCRIPT italic_G end_POSTSUPERSCRIPT start_POSTSUBSCRIPT italic_L - 1 end_POSTSUBSCRIPT ∘ bold_Φ start_POSTSUPERSCRIPT italic_G end_POSTSUPERSCRIPT start_POSTSUBSCRIPT italic_L - 2 end_POSTSUBSCRIPT ∘ ⋯ ∘ bold_Φ start_POSTSUPERSCRIPT italic_G end_POSTSUPERSCRIPT start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT ∘ bold_Φ start_POSTSUPERSCRIPT italic_G end_POSTSUPERSCRIPT start_POSTSUBSCRIPT 0 end_POSTSUBSCRIPT ) bold_x ∥ start_POSTSUBSCRIPT italic_C start_POSTSUPERSCRIPT italic_m end_POSTSUPERSCRIPT end_POSTSUBSCRIPT ≤ italic_C italic_G start_POSTSUPERSCRIPT - italic_k - 1 + italic_m end_POSTSUPERSCRIPT .




(2.15)






Here we adopt the notation of 
C
m
superscript
𝐶
𝑚
C^{m}
italic_C start_POSTSUPERSCRIPT italic_m end_POSTSUPERSCRIPT
-norm measuring the magnitude of derivatives up to order 
m
𝑚
m
italic_m
:








‖
g
‖
C
m
=
max
|
β
|
≤
m
⁢
sup
x
∈
[
0
,
1
]
n
|
D
β
⁢
g
⁢
(
x
)
|
.
subscript
norm
𝑔
superscript
𝐶
𝑚
subscript
𝛽
𝑚
subscript
supremum
𝑥
superscript
0
1
𝑛
superscript
𝐷
𝛽
𝑔
𝑥
\|g\|_{C^{m}}=\max_{|\beta|\leq m}\sup_{x\in[0,1]^{n}}\left|D^{\beta}g(x)%
\right|.
∥ italic_g ∥ start_POSTSUBSCRIPT italic_C start_POSTSUPERSCRIPT italic_m end_POSTSUPERSCRIPT end_POSTSUBSCRIPT = roman_max start_POSTSUBSCRIPT | italic_β | ≤ italic_m end_POSTSUBSCRIPT roman_sup start_POSTSUBSCRIPT italic_x ∈ [ 0 , 1 ] start_POSTSUPERSCRIPT italic_n end_POSTSUPERSCRIPT end_POSTSUBSCRIPT | italic_D start_POSTSUPERSCRIPT italic_β end_POSTSUPERSCRIPT italic_g ( italic_x ) | .














Proof.




By the classical 1D B-spline theory 
[
19
]
 and the fact that 
Φ
l
,
i
,
j
subscript
Φ
𝑙
𝑖
𝑗
\Phi_{l,i,j}
roman_Φ start_POSTSUBSCRIPT italic_l , italic_i , italic_j end_POSTSUBSCRIPT
 as continuous functions can be uniformly bounded on a bounded domain, we know that there exist finite-grid B-spline functions 
Φ
l
,
i
,
j
G
superscript
subscript
Φ
𝑙
𝑖
𝑗
𝐺
\Phi_{l,i,j}^{G}
roman_Φ start_POSTSUBSCRIPT italic_l , italic_i , italic_j end_POSTSUBSCRIPT start_POSTSUPERSCRIPT italic_G end_POSTSUPERSCRIPT
 such that for any 
0
≤
m
≤
k
0
𝑚
𝑘
0\leq m\leq k
0 ≤ italic_m ≤ italic_k
,








‖
(
Φ
l
,
i
,
j
∘
𝚽
l
−
1
∘
𝚽
l
−
2
∘
⋯
∘
𝚽
1
∘
𝚽
0
)
⁢
𝐱
−
(
Φ
l
,
i
,
j
G
∘
𝚽
l
−
1
∘
𝚽
l
−
2
∘
⋯
∘
𝚽
1
∘
𝚽
0
)
⁢
𝐱
‖
C
m
≤
C
⁢
G
−
k
−
1
+
m
,
subscript
norm
subscript
Φ
𝑙
𝑖
𝑗
subscript
𝚽
𝑙
1
subscript
𝚽
𝑙
2
⋯
subscript
𝚽
1
subscript
𝚽
0
𝐱
superscript
subscript
Φ
𝑙
𝑖
𝑗
𝐺
subscript
𝚽
𝑙
1
subscript
𝚽
𝑙
2
⋯
subscript
𝚽
1
subscript
𝚽
0
𝐱
superscript
𝐶
𝑚
𝐶
superscript
𝐺
𝑘
1
𝑚
\|(\Phi_{l,i,j}\circ\mathbf{\Phi}_{l-1}\circ\mathbf{\Phi}_{l-2}\circ\cdots%
\circ\mathbf{\Phi}_{1}\circ\mathbf{\Phi}_{0})\mathbf{x}-(\Phi_{l,i,j}^{G}\circ%
\mathbf{\Phi}_{l-1}\circ\mathbf{\Phi}_{l-2}\circ\cdots\circ\mathbf{\Phi}_{1}%
\circ\mathbf{\Phi}_{0})\mathbf{x}\|_{C^{m}}\leq CG^{-k-1+m}\,,
∥ ( roman_Φ start_POSTSUBSCRIPT italic_l , italic_i , italic_j end_POSTSUBSCRIPT ∘ bold_Φ start_POSTSUBSCRIPT italic_l - 1 end_POSTSUBSCRIPT ∘ bold_Φ start_POSTSUBSCRIPT italic_l - 2 end_POSTSUBSCRIPT ∘ ⋯ ∘ bold_Φ start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT ∘ bold_Φ start_POSTSUBSCRIPT 0 end_POSTSUBSCRIPT ) bold_x - ( roman_Φ start_POSTSUBSCRIPT italic_l , italic_i , italic_j end_POSTSUBSCRIPT start_POSTSUPERSCRIPT italic_G end_POSTSUPERSCRIPT ∘ bold_Φ start_POSTSUBSCRIPT italic_l - 1 end_POSTSUBSCRIPT ∘ bold_Φ start_POSTSUBSCRIPT italic_l - 2 end_POSTSUBSCRIPT ∘ ⋯ ∘ bold_Φ start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT ∘ bold_Φ start_POSTSUBSCRIPT 0 end_POSTSUBSCRIPT ) bold_x ∥ start_POSTSUBSCRIPT italic_C start_POSTSUPERSCRIPT italic_m end_POSTSUPERSCRIPT end_POSTSUBSCRIPT ≤ italic_C italic_G start_POSTSUPERSCRIPT - italic_k - 1 + italic_m end_POSTSUPERSCRIPT ,








with a constant 
C
𝐶
C
italic_C
 independent of 
G
𝐺
G
italic_G
. We fix those B-spline approximations. Therefore we have that the residue 
R
l
subscript
𝑅
𝑙
R_{l}
italic_R start_POSTSUBSCRIPT italic_l end_POSTSUBSCRIPT
 defined via








R
l
≔
(
𝚽
L
−
1
G
∘
⋯
∘
𝚽
l
+
1
G
∘
𝚽
l
∘
𝚽
l
−
1
∘
⋯
∘
𝚽
0
)
⁢
𝐱
−
(
𝚽
L
−
1
G
∘
⋯
∘
𝚽
l
+
1
G
∘
𝚽
l
G
∘
𝚽
l
−
1
∘
⋯
∘
𝚽
0
)
⁢
𝐱
≔
subscript
𝑅
𝑙
subscript
superscript
𝚽
𝐺
𝐿
1
⋯
subscript
superscript
𝚽
𝐺
𝑙
1
subscript
𝚽
𝑙
subscript
𝚽
𝑙
1
⋯
subscript
𝚽
0
𝐱
superscript
subscript
𝚽
𝐿
1
𝐺
⋯
superscript
subscript
𝚽
𝑙
1
𝐺
superscript
subscript
𝚽
𝑙
𝐺
subscript
𝚽
𝑙
1
⋯
subscript
𝚽
0
𝐱
R_{l}\coloneqq(\mathbf{\Phi}^{G}_{L-1}\circ\cdots\circ\mathbf{\Phi}^{G}_{l+1}%
\circ\mathbf{\Phi}_{l}\circ\mathbf{\Phi}_{l-1}\circ\cdots\circ\mathbf{\Phi}_{0%
})\mathbf{x}-(\mathbf{\Phi}_{L-1}^{G}\circ\cdots\circ\mathbf{\Phi}_{l+1}^{G}%
\circ\mathbf{\Phi}_{l}^{G}\circ\mathbf{\Phi}_{l-1}\circ\cdots\circ\mathbf{\Phi%
}_{0})\mathbf{x}
italic_R start_POSTSUBSCRIPT italic_l end_POSTSUBSCRIPT ≔ ( bold_Φ start_POSTSUPERSCRIPT italic_G end_POSTSUPERSCRIPT start_POSTSUBSCRIPT italic_L - 1 end_POSTSUBSCRIPT ∘ ⋯ ∘ bold_Φ start_POSTSUPERSCRIPT italic_G end_POSTSUPERSCRIPT start_POSTSUBSCRIPT italic_l + 1 end_POSTSUBSCRIPT ∘ bold_Φ start_POSTSUBSCRIPT italic_l end_POSTSUBSCRIPT ∘ bold_Φ start_POSTSUBSCRIPT italic_l - 1 end_POSTSUBSCRIPT ∘ ⋯ ∘ bold_Φ start_POSTSUBSCRIPT 0 end_POSTSUBSCRIPT ) bold_x - ( bold_Φ start_POSTSUBSCRIPT italic_L - 1 end_POSTSUBSCRIPT start_POSTSUPERSCRIPT italic_G end_POSTSUPERSCRIPT ∘ ⋯ ∘ bold_Φ start_POSTSUBSCRIPT italic_l + 1 end_POSTSUBSCRIPT start_POSTSUPERSCRIPT italic_G end_POSTSUPERSCRIPT ∘ bold_Φ start_POSTSUBSCRIPT italic_l end_POSTSUBSCRIPT start_POSTSUPERSCRIPT italic_G end_POSTSUPERSCRIPT ∘ bold_Φ start_POSTSUBSCRIPT italic_l - 1 end_POSTSUBSCRIPT ∘ ⋯ ∘ bold_Φ start_POSTSUBSCRIPT 0 end_POSTSUBSCRIPT ) bold_x








satisfies








‖
R
l
‖
C
m
≤
C
⁢
G
−
k
−
1
+
m
,
subscript
norm
subscript
𝑅
𝑙
superscript
𝐶
𝑚
𝐶
superscript
𝐺
𝑘
1
𝑚
\|R_{l}\|_{C^{m}}\leq CG^{-k-1+m}\,,
∥ italic_R start_POSTSUBSCRIPT italic_l end_POSTSUBSCRIPT ∥ start_POSTSUBSCRIPT italic_C start_POSTSUPERSCRIPT italic_m end_POSTSUPERSCRIPT end_POSTSUBSCRIPT ≤ italic_C italic_G start_POSTSUPERSCRIPT - italic_k - 1 + italic_m end_POSTSUPERSCRIPT ,








with a constant independent of 
G
𝐺
G
italic_G
. Finally notice that








f
−
(
𝚽
L
−
1
G
∘
𝚽
L
−
2
G
∘
⋯
∘
𝚽
1
G
∘
𝚽
0
G
)
⁢
𝐱
=
R
L
−
1
+
R
L
−
2
+
⋯
+
R
1
+
R
0
,
𝑓
subscript
superscript
𝚽
𝐺
𝐿
1
subscript
superscript
𝚽
𝐺
𝐿
2
⋯
subscript
superscript
𝚽
𝐺
1
subscript
superscript
𝚽
𝐺
0
𝐱
subscript
𝑅
𝐿
1
subscript
𝑅
𝐿
2
⋯
subscript
𝑅
1
subscript
𝑅
0
f-(\mathbf{\Phi}^{G}_{L-1}\circ\mathbf{\Phi}^{G}_{L-2}\circ\cdots\circ\mathbf{%
\Phi}^{G}_{1}\circ\mathbf{\Phi}^{G}_{0})\mathbf{x}=R_{L-1}+R_{L-2}+\cdots+R_{1%
}+R_{0}\,,
italic_f - ( bold_Φ start_POSTSUPERSCRIPT italic_G end_POSTSUPERSCRIPT start_POSTSUBSCRIPT italic_L - 1 end_POSTSUBSCRIPT ∘ bold_Φ start_POSTSUPERSCRIPT italic_G end_POSTSUPERSCRIPT start_POSTSUBSCRIPT italic_L - 2 end_POSTSUBSCRIPT ∘ ⋯ ∘ bold_Φ start_POSTSUPERSCRIPT italic_G end_POSTSUPERSCRIPT start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT ∘ bold_Φ start_POSTSUPERSCRIPT italic_G end_POSTSUPERSCRIPT start_POSTSUBSCRIPT 0 end_POSTSUBSCRIPT ) bold_x = italic_R start_POSTSUBSCRIPT italic_L - 1 end_POSTSUBSCRIPT + italic_R start_POSTSUBSCRIPT italic_L - 2 end_POSTSUBSCRIPT + ⋯ + italic_R start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT + italic_R start_POSTSUBSCRIPT 0 end_POSTSUBSCRIPT ,








we know that (
2.15
) holds.
∎








We know that asymptotically, provided that the assumption in Theorem 
2.1
 holds, KANs with finite grid size can approximate the function well with a residue rate 
independent of the dimension, hence beating curse of dimensionality!
 This comes naturally since we only use splines to approximate 1D functions. In particular, for 
m
=
0
𝑚
0
m=0
italic_m = 0
, we recover the accuracy in 
L
∞
superscript
𝐿
L^{\infty}
italic_L start_POSTSUPERSCRIPT ∞ end_POSTSUPERSCRIPT
 norm, which in turn provides a bound of RMSE on the finite domain, which gives a scaling exponent 
k
+
1
𝑘
1
k+1
italic_k + 1
. Of course, the constant 
C
𝐶
C
italic_C
 is dependent on the representation; hence it will depend on the dimension. We will leave the discussion of the dependence of the constant on the dimension as a future work.






We remark that although the Kolmogorov-Arnold theorem Eq. (
2.1
) corresponds to a KAN representation with shape 
[
d
,
2
⁢
d
+
1
,
1
]
𝑑
2
𝑑
1
1
[d,2d+1,1]
[ italic_d , 2 italic_d + 1 , 1 ]
, its functions are not necessarily smooth. On the other hand, if we are able to identify a smooth representation (maybe at the cost of extra layers or making the KAN wider than the theory prescribes), then Theorem 
2.1
 indicates that we can beat the curse of dimensionality (COD). This should not come as a surprise since we can inherently learn the structure of the function and make our finite-sample KAN approximation interpretable.






Neural scaling laws: comparison to other theories.
 Neural scaling laws are the phenomenon where test loss decreases with more model parameters, i.e., 
ℓ
∝
N
−
α
proportional-to
ℓ
superscript
𝑁
𝛼
\ell\propto N^{-\alpha}
roman_ℓ ∝ italic_N start_POSTSUPERSCRIPT - italic_α end_POSTSUPERSCRIPT
 where 
ℓ
ℓ
\ell
roman_ℓ
 is test RMSE, 
N
𝑁
N
italic_N
 is the number of parameters, and 
α
𝛼
\alpha
italic_α
 is the scaling exponent. A larger 
α
𝛼
\alpha
italic_α
 promises more improvement by simply scaling up the model. Different theories have been proposed to predict 
α
𝛼
\alpha
italic_α
. Sharma & Kaplan 
[
17
]
 suggest that 
α
𝛼
\alpha
italic_α
 comes from data fitting on an input manifold of intrinsic dimensionality 
d
𝑑
d
italic_d
. If the model function class is piecewise polynomials of order 
k
𝑘
k
italic_k
 (
k
=
1
𝑘
1
k=1
italic_k = 1
 for ReLU), then the standard approximation theory implies 
α
=
(
k
+
1
)
/
d
𝛼
𝑘
1
𝑑
\alpha=(k+1)/d
italic_α = ( italic_k + 1 ) / italic_d
 from the approximation theory. This bound suffers from the curse of dimensionality, so people have sought other bounds independent of 
d
𝑑
d
italic_d
 by leveraging compositional structures. In particular, Michaud et al. 
[
18
]
 considered computational graphs that only involve unary (e.g., squared, sine, exp) and binary (
+
+
+
 and 
×
\times
×
) operations, finding 
α
=
(
k
+
1
)
/
d
∗
=
(
k
+
1
)
/
2
𝛼
𝑘
1
superscript
𝑑
𝑘
1
2
\alpha=(k+1)/d^{*}=(k+1)/2
italic_α = ( italic_k + 1 ) / italic_d start_POSTSUPERSCRIPT ∗ end_POSTSUPERSCRIPT = ( italic_k + 1 ) / 2
, where 
d
∗
=
2
superscript
𝑑
2
d^{*}=2
italic_d start_POSTSUPERSCRIPT ∗ end_POSTSUPERSCRIPT = 2
 is the maximum arity. Poggio et al. 
[
14
]
 leveraged the idea of compositional sparsity and proved that given function class 
W
m
subscript
𝑊
𝑚
W_{m}
italic_W start_POSTSUBSCRIPT italic_m end_POSTSUBSCRIPT
 (function whose derivatives are continuous up to 
m
𝑚
m
italic_m
-th order), one needs 
N
=
O
⁢
(
ϵ
−
2
m
)
𝑁
𝑂
superscript
italic-ϵ
2
𝑚
N=O(\epsilon^{-\frac{2}{m}})
italic_N = italic_O ( italic_ϵ start_POSTSUPERSCRIPT - divide start_ARG 2 end_ARG start_ARG italic_m end_ARG end_POSTSUPERSCRIPT )
 number of parameters to achieve error 
ϵ
italic-ϵ
\epsilon
italic_ϵ
, which is equivalent to 
α
=
m
2
𝛼
𝑚
2
\alpha=\frac{m}{2}
italic_α = divide start_ARG italic_m end_ARG start_ARG 2 end_ARG
. Our approach, which assumes the existence of smooth Kolmogorov-Arnold representations, decomposes the high-dimensional function into several 1D functions, giving 
α
=
k
+
1
𝛼
𝑘
1
\alpha=k+1
italic_α = italic_k + 1
 (where 
k
𝑘
k
italic_k
 is the piecewise polynomial order of the splines). We choose 
k
=
3
𝑘
3
k=3
italic_k = 3
 cubic splines so 
α
=
4
𝛼
4
\alpha=4
italic_α = 4
 which is the largest and best scaling exponent compared to other works. We will show in Section 
3.1
 that this bound 
α
=
4
𝛼
4
\alpha=4
italic_α = 4
 can in fact be achieved empirically with KANs, while previous work 
[
18
]
 reported that MLPs have problems even saturating slower bounds (e.g., 
α
=
1
𝛼
1
\alpha=1
italic_α = 1
) and plateau quickly. Of course, we can increase 
k
𝑘
k
italic_k
 to match the smoothness of functions, but too high 
k
𝑘
k
italic_k
 might be too oscillatory, leading to optimization issues.






Comparison between KAT and UAT.

The power of fully-connected neural networks is justified by the universal approximation theorem (UAT), which states that given a function and error tolerance 
ϵ
>
0
italic-ϵ
0
\epsilon>0
italic_ϵ > 0
, a two-layer network with 
k
>
N
⁢
(
ϵ
)
𝑘
𝑁
italic-ϵ
k>N(\epsilon)
italic_k > italic_N ( italic_ϵ )
 neurons can approximate the function within error 
ϵ
italic-ϵ
\epsilon
italic_ϵ
. However, the UAT guarantees no bound for how 
N
⁢
(
ϵ
)
𝑁
italic-ϵ
N(\epsilon)
italic_N ( italic_ϵ )
 scales with 
ϵ
italic-ϵ
\epsilon
italic_ϵ
. Indeed, it suffers from the COD, and 
N
𝑁
N
italic_N
 has been shown to grow exponentially with 
d
𝑑
d
italic_d
 in some cases 
[
15
]
. The difference between KAT and UAT is a consequence that KANs take advantage of the intrinsically low-dimensional representation of the function while MLPs do not. Indeed, we will show that KANs are nicely aligned with symbolic functions while MLPs are not.










2.4 
For accuracy: Grid Extension




Figure 2.3: 
We can make KANs more accurate by grid extension (fine-graining spline grids). Top left (right): training dynamics of a 
[
2
,
5
,
1
]
2
5
1
[2,5,1]
[ 2 , 5 , 1 ]
 (
[
2
,
1
,
1
]
2
1
1
[2,1,1]
[ 2 , 1 , 1 ]
) KAN. Both models display staircases in their loss curves, i.e., loss suddently drops then plateaus after grid extension. Bottom left: test RMSE follows scaling laws against grid size 
G
𝐺
G
italic_G
. Bottom right: training time scales favorably with grid size 
G
𝐺
G
italic_G
.






In principle, a spline can be made arbitrarily accurate to a target function as the grid can be made arbitrarily fine-grained. This good feature is inherited by KANs. By contrast, MLPs do not have the notion of “fine-graining”. Admittedly, increasing the width and depth of MLPs can lead to improvement in performance (“neural scaling laws”). However, these neural scaling laws are slow (discussed in the last section). They are also expensive to obtain, because models of varying sizes are trained independently. By contrast, for KANs, one can first train a KAN with fewer parameters and then extend it to a KAN with more parameters by simply making its spline grids finer, without the need to retraining the larger model from scratch.






We next describe how to perform grid extension (illustrated in Figure 
2.2
 right), which is basically fitting a new fine-grained spline to an old coarse-grained spline. Suppose we want to approximate a 1D function 
f
𝑓
f
italic_f
 in a bounded region 
[
a
,
b
]
𝑎
𝑏
[a,b]
[ italic_a , italic_b ]
 with B-splines of order 
k
𝑘
k
italic_k
. A coarse-grained grid with 
G
1
subscript
𝐺
1
G_{1}
italic_G start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT
 intervals has grid points at 
{
t
0
=
a
,
t
1
,
t
2
,
⋯
,
t
G
1
=
b
}
formulae-sequence
subscript
𝑡
0
𝑎
subscript
𝑡
1
subscript
𝑡
2
⋯
subscript
𝑡
subscript
𝐺
1
𝑏
\{t_{0}=a,t_{1},t_{2},\cdots,t_{G_{1}}=b\}
{ italic_t start_POSTSUBSCRIPT 0 end_POSTSUBSCRIPT = italic_a , italic_t start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT , italic_t start_POSTSUBSCRIPT 2 end_POSTSUBSCRIPT , ⋯ , italic_t start_POSTSUBSCRIPT italic_G start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT end_POSTSUBSCRIPT = italic_b }
, which is augmented to 
{
t
−
k
,
⋯
,
t
−
1
,
t
0
,
⋯
,
t
G
1
,
t
G
1
+
1
,
⋯
,
t
G
1
+
k
}
subscript
𝑡
𝑘
⋯
subscript
𝑡
1
subscript
𝑡
0
⋯
subscript
𝑡
subscript
𝐺
1
subscript
𝑡
subscript
𝐺
1
1
⋯
subscript
𝑡
subscript
𝐺
1
𝑘
\{t_{-k},\cdots,t_{-1},t_{0},\cdots,t_{G_{1}},t_{G_{1}+1},\cdots,t_{G_{1}+k}\}
{ italic_t start_POSTSUBSCRIPT - italic_k end_POSTSUBSCRIPT , ⋯ , italic_t start_POSTSUBSCRIPT - 1 end_POSTSUBSCRIPT , italic_t start_POSTSUBSCRIPT 0 end_POSTSUBSCRIPT , ⋯ , italic_t start_POSTSUBSCRIPT italic_G start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT end_POSTSUBSCRIPT , italic_t start_POSTSUBSCRIPT italic_G start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT + 1 end_POSTSUBSCRIPT , ⋯ , italic_t start_POSTSUBSCRIPT italic_G start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT + italic_k end_POSTSUBSCRIPT }
. There are 
G
1
+
k
subscript
𝐺
1
𝑘
G_{1}+k
italic_G start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT + italic_k
 B-spline basis functions, with the 
i
th
superscript
𝑖
th
i^{\rm th}
italic_i start_POSTSUPERSCRIPT roman_th end_POSTSUPERSCRIPT
 B-spline 
B
i
⁢
(
x
)
subscript
𝐵
𝑖
𝑥
B_{i}(x)
italic_B start_POSTSUBSCRIPT italic_i end_POSTSUBSCRIPT ( italic_x )
 being non-zero only on 
[
t
−
k
+
i
,
t
i
+
1
]
subscript
𝑡
𝑘
𝑖
subscript
𝑡
𝑖
1
[t_{-k+i},t_{i+1}]
[ italic_t start_POSTSUBSCRIPT - italic_k + italic_i end_POSTSUBSCRIPT , italic_t start_POSTSUBSCRIPT italic_i + 1 end_POSTSUBSCRIPT ]
 
(
i
=
0
,
⋯
,
G
1
+
k
−
1
)
𝑖
0
⋯
subscript
𝐺
1
𝑘
1
(i=0,\cdots,G_{1}+k-1)
( italic_i = 0 , ⋯ , italic_G start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT + italic_k - 1 )
. Then 
f
𝑓
f
italic_f
 on the coarse grid is expressed in terms of linear combination of these B-splines basis functions 
f
coarse
⁢
(
x
)
=
∑
i
=
0
G
1
+
k
−
1
c
i
⁢
B
i
⁢
(
x
)
subscript
𝑓
coarse
𝑥
superscript
subscript
𝑖
0
subscript
𝐺
1
𝑘
1
subscript
𝑐
𝑖
subscript
𝐵
𝑖
𝑥
f_{\rm coarse}(x)=\sum_{i=0}^{G_{1}+k-1}c_{i}B_{i}(x)
italic_f start_POSTSUBSCRIPT roman_coarse end_POSTSUBSCRIPT ( italic_x ) = ∑ start_POSTSUBSCRIPT italic_i = 0 end_POSTSUBSCRIPT start_POSTSUPERSCRIPT italic_G start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT + italic_k - 1 end_POSTSUPERSCRIPT italic_c start_POSTSUBSCRIPT italic_i end_POSTSUBSCRIPT italic_B start_POSTSUBSCRIPT italic_i end_POSTSUBSCRIPT ( italic_x )
. Given a finer grid with 
G
2
subscript
𝐺
2
G_{2}
italic_G start_POSTSUBSCRIPT 2 end_POSTSUBSCRIPT
 intervals, 
f
𝑓
f
italic_f
 on the fine grid is correspondingly 
f
fine
⁢
(
x
)
=
∑
j
=
0
G
2
+
k
−
1
c
j
′
⁢
B
j
′
⁢
(
x
)
subscript
𝑓
fine
𝑥
superscript
subscript
𝑗
0
subscript
𝐺
2
𝑘
1
superscript
subscript
𝑐
𝑗
′
superscript
subscript
𝐵
𝑗
′
𝑥
f_{\rm fine}(x)=\sum_{j=0}^{G_{2}+k-1}c_{j}^{\prime}B_{j}^{\prime}(x)
italic_f start_POSTSUBSCRIPT roman_fine end_POSTSUBSCRIPT ( italic_x ) = ∑ start_POSTSUBSCRIPT italic_j = 0 end_POSTSUBSCRIPT start_POSTSUPERSCRIPT italic_G start_POSTSUBSCRIPT 2 end_POSTSUBSCRIPT + italic_k - 1 end_POSTSUPERSCRIPT italic_c start_POSTSUBSCRIPT italic_j end_POSTSUBSCRIPT start_POSTSUPERSCRIPT ′ end_POSTSUPERSCRIPT italic_B start_POSTSUBSCRIPT italic_j end_POSTSUBSCRIPT start_POSTSUPERSCRIPT ′ end_POSTSUPERSCRIPT ( italic_x )
. The parameters 
c
j
′
subscript
superscript
𝑐
′
𝑗
c^{\prime}_{j}
italic_c start_POSTSUPERSCRIPT ′ end_POSTSUPERSCRIPT start_POSTSUBSCRIPT italic_j end_POSTSUBSCRIPT
s can be initialized from the parameters 
c
i
subscript
𝑐
𝑖
c_{i}
italic_c start_POSTSUBSCRIPT italic_i end_POSTSUBSCRIPT
 by minimizing the distance between 
f
fine
⁢
(
x
)
subscript
𝑓
fine
𝑥
f_{\rm fine}(x)
italic_f start_POSTSUBSCRIPT roman_fine end_POSTSUBSCRIPT ( italic_x )
 to 
f
coarse
⁢
(
x
)
subscript
𝑓
coarse
𝑥
f_{\rm coarse}(x)
italic_f start_POSTSUBSCRIPT roman_coarse end_POSTSUBSCRIPT ( italic_x )
 (over some distribution of 
x
𝑥
x
italic_x
):








{
c
j
′
}
=
argmin
{
c
j
′
}
⁢
𝔼
x
∼
p
⁢
(
x
)
(
∑
j
=
0
G
2
+
k
−
1
c
j
′
⁢
B
j
′
⁢
(
x
)
−
∑
i
=
0
G
1
+
k
−
1
c
i
⁢
B
i
⁢
(
x
)
)
2
,
superscript
subscript
𝑐
𝑗
′
superscript
subscript
𝑐
𝑗
′
argmin
subscript
𝔼
similar-to
x
p
x
superscript
superscript
subscript
j
0
subscript
G
2
k
1
superscript
subscript
c
j
′
superscript
subscript
B
j
′
x
superscript
subscript
i
0
subscript
G
1
k
1
subscript
c
i
subscript
B
i
x
2
\{c_{j}^{\prime}\}=\underset{\{c_{j}^{\prime}\}}{\rm argmin}\ \mathop{\mathbb{%
E}}_{x\sim p(x)}\left(\sum_{j=0}^{G_{2}+k-1}c_{j}^{\prime}B_{j}^{\prime}(x)-%
\sum_{i=0}^{G_{1}+k-1}c_{i}B_{i}(x)\right)^{2},
{ italic_c start_POSTSUBSCRIPT italic_j end_POSTSUBSCRIPT start_POSTSUPERSCRIPT ′ end_POSTSUPERSCRIPT } = start_UNDERACCENT { italic_c start_POSTSUBSCRIPT italic_j end_POSTSUBSCRIPT start_POSTSUPERSCRIPT ′ end_POSTSUPERSCRIPT } end_UNDERACCENT start_ARG roman_argmin end_ARG blackboard_E start_POSTSUBSCRIPT roman_x ∼ roman_p ( roman_x ) end_POSTSUBSCRIPT ( ∑ start_POSTSUBSCRIPT roman_j = 0 end_POSTSUBSCRIPT start_POSTSUPERSCRIPT roman_G start_POSTSUBSCRIPT 2 end_POSTSUBSCRIPT + roman_k - 1 end_POSTSUPERSCRIPT roman_c start_POSTSUBSCRIPT roman_j end_POSTSUBSCRIPT start_POSTSUPERSCRIPT ′ end_POSTSUPERSCRIPT roman_B start_POSTSUBSCRIPT roman_j end_POSTSUBSCRIPT start_POSTSUPERSCRIPT ′ end_POSTSUPERSCRIPT ( roman_x ) - ∑ start_POSTSUBSCRIPT roman_i = 0 end_POSTSUBSCRIPT start_POSTSUPERSCRIPT roman_G start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT + roman_k - 1 end_POSTSUPERSCRIPT roman_c start_POSTSUBSCRIPT roman_i end_POSTSUBSCRIPT roman_B start_POSTSUBSCRIPT roman_i end_POSTSUBSCRIPT ( roman_x ) ) start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT ,




(2.16)






which can be implemented by the least squares algorithm. We perform grid extension for all splines in a KAN independently.






Toy example: staricase-like loss curves.
 We use a toy example 
f
⁢
(
x
,
y
)
=
exp
⁢
(
sin
⁢
(
π
⁢
x
)
+
y
2
)
𝑓
𝑥
𝑦
exp
sin
𝜋
𝑥
superscript
𝑦
2
f(x,y)={\rm exp}({\rm sin}(\pi x)+y^{2})
italic_f ( italic_x , italic_y ) = roman_exp ( roman_sin ( italic_π italic_x ) + italic_y start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT )
 to demonstrate the effect of grid extension. In Figure 
2.3
 (top left), we show the train and test RMSE for a 
[
2
,
5
,
1
]
2
5
1
[2,5,1]
[ 2 , 5 , 1 ]
 KAN. The number of grid points starts as 3, increases to a higher value every 200 LBFGS steps, ending up with 1000 grid points. It is clear that every time fine graining happens, the training loss drops faster than before (except for the finest grid with 1000 points, where optimization ceases to work probably due to bad loss landscapes). However, the test losses first go down then go up, displaying a U-shape, due to the bias-variance tradeoff (underfitting vs. overfitting). We conjecture that the optimal test loss is achieved at the interpolation threshold when the number of parameters match the number of data points. Since our training samples are 1000 and the total parameters of a 
[
2
,
5
,
1
]
2
5
1
[2,5,1]
[ 2 , 5 , 1 ]
 KAN is 
15
⁢
G
15
𝐺
15G
15 italic_G
 (
G
𝐺
G
italic_G
 is the number of grid intervals), we expect the interpolation threshold to be 
G
=
1000
/
15
≈
67
𝐺
1000
15
67
G=1000/15\approx 67
italic_G = 1000 / 15 ≈ 67
, which roughly agrees with our experimentally observed value 
G
∼
50
similar-to
𝐺
50
G\sim 50
italic_G ∼ 50
.






Small KANs generalize better.
 Is this the best test performance we can achieve? Notice that the synthetic task can be represented exactly by a 
[
2
,
1
,
1
]
2
1
1
[2,1,1]
[ 2 , 1 , 1 ]
 KAN, so we train a 
[
2
,
1
,
1
]
2
1
1
[2,1,1]
[ 2 , 1 , 1 ]
 KAN and present the training dynamics in Figure 
2.3
 top right. Interestingly, it can achieve even lower test losses than the 
[
2
,
5
,
1
]
2
5
1
[2,5,1]
[ 2 , 5 , 1 ]
 KAN, with clearer staircase structures and the interpolation threshold is delayed to a larger grid size as a result of fewer parameters. This highlights a subtlety of choosing KAN architectures. If we do not know the problem structure, how can we determine the minimal KAN shape? In Section 
2.5
, we will propose a method to auto-discover such minimal KAN architecture via regularization and pruning.






Scaling laws: comparison with theory.
 We are also interested in how the test loss decreases as the number of grid parameters increases. In Figure 
2.3
 (bottom left), a [2,1,1] KAN scales roughly as 
test
⁢
RMSE
∝
G
−
3
proportional-to
test
RMSE
superscript
𝐺
3
{\rm test\ RMSE}\propto G^{-3}
roman_test roman_RMSE ∝ italic_G start_POSTSUPERSCRIPT - 3 end_POSTSUPERSCRIPT
. However, according to the Theorem 
2.1
, we would expect 
test
⁢
RMSE
∝
G
−
4
proportional-to
test
RMSE
superscript
𝐺
4
{\rm test\ RMSE}\propto G^{-4}
roman_test roman_RMSE ∝ italic_G start_POSTSUPERSCRIPT - 4 end_POSTSUPERSCRIPT
. We found that the errors across samples are not uniform. This is probably attributed to boundary effects 
[
18
]
. In fact, there are a few samples that have significantly larger errors than others, making the overall scaling slow down. If we plot the square root of the 
median
 (not 
mean
) of the squared losses, we get a scaling closer to 
G
−
4
superscript
𝐺
4
G^{-4}
italic_G start_POSTSUPERSCRIPT - 4 end_POSTSUPERSCRIPT
. Despite this suboptimality (probably due to optimization), KANs still have much better scaling laws than MLPs, for data fitting (Figure 
3.1
) and PDE solving (Figure 
3.3
). In addition, the training time scales favorably with the number of grid points 
G
𝐺
G
italic_G
, shown in Figure 
2.3
 bottom right 
3
3
3
When 
G
=
1000
𝐺
1000
G=1000
italic_G = 1000
, training becomes significantly slower, which is specific to the use of the LBFGS optimizer with line search. We conjecture that the loss landscape becomes bad for 
G
=
1000
𝐺
1000
G=1000
italic_G = 1000
, so line search with trying to find an optimal step size within maximal iterations without early stopping.
.






External vs Internal degrees of freedom.
 A new concept that KANs highlights is a distinction between external versus internal degrees of freedom (parameters). The computational graph of how nodes are connected represents external degrees of freedom (“dofs”), while the grid points inside an activation function are internal degrees of freedom. KANs benefit from the fact that they have both external dofs and internal dofs. External dofs (that MLPs also have but splines do not) are responsible for learning compositional structures of multiple variables. Internal dofs (that splines also have but MLPs do not) are responsible for learning univariate functions.










2.5 
For Interpretability: Simplifying KANs and Making them interactive




One loose end from the last subsection is that we do not know how to choose the KAN shape that best matches the structure of a dataset. For example, if we know that the dataset is generated via the symbolic formula 
f
⁢
(
x
,
y
)
=
exp
⁢
(
sin
⁢
(
π
⁢
x
)
+
y
2
)
𝑓
𝑥
𝑦
exp
sin
𝜋
𝑥
superscript
𝑦
2
f(x,y)={\rm exp}({\rm sin}(\pi x)+y^{2})
italic_f ( italic_x , italic_y ) = roman_exp ( roman_sin ( italic_π italic_x ) + italic_y start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT )
, then we know that a 
[
2
,
1
,
1
]
2
1
1
[2,1,1]
[ 2 , 1 , 1 ]
 KAN is able to express this function. However, in practice we do not know the information a priori, so it would be nice to have approaches to determine this shape automatically. The idea is to start from a large enough KAN and train it with sparsity regularization followed by pruning. We will show that these pruned KANs are much more interpretable than non-pruned ones. To make KANs maximally interpretable, we propose a few simplification techniques in Section 
2.5.1
, and an example of how users can interact with KANs to make them more interpretable in Section 
2.5.2
.








2.5.1 
Simplification techniques




1. Sparsification.
 For MLPs, L1 regularization of linear weights is used to favor sparsity. KANs can adapt this high-level idea, but need two modifications:






(1)




There is no linear “weight” in KANs. Linear weights are replaced by learnable activation functions, so we should define the L1 norm of these activation functions.








(2)




We find L1 to be insufficient for sparsification of KANs; instead an additional entropy regularization is necessary (see Appendix 
C
 for more details).








We define the L1 norm of an activation function 
ϕ
italic-ϕ
\phi
italic_ϕ
 to be its average magnitude over its 
N
p
subscript
𝑁
𝑝
N_{p}
italic_N start_POSTSUBSCRIPT italic_p end_POSTSUBSCRIPT
 inputs, i.e.,








|
ϕ
|
1
≡
1
N
p
⁢
∑
s
=
1
N
p
|
ϕ
⁢
(
x
(
s
)
)
|
.
subscript
italic-ϕ
1
1
subscript
𝑁
𝑝
superscript
subscript
𝑠
1
subscript
𝑁
𝑝
italic-ϕ
superscript
𝑥
𝑠
\left|\phi\right|_{1}\equiv\frac{1}{N_{p}}\sum_{s=1}^{N_{p}}\left|\phi(x^{(s)}%
)\right|.
| italic_ϕ | start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT ≡ divide start_ARG 1 end_ARG start_ARG italic_N start_POSTSUBSCRIPT italic_p end_POSTSUBSCRIPT end_ARG ∑ start_POSTSUBSCRIPT italic_s = 1 end_POSTSUBSCRIPT start_POSTSUPERSCRIPT italic_N start_POSTSUBSCRIPT italic_p end_POSTSUBSCRIPT end_POSTSUPERSCRIPT | italic_ϕ ( italic_x start_POSTSUPERSCRIPT ( italic_s ) end_POSTSUPERSCRIPT ) | .




(2.17)






Then for a KAN layer 
𝚽
𝚽
\mathbf{\Phi}
bold_Φ
 with 
n
in
subscript
𝑛
in
n_{\rm in}
italic_n start_POSTSUBSCRIPT roman_in end_POSTSUBSCRIPT
 inputs and 
n
out
subscript
𝑛
out
n_{\rm out}
italic_n start_POSTSUBSCRIPT roman_out end_POSTSUBSCRIPT
 outputs, we define the L1 norm of 
𝚽
𝚽
\mathbf{\Phi}
bold_Φ
 to be the sum of L1 norms of all activation functions, i.e.,








|
𝚽
|
1
≡
∑
i
=
1
n
in
∑
j
=
1
n
out
|
ϕ
i
,
j
|
1
.
subscript
𝚽
1
superscript
subscript
𝑖
1
subscript
𝑛
in
superscript
subscript
𝑗
1
subscript
𝑛
out
subscript
subscript
italic-ϕ
𝑖
𝑗
1
\left|\mathbf{\Phi}\right|_{1}\equiv\sum_{i=1}^{n_{\rm in}}\sum_{j=1}^{n_{\rm
out%
}}\left|\phi_{i,j}\right|_{1}.
| bold_Φ | start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT ≡ ∑ start_POSTSUBSCRIPT italic_i = 1 end_POSTSUBSCRIPT start_POSTSUPERSCRIPT italic_n start_POSTSUBSCRIPT roman_in end_POSTSUBSCRIPT end_POSTSUPERSCRIPT ∑ start_POSTSUBSCRIPT italic_j = 1 end_POSTSUBSCRIPT start_POSTSUPERSCRIPT italic_n start_POSTSUBSCRIPT roman_out end_POSTSUBSCRIPT end_POSTSUPERSCRIPT | italic_ϕ start_POSTSUBSCRIPT italic_i , italic_j end_POSTSUBSCRIPT | start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT .




(2.18)






In addition, we define the entropy of 
𝚽
𝚽
\mathbf{\Phi}
bold_Φ
 to be








S
⁢
(
𝚽
)
≡
−
∑
i
=
1
n
in
∑
j
=
1
n
out
|
ϕ
i
,
j
|
1
|
𝚽
|
1
⁢
log
⁢
(
|
ϕ
i
,
j
|
1
|
𝚽
|
1
)
.
𝑆
𝚽
superscript
subscript
𝑖
1
subscript
𝑛
in
superscript
subscript
𝑗
1
subscript
𝑛
out
subscript
subscript
italic-ϕ
𝑖
𝑗
1
subscript
𝚽
1
log
subscript
subscript
italic-ϕ
𝑖
𝑗
1
subscript
𝚽
1
S(\mathbf{\Phi})\equiv-\sum_{i=1}^{n_{\rm in}}\sum_{j=1}^{n_{\rm out}}\frac{%
\left|\phi_{i,j}\right|_{1}}{\left|\mathbf{\Phi}\right|_{1}}{\rm log}\left(%
\frac{\left|\phi_{i,j}\right|_{1}}{\left|\mathbf{\Phi}\right|_{1}}\right).
italic_S ( bold_Φ ) ≡ - ∑ start_POSTSUBSCRIPT italic_i = 1 end_POSTSUBSCRIPT start_POSTSUPERSCRIPT italic_n start_POSTSUBSCRIPT roman_in end_POSTSUBSCRIPT end_POSTSUPERSCRIPT ∑ start_POSTSUBSCRIPT italic_j = 1 end_POSTSUBSCRIPT start_POSTSUPERSCRIPT italic_n start_POSTSUBSCRIPT roman_out end_POSTSUBSCRIPT end_POSTSUPERSCRIPT divide start_ARG | italic_ϕ start_POSTSUBSCRIPT italic_i , italic_j end_POSTSUBSCRIPT | start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT end_ARG start_ARG | bold_Φ | start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT end_ARG roman_log ( divide start_ARG | italic_ϕ start_POSTSUBSCRIPT italic_i , italic_j end_POSTSUBSCRIPT | start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT end_ARG start_ARG | bold_Φ | start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT end_ARG ) .




(2.19)






The total training objective 
ℓ
total
subscript
ℓ
total
\ell_{\rm total}
roman_ℓ start_POSTSUBSCRIPT roman_total end_POSTSUBSCRIPT
 is the prediction loss 
ℓ
pred
subscript
ℓ
pred
\ell_{\rm pred}
roman_ℓ start_POSTSUBSCRIPT roman_pred end_POSTSUBSCRIPT
 plus L1 and entropy regularization of all KAN layers:








ℓ
total
=
ℓ
pred
+
λ
⁢
(
μ
1
⁢
∑
l
=
0
L
−
1
|
𝚽
l
|
1
+
μ
2
⁢
∑
l
=
0
L
−
1
S
⁢
(
𝚽
l
)
)
,
subscript
ℓ
total
subscript
ℓ
pred
𝜆
subscript
𝜇
1
superscript
subscript
𝑙
0
𝐿
1
subscript
subscript
𝚽
𝑙
1
subscript
𝜇
2
superscript
subscript
𝑙
0
𝐿
1
𝑆
subscript
𝚽
𝑙
\ell_{\rm total}=\ell_{\rm pred}+\lambda\left(\mu_{1}\sum_{l=0}^{L-1}\left|%
\mathbf{\Phi}_{l}\right|_{1}+\mu_{2}\sum_{l=0}^{L-1}S(\mathbf{\Phi}_{l})\right),
roman_ℓ start_POSTSUBSCRIPT roman_total end_POSTSUBSCRIPT = roman_ℓ start_POSTSUBSCRIPT roman_pred end_POSTSUBSCRIPT + italic_λ ( italic_μ start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT ∑ start_POSTSUBSCRIPT italic_l = 0 end_POSTSUBSCRIPT start_POSTSUPERSCRIPT italic_L - 1 end_POSTSUPERSCRIPT | bold_Φ start_POSTSUBSCRIPT italic_l end_POSTSUBSCRIPT | start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT + italic_μ start_POSTSUBSCRIPT 2 end_POSTSUBSCRIPT ∑ start_POSTSUBSCRIPT italic_l = 0 end_POSTSUBSCRIPT start_POSTSUPERSCRIPT italic_L - 1 end_POSTSUPERSCRIPT italic_S ( bold_Φ start_POSTSUBSCRIPT italic_l end_POSTSUBSCRIPT ) ) ,




(2.20)






where 
μ
1
,
μ
2
subscript
𝜇
1
subscript
𝜇
2
\mu_{1},\mu_{2}
italic_μ start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT , italic_μ start_POSTSUBSCRIPT 2 end_POSTSUBSCRIPT
 are relative magnitudes usually set to 
μ
1
=
μ
2
=
1
subscript
𝜇
1
subscript
𝜇
2
1
\mu_{1}=\mu_{2}=1
italic_μ start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT = italic_μ start_POSTSUBSCRIPT 2 end_POSTSUBSCRIPT = 1
, and 
λ
𝜆
\lambda
italic_λ
 controls overall regularization magnitude.






2. Visualization.
 When we visualize a KAN, to get a sense of magnitudes, we set the transparency of an activation function 
ϕ
l
,
i
,
j
subscript
italic-ϕ
𝑙
𝑖
𝑗
\phi_{l,i,j}
italic_ϕ start_POSTSUBSCRIPT italic_l , italic_i , italic_j end_POSTSUBSCRIPT
 proportional to 
tanh
⁢
(
β
⁢
A
l
,
i
,
j
)
tanh
𝛽
subscript
𝐴
𝑙
𝑖
𝑗
{\rm tanh}(\beta A_{l,i,j})
roman_tanh ( italic_β italic_A start_POSTSUBSCRIPT italic_l , italic_i , italic_j end_POSTSUBSCRIPT )
 where 
β
=
3
𝛽
3
\beta=3
italic_β = 3
 . Hence, functions with small magnitude appear faded out to allow us to focus on important ones.






3. Pruning.
 After training with sparsification penalty, we may also want to prune the network to a smaller subnetwork. We sparsify KANs on the node level (rather than on the edge level). For each node (say the 
i
th
superscript
𝑖
th
i^{\rm th}
italic_i start_POSTSUPERSCRIPT roman_th end_POSTSUPERSCRIPT
 neuron in the 
l
th
superscript
𝑙
th
l^{\rm th}
italic_l start_POSTSUPERSCRIPT roman_th end_POSTSUPERSCRIPT
 layer), we define its incoming and outgoing score as








I
l
,
i
=
max
𝑘
⁢
(
|
ϕ
l
−
1
,
k
,
i
|
1
)
,
O
l
,
i
=
max
j
⁢
(
|
ϕ
l
+
1
,
j
,
i
|
1
)
,
formulae-sequence
subscript
𝐼
𝑙
𝑖
𝑘
max
subscript
subscript
italic-ϕ
l
1
k
i
1
subscript
O
l
i
j
max
subscript
subscript
italic-ϕ
l
1
j
i
1
I_{l,i}=\underset{k}{\rm max}(\left|\phi_{l-1,k,i}\right|_{1}),\qquad O_{l,i}=%
\underset{j}{\rm max}(\left|\phi_{l+1,j,i}\right|_{1}),
italic_I start_POSTSUBSCRIPT italic_l , italic_i end_POSTSUBSCRIPT = underitalic_k start_ARG roman_max end_ARG ( | italic_ϕ start_POSTSUBSCRIPT roman_l - 1 , roman_k , roman_i end_POSTSUBSCRIPT | start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT ) , roman_O start_POSTSUBSCRIPT roman_l , roman_i end_POSTSUBSCRIPT = underroman_j start_ARG roman_max end_ARG ( | italic_ϕ start_POSTSUBSCRIPT roman_l + 1 , roman_j , roman_i end_POSTSUBSCRIPT | start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT ) ,




(2.21)






and consider a node to be important if both incoming and outgoing scores are greater than a threshold hyperparameter 
θ
=
10
−
2
𝜃
superscript
10
2
\theta=10^{-2}
italic_θ = 10 start_POSTSUPERSCRIPT - 2 end_POSTSUPERSCRIPT
 by default. All unimportant neurons are pruned.






4. Symbolification.
 In cases where we suspect that some activation functions are in fact symbolic (e.g., 
cos
cos
{\rm cos}
roman_cos
 or 
log
log
{\rm log}
roman_log
), we provide an interface to set them to be a specified symbolic form, 
fix_symbolic(l,i,j,f)
 can set the 
(
l
,
i
,
j
)
𝑙
𝑖
𝑗
(l,i,j)
( italic_l , italic_i , italic_j )
 activation to be 
f
𝑓
f
italic_f
. However, we cannot simply set the activation function to be the exact symbolic formula, since its inputs and outputs may have shifts and scalings. So, we obtain preactivations 
x
𝑥
x
italic_x
 and postactivations 
y
𝑦
y
italic_y
 from samples, and fit affine parameters 
(
a
,
b
,
c
,
d
)
𝑎
𝑏
𝑐
𝑑
(a,b,c,d)
( italic_a , italic_b , italic_c , italic_d )
 such that

y
≈
c
⁢
f
⁢
(
a
⁢
x
+
b
)
+
d
𝑦
𝑐
𝑓
𝑎
𝑥
𝑏
𝑑
y\approx cf(ax+b)+d
italic_y ≈ italic_c italic_f ( italic_a italic_x + italic_b ) + italic_d
. The fitting is done by iterative grid search of 
a
,
b
𝑎
𝑏
a,b
italic_a , italic_b
 and linear regression.






Besides these techniques, we provide additional tools that allow users to apply more fine-grained control to KANs, listed in Appendix 
A
.










2.5.2 
A toy example: how humans can interact with KANs




Figure 2.4: 
An example of how to do symbolic regression with KAN.






Above we have proposed a number of simplification techniques for KANs. We can view these simplification choices as buttons one can click on. A user interacting with these buttons can decide which button is most promising to click next to make KANs more interpretable. We use an example below to showcase how a user could interact with a KAN to obtain maximally interpretable results.







Let us again consider the regression task








f
⁢
(
x
,
y
)
=
exp
⁡
(
sin
⁡
(
π
⁢
x
)
+
y
2
)
.
𝑓
𝑥
𝑦
𝜋
𝑥
superscript
𝑦
2
\displaystyle f(x,y)=\exp\left({\sin}(\pi x)+y^{2}\right).
italic_f ( italic_x , italic_y ) = roman_exp ( roman_sin ( italic_π italic_x ) + italic_y start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT ) .




(2.22)






Given data points 
(
x
i
,
y
i
,
f
i
)
subscript
𝑥
𝑖
subscript
𝑦
𝑖
subscript
𝑓
𝑖
(x_{i},y_{i},f_{i})
( italic_x start_POSTSUBSCRIPT italic_i end_POSTSUBSCRIPT , italic_y start_POSTSUBSCRIPT italic_i end_POSTSUBSCRIPT , italic_f start_POSTSUBSCRIPT italic_i end_POSTSUBSCRIPT )
, 
i
=
1
,
2
,
⋯
,
N
p
𝑖
1
2
⋯
subscript
𝑁
𝑝
i=1,2,\cdots,N_{p}
italic_i = 1 , 2 , ⋯ , italic_N start_POSTSUBSCRIPT italic_p end_POSTSUBSCRIPT
, a hypothetical user Alice is interested in figuring out the symbolic formula. The steps of Alice’s interaction with the KANs are described below (illustrated in Figure 
2.4
):






Step 1: Training with sparsification.
 Starting from a fully-connected 
[
2
,
5
,
1
]
2
5
1
[2,5,1]
[ 2 , 5 , 1 ]
 KAN, training with sparsification regularization can make it quite sparse. 4 out of 5 neurons in the hidden layer appear useless, hence we want to prune them away.






Step 2: Pruning.
 Automatic pruning is seen to discard all hidden neurons except the last one, leaving a 
[
2
,
1
,
1
]
2
1
1
[2,1,1]
[ 2 , 1 , 1 ]
 KAN. The activation functions appear to be known symbolic functions.






Step 3: Setting symbolic functions.
 Assuming that the user can correctly guess these symbolic formulas from staring at the KAN plot, they can set












fix_symbolic(0,0,0,‘sin’)




(2.23)










fix_symbolic(0,1,0,‘x^2’)












fix_symbolic(1,0,0,‘exp’)
.
fix_symbolic(1,0,0,‘exp’)
\displaystyle\texttt{fix\_symbolic(1,0,0,`exp')}.
fix_symbolic(1,0,0,‘exp’) .










In case the user has no domain knowledge or no idea which symbolic functions these activation functions might be, we provide a function 
suggest_symbolic
 to suggest symbolic candidates.






Step 4: Further training.
 After symbolifying all the activation functions in the network, the only remaining parameters are the affine parameters. We continue training these affine parameters, and when we see the loss dropping to machine precision, we know that we have found the correct symbolic expression.






Step 5: Output the symbolic formula.
 
Sympy
 is used to compute the symbolic formula of the output node. The user obtains 
1.0
⁢
e
1.0
⁢
y
2
+
1.0
⁢
sin
⁢
(
3.14
⁢
x
)
1.0
superscript
𝑒
1.0
superscript
𝑦
2
1.0
sin
3.14
𝑥
1.0e^{1.0y^{2}+1.0{\rm sin}(3.14x)}
1.0 italic_e start_POSTSUPERSCRIPT 1.0 italic_y start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT + 1.0 roman_sin ( 3.14 italic_x ) end_POSTSUPERSCRIPT
, which is the true answer (we only displayed two decimals for 
π
𝜋
\pi
italic_π
).






Remark: Why not symbolic regression (SR)?

It is reasonable to use symbolic regression for this example. However, symbolic regression methods are in general brittle and hard to debug. They either return a success or a failure in the end without outputting interpretable intermediate results. In contrast, KANs do continuous search (with gradient descent) in function space, so their results are more continuous and hence more robust. Moreover, users have more control over KANs as compared to SR due to KANs’ transparency. The way we visualize KANs is like displaying KANs’ “brain” to users, and users can perform “surgery” (debugging) on KANs. This level of control is typically unavailable for SR. We will show examples of this in Section 
4.4
. More generally, when the target function is not symbolic, symbolic regression will fail but KANs can still provide something meaningful. For example, a special function (e.g., a Bessel function) is impossible to SR to learn unless it is provided in advance, but KANs can use splines to approximate it numerically anyway (see Figure 
4.1
 (d)).














3 
KANs are accurate




In this section, we demonstrate that KANs are more effective at representing functions than MLPs in various tasks (regression and PDE solving). When comparing two families of models, it is fair to compare both their accuracy (loss) and their complexity (number of parameters). We will show that KANs display more favorable Pareto Frontiers than MLPs. Moreover, in Section 
3.5
, we show that KANs can naturally work in continual learning without catastrophic forgetting.








3.1 
Toy datasets




Figure 3.1: 
Compare KANs to MLPs on five toy examples. KANs can almost saturate the fastest scaling law predicted by our theory 
(
α
=
4
)
𝛼
4
(\alpha=4)
( italic_α = 4 )
, while MLPs scales slowly and plateau quickly.






In Section 
2.3
, our theory suggested that test RMSE loss 
ℓ
ℓ
\ell
roman_ℓ
 scales as 
ℓ
∝
N
−
4
proportional-to
ℓ
superscript
𝑁
4
\ell\propto N^{-4}
roman_ℓ ∝ italic_N start_POSTSUPERSCRIPT - 4 end_POSTSUPERSCRIPT
 with model parameters 
N
𝑁
N
italic_N
. However, this relies on the existence of a Kolmogorov-Arnold representation. As a sanity check, we construct five examples we know have smooth KA representations:






(1)




f
⁢
(
x
)
=
J
0
⁢
(
20
⁢
x
)
𝑓
𝑥
subscript
𝐽
0
20
𝑥
f(x)=J_{0}(20x)
italic_f ( italic_x ) = italic_J start_POSTSUBSCRIPT 0 end_POSTSUBSCRIPT ( 20 italic_x )
, which is the Bessel function. Since it is a univariate function, it can be represented by a spline, which is a 
[
1
,
1
]
1
1
[1,1]
[ 1 , 1 ]
 KAN.








(2)




f
⁢
(
x
,
y
)
=
exp
⁢
(
sin
⁢
(
π
⁢
x
)
+
y
2
)
𝑓
𝑥
𝑦
exp
sin
𝜋
𝑥
superscript
𝑦
2
f(x,y)={\rm exp}({\rm sin}(\pi x)+y^{2})
italic_f ( italic_x , italic_y ) = roman_exp ( roman_sin ( italic_π italic_x ) + italic_y start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT )
. We know that it can be exactly represented by a 
[
2
,
1
,
1
]
2
1
1
[2,1,1]
[ 2 , 1 , 1 ]
 KAN.








(3)




f
⁢
(
x
,
y
)
=
x
⁢
y
𝑓
𝑥
𝑦
𝑥
𝑦
f(x,y)=xy
italic_f ( italic_x , italic_y ) = italic_x italic_y
. We know from Figure 
4.1
 that it can be exactly represented by a 
[
2
,
2
,
1
]
2
2
1
[2,2,1]
[ 2 , 2 , 1 ]
 KAN.








(4)




A high-dimensional example 
f
⁢
(
x
1
,
⋯
,
x
100
)
=
exp
⁢
(
1
100
⁢
∑
i
=
1
100
sin
2
⁢
(
π
⁢
x
i
2
)
)
𝑓
subscript
𝑥
1
⋯
subscript
𝑥
100
exp
1
100
superscript
subscript
𝑖
1
100
superscript
sin
2
𝜋
subscript
𝑥
𝑖
2
f(x_{1},\cdots,x_{100})={\rm exp}(\frac{1}{100}\sum_{i=1}^{100}{\rm sin}^{2}(%
\frac{\pi x_{i}}{2}))
italic_f ( italic_x start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT , ⋯ , italic_x start_POSTSUBSCRIPT 100 end_POSTSUBSCRIPT ) = roman_exp ( divide start_ARG 1 end_ARG start_ARG 100 end_ARG ∑ start_POSTSUBSCRIPT italic_i = 1 end_POSTSUBSCRIPT start_POSTSUPERSCRIPT 100 end_POSTSUPERSCRIPT roman_sin start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT ( divide start_ARG italic_π italic_x start_POSTSUBSCRIPT italic_i end_POSTSUBSCRIPT end_ARG start_ARG 2 end_ARG ) )
 which can be represented by a 
[
100
,
1
,
1
]
100
1
1
[100,1,1]
[ 100 , 1 , 1 ]
 KAN.








(5)




A four-dimensional example 
f
⁢
(
x
1
,
x
2
,
x
3
,
x
4
)
=
exp
⁢
(
1
2
⁢
(
sin
⁢
(
π
⁢
(
x
1
2
+
x
2
2
)
)
+
sin
⁢
(
π
⁢
(
x
3
2
+
x
4
2
)
)
)
)
𝑓
subscript
𝑥
1
subscript
𝑥
2
subscript
𝑥
3
subscript
𝑥
4
exp
1
2
sin
𝜋
superscript
subscript
𝑥
1
2
superscript
subscript
𝑥
2
2
sin
𝜋
superscript
subscript
𝑥
3
2
superscript
subscript
𝑥
4
2
f(x_{1},x_{2},x_{3},x_{4})={\rm exp}(\frac{1}{2}({\rm sin}(\pi(x_{1}^{2}+x_{2}%
^{2}))+{\rm sin}(\pi(x_{3}^{2}+x_{4}^{2}))))
italic_f ( italic_x start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT , italic_x start_POSTSUBSCRIPT 2 end_POSTSUBSCRIPT , italic_x start_POSTSUBSCRIPT 3 end_POSTSUBSCRIPT , italic_x start_POSTSUBSCRIPT 4 end_POSTSUBSCRIPT ) = roman_exp ( divide start_ARG 1 end_ARG start_ARG 2 end_ARG ( roman_sin ( italic_π ( italic_x start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT + italic_x start_POSTSUBSCRIPT 2 end_POSTSUBSCRIPT start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT ) ) + roman_sin ( italic_π ( italic_x start_POSTSUBSCRIPT 3 end_POSTSUBSCRIPT start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT + italic_x start_POSTSUBSCRIPT 4 end_POSTSUBSCRIPT start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT ) ) ) )
 which can be represented by a 
[
4
,
4
,
2
,
1
]
4
4
2
1
[4,4,2,1]
[ 4 , 4 , 2 , 1 ]
 KAN.








We train these KANs by increasing grid points every 200 steps, in total covering 
G
=
{
3
,
5
,
10
,
20
,
50
,
100
,
200
,
500
,
1000
}
𝐺
3
5
10
20
50
100
200
500
1000
G=\{3,5,10,20,50,100,200,500,1000\}
italic_G = { 3 , 5 , 10 , 20 , 50 , 100 , 200 , 500 , 1000 }
. We train MLPs with different depths and widths as baselines. Both MLPs and KANs are trained with LBFGS for 1800 steps in total. We plot test RMSE as a function of the number of parameters for KANs and MLPs in Figure 
3.1
, showing that KANs have better scaling curves than MLPs, especially for the high-dimensional example. For comparison, we plot the lines predicted from our KAN theory as red dashed (
α
=
k
+
1
=
4
𝛼
𝑘
1
4
\alpha=k+1=4
italic_α = italic_k + 1 = 4
), and the lines predicted from Sharma & Kaplan 
[
17
]
 as black-dashed (
α
=
(
k
+
1
)
/
d
=
4
/
d
𝛼
𝑘
1
𝑑
4
𝑑
\alpha=(k+1)/d=4/d
italic_α = ( italic_k + 1 ) / italic_d = 4 / italic_d
). KANs can almost saturate the steeper red lines, while MLPs struggle to converge even as fast as the slower black lines and plateau quickly. We also note that for the last example, the 2-Layer KAN 
[
4
,
9
,
1
]
4
9
1
[4,9,1]
[ 4 , 9 , 1 ]
 behaves much worse than the 3-Layer KAN (shape 
[
4
,
2
,
2
,
1
]
4
2
2
1
[4,2,2,1]
[ 4 , 2 , 2 , 1 ]
). This highlights the greater expressive power of deeper KANs, which is the same for MLPs: deeper MLPs have more expressive power than shallower ones.










3.2 
Special functions




Figure 3.2: 
Fitting special functions. We show the Pareto Frontier of KANs and MLPs in the plane spanned by the number of model parameters and RMSE loss. Consistently accross all special functions, KANs have better Pareto Frontiers than MLPs. The definitions of these special functions are in Table 
2
.






One caveat for the above results is that we assume knowledge of the “true” KAN shape. In practice, we do not know the existence of KA representations. Even when we are promised that such a KA representation exists, we do not know the KAN shape a priori. Special functions in more than one variables are such cases, because it would be (mathematically) surprising if multivariate special functions (e.g., a Bessel function 
f
⁢
(
ν
,
x
)
=
J
ν
⁢
(
x
)
𝑓
𝜈
𝑥
subscript
𝐽
𝜈
𝑥
f(\nu,x)=J_{\nu}(x)
italic_f ( italic_ν , italic_x ) = italic_J start_POSTSUBSCRIPT italic_ν end_POSTSUBSCRIPT ( italic_x )
) could be written in KA represenations, involving only univariate functions and sums). We show below that:






(1)




Finding (approximate) compact KA representations of special functions is possible, revealing novel mathematical properties of special functions from the perspective of Kolmogorov-Arnold representations.








(2)




KANs are more efficient and accurate in representing special functions than MLPs.












We collect 15 special functions common in math and physics, summarized in Table 
2
. We choose MLPs with fixed width 5 or 100 and depths swept in 
{
2
,
3
,
4
,
5
,
6
}
2
3
4
5
6
\{2,3,4,5,6\}
{ 2 , 3 , 4 , 5 , 6 }
. We run KANs both with and without pruning. 
KANs without pruning
: We fix the shape of KAN, whose width are set to 5 and depths are swept in {2,3,4,5,6}.

KAN with pruning
. We use the sparsification 
(
λ
=
10
−
2
⁢
or
⁢
 10
−
3
)
𝜆
superscript
10
2
or
superscript
10
3
(\lambda=10^{-2}\ {\rm or}\ 10^{-3})
( italic_λ = 10 start_POSTSUPERSCRIPT - 2 end_POSTSUPERSCRIPT roman_or 10 start_POSTSUPERSCRIPT - 3 end_POSTSUPERSCRIPT )
 and pruning technique in Section 
2.5.1
 to obtain a smaller KAN pruned from a fixed-shape KAN. Each KAN is initialized to have 
G
=
3
𝐺
3
G=3
italic_G = 3
, trained with LBFGS, with increasing number of grid points every 200 steps to cover 
G
=
{
3
,
5
,
10
,
20
,
50
,
100
,
200
}
𝐺
3
5
10
20
50
100
200
G=\{3,5,10,20,50,100,200\}
italic_G = { 3 , 5 , 10 , 20 , 50 , 100 , 200 }
. For each hyperparameter combination, we run 3 random seeds.






For each dataset and each model family (KANs or MLPs), we plot the Pareto frontier 
4
4
4
Pareto frontier is defined as fits that are optimal in the sense of no other fit being both simpler and more accurate.
, in the (number of parameters, RMSE) plane, shown in Figure 
3.2
. KANs’ performance is shown to be consistently better than MLPs, i.e., KANs can achieve lower training/test losses than MLPs, given the same number of parameters. Moreover, we report the (surprisingly compact) shapes of our auto-discovered KANs for special functions in Table 
2
. On one hand, it is interesting to interpret what these compact representations mean mathematically (we include the KAN illustrations in Figure 
F.1
 and 
F.2
 in Appendix 
F
). On the other hand, these compact representations imply the possibility of breaking down a high-dimensional lookup table into several 1D lookup tables, which can potentially save a lot of memory, with the (almost negligible) overhead to perform a few additions at inference time.












Name


scipy.special API




 






Minimal KAN shape




test RMSE 
<
10
−
2
absent
superscript
10
2
<10^{-2}
< 10 start_POSTSUPERSCRIPT - 2 end_POSTSUPERSCRIPT




Minimal KAN test RMSE


Best KAN shape


Best KAN test RMSE


MLP test RMSE






Jacobian elliptic functions


ellipj
⁢
(
x
,
y
)
ellipj
𝑥
𝑦
{\rm ellipj}(x,y)
roman_ellipj ( italic_x , italic_y )


[2,2,1]


7.29
×
10
−
3
7.29
superscript
10
3
7.29\times 10^{-3}
7.29 × 10 start_POSTSUPERSCRIPT - 3 end_POSTSUPERSCRIPT


[2,3,2,1,1,1]


1.33
×
𝟏𝟎
−
𝟒
1.33
superscript
10
4
{\bf 1.33\times 10^{-4}}
bold_1.33 × bold_10 start_POSTSUPERSCRIPT - bold_4 end_POSTSUPERSCRIPT


6.48
×
10
−
4
6.48
superscript
10
4
6.48\times 10^{-4}
6.48 × 10 start_POSTSUPERSCRIPT - 4 end_POSTSUPERSCRIPT






Incomplete elliptic integral of the first kind


ellipkinc
⁢
(
x
,
y
)
ellipkinc
𝑥
𝑦
{\rm ellipkinc}(x,y)
roman_ellipkinc ( italic_x , italic_y )


[2,2,1,1]


1.00
×
10
−
3
1.00
superscript
10
3
1.00\times 10^{-3}
1.00 × 10 start_POSTSUPERSCRIPT - 3 end_POSTSUPERSCRIPT


[2,2,1,1,1]


1.24
×
𝟏𝟎
−
𝟒
1.24
superscript
10
4
{\bf 1.24\times 10^{-4}}
bold_1.24 × bold_10 start_POSTSUPERSCRIPT - bold_4 end_POSTSUPERSCRIPT


5.52
×
10
−
4
5.52
superscript
10
4
5.52\times 10^{-4}
5.52 × 10 start_POSTSUPERSCRIPT - 4 end_POSTSUPERSCRIPT






Incomplete elliptic integral of the second kind


ellipeinc
⁢
(
x
,
y
)
ellipeinc
𝑥
𝑦
{\rm ellipeinc}(x,y)
roman_ellipeinc ( italic_x , italic_y )


[2,2,1,1]


8.36
×
10
−
5
8.36
superscript
10
5
8.36\times 10^{-5}
8.36 × 10 start_POSTSUPERSCRIPT - 5 end_POSTSUPERSCRIPT


[2,2,1,1]


8.26
×
𝟏𝟎
−
𝟓
8.26
superscript
10
5
{\bf 8.26\times 10^{-5}}
bold_8.26 × bold_10 start_POSTSUPERSCRIPT - bold_5 end_POSTSUPERSCRIPT


3.04
×
10
−
4
3.04
superscript
10
4
3.04\times 10^{-4}
3.04 × 10 start_POSTSUPERSCRIPT - 4 end_POSTSUPERSCRIPT






Bessel function of the first kind


jv
⁢
(
x
,
y
)
jv
𝑥
𝑦
{\rm jv}(x,y)
roman_jv ( italic_x , italic_y )


[2,2,1]


4.93
×
10
−
3
4.93
superscript
10
3
4.93\times 10^{-3}
4.93 × 10 start_POSTSUPERSCRIPT - 3 end_POSTSUPERSCRIPT


[2,3,1,1,1]


1.64
×
𝟏𝟎
−
𝟑
1.64
superscript
10
3
{\bf 1.64\times 10^{-3}}
bold_1.64 × bold_10 start_POSTSUPERSCRIPT - bold_3 end_POSTSUPERSCRIPT


5.52
×
10
−
3
5.52
superscript
10
3
5.52\times 10^{-3}
5.52 × 10 start_POSTSUPERSCRIPT - 3 end_POSTSUPERSCRIPT






Bessel function of the second kind


yv
⁢
(
x
,
y
)
yv
𝑥
𝑦
{\rm yv}(x,y)
roman_yv ( italic_x , italic_y )


[2,3,1]


1.89
×
10
−
3
1.89
superscript
10
3
1.89\times 10^{-3}
1.89 × 10 start_POSTSUPERSCRIPT - 3 end_POSTSUPERSCRIPT


[2,2,2,1]


1.49
×
𝟏𝟎
−
𝟓
1.49
superscript
10
5
{\bf 1.49\times 10^{-5}}
bold_1.49 × bold_10 start_POSTSUPERSCRIPT - bold_5 end_POSTSUPERSCRIPT


3.45
×
10
−
4
3.45
superscript
10
4
3.45\times 10^{-4}
3.45 × 10 start_POSTSUPERSCRIPT - 4 end_POSTSUPERSCRIPT






Modified Bessel function of the second kind


kv
⁢
(
x
,
y
)
kv
𝑥
𝑦
{\rm kv}(x,y)
roman_kv ( italic_x , italic_y )


[2,1,1]


4.89
×
10
−
3
4.89
superscript
10
3
4.89\times 10^{-3}
4.89 × 10 start_POSTSUPERSCRIPT - 3 end_POSTSUPERSCRIPT


[2,2,1]


2.52
×
𝟏𝟎
−
𝟓
2.52
superscript
10
5
{\bf 2.52\times 10^{-5}}
bold_2.52 × bold_10 start_POSTSUPERSCRIPT - bold_5 end_POSTSUPERSCRIPT


1.67
×
10
−
4
1.67
superscript
10
4
1.67\times 10^{-4}
1.67 × 10 start_POSTSUPERSCRIPT - 4 end_POSTSUPERSCRIPT






Modified Bessel function of the first kind


iv
⁢
(
x
,
y
)
iv
𝑥
𝑦
{\rm iv}(x,y)
roman_iv ( italic_x , italic_y )


[2,4,3,2,1,1]


9.28
×
10
−
3
9.28
superscript
10
3
9.28\times 10^{-3}
9.28 × 10 start_POSTSUPERSCRIPT - 3 end_POSTSUPERSCRIPT


[2,4,3,2,1,1]


9.28
×
𝟏𝟎
−
𝟑
9.28
superscript
10
3
{\bf 9.28\times 10^{-3}}
bold_9.28 × bold_10 start_POSTSUPERSCRIPT - bold_3 end_POSTSUPERSCRIPT


1.07
×
10
−
2
1.07
superscript
10
2
1.07\times 10^{-2}
1.07 × 10 start_POSTSUPERSCRIPT - 2 end_POSTSUPERSCRIPT






Associated Legendre function 
(
m
=
0
)
𝑚
0
(m=0)
( italic_m = 0 )




lpmv
⁢
(
0
,
x
,
y
)
lpmv
0
𝑥
𝑦
{\rm lpmv}(0,x,y)
roman_lpmv ( 0 , italic_x , italic_y )


[2,2,1]


5.25
×
10
−
5
5.25
superscript
10
5
5.25\times 10^{-5}
5.25 × 10 start_POSTSUPERSCRIPT - 5 end_POSTSUPERSCRIPT


[2,2,1]


5.25
×
𝟏𝟎
−
𝟓
5.25
superscript
10
5
{\bf 5.25\times 10^{-5}}
bold_5.25 × bold_10 start_POSTSUPERSCRIPT - bold_5 end_POSTSUPERSCRIPT


1.74
×
10
−
2
1.74
superscript
10
2
1.74\times 10^{-2}
1.74 × 10 start_POSTSUPERSCRIPT - 2 end_POSTSUPERSCRIPT






Associated Legendre function 
(
m
=
1
)
𝑚
1
(m=1)
( italic_m = 1 )




lpmv
⁢
(
1
,
x
,
y
)
lpmv
1
𝑥
𝑦
{\rm lpmv}(1,x,y)
roman_lpmv ( 1 , italic_x , italic_y )


[2,4,1]


6.90
×
10
−
4
6.90
superscript
10
4
6.90\times 10^{-4}
6.90 × 10 start_POSTSUPERSCRIPT - 4 end_POSTSUPERSCRIPT


[2,4,1]


6.90
×
𝟏𝟎
−
𝟒
6.90
superscript
10
4
{\bf 6.90\times 10^{-4}}
bold_6.90 × bold_10 start_POSTSUPERSCRIPT - bold_4 end_POSTSUPERSCRIPT


1.50
×
10
−
3
1.50
superscript
10
3
1.50\times 10^{-3}
1.50 × 10 start_POSTSUPERSCRIPT - 3 end_POSTSUPERSCRIPT






Associated Legendre function 
(
m
=
2
)
𝑚
2
(m=2)
( italic_m = 2 )




lpmv
⁢
(
2
,
x
,
y
)
lpmv
2
𝑥
𝑦
{\rm lpmv}(2,x,y)
roman_lpmv ( 2 , italic_x , italic_y )


[2,2,1]


4.88
×
10
−
3
4.88
superscript
10
3
4.88\times 10^{-3}
4.88 × 10 start_POSTSUPERSCRIPT - 3 end_POSTSUPERSCRIPT


[2,3,2,1]


2.26
×
𝟏𝟎
−
𝟒
2.26
superscript
10
4
{\bf 2.26\times 10^{-4}}
bold_2.26 × bold_10 start_POSTSUPERSCRIPT - bold_4 end_POSTSUPERSCRIPT


9.43
×
10
−
4
9.43
superscript
10
4
9.43\times 10^{-4}
9.43 × 10 start_POSTSUPERSCRIPT - 4 end_POSTSUPERSCRIPT






spherical harmonics 
(
m
=
0
,
n
=
1
)
formulae-sequence
𝑚
0
𝑛
1
(m=0,n=1)
( italic_m = 0 , italic_n = 1 )




sph
⁢
_
⁢
harm
⁢
(
0
,
1
,
x
,
y
)
sph
_
harm
0
1
𝑥
𝑦
{\rm sph\_harm}(0,1,x,y)
roman_sph _ roman_harm ( 0 , 1 , italic_x , italic_y )


[2,1,1]


2.21
×
10
−
7
2.21
superscript
10
7
2.21\times 10^{-7}
2.21 × 10 start_POSTSUPERSCRIPT - 7 end_POSTSUPERSCRIPT


[2,1,1]


2.21
×
𝟏𝟎
−
𝟕
2.21
superscript
10
7
{\bf 2.21\times 10^{-7}}
bold_2.21 × bold_10 start_POSTSUPERSCRIPT - bold_7 end_POSTSUPERSCRIPT


1.25
×
10
−
6
1.25
superscript
10
6
1.25\times 10^{-6}
1.25 × 10 start_POSTSUPERSCRIPT - 6 end_POSTSUPERSCRIPT






spherical harmonics 
(
m
=
1
,
n
=
1
)
formulae-sequence
𝑚
1
𝑛
1
(m=1,n=1)
( italic_m = 1 , italic_n = 1 )




sph
⁢
_
⁢
harm
⁢
(
1
,
1
,
x
,
y
)
sph
_
harm
1
1
𝑥
𝑦
{\rm sph\_harm}(1,1,x,y)
roman_sph _ roman_harm ( 1 , 1 , italic_x , italic_y )


[2,2,1]


7.86
×
10
−
4
7.86
superscript
10
4
7.86\times 10^{-4}
7.86 × 10 start_POSTSUPERSCRIPT - 4 end_POSTSUPERSCRIPT


[2,3,2,1]


1.22
×
𝟏𝟎
−
𝟒
1.22
superscript
10
4
{\bf 1.22\times 10^{-4}}
bold_1.22 × bold_10 start_POSTSUPERSCRIPT - bold_4 end_POSTSUPERSCRIPT


6.70
×
10
−
4
6.70
superscript
10
4
6.70\times 10^{-4}
6.70 × 10 start_POSTSUPERSCRIPT - 4 end_POSTSUPERSCRIPT






spherical harmonics 
(
m
=
0
,
n
=
2
)
formulae-sequence
𝑚
0
𝑛
2
(m=0,n=2)
( italic_m = 0 , italic_n = 2 )




sph
⁢
_
⁢
harm
⁢
(
0
,
2
,
x
,
y
)
sph
_
harm
0
2
𝑥
𝑦
{\rm sph\_harm}(0,2,x,y)
roman_sph _ roman_harm ( 0 , 2 , italic_x , italic_y )


[2,1,1]


1.95
×
10
−
7
1.95
superscript
10
7
1.95\times 10^{-7}
1.95 × 10 start_POSTSUPERSCRIPT - 7 end_POSTSUPERSCRIPT


[2,1,1]


1.95
×
𝟏𝟎
−
𝟕
1.95
superscript
10
7
{\bf 1.95\times 10^{-7}}
bold_1.95 × bold_10 start_POSTSUPERSCRIPT - bold_7 end_POSTSUPERSCRIPT


2.85
×
10
−
6
2.85
superscript
10
6
2.85\times 10^{-6}
2.85 × 10 start_POSTSUPERSCRIPT - 6 end_POSTSUPERSCRIPT






spherical harmonics 
(
m
=
1
,
n
=
2
)
formulae-sequence
𝑚
1
𝑛
2
(m=1,n=2)
( italic_m = 1 , italic_n = 2 )




sph
⁢
_
⁢
harm
⁢
(
1
,
2
,
x
,
y
)
sph
_
harm
1
2
𝑥
𝑦
{\rm sph\_harm}(1,2,x,y)
roman_sph _ roman_harm ( 1 , 2 , italic_x , italic_y )


[2,2,1]


4.70
×
10
−
4
4.70
superscript
10
4
4.70\times 10^{-4}
4.70 × 10 start_POSTSUPERSCRIPT - 4 end_POSTSUPERSCRIPT


[2,2,1,1]


1.50
×
𝟏𝟎
−
𝟓
1.50
superscript
10
5
{\bf 1.50\times 10^{-5}}
bold_1.50 × bold_10 start_POSTSUPERSCRIPT - bold_5 end_POSTSUPERSCRIPT


1.84
×
10
−
3
1.84
superscript
10
3
1.84\times 10^{-3}
1.84 × 10 start_POSTSUPERSCRIPT - 3 end_POSTSUPERSCRIPT






spherical harmonics 
(
m
=
2
,
n
=
2
)
formulae-sequence
𝑚
2
𝑛
2
(m=2,n=2)
( italic_m = 2 , italic_n = 2 )




sph
⁢
_
⁢
harm
⁢
(
2
,
2
,
x
,
y
)
sph
_
harm
2
2
𝑥
𝑦
{\rm sph\_harm}(2,2,x,y)
roman_sph _ roman_harm ( 2 , 2 , italic_x , italic_y )


[2,2,1]


1.12
×
10
−
3
1.12
superscript
10
3
1.12\times 10^{-3}
1.12 × 10 start_POSTSUPERSCRIPT - 3 end_POSTSUPERSCRIPT


[2,2,3,2,1]


9.45
×
𝟏𝟎
−
𝟓
9.45
superscript
10
5
{\bf 9.45\times 10^{-5}}
bold_9.45 × bold_10 start_POSTSUPERSCRIPT - bold_5 end_POSTSUPERSCRIPT


6.21
×
10
−
4
6.21
superscript
10
4
6.21\times 10^{-4}
6.21 × 10 start_POSTSUPERSCRIPT - 4 end_POSTSUPERSCRIPT








Table 2: 
Special functions










3.3 
Feynman datasets




The setup in Section 
3.1
 is when we clearly know “true” KAN shapes. The setup in Section 
3.2
 is when we clearly do 
not
 know “true” KAN shapes. This part investigates a setup lying in the middle: Given the structure of the dataset, we may construct KANs by hand, but we are not sure if they are optimal. In this regime, it is interesting to compare human-constructed KANs and auto-discovered KANs via pruning (techniques in Section 
2.5.1
).












Feynman Eq.


Original Formula


Dimensionless formula


Variables




 






Human-constructed




KAN shape






 






Pruned




KAN shape




(smallest shape




that achieves




RMSE < 
10
−
2
superscript
10
2
10^{-2}
10 start_POSTSUPERSCRIPT - 2 end_POSTSUPERSCRIPT
)






 






Pruned




KAN shape




(lowest loss)






 






Human-constructed




KAN loss




(lowest test RMSE)






 






Pruned




KAN loss




(lowest test RMSE)






 






Unpruned




KAN loss




(lowest test RMSE)






 






MLP




loss




(lowest test RMSE)








I.6.2


exp
⁢
(
−
θ
2
2
⁢
σ
2
)
/
2
⁢
π
⁢
σ
2
exp
superscript
𝜃
2
2
superscript
𝜎
2
2
𝜋
superscript
𝜎
2
{\rm exp}(-\frac{\theta^{2}}{2\sigma^{2}})/\sqrt{2\pi\sigma^{2}}
roman_exp ( - divide start_ARG italic_θ start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT end_ARG start_ARG 2 italic_σ start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT end_ARG ) / square-root start_ARG 2 italic_π italic_σ start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT end_ARG


exp
⁢
(
−
θ
2
2
⁢
σ
2
)
/
2
⁢
π
⁢
σ
2
exp
superscript
𝜃
2
2
superscript
𝜎
2
2
𝜋
superscript
𝜎
2
{\rm exp}(-\frac{\theta^{2}}{2\sigma^{2}})/\sqrt{2\pi\sigma^{2}}
roman_exp ( - divide start_ARG italic_θ start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT end_ARG start_ARG 2 italic_σ start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT end_ARG ) / square-root start_ARG 2 italic_π italic_σ start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT end_ARG


θ
,
σ
𝜃
𝜎
\theta,\sigma
italic_θ , italic_σ


[2,2,1,1]


[2,2,1]


[2,2,1,1]


7.66
×
10
−
5
7.66
superscript
10
5
7.66\times 10^{-5}
7.66 × 10 start_POSTSUPERSCRIPT - 5 end_POSTSUPERSCRIPT


2.86
×
𝟏𝟎
−
𝟓
2.86
superscript
10
5
{\bf 2.86\times 10^{-5}}
bold_2.86 × bold_10 start_POSTSUPERSCRIPT - bold_5 end_POSTSUPERSCRIPT


4.60
×
10
−
5
4.60
superscript
10
5
4.60\times 10^{-5}
4.60 × 10 start_POSTSUPERSCRIPT - 5 end_POSTSUPERSCRIPT


1.45
×
10
−
4
1.45
superscript
10
4
1.45\times 10^{-4}
1.45 × 10 start_POSTSUPERSCRIPT - 4 end_POSTSUPERSCRIPT






I.6.2b


exp
⁢
(
−
(
θ
−
θ
1
)
2
2
⁢
σ
2
)
/
2
⁢
π
⁢
σ
2
exp
superscript
𝜃
subscript
𝜃
1
2
2
superscript
𝜎
2
2
𝜋
superscript
𝜎
2
{\rm exp}(-\frac{(\theta-\theta_{1})^{2}}{2\sigma^{2}})/\sqrt{2\pi\sigma^{2}}
roman_exp ( - divide start_ARG ( italic_θ - italic_θ start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT ) start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT end_ARG start_ARG 2 italic_σ start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT end_ARG ) / square-root start_ARG 2 italic_π italic_σ start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT end_ARG


exp
⁢
(
−
(
θ
−
θ
1
)
2
2
⁢
σ
2
)
/
2
⁢
π
⁢
σ
2
exp
superscript
𝜃
subscript
𝜃
1
2
2
superscript
𝜎
2
2
𝜋
superscript
𝜎
2
{\rm exp}(-\frac{(\theta-\theta_{1})^{2}}{2\sigma^{2}})/\sqrt{2\pi\sigma^{2}}
roman_exp ( - divide start_ARG ( italic_θ - italic_θ start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT ) start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT end_ARG start_ARG 2 italic_σ start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT end_ARG ) / square-root start_ARG 2 italic_π italic_σ start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT end_ARG


θ
,
θ
1
,
σ
𝜃
subscript
𝜃
1
𝜎
\theta,\theta_{1},\sigma
italic_θ , italic_θ start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT , italic_σ


[3,2,2,1,1]


[3,4,1]


[3,2,2,1,1]


1.22
×
10
−
3
1.22
superscript
10
3
1.22\times 10^{-3}
1.22 × 10 start_POSTSUPERSCRIPT - 3 end_POSTSUPERSCRIPT


4.45
×
𝟏𝟎
−
𝟒
4.45
superscript
10
4
{\bf 4.45\times 10^{-4}}
bold_4.45 × bold_10 start_POSTSUPERSCRIPT - bold_4 end_POSTSUPERSCRIPT


1.25
×
10
−
3
1.25
superscript
10
3
1.25\times 10^{-3}
1.25 × 10 start_POSTSUPERSCRIPT - 3 end_POSTSUPERSCRIPT


7.40
×
10
−
4
7.40
superscript
10
4
7.40\times 10^{-4}
7.40 × 10 start_POSTSUPERSCRIPT - 4 end_POSTSUPERSCRIPT






I.9.18


G
⁢
m
1
⁢
m
2
(
x
2
−
x
1
)
2
+
(
y
2
−
y
1
)
2
+
(
z
2
−
z
1
)
2
𝐺
subscript
𝑚
1
subscript
𝑚
2
superscript
subscript
𝑥
2
subscript
𝑥
1
2
superscript
subscript
𝑦
2
subscript
𝑦
1
2
superscript
subscript
𝑧
2
subscript
𝑧
1
2
\frac{Gm_{1}m_{2}}{(x_{2}-x_{1})^{2}+(y_{2}-y_{1})^{2}+(z_{2}-z_{1})^{2}}
divide start_ARG italic_G italic_m start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT italic_m start_POSTSUBSCRIPT 2 end_POSTSUBSCRIPT end_ARG start_ARG ( italic_x start_POSTSUBSCRIPT 2 end_POSTSUBSCRIPT - italic_x start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT ) start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT + ( italic_y start_POSTSUBSCRIPT 2 end_POSTSUBSCRIPT - italic_y start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT ) start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT + ( italic_z start_POSTSUBSCRIPT 2 end_POSTSUBSCRIPT - italic_z start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT ) start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT end_ARG


a
(
b
−
1
)
2
+
(
c
−
d
)
2
+
(
e
−
f
)
2
𝑎
superscript
𝑏
1
2
superscript
𝑐
𝑑
2
superscript
𝑒
𝑓
2
\frac{a}{(b-1)^{2}+(c-d)^{2}+(e-f)^{2}}
divide start_ARG italic_a end_ARG start_ARG ( italic_b - 1 ) start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT + ( italic_c - italic_d ) start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT + ( italic_e - italic_f ) start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT end_ARG


a
,
b
,
c
,
d
,
e
,
f
𝑎
𝑏
𝑐
𝑑
𝑒
𝑓
a,b,c,d,e,f
italic_a , italic_b , italic_c , italic_d , italic_e , italic_f


[6,4,2,1,1]


[6,4,1,1]


[6,4,1,1]


1.48
×
𝟏𝟎
−
𝟑
1.48
superscript
10
3
{\bf 1.48\times 10^{-3}}
bold_1.48 × bold_10 start_POSTSUPERSCRIPT - bold_3 end_POSTSUPERSCRIPT


8.62
×
10
−
3
8.62
superscript
10
3
8.62\times 10^{-3}
8.62 × 10 start_POSTSUPERSCRIPT - 3 end_POSTSUPERSCRIPT


6.56
×
10
−
3
6.56
superscript
10
3
6.56\times 10^{-3}
6.56 × 10 start_POSTSUPERSCRIPT - 3 end_POSTSUPERSCRIPT


1.59
×
10
−
3
1.59
superscript
10
3
1.59\times 10^{-3}
1.59 × 10 start_POSTSUPERSCRIPT - 3 end_POSTSUPERSCRIPT






I.12.11


q
⁢
(
E
f
+
B
⁢
v
⁢
sin
⁢
θ
)
𝑞
subscript
𝐸
𝑓
𝐵
𝑣
sin
𝜃
q(E_{f}+Bv{\rm sin}\theta)
italic_q ( italic_E start_POSTSUBSCRIPT italic_f end_POSTSUBSCRIPT + italic_B italic_v roman_sin italic_θ )


1
+
a
⁢
sin
⁢
θ
1
𝑎
sin
𝜃
1+a{\rm sin}\theta
1 + italic_a roman_sin italic_θ


a
,
θ
𝑎
𝜃
a,\theta
italic_a , italic_θ


[2,2,2,1]


[2,2,1]


[2,2,1]


2.07
×
10
−
3
2.07
superscript
10
3
2.07\times 10^{-3}
2.07 × 10 start_POSTSUPERSCRIPT - 3 end_POSTSUPERSCRIPT


1.39
×
10
−
3
1.39
superscript
10
3
1.39\times 10^{-3}
1.39 × 10 start_POSTSUPERSCRIPT - 3 end_POSTSUPERSCRIPT


9.13
×
10
−
4
9.13
superscript
10
4
9.13\times 10^{-4}
9.13 × 10 start_POSTSUPERSCRIPT - 4 end_POSTSUPERSCRIPT


6.71
×
𝟏𝟎
−
𝟒
6.71
superscript
10
4
{\bf 6.71\times 10^{-4}}
bold_6.71 × bold_10 start_POSTSUPERSCRIPT - bold_4 end_POSTSUPERSCRIPT






I.13.12


G
⁢
m
1
⁢
m
2
⁢
(
1
r
2
−
1
r
1
)
𝐺
subscript
𝑚
1
subscript
𝑚
2
1
subscript
𝑟
2
1
subscript
𝑟
1
Gm_{1}m_{2}(\frac{1}{r_{2}}-\frac{1}{r_{1}})
italic_G italic_m start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT italic_m start_POSTSUBSCRIPT 2 end_POSTSUBSCRIPT ( divide start_ARG 1 end_ARG start_ARG italic_r start_POSTSUBSCRIPT 2 end_POSTSUBSCRIPT end_ARG - divide start_ARG 1 end_ARG start_ARG italic_r start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT end_ARG )


a
⁢
(
1
b
−
1
)
𝑎
1
𝑏
1
a(\frac{1}{b}-1)
italic_a ( divide start_ARG 1 end_ARG start_ARG italic_b end_ARG - 1 )


a
,
b
𝑎
𝑏
a,b
italic_a , italic_b


[2,2,1]


[2,2,1]


[2,2,1]


7.22
×
10
−
3
7.22
superscript
10
3
7.22\times 10^{-3}
7.22 × 10 start_POSTSUPERSCRIPT - 3 end_POSTSUPERSCRIPT


4.81
×
10
−
3
4.81
superscript
10
3
4.81\times 10^{-3}
4.81 × 10 start_POSTSUPERSCRIPT - 3 end_POSTSUPERSCRIPT


2.72
×
10
−
3
2.72
superscript
10
3
2.72\times 10^{-3}
2.72 × 10 start_POSTSUPERSCRIPT - 3 end_POSTSUPERSCRIPT


1.42
×
𝟏𝟎
−
𝟑
1.42
superscript
10
3
{\bf 1.42\times 10^{-3}}
bold_1.42 × bold_10 start_POSTSUPERSCRIPT - bold_3 end_POSTSUPERSCRIPT






I.15.3x


x
−
u
⁢
t
1
−
(
u
c
)
2
𝑥
𝑢
𝑡
1
superscript
𝑢
𝑐
2
\frac{x-ut}{\sqrt{1-(\frac{u}{c})^{2}}}
divide start_ARG italic_x - italic_u italic_t end_ARG start_ARG square-root start_ARG 1 - ( divide start_ARG italic_u end_ARG start_ARG italic_c end_ARG ) start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT end_ARG end_ARG


1
−
a
1
−
b
2
1
𝑎
1
superscript
𝑏
2
\frac{1-a}{\sqrt{1-b^{2}}}
divide start_ARG 1 - italic_a end_ARG start_ARG square-root start_ARG 1 - italic_b start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT end_ARG end_ARG


a
,
b
𝑎
𝑏
a,b
italic_a , italic_b


[2,2,1,1]


[2,1,1]


[2,2,1,1,1]


7.35
×
10
−
3
7.35
superscript
10
3
7.35\times 10^{-3}
7.35 × 10 start_POSTSUPERSCRIPT - 3 end_POSTSUPERSCRIPT


1.58
×
10
−
3
1.58
superscript
10
3
1.58\times 10^{-3}
1.58 × 10 start_POSTSUPERSCRIPT - 3 end_POSTSUPERSCRIPT


1.14
×
10
−
3
1.14
superscript
10
3
1.14\times 10^{-3}
1.14 × 10 start_POSTSUPERSCRIPT - 3 end_POSTSUPERSCRIPT


8.54
×
𝟏𝟎
−
𝟒
8.54
superscript
10
4
{\bf 8.54\times 10^{-4}}
bold_8.54 × bold_10 start_POSTSUPERSCRIPT - bold_4 end_POSTSUPERSCRIPT






I.16.6


u
+
v
1
+
u
⁢
v
c
2
𝑢
𝑣
1
𝑢
𝑣
superscript
𝑐
2
\frac{u+v}{1+\frac{uv}{c^{2}}}
divide start_ARG italic_u + italic_v end_ARG start_ARG 1 + divide start_ARG italic_u italic_v end_ARG start_ARG italic_c start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT end_ARG end_ARG


a
+
b
1
+
a
⁢
b
𝑎
𝑏
1
𝑎
𝑏
\frac{a+b}{1+ab}
divide start_ARG italic_a + italic_b end_ARG start_ARG 1 + italic_a italic_b end_ARG


a
,
b
𝑎
𝑏
a,b
italic_a , italic_b


[2,2,2,2,2,1]


[2,2,1]


[2,2,1]


1.06
×
10
−
3
1.06
superscript
10
3
1.06\times 10^{-3}
1.06 × 10 start_POSTSUPERSCRIPT - 3 end_POSTSUPERSCRIPT


1.19
×
10
−
3
1.19
superscript
10
3
1.19\times 10^{-3}
1.19 × 10 start_POSTSUPERSCRIPT - 3 end_POSTSUPERSCRIPT


1.53
×
10
−
3
1.53
superscript
10
3
1.53\times 10^{-3}
1.53 × 10 start_POSTSUPERSCRIPT - 3 end_POSTSUPERSCRIPT


6.20
×
𝟏𝟎
−
𝟒
6.20
superscript
10
4
{\bf 6.20\times 10^{-4}}
bold_6.20 × bold_10 start_POSTSUPERSCRIPT - bold_4 end_POSTSUPERSCRIPT






I.18.4


m
1
⁢
r
1
+
m
2
⁢
r
2
m
1
+
m
2
subscript
𝑚
1
subscript
𝑟
1
subscript
𝑚
2
subscript
𝑟
2
subscript
𝑚
1
subscript
𝑚
2
\frac{m_{1}r_{1}+m_{2}r_{2}}{m_{1}+m_{2}}
divide start_ARG italic_m start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT italic_r start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT + italic_m start_POSTSUBSCRIPT 2 end_POSTSUBSCRIPT italic_r start_POSTSUBSCRIPT 2 end_POSTSUBSCRIPT end_ARG start_ARG italic_m start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT + italic_m start_POSTSUBSCRIPT 2 end_POSTSUBSCRIPT end_ARG


1
+
a
⁢
b
1
+
a
1
𝑎
𝑏
1
𝑎
\frac{1+ab}{1+a}
divide start_ARG 1 + italic_a italic_b end_ARG start_ARG 1 + italic_a end_ARG


a
,
b
𝑎
𝑏
a,b
italic_a , italic_b


[2,2,2,1,1]


[2,2,1]


[2,2,1]


3.92
×
10
−
4
3.92
superscript
10
4
3.92\times 10^{-4}
3.92 × 10 start_POSTSUPERSCRIPT - 4 end_POSTSUPERSCRIPT


1.50
×
𝟏𝟎
−
𝟒
1.50
superscript
10
4
{\bf 1.50\times 10^{-4}}
bold_1.50 × bold_10 start_POSTSUPERSCRIPT - bold_4 end_POSTSUPERSCRIPT


1.32
×
10
−
3
1.32
superscript
10
3
1.32\times 10^{-3}
1.32 × 10 start_POSTSUPERSCRIPT - 3 end_POSTSUPERSCRIPT


3.68
×
10
−
4
3.68
superscript
10
4
3.68\times 10^{-4}
3.68 × 10 start_POSTSUPERSCRIPT - 4 end_POSTSUPERSCRIPT






I.26.2


arcsin
⁢
(
n
⁢
sin
⁢
θ
2
)
arcsin
𝑛
sin
subscript
𝜃
2
{\rm arcsin}(n{\rm sin}\theta_{2})
roman_arcsin ( italic_n roman_sin italic_θ start_POSTSUBSCRIPT 2 end_POSTSUBSCRIPT )


arcsin
⁢
(
n
⁢
sin
⁢
θ
2
)
arcsin
𝑛
sin
subscript
𝜃
2
{\rm arcsin}(n{\rm sin}\theta_{2})
roman_arcsin ( italic_n roman_sin italic_θ start_POSTSUBSCRIPT 2 end_POSTSUBSCRIPT )


n
,
θ
2
𝑛
subscript
𝜃
2
n,\theta_{2}
italic_n , italic_θ start_POSTSUBSCRIPT 2 end_POSTSUBSCRIPT


[2,2,2,1,1]


[2,2,1]


[2,2,2,1,1]


1.22
×
10
−
1
1.22
superscript
10
1
1.22\times 10^{-1}
1.22 × 10 start_POSTSUPERSCRIPT - 1 end_POSTSUPERSCRIPT


7.90
×
𝟏𝟎
−
𝟒
7.90
superscript
10
4
{\bf 7.90\times 10^{-4}}
bold_7.90 × bold_10 start_POSTSUPERSCRIPT - bold_4 end_POSTSUPERSCRIPT


8.63
×
10
−
4
8.63
superscript
10
4
8.63\times 10^{-4}
8.63 × 10 start_POSTSUPERSCRIPT - 4 end_POSTSUPERSCRIPT


1.24
×
10
−
3
1.24
superscript
10
3
1.24\times 10^{-3}
1.24 × 10 start_POSTSUPERSCRIPT - 3 end_POSTSUPERSCRIPT






I.27.6


1
1
d
1
+
n
d
2
1
1
subscript
𝑑
1
𝑛
subscript
𝑑
2
\frac{1}{\frac{1}{d_{1}}+\frac{n}{d_{2}}}
divide start_ARG 1 end_ARG start_ARG divide start_ARG 1 end_ARG start_ARG italic_d start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT end_ARG + divide start_ARG italic_n end_ARG start_ARG italic_d start_POSTSUBSCRIPT 2 end_POSTSUBSCRIPT end_ARG end_ARG


1
1
+
a
⁢
b
1
1
𝑎
𝑏
\frac{1}{1+ab}
divide start_ARG 1 end_ARG start_ARG 1 + italic_a italic_b end_ARG


a
,
b
𝑎
𝑏
a,b
italic_a , italic_b


[2,2,1,1]


[2,1,1]


[2,1,1]


2.22
×
10
−
4
2.22
superscript
10
4
2.22\times 10^{-4}
2.22 × 10 start_POSTSUPERSCRIPT - 4 end_POSTSUPERSCRIPT


1.94
×
𝟏𝟎
−
𝟒
1.94
superscript
10
4
{\bf 1.94\times 10^{-4}}
bold_1.94 × bold_10 start_POSTSUPERSCRIPT - bold_4 end_POSTSUPERSCRIPT


2.14
×
10
−
4
2.14
superscript
10
4
2.14\times 10^{-4}
2.14 × 10 start_POSTSUPERSCRIPT - 4 end_POSTSUPERSCRIPT


2.46
×
10
−
4
2.46
superscript
10
4
2.46\times 10^{-4}
2.46 × 10 start_POSTSUPERSCRIPT - 4 end_POSTSUPERSCRIPT






I.29.16


x
1
2
+
x
2
2
−
2
⁢
x
1
⁢
x
2
⁢
cos
⁢
(
θ
1
−
θ
2
)
superscript
subscript
𝑥
1
2
superscript
subscript
𝑥
2
2
2
subscript
𝑥
1
subscript
𝑥
2
cos
subscript
𝜃
1
subscript
𝜃
2
\sqrt{x_{1}^{2}+x_{2}^{2}-2x_{1}x_{2}{\rm cos}(\theta_{1}-\theta_{2})}
square-root start_ARG italic_x start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT + italic_x start_POSTSUBSCRIPT 2 end_POSTSUBSCRIPT start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT - 2 italic_x start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT italic_x start_POSTSUBSCRIPT 2 end_POSTSUBSCRIPT roman_cos ( italic_θ start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT - italic_θ start_POSTSUBSCRIPT 2 end_POSTSUBSCRIPT ) end_ARG


1
+
a
2
−
2
⁢
a
⁢
cos
⁢
(
θ
1
−
θ
2
)
1
superscript
𝑎
2
2
𝑎
cos
subscript
𝜃
1
subscript
𝜃
2
\sqrt{1+a^{2}-2a{\rm cos}(\theta_{1}-\theta_{2})}
square-root start_ARG 1 + italic_a start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT - 2 italic_a roman_cos ( italic_θ start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT - italic_θ start_POSTSUBSCRIPT 2 end_POSTSUBSCRIPT ) end_ARG


a
,
θ
1
,
θ
2
𝑎
subscript
𝜃
1
subscript
𝜃
2
a,\theta_{1},\theta_{2}
italic_a , italic_θ start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT , italic_θ start_POSTSUBSCRIPT 2 end_POSTSUBSCRIPT


[3,2,2,3,2,1,1]


[3,2,2,1]


[3,2,3,1]


2.36
×
10
−
1
2.36
superscript
10
1
2.36\times 10^{-1}
2.36 × 10 start_POSTSUPERSCRIPT - 1 end_POSTSUPERSCRIPT


3.99
×
10
−
3
3.99
superscript
10
3
3.99\times 10^{-3}
3.99 × 10 start_POSTSUPERSCRIPT - 3 end_POSTSUPERSCRIPT


3.20
×
𝟏𝟎
−
𝟑
3.20
superscript
10
3
{\bf 3.20\times 10^{-3}}
bold_3.20 × bold_10 start_POSTSUPERSCRIPT - bold_3 end_POSTSUPERSCRIPT


4.64
×
10
−
3
4.64
superscript
10
3
4.64\times 10^{-3}
4.64 × 10 start_POSTSUPERSCRIPT - 3 end_POSTSUPERSCRIPT






I.30.3


I
∗
,
0
⁢
sin
2
⁢
(
n
⁢
θ
2
)
sin
2
⁢
(
θ
2
)
subscript
𝐼
0
superscript
sin
2
𝑛
𝜃
2
superscript
sin
2
𝜃
2
I_{*,0}\frac{{\rm sin}^{2}(\frac{n\theta}{2})}{{\rm sin}^{2}(\frac{\theta}{2})}
italic_I start_POSTSUBSCRIPT ∗ , 0 end_POSTSUBSCRIPT divide start_ARG roman_sin start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT ( divide start_ARG italic_n italic_θ end_ARG start_ARG 2 end_ARG ) end_ARG start_ARG roman_sin start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT ( divide start_ARG italic_θ end_ARG start_ARG 2 end_ARG ) end_ARG


sin
2
⁢
(
n
⁢
θ
2
)
sin
2
⁢
(
θ
2
)
superscript
sin
2
𝑛
𝜃
2
superscript
sin
2
𝜃
2
\frac{{\rm sin}^{2}(\frac{n\theta}{2})}{{\rm sin}^{2}(\frac{\theta}{2})}
divide start_ARG roman_sin start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT ( divide start_ARG italic_n italic_θ end_ARG start_ARG 2 end_ARG ) end_ARG start_ARG roman_sin start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT ( divide start_ARG italic_θ end_ARG start_ARG 2 end_ARG ) end_ARG


n
,
θ
𝑛
𝜃
n,\theta
italic_n , italic_θ


[2,3,2,2,1,1]


[2,4,3,1]


[2,3,2,3,1,1]


3.85
×
10
−
1
3.85
superscript
10
1
3.85\times 10^{-1}
3.85 × 10 start_POSTSUPERSCRIPT - 1 end_POSTSUPERSCRIPT


1.03
×
𝟏𝟎
−
𝟑
1.03
superscript
10
3
{\bf 1.03\times 10^{-3}}
bold_1.03 × bold_10 start_POSTSUPERSCRIPT - bold_3 end_POSTSUPERSCRIPT


1.11
×
10
−
2
1.11
superscript
10
2
1.11\times 10^{-2}
1.11 × 10 start_POSTSUPERSCRIPT - 2 end_POSTSUPERSCRIPT


1.50
×
10
−
2
1.50
superscript
10
2
1.50\times 10^{-2}
1.50 × 10 start_POSTSUPERSCRIPT - 2 end_POSTSUPERSCRIPT






I.30.5


arcsin
⁢
(
λ
n
⁢
d
)
arcsin
𝜆
𝑛
𝑑
{\rm arcsin}(\frac{\lambda}{nd})
roman_arcsin ( divide start_ARG italic_λ end_ARG start_ARG italic_n italic_d end_ARG )


arcsin
⁢
(
a
n
)
arcsin
𝑎
𝑛
{\rm arcsin}(\frac{a}{n})
roman_arcsin ( divide start_ARG italic_a end_ARG start_ARG italic_n end_ARG )


a
,
n
𝑎
𝑛
a,n
italic_a , italic_n


[2,1,1]


[2,1,1]


[2,1,1,1,1,1]


2.23
×
10
−
4
2.23
superscript
10
4
2.23\times 10^{-4}
2.23 × 10 start_POSTSUPERSCRIPT - 4 end_POSTSUPERSCRIPT


3.49
×
𝟏𝟎
−
𝟓
3.49
superscript
10
5
{\bf 3.49\times 10^{-5}}
bold_3.49 × bold_10 start_POSTSUPERSCRIPT - bold_5 end_POSTSUPERSCRIPT


6.92
×
10
−
5
6.92
superscript
10
5
6.92\times 10^{-5}
6.92 × 10 start_POSTSUPERSCRIPT - 5 end_POSTSUPERSCRIPT


9.45
×
10
−
5
9.45
superscript
10
5
9.45\times 10^{-5}
9.45 × 10 start_POSTSUPERSCRIPT - 5 end_POSTSUPERSCRIPT






I.37.4


I
∗
=
I
1
+
I
2
+
2
⁢
I
1
⁢
I
2
⁢
cos
⁢
δ
subscript
𝐼
subscript
𝐼
1
subscript
𝐼
2
2
subscript
𝐼
1
subscript
𝐼
2
cos
𝛿
I_{*}=I_{1}+I_{2}+2\sqrt{I_{1}I_{2}}{\rm cos}\delta
italic_I start_POSTSUBSCRIPT ∗ end_POSTSUBSCRIPT = italic_I start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT + italic_I start_POSTSUBSCRIPT 2 end_POSTSUBSCRIPT + 2 square-root start_ARG italic_I start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT italic_I start_POSTSUBSCRIPT 2 end_POSTSUBSCRIPT end_ARG roman_cos italic_δ


1
+
a
+
2
⁢
a
⁢
cos
⁢
δ
1
𝑎
2
𝑎
cos
𝛿
1+a+2\sqrt{a}{\rm cos}\delta
1 + italic_a + 2 square-root start_ARG italic_a end_ARG roman_cos italic_δ


a
,
δ
𝑎
𝛿
a,\delta
italic_a , italic_δ


[2,3,2,1]


[2,2,1]


[2,2,1]


7.57
×
10
−
5
7.57
superscript
10
5
7.57\times 10^{-5}
7.57 × 10 start_POSTSUPERSCRIPT - 5 end_POSTSUPERSCRIPT


4.91
×
𝟏𝟎
−
𝟔
4.91
superscript
10
6
{\bf 4.91\times 10^{-6}}
bold_4.91 × bold_10 start_POSTSUPERSCRIPT - bold_6 end_POSTSUPERSCRIPT


3.41
×
10
−
4
3.41
superscript
10
4
3.41\times 10^{-4}
3.41 × 10 start_POSTSUPERSCRIPT - 4 end_POSTSUPERSCRIPT


5.67
×
10
−
4
5.67
superscript
10
4
5.67\times 10^{-4}
5.67 × 10 start_POSTSUPERSCRIPT - 4 end_POSTSUPERSCRIPT






I.40.1


n
0
⁢
exp
⁢
(
−
m
⁢
g
⁢
x
k
b
⁢
T
)
subscript
𝑛
0
exp
𝑚
𝑔
𝑥
subscript
𝑘
𝑏
𝑇
n_{0}{\rm exp}(-\frac{mgx}{k_{b}T})
italic_n start_POSTSUBSCRIPT 0 end_POSTSUBSCRIPT roman_exp ( - divide start_ARG italic_m italic_g italic_x end_ARG start_ARG italic_k start_POSTSUBSCRIPT italic_b end_POSTSUBSCRIPT italic_T end_ARG )


n
0
⁢
e
−
a
subscript
𝑛
0
superscript
𝑒
𝑎
n_{0}e^{-a}
italic_n start_POSTSUBSCRIPT 0 end_POSTSUBSCRIPT italic_e start_POSTSUPERSCRIPT - italic_a end_POSTSUPERSCRIPT


n
0
,
a
subscript
𝑛
0
𝑎
n_{0},a
italic_n start_POSTSUBSCRIPT 0 end_POSTSUBSCRIPT , italic_a


[2,1,1]


[2,2,1]


[2,2,1,1,1,2,1]


3.45
×
10
−
3
3.45
superscript
10
3
3.45\times 10^{-3}
3.45 × 10 start_POSTSUPERSCRIPT - 3 end_POSTSUPERSCRIPT


5.01
×
10
−
4
5.01
superscript
10
4
5.01\times 10^{-4}
5.01 × 10 start_POSTSUPERSCRIPT - 4 end_POSTSUPERSCRIPT


3.12
×
𝟏𝟎
−
𝟒
3.12
superscript
10
4
{\bf 3.12\times 10^{-4}}
bold_3.12 × bold_10 start_POSTSUPERSCRIPT - bold_4 end_POSTSUPERSCRIPT


3.99
×
10
−
4
3.99
superscript
10
4
3.99\times 10^{-4}
3.99 × 10 start_POSTSUPERSCRIPT - 4 end_POSTSUPERSCRIPT






I.44.4


n
⁢
k
b
⁢
T
⁢
ln
⁢
(
V
2
V
1
)
𝑛
subscript
𝑘
𝑏
𝑇
ln
subscript
𝑉
2
subscript
𝑉
1
nk_{b}T{\rm ln}(\frac{V_{2}}{V_{1}})
italic_n italic_k start_POSTSUBSCRIPT italic_b end_POSTSUBSCRIPT italic_T roman_ln ( divide start_ARG italic_V start_POSTSUBSCRIPT 2 end_POSTSUBSCRIPT end_ARG start_ARG italic_V start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT end_ARG )


n
⁢
ln
⁢
a
𝑛
ln
𝑎
n{\rm ln}a
italic_n roman_ln italic_a


n
,
a
𝑛
𝑎
n,a
italic_n , italic_a


[2,2,1]


[2,2,1]


[2,2,1]


2.30
×
𝟏𝟎
−
𝟓
2.30
superscript
10
5
{\bf 2.30\times 10^{-5}}
bold_2.30 × bold_10 start_POSTSUPERSCRIPT - bold_5 end_POSTSUPERSCRIPT


2.43
×
10
−
5
2.43
superscript
10
5
2.43\times 10^{-5}
2.43 × 10 start_POSTSUPERSCRIPT - 5 end_POSTSUPERSCRIPT


1.10
×
10
−
4
1.10
superscript
10
4
1.10\times 10^{-4}
1.10 × 10 start_POSTSUPERSCRIPT - 4 end_POSTSUPERSCRIPT


3.99
×
10
−
4
3.99
superscript
10
4
3.99\times 10^{-4}
3.99 × 10 start_POSTSUPERSCRIPT - 4 end_POSTSUPERSCRIPT






I.50.26


x
1
⁢
(
cos
⁢
(
ω
⁢
t
)
+
α
⁢
cos
2
⁢
(
w
⁢
t
)
)
subscript
𝑥
1
cos
𝜔
𝑡
𝛼
superscript
cos
2
𝑤
𝑡
x_{1}({\rm cos}(\omega t)+\alpha{\rm cos}^{2}(wt))
italic_x start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT ( roman_cos ( italic_ω italic_t ) + italic_α roman_cos start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT ( italic_w italic_t ) )


cos
⁢
a
+
α
⁢
cos
2
⁢
a
cos
𝑎
𝛼
superscript
cos
2
𝑎
{\rm cos}a+\alpha{\rm cos}^{2}a
roman_cos italic_a + italic_α roman_cos start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT italic_a


a
,
α
𝑎
𝛼
a,\alpha
italic_a , italic_α


[2,2,3,1]


[2,3,1]


[2,3,2,1]


1.52
×
𝟏𝟎
−
𝟒
1.52
superscript
10
4
{\bf 1.52\times 10^{-4}}
bold_1.52 × bold_10 start_POSTSUPERSCRIPT - bold_4 end_POSTSUPERSCRIPT


5.82
×
10
−
4
5.82
superscript
10
4
5.82\times 10^{-4}
5.82 × 10 start_POSTSUPERSCRIPT - 4 end_POSTSUPERSCRIPT


4.90
×
10
−
4
4.90
superscript
10
4
4.90\times 10^{-4}
4.90 × 10 start_POSTSUPERSCRIPT - 4 end_POSTSUPERSCRIPT


1.53
×
10
−
3
1.53
superscript
10
3
1.53\times 10^{-3}
1.53 × 10 start_POSTSUPERSCRIPT - 3 end_POSTSUPERSCRIPT






II.2.42


k
⁢
(
T
2
−
T
1
)
⁢
A
d
𝑘
subscript
𝑇
2
subscript
𝑇
1
𝐴
𝑑
\frac{k(T_{2}-T_{1})A}{d}
divide start_ARG italic_k ( italic_T start_POSTSUBSCRIPT 2 end_POSTSUBSCRIPT - italic_T start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT ) italic_A end_ARG start_ARG italic_d end_ARG


(
a
−
1
)
⁢
b
𝑎
1
𝑏
(a-1)b
( italic_a - 1 ) italic_b


a
,
b
𝑎
𝑏
a,b
italic_a , italic_b


[2,2,1]


[2,2,1]


[2,2,2,1]


8.54
×
10
−
4
8.54
superscript
10
4
8.54\times 10^{-4}
8.54 × 10 start_POSTSUPERSCRIPT - 4 end_POSTSUPERSCRIPT


7.22
×
10
−
4
7.22
superscript
10
4
7.22\times 10^{-4}
7.22 × 10 start_POSTSUPERSCRIPT - 4 end_POSTSUPERSCRIPT


1.22
×
10
−
3
1.22
superscript
10
3
1.22\times 10^{-3}
1.22 × 10 start_POSTSUPERSCRIPT - 3 end_POSTSUPERSCRIPT


1.81
×
𝟏𝟎
−
𝟒
1.81
superscript
10
4
{\bf 1.81\times 10^{-4}}
bold_1.81 × bold_10 start_POSTSUPERSCRIPT - bold_4 end_POSTSUPERSCRIPT






II.6.15a


3
4
⁢
π
⁢
ϵ
⁢
p
d
⁢
z
r
5
⁢
x
2
+
y
2
3
4
𝜋
italic-ϵ
subscript
𝑝
𝑑
𝑧
superscript
𝑟
5
superscript
𝑥
2
superscript
𝑦
2
\frac{3}{4\pi\epsilon}\frac{p_{d}z}{r^{5}}\sqrt{x^{2}+y^{2}}
divide start_ARG 3 end_ARG start_ARG 4 italic_π italic_ϵ end_ARG divide start_ARG italic_p start_POSTSUBSCRIPT italic_d end_POSTSUBSCRIPT italic_z end_ARG start_ARG italic_r start_POSTSUPERSCRIPT 5 end_POSTSUPERSCRIPT end_ARG square-root start_ARG italic_x start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT + italic_y start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT end_ARG


1
4
⁢
π
⁢
c
⁢
a
2
+
b
2
1
4
𝜋
𝑐
superscript
𝑎
2
superscript
𝑏
2
\frac{1}{4\pi}c\sqrt{a^{2}+b^{2}}
divide start_ARG 1 end_ARG start_ARG 4 italic_π end_ARG italic_c square-root start_ARG italic_a start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT + italic_b start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT end_ARG


a
,
b
,
c
𝑎
𝑏
𝑐
a,b,c
italic_a , italic_b , italic_c


[3,2,2,2,1]


[3,2,1,1]


[3,2,1,1]


2.61
×
10
−
3
2.61
superscript
10
3
2.61\times 10^{-3}
2.61 × 10 start_POSTSUPERSCRIPT - 3 end_POSTSUPERSCRIPT


3.28
×
10
−
3
3.28
superscript
10
3
3.28\times 10^{-3}
3.28 × 10 start_POSTSUPERSCRIPT - 3 end_POSTSUPERSCRIPT


1.35
×
10
−
3
1.35
superscript
10
3
1.35\times 10^{-3}
1.35 × 10 start_POSTSUPERSCRIPT - 3 end_POSTSUPERSCRIPT


5.92
×
𝟏𝟎
−
𝟒
5.92
superscript
10
4
{\bf 5.92\times 10^{-4}}
bold_5.92 × bold_10 start_POSTSUPERSCRIPT - bold_4 end_POSTSUPERSCRIPT






II.11.7


n
0
⁢
(
1
+
p
d
⁢
E
f
⁢
cos
⁢
θ
k
b
⁢
T
)
subscript
𝑛
0
1
subscript
𝑝
𝑑
subscript
𝐸
𝑓
cos
𝜃
subscript
𝑘
𝑏
𝑇
n_{0}(1+\frac{p_{d}E_{f}{\rm cos}\theta}{k_{b}T})
italic_n start_POSTSUBSCRIPT 0 end_POSTSUBSCRIPT ( 1 + divide start_ARG italic_p start_POSTSUBSCRIPT italic_d end_POSTSUBSCRIPT italic_E start_POSTSUBSCRIPT italic_f end_POSTSUBSCRIPT roman_cos italic_θ end_ARG start_ARG italic_k start_POSTSUBSCRIPT italic_b end_POSTSUBSCRIPT italic_T end_ARG )


n
0
⁢
(
1
+
a
⁢
cos
⁢
θ
)
subscript
𝑛
0
1
𝑎
cos
𝜃
n_{0}(1+a{\rm cos}\theta)
italic_n start_POSTSUBSCRIPT 0 end_POSTSUBSCRIPT ( 1 + italic_a roman_cos italic_θ )


n
0
,
a
,
θ
subscript
𝑛
0
𝑎
𝜃
n_{0},a,\theta
italic_n start_POSTSUBSCRIPT 0 end_POSTSUBSCRIPT , italic_a , italic_θ


[3,3,3,2,2,1]


[3,3,1,1]


[3,3,1,1]


7.10
×
10
−
3
7.10
superscript
10
3
7.10\times 10^{-3}
7.10 × 10 start_POSTSUPERSCRIPT - 3 end_POSTSUPERSCRIPT


8.52
×
10
−
3
8.52
superscript
10
3
8.52\times 10^{-3}
8.52 × 10 start_POSTSUPERSCRIPT - 3 end_POSTSUPERSCRIPT


5.03
×
10
−
3
5.03
superscript
10
3
5.03\times 10^{-3}
5.03 × 10 start_POSTSUPERSCRIPT - 3 end_POSTSUPERSCRIPT


5.92
×
𝟏𝟎
−
𝟒
5.92
superscript
10
4
{\bf 5.92\times 10^{-4}}
bold_5.92 × bold_10 start_POSTSUPERSCRIPT - bold_4 end_POSTSUPERSCRIPT






II.11.27


n
⁢
α
1
−
n
⁢
α
3
⁢
ϵ
⁢
E
f
𝑛
𝛼
1
𝑛
𝛼
3
italic-ϵ
subscript
𝐸
𝑓
\frac{n\alpha}{1-\frac{n\alpha}{3}}\epsilon E_{f}
divide start_ARG italic_n italic_α end_ARG start_ARG 1 - divide start_ARG italic_n italic_α end_ARG start_ARG 3 end_ARG end_ARG italic_ϵ italic_E start_POSTSUBSCRIPT italic_f end_POSTSUBSCRIPT


n
⁢
α
1
−
n
⁢
α
3
𝑛
𝛼
1
𝑛
𝛼
3
\frac{n\alpha}{1-\frac{n\alpha}{3}}
divide start_ARG italic_n italic_α end_ARG start_ARG 1 - divide start_ARG italic_n italic_α end_ARG start_ARG 3 end_ARG end_ARG


n
,
α
𝑛
𝛼
n,\alpha
italic_n , italic_α


[2,2,1,2,1]


[2,1,1]


[2,2,1]


2.67
×
10
−
5
2.67
superscript
10
5
2.67\times 10^{-5}
2.67 × 10 start_POSTSUPERSCRIPT - 5 end_POSTSUPERSCRIPT


4.40
×
10
−
5
4.40
superscript
10
5
4.40\times 10^{-5}
4.40 × 10 start_POSTSUPERSCRIPT - 5 end_POSTSUPERSCRIPT


1.43
×
𝟏𝟎
−
𝟓
1.43
superscript
10
5
{\bf 1.43\times 10^{-5}}
bold_1.43 × bold_10 start_POSTSUPERSCRIPT - bold_5 end_POSTSUPERSCRIPT


7.18
×
10
−
5
7.18
superscript
10
5
7.18\times 10^{-5}
7.18 × 10 start_POSTSUPERSCRIPT - 5 end_POSTSUPERSCRIPT






II.35.18


n
0
exp
⁢
(
μ
m
⁢
B
k
b
⁢
T
)
+
exp
⁢
(
−
μ
m
⁢
B
k
b
⁢
T
)
subscript
𝑛
0
exp
subscript
𝜇
𝑚
𝐵
subscript
𝑘
𝑏
𝑇
exp
subscript
𝜇
𝑚
𝐵
subscript
𝑘
𝑏
𝑇
\frac{n_{0}}{{\rm exp}(\frac{\mu_{m}B}{k_{b}T})+{\rm exp}(-\frac{\mu_{m}B}{k_{%
b}T})}
divide start_ARG italic_n start_POSTSUBSCRIPT 0 end_POSTSUBSCRIPT end_ARG start_ARG roman_exp ( divide start_ARG italic_μ start_POSTSUBSCRIPT italic_m end_POSTSUBSCRIPT italic_B end_ARG start_ARG italic_k start_POSTSUBSCRIPT italic_b end_POSTSUBSCRIPT italic_T end_ARG ) + roman_exp ( - divide start_ARG italic_μ start_POSTSUBSCRIPT italic_m end_POSTSUBSCRIPT italic_B end_ARG start_ARG italic_k start_POSTSUBSCRIPT italic_b end_POSTSUBSCRIPT italic_T end_ARG ) end_ARG


n
0
exp
⁢
(
a
)
+
exp
⁢
(
−
a
)
subscript
𝑛
0
exp
𝑎
exp
𝑎
\frac{n_{0}}{{\rm exp}(a)+{\rm exp}(-a)}
divide start_ARG italic_n start_POSTSUBSCRIPT 0 end_POSTSUBSCRIPT end_ARG start_ARG roman_exp ( italic_a ) + roman_exp ( - italic_a ) end_ARG


n
0
,
a
subscript
𝑛
0
𝑎
n_{0},a
italic_n start_POSTSUBSCRIPT 0 end_POSTSUBSCRIPT , italic_a


[2,1,1]


[2,1,1]


[2,1,1,1]


4.13
×
10
−
4
4.13
superscript
10
4
4.13\times 10^{-4}
4.13 × 10 start_POSTSUPERSCRIPT - 4 end_POSTSUPERSCRIPT


1.58
×
10
−
4
1.58
superscript
10
4
1.58\times 10^{-4}
1.58 × 10 start_POSTSUPERSCRIPT - 4 end_POSTSUPERSCRIPT


7.71
×
𝟏𝟎
−
𝟓
7.71
superscript
10
5
{\bf 7.71\times 10^{-5}}
bold_7.71 × bold_10 start_POSTSUPERSCRIPT - bold_5 end_POSTSUPERSCRIPT


7.92
×
10
−
5
7.92
superscript
10
5
7.92\times 10^{-5}
7.92 × 10 start_POSTSUPERSCRIPT - 5 end_POSTSUPERSCRIPT






II.36.38


μ
m
⁢
B
k
b
⁢
T
+
μ
m
⁢
α
⁢
M
ϵ
⁢
c
2
⁢
k
b
⁢
T
subscript
𝜇
𝑚
𝐵
subscript
𝑘
𝑏
𝑇
subscript
𝜇
𝑚
𝛼
𝑀
italic-ϵ
superscript
𝑐
2
subscript
𝑘
𝑏
𝑇
\frac{\mu_{m}B}{k_{b}T}+\frac{\mu_{m}\alpha M}{\epsilon c^{2}k_{b}T}
divide start_ARG italic_μ start_POSTSUBSCRIPT italic_m end_POSTSUBSCRIPT italic_B end_ARG start_ARG italic_k start_POSTSUBSCRIPT italic_b end_POSTSUBSCRIPT italic_T end_ARG + divide start_ARG italic_μ start_POSTSUBSCRIPT italic_m end_POSTSUBSCRIPT italic_α italic_M end_ARG start_ARG italic_ϵ italic_c start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT italic_k start_POSTSUBSCRIPT italic_b end_POSTSUBSCRIPT italic_T end_ARG


a
+
α
⁢
b
𝑎
𝛼
𝑏
a+\alpha b
italic_a + italic_α italic_b


a
,
α
,
b
𝑎
𝛼
𝑏
a,\alpha,b
italic_a , italic_α , italic_b


[3,3,1]


[3,2,1]


[3,2,1]


2.85
×
10
−
3
2.85
superscript
10
3
2.85\times 10^{-3}
2.85 × 10 start_POSTSUPERSCRIPT - 3 end_POSTSUPERSCRIPT


1.15
×
𝟏𝟎
−
𝟑
1.15
superscript
10
3
{\bf 1.15\times 10^{-3}}
bold_1.15 × bold_10 start_POSTSUPERSCRIPT - bold_3 end_POSTSUPERSCRIPT


3.03
×
10
−
3
3.03
superscript
10
3
3.03\times 10^{-3}
3.03 × 10 start_POSTSUPERSCRIPT - 3 end_POSTSUPERSCRIPT


2.15
×
10
−
3
2.15
superscript
10
3
2.15\times 10^{-3}
2.15 × 10 start_POSTSUPERSCRIPT - 3 end_POSTSUPERSCRIPT






II.38.3


Y
⁢
A
⁢
x
d
𝑌
𝐴
𝑥
𝑑
\frac{YAx}{d}
divide start_ARG italic_Y italic_A italic_x end_ARG start_ARG italic_d end_ARG


a
b
𝑎
𝑏
\frac{a}{b}
divide start_ARG italic_a end_ARG start_ARG italic_b end_ARG


a
,
b
𝑎
𝑏
a,b
italic_a , italic_b


[2,1,1]


[2,1,1]


[2,2,1,1,1]


1.47
×
10
−
4
1.47
superscript
10
4
1.47\times 10^{-4}
1.47 × 10 start_POSTSUPERSCRIPT - 4 end_POSTSUPERSCRIPT


8.78
×
𝟏𝟎
−
𝟓
8.78
superscript
10
5
{\bf 8.78\times 10^{-5}}
bold_8.78 × bold_10 start_POSTSUPERSCRIPT - bold_5 end_POSTSUPERSCRIPT


6.43
×
10
−
4
6.43
superscript
10
4
6.43\times 10^{-4}
6.43 × 10 start_POSTSUPERSCRIPT - 4 end_POSTSUPERSCRIPT


5.26
×
10
−
4
5.26
superscript
10
4
5.26\times 10^{-4}
5.26 × 10 start_POSTSUPERSCRIPT - 4 end_POSTSUPERSCRIPT






III.9.52


p
d
⁢
E
f
h
⁢
sin
2
⁢
(
(
ω
−
ω
0
)
⁢
t
/
2
)
(
(
ω
−
ω
0
)
⁢
t
/
2
)
2
subscript
𝑝
𝑑
subscript
𝐸
𝑓
ℎ
superscript
sin
2
𝜔
subscript
𝜔
0
𝑡
2
superscript
𝜔
subscript
𝜔
0
𝑡
2
2
\frac{p_{d}E_{f}}{h}\frac{{\rm sin}^{2}((\omega-\omega_{0})t/2)}{((\omega-%
\omega_{0})t/2)^{2}}
divide start_ARG italic_p start_POSTSUBSCRIPT italic_d end_POSTSUBSCRIPT italic_E start_POSTSUBSCRIPT italic_f end_POSTSUBSCRIPT end_ARG start_ARG italic_h end_ARG divide start_ARG roman_sin start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT ( ( italic_ω - italic_ω start_POSTSUBSCRIPT 0 end_POSTSUBSCRIPT ) italic_t / 2 ) end_ARG start_ARG ( ( italic_ω - italic_ω start_POSTSUBSCRIPT 0 end_POSTSUBSCRIPT ) italic_t / 2 ) start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT end_ARG


a
⁢
sin
2
⁢
(
b
−
c
2
)
(
b
−
c
2
)
2
𝑎
superscript
sin
2
𝑏
𝑐
2
superscript
𝑏
𝑐
2
2
a\frac{{\rm sin}^{2}(\frac{b-c}{2})}{(\frac{b-c}{2})^{2}}
italic_a divide start_ARG roman_sin start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT ( divide start_ARG italic_b - italic_c end_ARG start_ARG 2 end_ARG ) end_ARG start_ARG ( divide start_ARG italic_b - italic_c end_ARG start_ARG 2 end_ARG ) start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT end_ARG


a
,
b
,
c
𝑎
𝑏
𝑐
a,b,c
italic_a , italic_b , italic_c


[3,2,3,1,1]


[3,3,2,1]


[3,3,2,1,1,1]


4.43
×
10
−
2
4.43
superscript
10
2
4.43\times 10^{-2}
4.43 × 10 start_POSTSUPERSCRIPT - 2 end_POSTSUPERSCRIPT


3.90
×
10
−
3
3.90
superscript
10
3
3.90\times 10^{-3}
3.90 × 10 start_POSTSUPERSCRIPT - 3 end_POSTSUPERSCRIPT


2.11
×
10
−
2
2.11
superscript
10
2
2.11\times 10^{-2}
2.11 × 10 start_POSTSUPERSCRIPT - 2 end_POSTSUPERSCRIPT


9.07
×
𝟏𝟎
−
𝟒
9.07
superscript
10
4
{\bf 9.07\times 10^{-4}}
bold_9.07 × bold_10 start_POSTSUPERSCRIPT - bold_4 end_POSTSUPERSCRIPT






III.10.19


μ
m
⁢
B
x
2
+
B
y
2
+
B
z
2
subscript
𝜇
𝑚
superscript
subscript
𝐵
𝑥
2
superscript
subscript
𝐵
𝑦
2
superscript
subscript
𝐵
𝑧
2
\mu_{m}\sqrt{B_{x}^{2}+B_{y}^{2}+B_{z}^{2}}
italic_μ start_POSTSUBSCRIPT italic_m end_POSTSUBSCRIPT square-root start_ARG italic_B start_POSTSUBSCRIPT italic_x end_POSTSUBSCRIPT start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT + italic_B start_POSTSUBSCRIPT italic_y end_POSTSUBSCRIPT start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT + italic_B start_POSTSUBSCRIPT italic_z end_POSTSUBSCRIPT start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT end_ARG


1
+
a
2
+
b
2
1
superscript
𝑎
2
superscript
𝑏
2
\sqrt{1+a^{2}+b^{2}}
square-root start_ARG 1 + italic_a start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT + italic_b start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT end_ARG


a
,
b
𝑎
𝑏
a,b
italic_a , italic_b


[2,1,1]


[2,1,1]


[2,1,2,1]


2.54
×
10
−
3
2.54
superscript
10
3
2.54\times 10^{-3}
2.54 × 10 start_POSTSUPERSCRIPT - 3 end_POSTSUPERSCRIPT


1.18
×
10
−
3
1.18
superscript
10
3
1.18\times 10^{-3}
1.18 × 10 start_POSTSUPERSCRIPT - 3 end_POSTSUPERSCRIPT


8.16
×
10
−
4
8.16
superscript
10
4
8.16\times 10^{-4}
8.16 × 10 start_POSTSUPERSCRIPT - 4 end_POSTSUPERSCRIPT


1.67
×
𝟏𝟎
−
𝟒
1.67
superscript
10
4
{\bf 1.67\times 10^{-4}}
bold_1.67 × bold_10 start_POSTSUPERSCRIPT - bold_4 end_POSTSUPERSCRIPT






III.17.37


β
⁢
(
1
+
α
⁢
cos
⁢
θ
)
𝛽
1
𝛼
cos
𝜃
\beta(1+\alpha{\rm cos}\theta)
italic_β ( 1 + italic_α roman_cos italic_θ )


β
⁢
(
1
+
α
⁢
cos
⁢
θ
)
𝛽
1
𝛼
cos
𝜃
\beta(1+\alpha{\rm cos}\theta)
italic_β ( 1 + italic_α roman_cos italic_θ )


α
,
β
,
θ
𝛼
𝛽
𝜃
\alpha,\beta,\theta
italic_α , italic_β , italic_θ


[3,3,3,2,2,1]


[3,3,1]


[3,3,1]


1.10
×
10
−
3
1.10
superscript
10
3
1.10\times 10^{-3}
1.10 × 10 start_POSTSUPERSCRIPT - 3 end_POSTSUPERSCRIPT


5.03
×
10
−
4
5.03
superscript
10
4
5.03\times 10^{-4}
5.03 × 10 start_POSTSUPERSCRIPT - 4 end_POSTSUPERSCRIPT


4.12
×
𝟏𝟎
−
𝟒
4.12
superscript
10
4
{\bf 4.12\times 10^{-4}}
bold_4.12 × bold_10 start_POSTSUPERSCRIPT - bold_4 end_POSTSUPERSCRIPT


6.80
×
10
−
4
6.80
superscript
10
4
6.80\times 10^{-4}
6.80 × 10 start_POSTSUPERSCRIPT - 4 end_POSTSUPERSCRIPT








Table 3: 
Feynman dataset






Feynman dataset.
 The Feynman dataset collects many physics equations from Feynman’s textbooks 
[
20
, 
21
]
. For our purpose, we are interested in problems in the 
Feynman_no_units
 dataset that have at least 2 variables, since univariate problems are trivial for KANs (they simplify to 1D splines). A sample equation from the Feynman dataset is the relativisic velocity addition formula








f
⁢
(
u
,
v
)
=
(
u
+
v
)
/
(
1
+
u
⁢
v
)
.
𝑓
𝑢
𝑣
𝑢
𝑣
1
𝑢
𝑣
\displaystyle f(u,v)=(u+v)/(1+uv).
italic_f ( italic_u , italic_v ) = ( italic_u + italic_v ) / ( 1 + italic_u italic_v ) .




(3.1)






The dataset can be constructed by randomly drawing 
u
i
∈
(
−
1
,
1
)
subscript
𝑢
𝑖
1
1
u_{i}\in(-1,1)
italic_u start_POSTSUBSCRIPT italic_i end_POSTSUBSCRIPT ∈ ( - 1 , 1 )
, 
v
i
∈
(
−
1
,
1
)
subscript
𝑣
𝑖
1
1
v_{i}\in(-1,1)
italic_v start_POSTSUBSCRIPT italic_i end_POSTSUBSCRIPT ∈ ( - 1 , 1 )
, and computing 
f
i
=
f
⁢
(
u
i
,
v
i
)
subscript
𝑓
𝑖
𝑓
subscript
𝑢
𝑖
subscript
𝑣
𝑖
f_{i}=f(u_{i},v_{i})
italic_f start_POSTSUBSCRIPT italic_i end_POSTSUBSCRIPT = italic_f ( italic_u start_POSTSUBSCRIPT italic_i end_POSTSUBSCRIPT , italic_v start_POSTSUBSCRIPT italic_i end_POSTSUBSCRIPT )
. Given many tuples 
(
u
i
,
v
i
,
f
i
)
subscript
𝑢
𝑖
subscript
𝑣
𝑖
subscript
𝑓
𝑖
(u_{i},v_{i},f_{i})
( italic_u start_POSTSUBSCRIPT italic_i end_POSTSUBSCRIPT , italic_v start_POSTSUBSCRIPT italic_i end_POSTSUBSCRIPT , italic_f start_POSTSUBSCRIPT italic_i end_POSTSUBSCRIPT )
, a neural network is trained and aims to predict 
f
𝑓
f
italic_f
 from 
u
𝑢
u
italic_u
 and 
v
𝑣
v
italic_v
. We are interested in (1) how well a neural network can perform on test samples; (2) how much we can learn about the structure of the problem from neural networks.






We compare four kinds of neural networks:






(1)




Human-constructued KAN. Given a symbolic formula, we rewrite it in Kolmogorov-Arnold representations. For example, to multiply two numbers 
x
𝑥
x
italic_x
 and 
y
𝑦
y
italic_y
, we can use the identity 
x
⁢
y
=
(
x
+
y
)
2
4
−
(
x
−
y
)
2
4
𝑥
𝑦
superscript
𝑥
𝑦
2
4
superscript
𝑥
𝑦
2
4
xy=\frac{(x+y)^{2}}{4}-\frac{(x-y)^{2}}{4}
italic_x italic_y = divide start_ARG ( italic_x + italic_y ) start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT end_ARG start_ARG 4 end_ARG - divide start_ARG ( italic_x - italic_y ) start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT end_ARG start_ARG 4 end_ARG
, which corresponds to a 
[
2
,
2
,
1
]
2
2
1
[2,2,1]
[ 2 , 2 , 1 ]
 KAN. The constructued shapes are listed in the “Human-constructed KAN shape” in Table 
3
.








(2)




KANs without pruning. We fix the KAN shape to width 5 and depths are swept over {2,3,4,5,6}.








(3)




KAN with pruning. We use the sparsification 
(
λ
=
10
−
2
⁢
or
⁢
 10
−
3
)
𝜆
superscript
10
2
or
superscript
10
3
(\lambda=10^{-2}\ {\rm or}\ 10^{-3})
( italic_λ = 10 start_POSTSUPERSCRIPT - 2 end_POSTSUPERSCRIPT roman_or 10 start_POSTSUPERSCRIPT - 3 end_POSTSUPERSCRIPT )
 and the pruning technique from Section 
2.5.1
 to obtain a smaller KAN from a fixed-shape KAN from (2).








(4)




MLPs with fixed width 20, depths swept in 
{
2
,
3
,
4
,
5
,
6
}
2
3
4
5
6
\{2,3,4,5,6\}
{ 2 , 3 , 4 , 5 , 6 }
, and activations chosen from 
{
Tanh
,
ReLU
,
SiLU
}
Tanh
ReLU
SiLU
\{{\rm Tanh},{\rm ReLU},{\rm SiLU}\}
{ roman_Tanh , roman_ReLU , roman_SiLU }
.








Each KAN is initialized to have 
G
=
3
𝐺
3
G=3
italic_G = 3
, trained with LBFGS, with increasing number of grid points every 200 steps to cover 
G
=
{
3
,
5
,
10
,
20
,
50
,
100
,
200
}
𝐺
3
5
10
20
50
100
200
G=\{3,5,10,20,50,100,200\}
italic_G = { 3 , 5 , 10 , 20 , 50 , 100 , 200 }
. For each hyperparameter combination, we try 3 random seeds. For each dataset (equation) and each method, we report the results of the best model (minimal KAN shape, or lowest test loss) over random seeds and depths in Table 
3
. We find that MLPs and KANs behave comparably on average. For each dataset and each model family (KANs or MLPs), we plot the Pareto frontier in the plane spanned by the number of parameters and RMSE losses, shown in Figure 
D.1
 in Appendix 
D
. We conjecture that the Feynman datasets are too simple to let KANs make further improvements, in the sense that variable dependence is usually smooth or monotonic, which is in contrast to the complexity of special functions which often demonstrate oscillatory behavior.






Auto-discovered KANs are smaller than human-constructed ones.
 We report the pruned KAN shape in two columns of Table 
3
; one column is for the minimal pruned KAN shape that can achieve reasonable loss (i.e., test RMSE smaller than 
10
−
2
superscript
10
2
10^{-2}
10 start_POSTSUPERSCRIPT - 2 end_POSTSUPERSCRIPT
); the other column is for the pruned KAN that achieves lowest test loss. For completeness, we visualize all 54 pruned KANs in Appendix 
D
 (Figure 
D.2
 and 
D.3
). It is interesting to observe that auto-discovered KAN shapes (for both minimal and best) are usually smaller than our human constructions. This means that KA representations can be more efficient than we imagine. At the same time, this may make interpretability subtle because information is being squashed into a smaller space than what we are comfortable with.






Consider the relativistic velocity composition 
f
⁢
(
u
,
v
)
=
u
+
v
1
+
u
⁢
v
𝑓
𝑢
𝑣
𝑢
𝑣
1
𝑢
𝑣
f(u,v)=\frac{u+v}{1+uv}
italic_f ( italic_u , italic_v ) = divide start_ARG italic_u + italic_v end_ARG start_ARG 1 + italic_u italic_v end_ARG
, for example. Our construction is quite deep because we were assuming that multiplication of 
u
,
v
𝑢
𝑣
u,v
italic_u , italic_v
 would use two layers (see Figure 
4.1
 (a)), inversion of 
1
+
u
⁢
v
1
𝑢
𝑣
1+uv
1 + italic_u italic_v
 would use one layer, and multiplication of 
u
+
v
𝑢
𝑣
u+v
italic_u + italic_v
 and 
1
/
(
1
+
u
⁢
v
)
1
1
𝑢
𝑣
1/(1+uv)
1 / ( 1 + italic_u italic_v )
 would use another two layers
5
5
5
Note that we cannot use the logarithmic construction for division, because 
u
𝑢
u
italic_u
 and 
v
𝑣
v
italic_v
 here might be negative numbers.
, resulting a total of 5 layers. However, the auto-discovered KANs are only 2 layers deep! In hindsight, this is actually expected if we recall the rapidity trick in relativity: define the two “rapidities” 
a
≡
arctanh
⁢
u
𝑎
arctanh
𝑢
a\equiv{\rm arctanh}\ u
italic_a ≡ roman_arctanh italic_u
 and 
b
≡
arctanh
⁢
v
𝑏
arctanh
𝑣
b\equiv{\rm arctanh}\ v
italic_b ≡ roman_arctanh italic_v
. The relativistic composition of velocities are simple additions in rapidity space, i.e., 
u
+
v
1
+
u
⁢
v
=
tanh
⁢
(
arctanh
⁢
u
+
arctanh
⁢
v
)
𝑢
𝑣
1
𝑢
𝑣
tanh
arctanh
𝑢
arctanh
𝑣
\frac{u+v}{1+uv}={\rm tanh}({\rm arctanh}\ u+{\rm arctanh}\ v)
divide start_ARG italic_u + italic_v end_ARG start_ARG 1 + italic_u italic_v end_ARG = roman_tanh ( roman_arctanh italic_u + roman_arctanh italic_v )
, which can be realized by a two-layer KAN. Pretending we do not know the notion of rapidity in physics, we could potentially discover this concept right from KANs without trial-and-error symbolic manipulations. The interpretability of KANs which can facilitate scientific discovery is the main topic in Section 
4
.










3.4 
Solving partial differential equations




Figure 3.3: 
The PDE example. We plot L2 squared and H1 squared losses between the predicted solution and ground truth solution. First and second: training dynamics of losses. Third and fourth: scaling laws of losses against the number of parameters. KANs converge faster, achieve lower losses, and have steeper scaling laws than MLPs.






We consider a Poisson equation with zero Dirichlet boundary data. For 
Ω
=
[
−
1
,
1
]
2
Ω
superscript
1
1
2
\Omega=[-1,1]^{2}
roman_Ω = [ - 1 , 1 ] start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT
, consider the PDE










u
x
⁢
x
+
u
y
⁢
y
subscript
𝑢
𝑥
𝑥
subscript
𝑢
𝑦
𝑦
\displaystyle u_{xx}+u_{yy}
italic_u start_POSTSUBSCRIPT italic_x italic_x end_POSTSUBSCRIPT + italic_u start_POSTSUBSCRIPT italic_y italic_y end_POSTSUBSCRIPT


=
f
in
⁢
Ω
,
absent
𝑓
in
Ω
\displaystyle=f\quad\text{in}\,\,\Omega\,,
= italic_f in roman_Ω ,




(3.2)








u
𝑢
\displaystyle u
italic_u


=
0
on
⁢
∂
Ω
.
absent
0
on
Ω
\displaystyle=0\quad\text{on}\,\,\partial\Omega\,.
= 0 on ∂ roman_Ω .










We consider the data 
f
=
−
π
2
⁢
(
1
+
4
⁢
y
2
)
⁢
sin
⁡
(
π
⁢
x
)
⁢
sin
⁡
(
π
⁢
y
2
)
+
2
⁢
π
⁢
sin
⁡
(
π
⁢
x
)
⁢
cos
⁡
(
π
⁢
y
2
)
𝑓
superscript
𝜋
2
1
4
superscript
𝑦
2
𝜋
𝑥
𝜋
superscript
𝑦
2
2
𝜋
𝜋
𝑥
𝜋
superscript
𝑦
2
f=-\pi^{2}(1+4y^{2})\sin(\pi x)\sin(\pi y^{2})+2\pi\sin(\pi x)\cos(\pi y^{2})
italic_f = - italic_π start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT ( 1 + 4 italic_y start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT ) roman_sin ( italic_π italic_x ) roman_sin ( italic_π italic_y start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT ) + 2 italic_π roman_sin ( italic_π italic_x ) roman_cos ( italic_π italic_y start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT )
 for which 
u
=
sin
⁡
(
π
⁢
x
)
⁢
sin
⁡
(
π
⁢
y
2
)
𝑢
𝜋
𝑥
𝜋
superscript
𝑦
2
u=\sin(\pi x)\sin(\pi y^{2})
italic_u = roman_sin ( italic_π italic_x ) roman_sin ( italic_π italic_y start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT )
 is the true solution. We use the framework of physics-informed neural networks (PINNs) 
[
22
, 
23
]
 to solve this PDE, with the loss function given by








loss
pde
=
α
⁢
loss
i
+
loss
b
≔
α
⁢
1
n
i
⁢
∑
i
=
1
n
i
|
u
x
⁢
x
⁢
(
z
i
)
+
u
y
⁢
y
⁢
(
z
i
)
−
f
⁢
(
z
i
)
|
2
+
1
n
b
⁢
∑
i
=
1
n
b
u
2
,
subscript
loss
pde
𝛼
subscript
loss
𝑖
subscript
loss
𝑏
≔
𝛼
1
subscript
𝑛
𝑖
superscript
subscript
𝑖
1
subscript
𝑛
𝑖
superscript
subscript
𝑢
𝑥
𝑥
subscript
𝑧
𝑖
subscript
𝑢
𝑦
𝑦
subscript
𝑧
𝑖
𝑓
subscript
𝑧
𝑖
2
1
subscript
𝑛
𝑏
superscript
subscript
𝑖
1
subscript
𝑛
𝑏
superscript
𝑢
2
\text{loss}_{\text{pde}}=\alpha\text{loss}_{i}+\text{loss}_{b}\coloneqq\alpha%
\frac{1}{n_{i}}\sum_{i=1}^{n_{i}}|u_{xx}(z_{i})+u_{yy}(z_{i})-f(z_{i})|^{2}+%
\frac{1}{n_{b}}\sum_{i=1}^{n_{b}}u^{2}\,,
loss start_POSTSUBSCRIPT pde end_POSTSUBSCRIPT = italic_α loss start_POSTSUBSCRIPT italic_i end_POSTSUBSCRIPT + loss start_POSTSUBSCRIPT italic_b end_POSTSUBSCRIPT ≔ italic_α divide start_ARG 1 end_ARG start_ARG italic_n start_POSTSUBSCRIPT italic_i end_POSTSUBSCRIPT end_ARG ∑ start_POSTSUBSCRIPT italic_i = 1 end_POSTSUBSCRIPT start_POSTSUPERSCRIPT italic_n start_POSTSUBSCRIPT italic_i end_POSTSUBSCRIPT end_POSTSUPERSCRIPT | italic_u start_POSTSUBSCRIPT italic_x italic_x end_POSTSUBSCRIPT ( italic_z start_POSTSUBSCRIPT italic_i end_POSTSUBSCRIPT ) + italic_u start_POSTSUBSCRIPT italic_y italic_y end_POSTSUBSCRIPT ( italic_z start_POSTSUBSCRIPT italic_i end_POSTSUBSCRIPT ) - italic_f ( italic_z start_POSTSUBSCRIPT italic_i end_POSTSUBSCRIPT ) | start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT + divide start_ARG 1 end_ARG start_ARG italic_n start_POSTSUBSCRIPT italic_b end_POSTSUBSCRIPT end_ARG ∑ start_POSTSUBSCRIPT italic_i = 1 end_POSTSUBSCRIPT start_POSTSUPERSCRIPT italic_n start_POSTSUBSCRIPT italic_b end_POSTSUBSCRIPT end_POSTSUPERSCRIPT italic_u start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT ,








where we use 
loss
i
subscript
loss
𝑖
\text{loss}_{i}
loss start_POSTSUBSCRIPT italic_i end_POSTSUBSCRIPT
 to denote the interior loss, discretized and evaluated by a uniform sampling of 
n
i
subscript
𝑛
𝑖
n_{i}
italic_n start_POSTSUBSCRIPT italic_i end_POSTSUBSCRIPT
 points 
z
i
=
(
x
i
,
y
i
)
subscript
𝑧
𝑖
subscript
𝑥
𝑖
subscript
𝑦
𝑖
z_{i}=(x_{i},y_{i})
italic_z start_POSTSUBSCRIPT italic_i end_POSTSUBSCRIPT = ( italic_x start_POSTSUBSCRIPT italic_i end_POSTSUBSCRIPT , italic_y start_POSTSUBSCRIPT italic_i end_POSTSUBSCRIPT )
 inside the domain, and similarly we use 
loss
b
subscript
loss
𝑏
\text{loss}_{b}
loss start_POSTSUBSCRIPT italic_b end_POSTSUBSCRIPT
 to denote the boundary loss, discretized and evaluated by a uniform sampling of 
n
b
subscript
𝑛
𝑏
n_{b}
italic_n start_POSTSUBSCRIPT italic_b end_POSTSUBSCRIPT
 points on the boundary. 
α
𝛼
\alpha
italic_α
 is the hyperparameter balancing the effect of the two terms.






We compare the KAN architecture with that of MLPs using the same hyperparameters 
n
i
=
10000
subscript
𝑛
𝑖
10000
n_{i}=10000
italic_n start_POSTSUBSCRIPT italic_i end_POSTSUBSCRIPT = 10000
, 
n
b
=
800
subscript
𝑛
𝑏
800
n_{b}=800
italic_n start_POSTSUBSCRIPT italic_b end_POSTSUBSCRIPT = 800
, and 
α
=
0.01
𝛼
0.01
\alpha=0.01
italic_α = 0.01
. We measure both the error in the 
L
2
superscript
𝐿
2
L^{2}
italic_L start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT
 norm and energy (
H
1
superscript
𝐻
1
H^{1}
italic_H start_POSTSUPERSCRIPT 1 end_POSTSUPERSCRIPT
) norm and see that KAN achieves a much better scaling law with a smaller error, using smaller networks and fewer parameters; see Figure 
3.3
. Therefore we speculate that KANs might have the potential of serving as a good neural network representation for model reduction of PDEs.










3.5 
Continual Learning




Figure 3.4: 
A toy continual learning problem. The dataset is a 1D regression task with 5 Gaussian peaks (top row). Data around each peak is presented sequentially (instead of all at once) to KANs and MLPs. KANs (middle row) can perfectly avoid catastrophic forgetting, while MLPs (bottom row) display severe catastrophic forgetting. 






Catastrophic forgetting is a serious problem in current machine learning 
[
24
]
. When a human masters a task and switches to another task, they do not forget how to perform the first task. Unfortunately, this is not the case for neural networks. When a neural network is trained on task 1 and then shifted to being trained on task 2, the network will soon forget about how to perform task 1. A key difference between artificial neural networks and human brains is that human brains have functionally distinct modules placed locally in space. When a new task is learned, structure re-organization only occurs in local regions responsible for relevant skills 
[
25
, 
26
]
, leaving other regions intact. Most artificial neural networks, including MLPs, do not have this notion of locality, which is probably the reason for catastrophic forgetting.






We show that KANs have local plasticity and can avoid catastrophic forgetting by leveraging the locality of splines. The idea is simple: since spline bases are local, a sample will only affect a few nearby spline coefficients, leaving far-away coefficients intact (which is desirable since far-away regions may have already stored information that we want to preserve). By contrast, since MLPs usually use global activations, e.g., ReLU/Tanh/SiLU etc., any local change may propagate uncontrollably to regions far away, destroying the information being stored there.






We use a toy example to validate this intuition. The 1D regression task is composed of 5 Gaussian peaks. Data around each peak is presented sequentially (instead of all at once) to KANs and MLPs, as shown in Figure 
3.4
 top row. KAN and MLP predictions after each training phase are shown in the middle and bottom rows. As expected, KAN only remodels regions where data is present on in the current phase, leaving previous regions unchanged. By contrast, MLPs remodels the whole region after seeing new data samples, leading to catastrophic forgetting.






Here we simply present our preliminary results on an extremely simple example, to demonstrate how one could possibly leverage locality in KANs (thanks to spline parametrizations) to reduce catastrophic forgetting. However, it remains unclear whether our method can generalize to more realistic setups, which we leave for future work. We would also like to study how our method can be connected to and combined with SOTA methods in continual learning 
[
27
, 
28
]
.












4 
KANs are interpretable




In this section, we show that KANs are interpretable and interactive thanks to the techniques we developed in Section 
2.5
. We want to test the use of KANs not only on synthetic tasks (Section 
4.1
 and 
4.2
), but also in real-life scientific research. We demonstrate that KANs can (re)discover both highly non-trivial relations in knot theory (Section 
4.3
) and phase transition boundaries in condensed matter physics (Section 
4.4
). KANs could potentially be the foundation model for AI + Science due to their accuracy (last section) and interpretability (this section).








4.1 
Supervised toy datasets




Figure 4.1: 
KANs are interepretable for simple symbolic tasks






We first examine KANs’ ability to reveal the compositional structures in symbolic formulas. Six examples are listed below and their KANs are visualized in Figure 
4.1
. KANs are able to reveal the compositional structures present in these formulas, as well as learn the correct univariate functions.










(a)




Multiplication 
f
⁢
(
x
,
y
)
=
x
⁢
y
𝑓
𝑥
𝑦
𝑥
𝑦
f(x,y)=xy
italic_f ( italic_x , italic_y ) = italic_x italic_y
. A 
[
2
,
5
,
1
]
2
5
1
[2,5,1]
[ 2 , 5 , 1 ]
 KAN is pruned to a 
[
2
,
2
,
1
]
2
2
1
[2,2,1]
[ 2 , 2 , 1 ]
 KAN. The learned activation functions are linear and quadratic. From the computation graph, we see that the way it computes 
x
⁢
y
𝑥
𝑦
xy
italic_x italic_y
 is leveraging 
2
⁢
x
⁢
y
=
(
x
+
y
)
2
−
(
x
2
+
y
2
)
2
𝑥
𝑦
superscript
𝑥
𝑦
2
superscript
𝑥
2
superscript
𝑦
2
2xy=(x+y)^{2}-(x^{2}+y^{2})
2 italic_x italic_y = ( italic_x + italic_y ) start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT - ( italic_x start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT + italic_y start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT )
.








(b)




Division of positive numbers 
f
⁢
(
x
,
y
)
=
x
/
y
𝑓
𝑥
𝑦
𝑥
𝑦
f(x,y)=x/y
italic_f ( italic_x , italic_y ) = italic_x / italic_y
. A 
[
2
,
5
,
1
]
2
5
1
[2,5,1]
[ 2 , 5 , 1 ]
 KAN is pruned to a 
[
2
,
1
,
1
]
2
1
1
[2,1,1]
[ 2 , 1 , 1 ]
 KAN. The learned activation functions are logarithmic and exponential functions, and the KAN is computing 
x
/
y
𝑥
𝑦
x/y
italic_x / italic_y
 by leveraging the identity 
x
/
y
=
exp
⁡
(
log
⁡
x
−
log
⁡
y
)
𝑥
𝑦
𝑥
𝑦
x/y={\exp}({\log}x-{\log}y)
italic_x / italic_y = roman_exp ( roman_log italic_x - roman_log italic_y )
.








(c)




Numerical to categorical. The task is to convert a real number in 
[
0
,
1
]
0
1
[0,1]
[ 0 , 1 ]
 to its first decimal digit (as one hots), e.g., 
0.0618
→
[
1
,
0
,
0
,
0
,
0
,
⋯
]
→
0.0618
1
0
0
0
0
⋯
0.0618\to[1,0,0,0,0,\cdots]
0.0618 → [ 1 , 0 , 0 , 0 , 0 , ⋯ ]
, 
0.314
→
[
0
,
0
,
0
,
1
,
0
,
⋯
]
→
0.314
0
0
0
1
0
⋯
0.314\to[0,0,0,1,0,\cdots]
0.314 → [ 0 , 0 , 0 , 1 , 0 , ⋯ ]
. Notice that activation functions are learned to be spikes located around the corresponding decimal digits.








(d)




Special function 
f
⁢
(
x
,
y
)
=
exp
⁢
(
J
0
⁢
(
20
⁢
x
)
+
y
2
)
𝑓
𝑥
𝑦
exp
subscript
𝐽
0
20
𝑥
superscript
𝑦
2
f(x,y)={\rm exp}(J_{0}(20x)+y^{2})
italic_f ( italic_x , italic_y ) = roman_exp ( italic_J start_POSTSUBSCRIPT 0 end_POSTSUBSCRIPT ( 20 italic_x ) + italic_y start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT )
. One limitation of symbolic regression is that it will never find the correct formula of a special function if the special function is not provided as prior knowledge. KANs can learn special functions – the highly wiggly Bessel function 
J
0
⁢
(
20
⁢
x
)
subscript
𝐽
0
20
𝑥
J_{0}(20x)
italic_J start_POSTSUBSCRIPT 0 end_POSTSUBSCRIPT ( 20 italic_x )
 is learned (numerically) by KAN.








(e)




Phase transition 
f
⁢
(
x
1
,
x
2
,
x
3
)
=
tanh
⁢
(
5
⁢
(
x
1
4
+
x
2
4
+
x
3
4
−
1
)
)
𝑓
subscript
𝑥
1
subscript
𝑥
2
subscript
𝑥
3
tanh
5
superscript
subscript
𝑥
1
4
superscript
subscript
𝑥
2
4
superscript
subscript
𝑥
3
4
1
f(x_{1},x_{2},x_{3})={\rm tanh}(5(x_{1}^{4}+x_{2}^{4}+x_{3}^{4}-1))
italic_f ( italic_x start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT , italic_x start_POSTSUBSCRIPT 2 end_POSTSUBSCRIPT , italic_x start_POSTSUBSCRIPT 3 end_POSTSUBSCRIPT ) = roman_tanh ( 5 ( italic_x start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT start_POSTSUPERSCRIPT 4 end_POSTSUPERSCRIPT + italic_x start_POSTSUBSCRIPT 2 end_POSTSUBSCRIPT start_POSTSUPERSCRIPT 4 end_POSTSUPERSCRIPT + italic_x start_POSTSUBSCRIPT 3 end_POSTSUBSCRIPT start_POSTSUPERSCRIPT 4 end_POSTSUPERSCRIPT - 1 ) )
. Phase transitions are of great interest in physics, so we want KANs to be able to detect phase transitions and to identify the correct order parameters. We use the tanh function to simulate the phase transition behavior, and the order parameter is the combination of the quartic terms of 
x
1
,
x
2
,
x
3
subscript
𝑥
1
subscript
𝑥
2
subscript
𝑥
3
x_{1},x_{2},x_{3}
italic_x start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT , italic_x start_POSTSUBSCRIPT 2 end_POSTSUBSCRIPT , italic_x start_POSTSUBSCRIPT 3 end_POSTSUBSCRIPT
. Both the quartic dependence and tanh dependence emerge after KAN training. This is a simplified case of a localization phase transition discussed in Section 
4.4
.








(f)




Deeper compositions 
f
⁢
(
x
1
,
x
2
,
x
3
,
x
4
)
=
(
x
1
−
x
2
)
2
+
(
x
3
−
x
4
)
2
𝑓
subscript
𝑥
1
subscript
𝑥
2
subscript
𝑥
3
subscript
𝑥
4
superscript
subscript
𝑥
1
subscript
𝑥
2
2
superscript
subscript
𝑥
3
subscript
𝑥
4
2
f(x_{1},x_{2},x_{3},x_{4})=\sqrt{(x_{1}-x_{2})^{2}+(x_{3}-x_{4})^{2}}
italic_f ( italic_x start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT , italic_x start_POSTSUBSCRIPT 2 end_POSTSUBSCRIPT , italic_x start_POSTSUBSCRIPT 3 end_POSTSUBSCRIPT , italic_x start_POSTSUBSCRIPT 4 end_POSTSUBSCRIPT ) = square-root start_ARG ( italic_x start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT - italic_x start_POSTSUBSCRIPT 2 end_POSTSUBSCRIPT ) start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT + ( italic_x start_POSTSUBSCRIPT 3 end_POSTSUBSCRIPT - italic_x start_POSTSUBSCRIPT 4 end_POSTSUBSCRIPT ) start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT end_ARG
. To compute this, we would need the identity function, squared function, and square root, which requires at least a three-layer KAN. Indeed, we find that a 
[
4
,
3
,
3
,
1
]
4
3
3
1
[4,3,3,1]
[ 4 , 3 , 3 , 1 ]
 KAN can be auto-pruned to a 
[
4
,
2
,
1
,
1
]
4
2
1
1
[4,2,1,1]
[ 4 , 2 , 1 , 1 ]
 KAN, which exactly corresponds to the computation graph we would expect.








More examples from the Feynman dataset and the special function dataset are visualized in Figure 
D.2
, 
D.3
, 
F.1
, 
F.2
 in Appendices 
D
 and 
F
.










4.2 
Unsupervised toy dataset




Often, scientific discoveries are formulated as supervised learning problems, i.e., given input variables 
x
1
,
x
2
,
⋯
,
x
d
subscript
𝑥
1
subscript
𝑥
2
⋯
subscript
𝑥
𝑑
x_{1},x_{2},\cdots,x_{d}
italic_x start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT , italic_x start_POSTSUBSCRIPT 2 end_POSTSUBSCRIPT , ⋯ , italic_x start_POSTSUBSCRIPT italic_d end_POSTSUBSCRIPT
 and output variable(s) 
y
𝑦
y
italic_y
, we want to find an interpretable function 
f
𝑓
f
italic_f
 such that 
y
≈
f
⁢
(
x
1
,
x
2
,
⋯
,
x
d
)
𝑦
𝑓
subscript
𝑥
1
subscript
𝑥
2
⋯
subscript
𝑥
𝑑
y\approx f(x_{1},x_{2},\cdots,x_{d})
italic_y ≈ italic_f ( italic_x start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT , italic_x start_POSTSUBSCRIPT 2 end_POSTSUBSCRIPT , ⋯ , italic_x start_POSTSUBSCRIPT italic_d end_POSTSUBSCRIPT )
. However, another type of scientific discovery can be formulated as unsupervised learning, i.e., given a set of variables 
(
x
1
,
x
2
,
⋯
,
x
d
)
subscript
𝑥
1
subscript
𝑥
2
⋯
subscript
𝑥
𝑑
(x_{1},x_{2},\cdots,x_{d})
( italic_x start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT , italic_x start_POSTSUBSCRIPT 2 end_POSTSUBSCRIPT , ⋯ , italic_x start_POSTSUBSCRIPT italic_d end_POSTSUBSCRIPT )
, we want to discover a structural relationship between the variables. Specifically, we want to find a non-zero 
f
𝑓
f
italic_f
 such that








f
⁢
(
x
1
,
x
2
,
⋯
,
x
d
)
≈
0
.
𝑓
subscript
𝑥
1
subscript
𝑥
2
⋯
subscript
𝑥
𝑑
0
\displaystyle f(x_{1},x_{2},\cdots,x_{d})\approx 0.
italic_f ( italic_x start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT , italic_x start_POSTSUBSCRIPT 2 end_POSTSUBSCRIPT , ⋯ , italic_x start_POSTSUBSCRIPT italic_d end_POSTSUBSCRIPT ) ≈ 0 .




(4.1)






For example, consider a set of features 
(
x
1
,
x
2
,
x
3
)
subscript
𝑥
1
subscript
𝑥
2
subscript
𝑥
3
(x_{1},x_{2},x_{3})
( italic_x start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT , italic_x start_POSTSUBSCRIPT 2 end_POSTSUBSCRIPT , italic_x start_POSTSUBSCRIPT 3 end_POSTSUBSCRIPT )
 that satisfies 
x
3
=
exp
⁢
(
sin
⁢
(
π
⁢
x
1
)
+
x
2
2
)
subscript
𝑥
3
exp
sin
𝜋
subscript
𝑥
1
superscript
subscript
𝑥
2
2
x_{3}={\rm exp}({\rm sin}(\pi x_{1})+x_{2}^{2})
italic_x start_POSTSUBSCRIPT 3 end_POSTSUBSCRIPT = roman_exp ( roman_sin ( italic_π italic_x start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT ) + italic_x start_POSTSUBSCRIPT 2 end_POSTSUBSCRIPT start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT )
. Then a valid 
f
𝑓
f
italic_f
 is 
f
⁢
(
x
1
,
x
2
,
x
3
)
=
sin
⁢
(
π
⁢
x
1
)
+
x
2
2
−
log
⁢
(
x
3
)
=
0
𝑓
subscript
𝑥
1
subscript
𝑥
2
subscript
𝑥
3
sin
𝜋
subscript
𝑥
1
superscript
subscript
𝑥
2
2
log
subscript
𝑥
3
0
f(x_{1},x_{2},x_{3})={\rm sin}(\pi x_{1})+x_{2}^{2}-{\rm log}(x_{3})=0
italic_f ( italic_x start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT , italic_x start_POSTSUBSCRIPT 2 end_POSTSUBSCRIPT , italic_x start_POSTSUBSCRIPT 3 end_POSTSUBSCRIPT ) = roman_sin ( italic_π italic_x start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT ) + italic_x start_POSTSUBSCRIPT 2 end_POSTSUBSCRIPT start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT - roman_log ( italic_x start_POSTSUBSCRIPT 3 end_POSTSUBSCRIPT ) = 0
, implying that points of 
(
x
1
,
x
2
,
x
3
)
subscript
𝑥
1
subscript
𝑥
2
subscript
𝑥
3
(x_{1},x_{2},x_{3})
( italic_x start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT , italic_x start_POSTSUBSCRIPT 2 end_POSTSUBSCRIPT , italic_x start_POSTSUBSCRIPT 3 end_POSTSUBSCRIPT )
 form a 2D submanifold specified by 
f
=
0
𝑓
0
f=0
italic_f = 0
 instead of filling the whole 3D space.






If an algorithm for solving the unsupervised problem can be devised, it has a considerable advantage over the supervised problem, since it requires only the sets of features 
S
=
(
x
1
,
x
2
,
⋯
,
x
d
)
𝑆
subscript
𝑥
1
subscript
𝑥
2
⋯
subscript
𝑥
𝑑
S=(x_{1},x_{2},\cdots,x_{d})
italic_S = ( italic_x start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT , italic_x start_POSTSUBSCRIPT 2 end_POSTSUBSCRIPT , ⋯ , italic_x start_POSTSUBSCRIPT italic_d end_POSTSUBSCRIPT )
. The supervised problem, on the other hand, tries to predict subsets of features in terms of the others, i.e. it splits 
S
=
S
in
∪
S
out
𝑆
subscript
𝑆
in
subscript
𝑆
out
S=S_{\text{in}}\cup S_{\text{out}}
italic_S = italic_S start_POSTSUBSCRIPT in end_POSTSUBSCRIPT ∪ italic_S start_POSTSUBSCRIPT out end_POSTSUBSCRIPT
 into input and output features of the function to be learned. Without domain expertise to advise the splitting, there are 
2
d
−
2
superscript
2
𝑑
2
2^{d}-2
2 start_POSTSUPERSCRIPT italic_d end_POSTSUPERSCRIPT - 2
 possibilities such that 
|
S
in
|
>
0
subscript
𝑆
in
0
|S_{\text{in}}|>0
| italic_S start_POSTSUBSCRIPT in end_POSTSUBSCRIPT | > 0
 and 
|
S
out
|
>
0
subscript
𝑆
out
0
|S_{\text{out}}|>0
| italic_S start_POSTSUBSCRIPT out end_POSTSUBSCRIPT | > 0
. This exponentially large space of supervised problems can be avoided by using the unsupervised approach.
This unsupervised learning approach will be valuable to the knot dataset in Section 
4.3
. A Google Deepmind team 
[
29
]
 manually chose signature to be the target variable, otherwise they would face this combinatorial problem described above.
This raises the question whether we can instead tackle the unsupervised learning directly. We present our method and a toy example below.






We tackle the unsupervised learning problem by turning it into a supervised learning problem on all of the 
d
𝑑
d
italic_d
 features, without requiring the choice of a splitting. The essential idea is to learn a function 
f
⁢
(
x
1
,
…
,
x
d
)
=
0
𝑓
subscript
𝑥
1
…
subscript
𝑥
𝑑
0
f(x_{1},\dots,x_{d})=0
italic_f ( italic_x start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT , … , italic_x start_POSTSUBSCRIPT italic_d end_POSTSUBSCRIPT ) = 0
 such that 
f
𝑓
f
italic_f
 is not the 
0
0
-function. To do this, similar to contrastive learning, we define positive samples and negative samples: positive samples are feature vectors of real data. Negative samples are constructed by feature corruption. To ensure that the overall feature distribution for each topological invariant stays the same, we perform feature corruption by random permutation of each feature across the entire training set. Now we want to train a network 
g
𝑔
g
italic_g
 such that 
g
⁢
(
𝐱
real
)
=
1
𝑔
subscript
𝐱
real
1
g(\mathbf{x}_{\rm real})=1
italic_g ( bold_x start_POSTSUBSCRIPT roman_real end_POSTSUBSCRIPT ) = 1
 and 
g
⁢
(
𝐱
fake
)
=
0
𝑔
subscript
𝐱
fake
0
g(\mathbf{x}_{\rm fake})=0
italic_g ( bold_x start_POSTSUBSCRIPT roman_fake end_POSTSUBSCRIPT ) = 0
 which turns the problem into a supervised problem. However, remember that we originally want 
f
⁢
(
𝐱
real
)
=
0
𝑓
subscript
𝐱
real
0
f(\mathbf{x}_{\rm real})=0
italic_f ( bold_x start_POSTSUBSCRIPT roman_real end_POSTSUBSCRIPT ) = 0
 and 
f
⁢
(
𝐱
fake
)
≠
0
𝑓
subscript
𝐱
fake
0
f(\mathbf{x}_{\rm fake})\neq 0
italic_f ( bold_x start_POSTSUBSCRIPT roman_fake end_POSTSUBSCRIPT ) ≠ 0
. We can achieve this by having 
g
=
σ
∘
f
𝑔
𝜎
𝑓
g=\sigma\circ f
italic_g = italic_σ ∘ italic_f
 where 
σ
⁢
(
x
)
=
exp
⁢
(
−
x
2
2
⁢
w
2
)
𝜎
𝑥
exp
superscript
𝑥
2
2
superscript
𝑤
2
\sigma(x)={\rm exp}(-\frac{x^{2}}{2w^{2}})
italic_σ ( italic_x ) = roman_exp ( - divide start_ARG italic_x start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT end_ARG start_ARG 2 italic_w start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT end_ARG )
 is a Gaussian function with a small width 
w
𝑤
w
italic_w
, which can be conveniently realized by a KAN with shape 
[
…
,
1
,
1
]
…
1
1
[...,1,1]
[ … , 1 , 1 ]
 whose last activation is set to be the Gaussian function 
σ
𝜎
\sigma
italic_σ
 and all previous layers form 
f
𝑓
f
italic_f
. Except for the modifications mentioned above, everything else is the same for supervised training.






Figure 4.2: 
Unsupervised learning of a toy task. KANs can identify groups of dependent variables, i.e., 
(
x
1
,
x
2
,
x
3
)
subscript
𝑥
1
subscript
𝑥
2
subscript
𝑥
3
(x_{1},x_{2},x_{3})
( italic_x start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT , italic_x start_POSTSUBSCRIPT 2 end_POSTSUBSCRIPT , italic_x start_POSTSUBSCRIPT 3 end_POSTSUBSCRIPT )
 and 
(
x
4
,
x
5
)
subscript
𝑥
4
subscript
𝑥
5
(x_{4},x_{5})
( italic_x start_POSTSUBSCRIPT 4 end_POSTSUBSCRIPT , italic_x start_POSTSUBSCRIPT 5 end_POSTSUBSCRIPT )
 in this case.






Now we demonstrate that the unsupervised paradigm works for a synthetic example. Let us consider a 6D dataset, where 
(
x
1
,
x
2
,
x
3
)
subscript
𝑥
1
subscript
𝑥
2
subscript
𝑥
3
(x_{1},x_{2},x_{3})
( italic_x start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT , italic_x start_POSTSUBSCRIPT 2 end_POSTSUBSCRIPT , italic_x start_POSTSUBSCRIPT 3 end_POSTSUBSCRIPT )
 are dependent variables such that 
x
3
=
exp
⁡
(
sin
⁡
(
x
1
)
+
x
2
2
)
subscript
𝑥
3
subscript
𝑥
1
superscript
subscript
𝑥
2
2
x_{3}=\exp(\sin(x_{1})+x_{2}^{2})
italic_x start_POSTSUBSCRIPT 3 end_POSTSUBSCRIPT = roman_exp ( roman_sin ( italic_x start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT ) + italic_x start_POSTSUBSCRIPT 2 end_POSTSUBSCRIPT start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT )
; 
(
x
4
,
x
5
)
subscript
𝑥
4
subscript
𝑥
5
(x_{4},x_{5})
( italic_x start_POSTSUBSCRIPT 4 end_POSTSUBSCRIPT , italic_x start_POSTSUBSCRIPT 5 end_POSTSUBSCRIPT )
 are dependent variables with 
x
5
=
x
4
3
subscript
𝑥
5
superscript
subscript
𝑥
4
3
x_{5}=x_{4}^{3}
italic_x start_POSTSUBSCRIPT 5 end_POSTSUBSCRIPT = italic_x start_POSTSUBSCRIPT 4 end_POSTSUBSCRIPT start_POSTSUPERSCRIPT 3 end_POSTSUPERSCRIPT
; 
x
6
subscript
𝑥
6
x_{6}
italic_x start_POSTSUBSCRIPT 6 end_POSTSUBSCRIPT
 is independent of the other variables. In Figure 
4.2
, we show that for seed = 0, KAN reveals the functional dependence among 
x
1
subscript
𝑥
1
x_{1}
italic_x start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT
,
x
2
subscript
𝑥
2
x_{2}
italic_x start_POSTSUBSCRIPT 2 end_POSTSUBSCRIPT
, and 
x
3
subscript
𝑥
3
x_{3}
italic_x start_POSTSUBSCRIPT 3 end_POSTSUBSCRIPT
; for another seed = 2024, KAN reveals the functional dependence between 
x
4
subscript
𝑥
4
x_{4}
italic_x start_POSTSUBSCRIPT 4 end_POSTSUBSCRIPT
 and 
x
5
subscript
𝑥
5
x_{5}
italic_x start_POSTSUBSCRIPT 5 end_POSTSUBSCRIPT
. Our preliminary results rely on randomness (different seeds) to discover different relations; in the future we would like to investigate a more systematic and more controlled way to discover a complete set of relations. Even so, our tool in its current status can provide insights for scientific tasks. We present our results with the knot dataset in Section 
4.3
.










4.3 
Application to Mathematics: Knot Theory




Knot theory is a subject in low-dimensional topology that sheds light on topological aspects of three-manifolds and four-manifolds and has a variety of applications, including in biology and topological quantum computing. Mathematically, a knot 
K
𝐾
K
italic_K
 is an embedding of 
S
1
superscript
𝑆
1
S^{1}
italic_S start_POSTSUPERSCRIPT 1 end_POSTSUPERSCRIPT
 into 
S
3
superscript
𝑆
3
S^{3}
italic_S start_POSTSUPERSCRIPT 3 end_POSTSUPERSCRIPT
. Two knots 
K
𝐾
K
italic_K
 and 
K
′
superscript
𝐾
′
K^{\prime}
italic_K start_POSTSUPERSCRIPT ′ end_POSTSUPERSCRIPT
 are topologically equivalent if one can be deformed into the other via deformation of the ambient space 
S
3
superscript
𝑆
3
S^{3}
italic_S start_POSTSUPERSCRIPT 3 end_POSTSUPERSCRIPT
, in which case we write 
[
K
]
=
[
K
′
]
delimited-[]
𝐾
delimited-[]
superscript
𝐾
′
[K]=[K^{\prime}]
[ italic_K ] = [ italic_K start_POSTSUPERSCRIPT ′ end_POSTSUPERSCRIPT ]
. Some knots are topologically trivial, meaning that they can be smoothly deformed to a standard circle. Knots have a variety of deformation-invariant features 
f
𝑓
f
italic_f
 called topological invariants, which may be used to show that two knots are topologically inequivalent, 
[
K
]
≠
[
K
′
]
delimited-[]
𝐾
delimited-[]
superscript
𝐾
′
[K]\neq[K^{\prime}]
[ italic_K ] ≠ [ italic_K start_POSTSUPERSCRIPT ′ end_POSTSUPERSCRIPT ]
 if 
f
⁢
(
K
)
≠
f
⁢
(
K
′
)
𝑓
𝐾
𝑓
superscript
𝐾
′
f(K)\neq f(K^{\prime})
italic_f ( italic_K ) ≠ italic_f ( italic_K start_POSTSUPERSCRIPT ′ end_POSTSUPERSCRIPT )
. In some cases the topological invariants are geometric in nature. For instance, a hyperbolic knot 
K
𝐾
K
italic_K
 has a knot complement 
S
3
∖
K
superscript
𝑆
3
𝐾
S^{3}\setminus K
italic_S start_POSTSUPERSCRIPT 3 end_POSTSUPERSCRIPT ∖ italic_K
 that admits a canonical hyperbolic metric 
g
𝑔
g
italic_g
 such that 
vol
g
⁢
(
K
)
subscript
vol
𝑔
𝐾
\text{vol}_{g}(K)
vol start_POSTSUBSCRIPT italic_g end_POSTSUBSCRIPT ( italic_K )
 is a topological invariant known as the hyperbolic volume. Other topological invariants are algebraic in nature, such as the Jones polynomial.






Given the fundamental nature of knots in mathematics and the importance of its applications, it is interesting to study whether ML can lead to new results. For instance, in 
[
30
]
 reinforcement learning was utilized to establish ribbonness of certain knots, which ruled out many potential counterexamples to the smooth 4d Poincaré conjecture.






Supervised learning
 In 
[
29
]
, supervised learning and human domain experts were utilized to arrive at a new theorem relating algebraic and geometric knot invariants. In this case, gradient saliency identified key invariants for the supervised problem, which led the domain experts to make a conjecture that was subsequently refined and proven. We study whether a KAN can achieve good interpretable results on the same problem, which predicts the signature of a knot. Their main results from studying the knot theory dataset are:






(1)




They use network attribution methods to find that the signature 
σ
𝜎
\sigma
italic_σ
 is mostly dependent on meridinal distance 
μ
𝜇
\mu
italic_μ
 (real 
μ
r
subscript
𝜇
𝑟
\mu_{r}
italic_μ start_POSTSUBSCRIPT italic_r end_POSTSUBSCRIPT
, imag 
μ
i
subscript
𝜇
𝑖
\mu_{i}
italic_μ start_POSTSUBSCRIPT italic_i end_POSTSUBSCRIPT
) and longitudinal distance 
λ
𝜆
\lambda
italic_λ
.








(2)




Human scientists later identified that 
σ
𝜎
\sigma
italic_σ
 has high correlation with the 
slope
≡
Re
⁢
(
λ
μ
)
=
λ
⁢
μ
r
μ
r
2
+
μ
i
2
slope
Re
𝜆
𝜇
𝜆
subscript
𝜇
𝑟
superscript
subscript
𝜇
𝑟
2
superscript
subscript
𝜇
𝑖
2
{\rm slope}\equiv{\rm Re}(\frac{\lambda}{\mu})=\frac{\lambda\mu_{r}}{\mu_{r}^{%
2}+\mu_{i}^{2}}
roman_slope ≡ roman_Re ( divide start_ARG italic_λ end_ARG start_ARG italic_μ end_ARG ) = divide start_ARG italic_λ italic_μ start_POSTSUBSCRIPT italic_r end_POSTSUBSCRIPT end_ARG start_ARG italic_μ start_POSTSUBSCRIPT italic_r end_POSTSUBSCRIPT start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT + italic_μ start_POSTSUBSCRIPT italic_i end_POSTSUBSCRIPT start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT end_ARG
 and derived a bound for 
|
2
⁢
σ
−
slope
|
2
𝜎
slope
|2\sigma-{\rm slope}|
| 2 italic_σ - roman_slope |
.








We show below that KANs not only rediscover these results with much smaller networks and much more automation, but also present some interesting new results and insights.






Figure 4.3: 
Knot dataset, supervised mode. With KANs, we rediscover Deepmind’s results that signature is mainly dependent on meridinal translation (real and imaginary parts).






To investigate (1), we treat 17 knot invariants as inputs and signature as outputs. Similar to the setup in 
[
29
]
, signatures (which are even numbers) are encoded as one-hot vectors and networks are trained with cross-entropy loss. We find that an extremely small 
[
17
,
1
,
14
]
17
1
14
[17,1,14]
[ 17 , 1 , 14 ]
 KAN is able to achieve 
81.6
%
percent
81.6
81.6\%
81.6 %
 test accuracy (while Deepmind’s 4-layer width-300 MLP achieves 78% test accuracy). The 
[
17
,
1
,
14
]
17
1
14
[17,1,14]
[ 17 , 1 , 14 ]
 KAN (
G
=
3
𝐺
3
G=3
italic_G = 3
, 
k
=
3
𝑘
3
k=3
italic_k = 3
) has 
≈
200
absent
200
\approx 200
≈ 200
 parameters, while the MLP has 
≈
3
×
10
5
absent
3
superscript
10
5
\approx 3\times 10^{5}
≈ 3 × 10 start_POSTSUPERSCRIPT 5 end_POSTSUPERSCRIPT
 parameters, shown in Table 
4
. It is remarkable that KANs can be both more accurate and much more parameter efficient than MLPs at the same time. In terms of interpretability, we scale the transparency of each activation according to its magnitude, so it becomes immediately clear which input variables are important without the need for feature attribution (see Figure 
4.3
 left): signature is mostly dependent on 
μ
r
subscript
𝜇
𝑟
\mu_{r}
italic_μ start_POSTSUBSCRIPT italic_r end_POSTSUBSCRIPT
, and slightly dependent on 
μ
i
subscript
𝜇
𝑖
\mu_{i}
italic_μ start_POSTSUBSCRIPT italic_i end_POSTSUBSCRIPT
 and 
λ
𝜆
\lambda
italic_λ
, while dependence on other variables is small. We then train a 
[
3
,
1
,
14
]
3
1
14
[3,1,14]
[ 3 , 1 , 14 ]
 KAN on the three important variables, obtaining test accuracy 
78.2
%
percent
78.2
78.2\%
78.2 %
. Our results have one subtle difference from results in 
[
29
]
: they find that signature is mostly dependent on 
μ
i
subscript
𝜇
𝑖
\mu_{i}
italic_μ start_POSTSUBSCRIPT italic_i end_POSTSUBSCRIPT
, while we find that signature is mostly dependent on 
μ
r
subscript
𝜇
𝑟
\mu_{r}
italic_μ start_POSTSUBSCRIPT italic_r end_POSTSUBSCRIPT
. This difference could be due to subtle algorithmic choices, but has led us to carry out the following experiments: (a) ablation studies. We show that 
μ
r
subscript
𝜇
𝑟
\mu_{r}
italic_μ start_POSTSUBSCRIPT italic_r end_POSTSUBSCRIPT
 contributes more to accuracy than 
μ
i
subscript
𝜇
𝑖
\mu_{i}
italic_μ start_POSTSUBSCRIPT italic_i end_POSTSUBSCRIPT
 (see Figure 
4.3
): for example, 
μ
r
subscript
𝜇
𝑟
\mu_{r}
italic_μ start_POSTSUBSCRIPT italic_r end_POSTSUBSCRIPT
 alone can achieve 
65.0
%
percent
65.0
65.0\%
65.0 %
 accuracy, while 
μ
i
subscript
𝜇
𝑖
\mu_{i}
italic_μ start_POSTSUBSCRIPT italic_i end_POSTSUBSCRIPT
 alone can only achieve 
43.8
%
percent
43.8
43.8\%
43.8 %
 accuracy. (b) We find a symbolic formula (in Table 
5
) which only involves 
μ
r
subscript
𝜇
𝑟
\mu_{r}
italic_μ start_POSTSUBSCRIPT italic_r end_POSTSUBSCRIPT
 and 
λ
𝜆
\lambda
italic_λ
, but can achieve 
77.8
%
percent
77.8
77.8\%
77.8 %
 test accuracy.










Method


Architecture


Parameter Count


Accuracy






Deepmind’s MLP


4 layer, width-300


3
×
10
5
3
superscript
10
5
3\times 10^{5}
3 × 10 start_POSTSUPERSCRIPT 5 end_POSTSUPERSCRIPT


78.0
%
percent
78.0
78.0\%
78.0 %






KANs


2 layer, 
[
17
,
1
,
14
]
17
1
14
[17,1,14]
[ 17 , 1 , 14 ]
 (
G
=
3
𝐺
3
G=3
italic_G = 3
, 
k
=
3
𝑘
3
k=3
italic_k = 3
)


2
×
10
2
2
superscript
10
2
2\times 10^{2}
2 × 10 start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT


81.6
%
percent
81.6
81.6\%
81.6 %






Table 4: 
KANs can achieve better accuracy than MLPs with much fewer parameters in the signature classification problem.






To investigate (2), i.e., obtain the symbolic form of 
σ
𝜎
\sigma
italic_σ
, we formulate the problem as a regression task. Using auto-symbolic regression introduced in Section 
2.5.1
, we can convert a trained KAN into symbolic formulas. We train KANs with shapes 
[
3
,
1
]
3
1
[3,1]
[ 3 , 1 ]
, 
[
3
,
1
,
1
]
3
1
1
[3,1,1]
[ 3 , 1 , 1 ]
, 
[
3
,
2
,
1
]
3
2
1
[3,2,1]
[ 3 , 2 , 1 ]
, whose corresponding symbolic formulas are displayed in Table 
5
 B-D. It is clear that by having a larger KAN, both accuracy and complexity increase. So KANs provide not just a single symbolic formula, but a whole Pareto frontier of formulas, trading off simplicity and accuracy. However, KANs need additional inductive biases to further simplify these equations to rediscover the formula from 
[
29
]
 (Table 
5
 A). We have tested two scenarios: (1) in the first scenario, we assume the ground truth formula has a multi-variate Pade representation (division of two multi-variate Taylor series). We first train 
[
3
,
2
,
1
]
3
2
1
[3,2,1]
[ 3 , 2 , 1 ]
 and then fit it to a Pade representation. We can obtain Formula E in Table 
5
, which bears similarity with Deepmind’s formula. (2) We hypothesize that the division is not very interpretable for KANs, so we train two KANs (one for the numerator and the other for the denominator) and divide them manually. Surprisingly, we end up with the formula F (in Table 
5
) which only involves 
μ
r
subscript
𝜇
𝑟
\mu_{r}
italic_μ start_POSTSUBSCRIPT italic_r end_POSTSUBSCRIPT
 and 
λ
𝜆
\lambda
italic_λ
, although 
μ
i
subscript
𝜇
𝑖
\mu_{i}
italic_μ start_POSTSUBSCRIPT italic_i end_POSTSUBSCRIPT
 is also provided but ignored by KANs.












Id






Formula






Discovered by




 






test




acc






 






r
2
superscript
𝑟
2
r^{2}
italic_r start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT
 with




Signature






 






r
2
superscript
𝑟
2
r^{2}
italic_r start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT
 with DM




formula








A






λ
⁢
μ
r
(
μ
r
2
+
μ
i
2
)
𝜆
subscript
𝜇
𝑟
superscript
subscript
𝜇
𝑟
2
superscript
subscript
𝜇
𝑖
2
\frac{\lambda\mu_{r}}{(\mu_{r}^{2}+\mu_{i}^{2})}
divide start_ARG italic_λ italic_μ start_POSTSUBSCRIPT italic_r end_POSTSUBSCRIPT end_ARG start_ARG ( italic_μ start_POSTSUBSCRIPT italic_r end_POSTSUBSCRIPT start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT + italic_μ start_POSTSUBSCRIPT italic_i end_POSTSUBSCRIPT start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT ) end_ARG








 






Human (DM)




83.1%


0.946


1






B






−
0.02
⁢
sin
⁢
(
4.98
⁢
μ
i
+
0.85
)
+
0.08
⁢
|
4.02
⁢
μ
r
+
6.28
|
−
0.52
−
0.04
⁢
e
−
0.88
⁢
(
1
−
0.45
⁢
λ
)
2
0.02
sin
4.98
subscript
𝜇
𝑖
0.85
0.08
4.02
subscript
𝜇
𝑟
6.28
0.52
0.04
superscript
𝑒
0.88
superscript
1
0.45
𝜆
2
-0.02{\rm sin}(4.98\mu_{i}+0.85)+0.08|4.02\mu_{r}+6.28|-0.52-0.04e^{-0.88(1-0.%
45\lambda)^{2}}
- 0.02 roman_sin ( 4.98 italic_μ start_POSTSUBSCRIPT italic_i end_POSTSUBSCRIPT + 0.85 ) + 0.08 | 4.02 italic_μ start_POSTSUBSCRIPT italic_r end_POSTSUBSCRIPT + 6.28 | - 0.52 - 0.04 italic_e start_POSTSUPERSCRIPT - 0.88 ( 1 - 0.45 italic_λ ) start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT end_POSTSUPERSCRIPT








[
3
,
1
]
3
1
[3,1]
[ 3 , 1 ]
 KAN


62.6%


0.837


0.897






C






0.17
⁢
tan
⁢
(
−
1.51
+
0.1
⁢
e
−
1.43
⁢
(
1
−
0.4
⁢
μ
i
)
2
+
0.09
⁢
e
−
0.06
⁢
(
1
−
0.21
⁢
λ
)
2
+
1.32
⁢
e
−
3.18
⁢
(
1
−
0.43
⁢
μ
r
)
2
)
0.17
tan
1.51
0.1
superscript
𝑒
1.43
superscript
1
0.4
subscript
𝜇
𝑖
2
0.09
superscript
𝑒
0.06
superscript
1
0.21
𝜆
2
1.32
superscript
𝑒
3.18
superscript
1
0.43
subscript
𝜇
𝑟
2
0.17{\rm tan}(-1.51+0.1e^{-1.43(1-0.4\mu_{i})^{2}+0.09e^{-0.06(1-0.21\lambda)^%
{2}}}+1.32e^{-3.18(1-0.43\mu_{r})^{2}})
0.17 roman_tan ( - 1.51 + 0.1 italic_e start_POSTSUPERSCRIPT - 1.43 ( 1 - 0.4 italic_μ start_POSTSUBSCRIPT italic_i end_POSTSUBSCRIPT ) start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT + 0.09 italic_e start_POSTSUPERSCRIPT - 0.06 ( 1 - 0.21 italic_λ ) start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT end_POSTSUPERSCRIPT end_POSTSUPERSCRIPT + 1.32 italic_e start_POSTSUPERSCRIPT - 3.18 ( 1 - 0.43 italic_μ start_POSTSUBSCRIPT italic_r end_POSTSUBSCRIPT ) start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT end_POSTSUPERSCRIPT )








[
3
,
1
,
1
]
3
1
1
[3,1,1]
[ 3 , 1 , 1 ]
 KAN


71.9%


0.871


0.934






D






−
0.09
+
1.04
⁢
exp
⁢
(
−
9.59
⁢
(
−
0.62
⁢
sin
⁢
(
0.61
⁢
μ
r
+
7.26
)
)
−
0.32
⁢
tan
⁢
(
0.03
⁢
λ
−
6.59
)
+
1
−
0.11
⁢
e
−
1.77
(
0.31
−
μ
i
)
2
)
2
−
1.09
⁢
e
−
7.6
(
0.65
(
1
−
0.01
λ
)
3
+
0.27
⁢
atan
⁢
(
0.53
⁢
μ
i
−
0.6
)
+
0.09
+
exp
⁢
(
−
2.58
⁢
(
1
−
0.36
⁢
μ
r
)
2
)
)
-0.09+1.04{\rm exp}(-9.59(-0.62{\rm sin}(0.61\mu_{r}+7.26))-0.32{\rm tan}(0.03%
\lambda-6.59)+1-0.11e^{-1.77(0.31-\mu_{i})^{2})^{2}}-1.09e^{-7.6(0.65(1-0.01%
\lambda)^{3}}+0.27{\rm atan}(0.53\mu_{i}-0.6)+0.09+{\rm exp}(-2.58(1-0.36\mu_{%
r})^{2}))
- 0.09 + 1.04 roman_exp ( - 9.59 ( - 0.62 roman_sin ( 0.61 italic_μ start_POSTSUBSCRIPT italic_r end_POSTSUBSCRIPT + 7.26 ) ) - 0.32 roman_tan ( 0.03 italic_λ - 6.59 ) + 1 - 0.11 italic_e start_POSTSUPERSCRIPT - 1.77 ( 0.31 - italic_μ start_POSTSUBSCRIPT italic_i end_POSTSUBSCRIPT ) start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT ) start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT end_POSTSUPERSCRIPT - 1.09 italic_e start_POSTSUPERSCRIPT - 7.6 ( 0.65 ( 1 - 0.01 italic_λ ) start_POSTSUPERSCRIPT 3 end_POSTSUPERSCRIPT end_POSTSUPERSCRIPT + 0.27 roman_atan ( 0.53 italic_μ start_POSTSUBSCRIPT italic_i end_POSTSUBSCRIPT - 0.6 ) + 0.09 + roman_exp ( - 2.58 ( 1 - 0.36 italic_μ start_POSTSUBSCRIPT italic_r end_POSTSUBSCRIPT ) start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT ) )








[
3
,
2
,
1
]
3
2
1
[3,2,1]
[ 3 , 2 , 1 ]
 KAN


84.0%


0.947


0.997






E






4.76
⁢
λ
⁢
μ
r
3.09
⁢
μ
i
+
6.05
⁢
μ
r
2
+
3.54
⁢
μ
i
2
4.76
𝜆
subscript
𝜇
𝑟
3.09
subscript
𝜇
𝑖
6.05
superscript
subscript
𝜇
𝑟
2
3.54
superscript
subscript
𝜇
𝑖
2
\frac{4.76\lambda\mu_{r}}{3.09\mu_{i}+6.05\mu_{r}^{2}+3.54\mu_{i}^{2}}
divide start_ARG 4.76 italic_λ italic_μ start_POSTSUBSCRIPT italic_r end_POSTSUBSCRIPT end_ARG start_ARG 3.09 italic_μ start_POSTSUBSCRIPT italic_i end_POSTSUBSCRIPT + 6.05 italic_μ start_POSTSUBSCRIPT italic_r end_POSTSUBSCRIPT start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT + 3.54 italic_μ start_POSTSUBSCRIPT italic_i end_POSTSUBSCRIPT start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT end_ARG








 






[3,2,1] KAN




+ Pade approx




82.8
%
percent
82.8
82.8\%
82.8 %


0.946


0.997






F






2.94
−
2.92
⁢
(
1
−
0.10
⁢
μ
r
)
2
0.32
⁢
(
0.18
−
μ
r
)
2
+
5.36
⁢
(
1
−
0.04
⁢
λ
)
2
+
0.50
2.94
2.92
superscript
1
0.10
subscript
𝜇
𝑟
2
0.32
superscript
0.18
subscript
𝜇
𝑟
2
5.36
superscript
1
0.04
𝜆
2
0.50
\frac{2.94-2.92(1-0.10\mu_{r})^{2}}{0.32(0.18-\mu_{r})^{2}+5.36(1-0.04\lambda)%
^{2}+0.50}
divide start_ARG 2.94 - 2.92 ( 1 - 0.10 italic_μ start_POSTSUBSCRIPT italic_r end_POSTSUBSCRIPT ) start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT end_ARG start_ARG 0.32 ( 0.18 - italic_μ start_POSTSUBSCRIPT italic_r end_POSTSUBSCRIPT ) start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT + 5.36 ( 1 - 0.04 italic_λ ) start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT + 0.50 end_ARG








[
3
,
1
]
3
1
[3,1]
[ 3 , 1 ]
 KAN/
[
3
,
1
]
3
1
[3,1]
[ 3 , 1 ]
 KAN


77.8%


0.925


0.977








Table 5: 
Symbolic formulas of signature as a function of meridinal translation 
μ
𝜇
\mu
italic_μ
 (real 
μ
r
subscript
𝜇
𝑟
\mu_{r}
italic_μ start_POSTSUBSCRIPT italic_r end_POSTSUBSCRIPT
, imag 
μ
i
subscript
𝜇
𝑖
\mu_{i}
italic_μ start_POSTSUBSCRIPT italic_i end_POSTSUBSCRIPT
) and longitudinal translation 
λ
𝜆
\lambda
italic_λ
. In 
[
29
]
, formula A was discovered by human scientists inspired by neural network attribution results. Formulas B-F are auto-discovered by KANs. KANs can trade-off between simplicity and accuracy (B, C, D). By adding more inductive biases, KAN is able to discover formula E which is not too dissimilar from formula A. KANs also discovered a formula F which only involves two variables (
μ
r
subscript
𝜇
𝑟
\mu_{r}
italic_μ start_POSTSUBSCRIPT italic_r end_POSTSUBSCRIPT
 and 
λ
𝜆
\lambda
italic_λ
) instead of all three variables, with little sacrifice in accuracy.






So far, we have rediscovered the main results from 
[
29
]
. It is remarkable to see that KANs made this discovery very intuitive and convenient. Instead of using feature attribution methods (which are great methods), one can instead simply stare at visualizations of KANs. Moreover, automatic symbolic regression also makes the discovery of symbolic formulas much easier.






In the next part, we propose a new paradigm of “AI for Math” not included in the Deepmind paper, where we aim to use KANs’ unsupervised learning mode to discover more relations (besides signature) in knot invariants.






Figure 4.4: 
Knot dataset, unsupervised mode. With KANs, we rediscover three mathematical relations in the knot dataset.






Unsupervised learning
 As we mentioned in Section 
4.2
, unsupervised learning is the setup that is more promising since it avoids manual partition of input and output variables which have combinatorially many possibilities. In the unsupervised learning mode, we treat all 18 variables (including signature) as inputs such that they are on the same footing. Knot data are positive samples, and we randomly shuffle features to obtain negative samples.
An 
[
18
,
1
,
1
]
18
1
1
[18,1,1]
[ 18 , 1 , 1 ]
 KAN is trained to classify whether a given feature vector belongs to a positive sample (1) or a negative sample (0). We manually set the second layer activation to be the Gaussian function with a peak one centered at zero, so positive samples will have activations at (around) zero, implicitly giving a relation among knot invariants 
∑
i
=
1
18
g
i
⁢
(
x
i
)
=
0
superscript
subscript
𝑖
1
18
subscript
𝑔
𝑖
subscript
𝑥
𝑖
0
\sum_{i=1}^{18}g_{i}(x_{i})=0
∑ start_POSTSUBSCRIPT italic_i = 1 end_POSTSUBSCRIPT start_POSTSUPERSCRIPT 18 end_POSTSUPERSCRIPT italic_g start_POSTSUBSCRIPT italic_i end_POSTSUBSCRIPT ( italic_x start_POSTSUBSCRIPT italic_i end_POSTSUBSCRIPT ) = 0
 where 
x
i
subscript
𝑥
𝑖
x_{i}
italic_x start_POSTSUBSCRIPT italic_i end_POSTSUBSCRIPT
 stands for a feature (invariant), and 
g
i
subscript
𝑔
𝑖
g_{i}
italic_g start_POSTSUBSCRIPT italic_i end_POSTSUBSCRIPT
 is the corresponding activation function which can be readily read off from KAN diagrams. We train the KANs with 
λ
=
{
10
−
2
,
10
−
3
}
𝜆
superscript
10
2
superscript
10
3
\lambda=\{10^{-2},10^{-3}\}
italic_λ = { 10 start_POSTSUPERSCRIPT - 2 end_POSTSUPERSCRIPT , 10 start_POSTSUPERSCRIPT - 3 end_POSTSUPERSCRIPT }
 to favor sparse combination of inputs, and 
seed
=
{
0
,
1
,
⋯
,
99
}
seed
0
1
⋯
99
{\rm seed}=\{0,1,\cdots,99\}
roman_seed = { 0 , 1 , ⋯ , 99 }
. All 200 networks can be grouped into three clusters, with representative KANs displayed in Figure 
4.4
. These three groups of dependent variables are:






(1)




The first group of dependent variables is signature, real part of meridinal distance, and longitudinal distance (plus two other variables which can be removed because of (3)). This is the signature dependence studied above, so it is very interesting to see that this dependence relation is rediscovered again in the unsupervised mode.








(2)




The second group of variables involve cusp volume 
V
𝑉
V
italic_V
, real part of meridinal translation 
μ
r
subscript
𝜇
𝑟
\mu_{r}
italic_μ start_POSTSUBSCRIPT italic_r end_POSTSUBSCRIPT
 and longitudinal translation 
λ
𝜆
\lambda
italic_λ
. Their activations all look like logarithmic functions (which can be verified by the implied symbolic functionality in Section 
2.5.1
). So the relation is 
−
log
⁡
V
+
log
⁡
μ
r
+
log
⁡
λ
=
0
𝑉
subscript
𝜇
𝑟
𝜆
0
-\log V+\log\mu_{r}+\log\lambda=0
- roman_log italic_V + roman_log italic_μ start_POSTSUBSCRIPT italic_r end_POSTSUBSCRIPT + roman_log italic_λ = 0
 which is equivalent to 
V
=
μ
r
⁢
λ
𝑉
subscript
𝜇
𝑟
𝜆
V=\mu_{r}\lambda
italic_V = italic_μ start_POSTSUBSCRIPT italic_r end_POSTSUBSCRIPT italic_λ
, which is true by definition. It is, however, reassuring that we discover this relation without any prior knowledge.








(3)




The third group of variables includes the real part of short geodesic 
g
r
subscript
𝑔
𝑟
g_{r}
italic_g start_POSTSUBSCRIPT italic_r end_POSTSUBSCRIPT
 and injectivity radius. Their activations look qualitatively the same but differ by a minus sign, so it is conjectured that these two variables have a linear correlation. We plot 2D scatters, finding that 
2
⁢
r
2
𝑟
2r
2 italic_r
 upper bounds 
g
r
subscript
𝑔
𝑟
g_{r}
italic_g start_POSTSUBSCRIPT italic_r end_POSTSUBSCRIPT
, which is also a well-known relation 
[
31
]
.












It is interesting that KANs’ unsupervised mode can rediscover several known mathematical relations. The good news is that the results discovered by KANs are probably reliable; the bad news is that we have not discovered anything new yet. It is worth noting that we have chosen a shallow KAN for simple visualization, but deeper KANs can probably find more relations if they exist. We would like to investigate how to discover more complicated relations with deeper KANs in future work.










4.4 
Application to Physics: Anderson localization




Anderson localization is the fundamental phenomenon in which disorder in a quantum system leads to the localization of electronic wave functions, causing all transport to be ceased 
[
32
]
. In one and two dimensions, scaling arguments show that all electronic eigenstates are exponentially localized for an infinitesimal amount of random disorder 
[
33
, 
34
]
. In contrast, in three dimensions, a critical energy forms a phase boundary that separates the extended states from the localized states, known as a mobility edge. The understanding of these mobility edges is crucial for explaining various fundamental phenomena such as the metal-insulator transition in solids 
[
35
]
, as well as localization effects of light in photonic devices 
[
36
, 
37
, 
38
, 
39
, 
40
]
. It is therefore necessary to develop microscopic models that exhibit mobility edges to enable detailed investigations. Developing such models is often more practical in lower dimensions, where introducing quasiperiodicity instead of random disorder can also result in mobility edges that separate localized and extended phases. Furthermore, experimental realizations of analytical mobility edges can help resolve the debate on localization in interacting systems 
[
41
, 
42
]
. Indeed, several recent studies have focused on identifying such models and deriving exact analytic expressions for their mobility edges 
[
43
, 
44
, 
45
, 
46
, 
47
, 
48
, 
49
]
.






Here, we apply KANs to numerical data generated from quasiperiodic tight-binding models to extract their mobility edges. In particular, we examine three classes of models: the Mosaic model (MM) 
[
47
]
, the generalized Aubry-André model (GAAM) 
[
46
]
 and the modified Aubry-André model (MAAM) 
[
44
]
. For the MM, we testify KAN’s ability to accurately extract mobility edge as a 1D function of energy. For the GAAM, we find that the formula obtained from a KAN closely matches the ground truth. For the more complicated MAAM, we demonstrate yet another example of the symbolic interpretability of this framework. A user can simplify the complex expression obtained from KANs (and corresponding symbolic formulas) by means of a “collaboration” where the human generates hypotheses to obtain a better match (e.g., making an assumption of the form of certain activation function), after which KANs can carry out quick hypotheses testing.






To quantify the localization of states in these models, the inverse participation ratio (IPR) is commonly used. The IPR for the 
k
t
⁢
h
superscript
𝑘
𝑡
ℎ
k^{th}
italic_k start_POSTSUPERSCRIPT italic_t italic_h end_POSTSUPERSCRIPT
 eigenstate, 
ψ
(
k
)
superscript
𝜓
𝑘
\psi^{(k)}
italic_ψ start_POSTSUPERSCRIPT ( italic_k ) end_POSTSUPERSCRIPT
, is given by








IPR
k
=
∑
n
|
ψ
n
(
k
)
|
4
(
∑
n
|
ψ
n
(
k
)
|
2
)
2
subscript
IPR
𝑘
subscript
𝑛
superscript
subscript
superscript
𝜓
𝑘
𝑛
4
superscript
subscript
𝑛
superscript
subscript
superscript
𝜓
𝑘
𝑛
2
2
\displaystyle\text{IPR}_{k}=\frac{\sum_{n}|\psi^{(k)}_{n}|^{4}}{\left(\sum_{n}%
|\psi^{(k)}_{n}|^{2}\right)^{2}}
IPR start_POSTSUBSCRIPT italic_k end_POSTSUBSCRIPT = divide start_ARG ∑ start_POSTSUBSCRIPT italic_n end_POSTSUBSCRIPT | italic_ψ start_POSTSUPERSCRIPT ( italic_k ) end_POSTSUPERSCRIPT start_POSTSUBSCRIPT italic_n end_POSTSUBSCRIPT | start_POSTSUPERSCRIPT 4 end_POSTSUPERSCRIPT end_ARG start_ARG ( ∑ start_POSTSUBSCRIPT italic_n end_POSTSUBSCRIPT | italic_ψ start_POSTSUPERSCRIPT ( italic_k ) end_POSTSUPERSCRIPT start_POSTSUBSCRIPT italic_n end_POSTSUBSCRIPT | start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT ) start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT end_ARG




(4.2)






where the sum runs over the site index. Here, we use the related measure of localization – the fractal dimension of the states, given by








D
k
=
−
log
⁡
(
IPR
k
)
log
⁡
(
N
)
subscript
𝐷
𝑘
subscript
IPR
𝑘
𝑁
\displaystyle D_{k}=-\frac{\log(\text{IPR}_{k})}{\log(N)}
italic_D start_POSTSUBSCRIPT italic_k end_POSTSUBSCRIPT = - divide start_ARG roman_log ( IPR start_POSTSUBSCRIPT italic_k end_POSTSUBSCRIPT ) end_ARG start_ARG roman_log ( italic_N ) end_ARG




(4.3)






where 
N
𝑁
N
italic_N
 is the system size. 
D
k
=
0
⁢
(
1
)
subscript
𝐷
𝑘
0
1
D_{k}=0(1)
italic_D start_POSTSUBSCRIPT italic_k end_POSTSUBSCRIPT = 0 ( 1 )
 indicates localized (extended) states.






Mosaic Model (MM)
 We first consider a class of tight-binding models defined by the Hamiltonian 
[
47
]








H
=
t
⁢
∑
n
(
c
n
+
1
†
⁢
c
n
+
H.c.
)
+
∑
n
V
n
⁢
(
λ
,
ϕ
)
⁢
c
n
†
⁢
c
n
,
𝐻
𝑡
subscript
𝑛
subscript
superscript
𝑐
†
𝑛
1
subscript
𝑐
𝑛
H.c.
subscript
𝑛
subscript
𝑉
𝑛
𝜆
italic-ϕ
subscript
superscript
𝑐
†
𝑛
subscript
𝑐
𝑛
\displaystyle H=t\sum_{n}\left(c^{\dagger}_{n+1}c_{n}+\text{H.c.}\right)+\sum_%
{n}V_{n}(\lambda,\phi)c^{\dagger}_{n}c_{n},
italic_H = italic_t ∑ start_POSTSUBSCRIPT italic_n end_POSTSUBSCRIPT ( italic_c start_POSTSUPERSCRIPT † end_POSTSUPERSCRIPT start_POSTSUBSCRIPT italic_n + 1 end_POSTSUBSCRIPT italic_c start_POSTSUBSCRIPT italic_n end_POSTSUBSCRIPT + H.c. ) + ∑ start_POSTSUBSCRIPT italic_n end_POSTSUBSCRIPT italic_V start_POSTSUBSCRIPT italic_n end_POSTSUBSCRIPT ( italic_λ , italic_ϕ ) italic_c start_POSTSUPERSCRIPT † end_POSTSUPERSCRIPT start_POSTSUBSCRIPT italic_n end_POSTSUBSCRIPT italic_c start_POSTSUBSCRIPT italic_n end_POSTSUBSCRIPT ,




(4.4)






where 
t
𝑡
t
italic_t
 is the nearest-neighbor coupling, 
c
n
⁢
(
c
n
†
)
subscript
𝑐
𝑛
subscript
superscript
𝑐
†
𝑛
c_{n}(c^{\dagger}_{n})
italic_c start_POSTSUBSCRIPT italic_n end_POSTSUBSCRIPT ( italic_c start_POSTSUPERSCRIPT † end_POSTSUPERSCRIPT start_POSTSUBSCRIPT italic_n end_POSTSUBSCRIPT )
 is the annihilation (creation) operator at site 
n
𝑛
n
italic_n
 and the potential energy 
V
n
subscript
𝑉
𝑛
V_{n}
italic_V start_POSTSUBSCRIPT italic_n end_POSTSUBSCRIPT
 is given by








V
n
⁢
(
λ
,
ϕ
)
=
{
λ
⁢
cos
⁡
(
2
⁢
π
⁢
n
⁢
b
+
ϕ
)
j
=
m
⁢
κ
0
,
otherwise,
subscript
𝑉
𝑛
𝜆
italic-ϕ
cases
𝜆
2
𝜋
𝑛
𝑏
italic-ϕ
𝑗
𝑚
𝜅
0
otherwise,
\displaystyle V_{n}(\lambda,\phi)=\begin{cases}\lambda\cos(2\pi nb+\phi)&j=m%
\kappa\\
0,&\text{otherwise,}\end{cases}
italic_V start_POSTSUBSCRIPT italic_n end_POSTSUBSCRIPT ( italic_λ , italic_ϕ ) = { start_ROW start_CELL italic_λ roman_cos ( 2 italic_π italic_n italic_b + italic_ϕ ) end_CELL start_CELL italic_j = italic_m italic_κ end_CELL end_ROW start_ROW start_CELL 0 , end_CELL start_CELL otherwise, end_CELL end_ROW




(4.5)






To introduce quasiperiodicity, we set 
b
𝑏
b
italic_b
 to be irrational (in particular, we choose 
b
𝑏
b
italic_b
 to be the golden ratio 
1
+
5
2
1
5
2
\frac{1+\sqrt{5}}{2}
divide start_ARG 1 + square-root start_ARG 5 end_ARG end_ARG start_ARG 2 end_ARG
). 
κ
𝜅
\kappa
italic_κ
 is an integer and the quasiperiodic potential occurs with interval 
κ
𝜅
\kappa
italic_κ
. The energy (
E
𝐸
E
italic_E
) spectrum for this model generically contains extended and localized regimes separated by a mobility edge. Interestingly, a unique feature found here is that the mobility edges are present for an arbitrarily strong quasiperiodic potential (i.e. there are always extended states present in the system that co-exist with localized ones).






The mobility edge can be described by 
g
⁢
(
λ
,
E
)
≡
λ
−
|
f
κ
⁢
(
E
)
|
=
0
𝑔
𝜆
𝐸
𝜆
subscript
𝑓
𝜅
𝐸
0
g(\lambda,E)\equiv\lambda-|f_{\kappa}(E)|=0
italic_g ( italic_λ , italic_E ) ≡ italic_λ - | italic_f start_POSTSUBSCRIPT italic_κ end_POSTSUBSCRIPT ( italic_E ) | = 0
. 
g
⁢
(
λ
,
E
)
𝑔
𝜆
𝐸
g(\lambda,E)
italic_g ( italic_λ , italic_E )
 > 0 and 
g
⁢
(
λ
,
E
)
𝑔
𝜆
𝐸
g(\lambda,E)
italic_g ( italic_λ , italic_E )
 < 0 correspond to localized and extended phases, respectively. Learning the mobility edge therefore hinges on learning the “order parameter” 
g
⁢
(
λ
,
E
)
𝑔
𝜆
𝐸
g(\lambda,E)
italic_g ( italic_λ , italic_E )
. Admittedly, this problem can be tackled by many other theoretical methods for this class of models 
[
47
]
, but we will demonstrate below that our KAN framework is ready and convenient to take in assumptions and inductive biases from human users.






Let us assume a hypothetical user Alice, who is a new PhD student in condensed matter physics, and she is provided with a 
[
2
,
1
]
2
1
[2,1]
[ 2 , 1 ]
 KAN as an assistant for the task. Firstly, she understands that this is a classification task, so it is wise to set the activation function in the second layer to be sigmoid by using the 
fix_symbolic
 functionality. Secondly, she realizes that learning the whole 2D function 
g
⁢
(
λ
,
E
)
𝑔
𝜆
𝐸
g(\lambda,E)
italic_g ( italic_λ , italic_E )
 is unnecessary because in the end she only cares about 
λ
=
λ
⁢
(
E
)
𝜆
𝜆
𝐸
\lambda=\lambda(E)
italic_λ = italic_λ ( italic_E )
 determined by 
g
⁢
(
λ
,
E
)
=
0
𝑔
𝜆
𝐸
0
g(\lambda,E)=0
italic_g ( italic_λ , italic_E ) = 0
. In so doing, it is reasonable to assume 
g
⁢
(
λ
,
E
)
=
λ
−
h
⁢
(
E
)
=
0
𝑔
𝜆
𝐸
𝜆
ℎ
𝐸
0
g(\lambda,E)=\lambda-h(E)=0
italic_g ( italic_λ , italic_E ) = italic_λ - italic_h ( italic_E ) = 0
. Alice simply sets the activation function of 
λ
𝜆
\lambda
italic_λ
 to be linear by again using the 
fix_symbolic
 functionality. Now Alice trains the KAN network and conveniently obtains the mobility edge, as shown in Figure 
4.5
. Alice can get both intuitive qualitative understanding (bottom) and quantitative results (middle), which well match the ground truth (top).






Figure 4.5: 
Results for the Mosaic Model. Top: phase diagram. Middle and Bottom: KANs can obtain both qualitative intuition (bottom) and extract quantitative results (middle). 
φ
=
1
+
5
2
𝜑
1
5
2
\varphi=\frac{1+\sqrt{5}}{2}
italic_φ = divide start_ARG 1 + square-root start_ARG 5 end_ARG end_ARG start_ARG 2 end_ARG
 is the golden ratio.






Generalized Andre-Aubry Model (GAAM)
 We next consider a class of tight-binding models defined by the Hamiltonian 
[
46
]








H
=
t
⁢
∑
n
(
c
n
+
1
†
⁢
c
n
+
H.c.
)
+
∑
n
V
n
⁢
(
α
,
λ
,
ϕ
)
⁢
c
n
†
⁢
c
n
,
𝐻
𝑡
subscript
𝑛
subscript
superscript
𝑐
†
𝑛
1
subscript
𝑐
𝑛
H.c.
subscript
𝑛
subscript
𝑉
𝑛
𝛼
𝜆
italic-ϕ
subscript
superscript
𝑐
†
𝑛
subscript
𝑐
𝑛
\displaystyle H=t\sum_{n}\left(c^{\dagger}_{n+1}c_{n}+\text{H.c.}\right)+\sum_%
{n}V_{n}(\alpha,\lambda,\phi)c^{\dagger}_{n}c_{n},
italic_H = italic_t ∑ start_POSTSUBSCRIPT italic_n end_POSTSUBSCRIPT ( italic_c start_POSTSUPERSCRIPT † end_POSTSUPERSCRIPT start_POSTSUBSCRIPT italic_n + 1 end_POSTSUBSCRIPT italic_c start_POSTSUBSCRIPT italic_n end_POSTSUBSCRIPT + H.c. ) + ∑ start_POSTSUBSCRIPT italic_n end_POSTSUBSCRIPT italic_V start_POSTSUBSCRIPT italic_n end_POSTSUBSCRIPT ( italic_α , italic_λ , italic_ϕ ) italic_c start_POSTSUPERSCRIPT † end_POSTSUPERSCRIPT start_POSTSUBSCRIPT italic_n end_POSTSUBSCRIPT italic_c start_POSTSUBSCRIPT italic_n end_POSTSUBSCRIPT ,




(4.6)






where 
t
𝑡
t
italic_t
 is the nearest-neighbor coupling, 
c
n
⁢
(
c
n
†
)
subscript
𝑐
𝑛
subscript
superscript
𝑐
†
𝑛
c_{n}(c^{\dagger}_{n})
italic_c start_POSTSUBSCRIPT italic_n end_POSTSUBSCRIPT ( italic_c start_POSTSUPERSCRIPT † end_POSTSUPERSCRIPT start_POSTSUBSCRIPT italic_n end_POSTSUBSCRIPT )
 is the annihilation (creation) operator at site 
n
𝑛
n
italic_n
 and the potential energy 
V
n
subscript
𝑉
𝑛
V_{n}
italic_V start_POSTSUBSCRIPT italic_n end_POSTSUBSCRIPT
 is given by








V
n
⁢
(
α
,
λ
,
ϕ
)
=
2
⁢
λ
⁢
cos
⁡
(
2
⁢
π
⁢
n
⁢
b
+
ϕ
)
1
−
α
⁢
cos
⁡
(
2
⁢
π
⁢
n
⁢
b
+
ϕ
)
,
subscript
𝑉
𝑛
𝛼
𝜆
italic-ϕ
2
𝜆
2
𝜋
𝑛
𝑏
italic-ϕ
1
𝛼
2
𝜋
𝑛
𝑏
italic-ϕ
\displaystyle V_{n}(\alpha,\lambda,\phi)=2\lambda\frac{\cos(2\pi nb+\phi)}{1-%
\alpha\cos(2\pi nb+\phi)},
italic_V start_POSTSUBSCRIPT italic_n end_POSTSUBSCRIPT ( italic_α , italic_λ , italic_ϕ ) = 2 italic_λ divide start_ARG roman_cos ( 2 italic_π italic_n italic_b + italic_ϕ ) end_ARG start_ARG 1 - italic_α roman_cos ( 2 italic_π italic_n italic_b + italic_ϕ ) end_ARG ,




(4.7)






which is smooth for 
α
∈
(
−
1
,
1
)
𝛼
1
1
\alpha\in(-1,1)
italic_α ∈ ( - 1 , 1 )
. To introduce quasiperiodicity, we again set 
b
𝑏
b
italic_b
 to be irrational (in particular, we choose 
b
𝑏
b
italic_b
 to be the golden ratio). As before, we would like to obtain an expression for the mobility edge. For these models, the mobility edge is given by the closed form expression 
[
46
, 
48
]
,








α
⁢
E
=
2
⁢
(
t
−
λ
)
.
𝛼
𝐸
2
𝑡
𝜆
\displaystyle\alpha E=2(t-\lambda).
italic_α italic_E = 2 ( italic_t - italic_λ ) .




(4.8)










We randomly sample the model parameters: 
ϕ
italic-ϕ
\phi
italic_ϕ
, 
α
𝛼
\alpha
italic_α
 and 
λ
𝜆
\lambda
italic_λ
 (setting the energy scale 
t
=
1
𝑡
1
t=1
italic_t = 1
) and calculate the energy eigenvalues as well as the fractal dimension of the corresponding eigenstates, which forms our training dataset.












System


Origin






Mobility Edge Formula






Accuracy






GAAM


Theory






α
⁢
E
+
2
⁢
λ
−
2
=
0
𝛼
𝐸
2
𝜆
2
0
\alpha E+2\lambda-2=0
italic_α italic_E + 2 italic_λ - 2 = 0






99.2%








 






KAN auto








1.52
⁢
E
2
+
21.06
⁢
α
⁢
E
+
0.66
⁢
E
+
3.55
⁢
α
2
+
0.91
⁢
α
+
45.13
⁢
λ
−
54.45
=
0
cancel
1.52
superscript
𝐸
2
21.06
𝛼
𝐸
cancel
0.66
𝐸
cancel
3.55
superscript
𝛼
2
cancel
0.91
𝛼
45.13
𝜆
54.45
0
\cancel{1.52E^{2}}+21.06\alpha E+\cancel{0.66E}+\cancel{3.55\alpha^{2}}+%
\cancel{0.91\alpha}+45.13\lambda-54.45=0
cancel 1.52 italic_E start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT + 21.06 italic_α italic_E + cancel 0.66 italic_E + cancel 3.55 italic_α start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT + cancel 0.91 italic_α + 45.13 italic_λ - 54.45 = 0






99.0%






MAAM




 






Theory








E
+
exp
⁢
(
p
)
−
λ
⁢
cosh
⁢
p
=
0
𝐸
exp
𝑝
𝜆
cosh
𝑝
0
E+{\rm exp}(p)-\lambda{\rm cosh}p=0
italic_E + roman_exp ( italic_p ) - italic_λ roman_cosh italic_p = 0






98.6%








 






KAN auto








13.99
⁢
sin
⁢
(
0.28
⁢
sin
⁢
(
0.87
⁢
λ
+
2.22
)
−
0.84
⁢
arctan
⁢
(
0.58
⁢
E
−
0.26
)
+
0.85
⁢
arctan
⁢
(
0.94
⁢
p
+
0.13
)
−
8.14
)
−
16.74
+
43.08
⁢
exp
⁢
(
−
0.93
⁢
(
0.06
⁢
(
0.13
−
p
)
2
−
0.27
⁢
tanh
⁢
(
0.65
⁢
E
+
0.25
)
+
0.63
⁢
arctan
⁢
(
0.54
⁢
λ
−
0.62
)
+
1
)
2
)
=
0
13.99
sin
0.28
sin
0.87
𝜆
2.22
0.84
arctan
0.58
𝐸
0.26
0.85
arctan
0.94
𝑝
0.13
8.14
16.74
43.08
exp
0.93
superscript
0.06
superscript
0.13
𝑝
2
0.27
tanh
0.65
𝐸
0.25
0.63
arctan
0.54
𝜆
0.62
1
2
0
13.99{\rm sin}(0.28{\rm sin}(0.87\lambda+2.22)-0.84{\rm arctan}(0.58E-0.26)+0.%
85{\rm arctan}(0.94p+0.13)-8.14)-16.74+43.08{\rm exp}(-0.93(0.06(0.13-p)^{2}-0%
.27{\rm tanh}(0.65E+0.25)+0.63{\rm arctan}(0.54\lambda-0.62)+1)^{2})=0
13.99 roman_sin ( 0.28 roman_sin ( 0.87 italic_λ + 2.22 ) - 0.84 roman_arctan ( 0.58 italic_E - 0.26 ) + 0.85 roman_arctan ( 0.94 italic_p + 0.13 ) - 8.14 ) - 16.74 + 43.08 roman_exp ( - 0.93 ( 0.06 ( 0.13 - italic_p ) start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT - 0.27 roman_tanh ( 0.65 italic_E + 0.25 ) + 0.63 roman_arctan ( 0.54 italic_λ - 0.62 ) + 1 ) start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT ) = 0






97.1%








 






KAN man (step 2) + auto








4.19
⁢
(
0.28
⁢
sin
⁢
(
0.97
⁢
λ
+
2.17
)
−
0.77
⁢
arctan
⁢
(
0.83
⁢
E
−
0.19
)
+
arctan
⁢
(
0.97
⁢
p
+
0.15
)
−
0.35
)
2
−
28.93
+
39.27
⁢
exp
⁢
(
−
0.6
⁢
(
0.28
⁢
cosh
2
⁢
(
0.49
⁢
p
−
0.16
)
−
0.34
⁢
arctan
⁢
(
0.65
⁢
E
+
0.51
)
+
0.83
⁢
arctan
⁢
(
0.54
⁢
λ
−
0.62
)
+
1
)
2
)
=
0
4.19
superscript
0.28
sin
0.97
𝜆
2.17
0.77
arctan
0.83
𝐸
0.19
arctan
0.97
𝑝
0.15
0.35
2
28.93
39.27
exp
0.6
superscript
0.28
superscript
cosh
2
0.49
𝑝
0.16
0.34
arctan
0.65
𝐸
0.51
0.83
arctan
0.54
𝜆
0.62
1
2
0
4.19(0.28{\rm sin}(0.97\lambda+2.17)-0.77{\rm arctan}(0.83E-0.19)+{\rm arctan}%
(0.97p+0.15)-0.35)^{2}-28.93+39.27{\rm exp}(-0.6(0.28{\rm cosh}^{2}(0.49p-0.16%
)-0.34{\rm arctan}(0.65E+0.51)+0.83{\rm arctan}(0.54\lambda-0.62)+1)^{2})=0
4.19 ( 0.28 roman_sin ( 0.97 italic_λ + 2.17 ) - 0.77 roman_arctan ( 0.83 italic_E - 0.19 ) + roman_arctan ( 0.97 italic_p + 0.15 ) - 0.35 ) start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT - 28.93 + 39.27 roman_exp ( - 0.6 ( 0.28 roman_cosh start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT ( 0.49 italic_p - 0.16 ) - 0.34 roman_arctan ( 0.65 italic_E + 0.51 ) + 0.83 roman_arctan ( 0.54 italic_λ - 0.62 ) + 1 ) start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT ) = 0






97.7%








 






KAN man (step 3) + auto








−
4.63
⁢
E
−
10.25
⁢
(
−
0.94
⁢
sin
⁢
(
0.97
⁢
λ
−
6.81
)
+
tanh
⁢
(
0.8
⁢
p
−
0.45
)
+
0.09
)
2
+
11.78
⁢
sin
⁢
(
0.76
⁢
p
−
1.41
)
+
22.49
⁢
arctan
⁢
(
1.08
⁢
λ
−
1.32
)
+
31.72
=
0
4.63
𝐸
10.25
superscript
0.94
sin
0.97
𝜆
6.81
tanh
0.8
𝑝
0.45
0.09
2
11.78
sin
0.76
𝑝
1.41
22.49
arctan
1.08
𝜆
1.32
31.72
0
-4.63E-10.25(-0.94{\rm sin}(0.97\lambda-6.81)+{\rm tanh}(0.8p-0.45)+0.09)^{2}+%
11.78{\rm sin}(0.76p-1.41)+22.49{\rm arctan}(1.08\lambda-1.32)+31.72=0
- 4.63 italic_E - 10.25 ( - 0.94 roman_sin ( 0.97 italic_λ - 6.81 ) + roman_tanh ( 0.8 italic_p - 0.45 ) + 0.09 ) start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT + 11.78 roman_sin ( 0.76 italic_p - 1.41 ) + 22.49 roman_arctan ( 1.08 italic_λ - 1.32 ) + 31.72 = 0






97.7%








 






KAN man (step 4A)








6.92
⁢
E
−
6.23
⁢
(
−
0.92
⁢
λ
−
1
)
2
+
2572.45
⁢
(
−
0.05
⁢
λ
+
0.95
⁢
cosh
⁢
(
0.11
⁢
p
+
0.4
)
−
1
)
2
−
12.96
⁢
cosh
2
⁢
(
0.53
⁢
p
+
0.16
)
+
19.89
=
0
6.92
𝐸
6.23
superscript
0.92
𝜆
1
2
2572.45
superscript
0.05
𝜆
0.95
cosh
0.11
𝑝
0.4
1
2
12.96
superscript
cosh
2
0.53
𝑝
0.16
19.89
0
6.92E-6.23(-0.92\lambda-1)^{2}+2572.45(-0.05\lambda+0.95{\rm cosh}(0.11p+0.4)-%
1)^{2}-12.96{\rm cosh}^{2}(0.53p+0.16)+19.89=0
6.92 italic_E - 6.23 ( - 0.92 italic_λ - 1 ) start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT + 2572.45 ( - 0.05 italic_λ + 0.95 roman_cosh ( 0.11 italic_p + 0.4 ) - 1 ) start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT - 12.96 roman_cosh start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT ( 0.53 italic_p + 0.16 ) + 19.89 = 0






96.6%








 






KAN man (step 4B)








7.25
⁢
E
−
8.81
⁢
(
−
0.83
⁢
λ
−
1
)
2
−
4.08
⁢
(
−
p
−
0.04
)
2
+
12.71
⁢
(
−
0.71
⁢
λ
+
(
0.3
⁢
p
+
1
)
2
−
0.86
)
2
+
10.29
=
0
7.25
𝐸
8.81
superscript
0.83
𝜆
1
2
4.08
superscript
𝑝
0.04
2
12.71
superscript
0.71
𝜆
superscript
0.3
𝑝
1
2
0.86
2
10.29
0
7.25E-8.81(-0.83\lambda-1)^{2}-4.08(-p-0.04)^{2}+12.71(-0.71\lambda+(0.3p+1)^{%
2}-0.86)^{2}+10.29=0
7.25 italic_E - 8.81 ( - 0.83 italic_λ - 1 ) start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT - 4.08 ( - italic_p - 0.04 ) start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT + 12.71 ( - 0.71 italic_λ + ( 0.3 italic_p + 1 ) start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT - 0.86 ) start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT + 10.29 = 0






95.4%








Table 6: 
Symbolic formulas for two systems GAAM and MAAM, ground truth ones and KAN-discovered ones.






Here the “order parameter” to be learned is 
g
⁢
(
α
,
E
,
λ
,
ϕ
)
=
α
⁢
E
+
2
⁢
(
λ
−
1
)
𝑔
𝛼
𝐸
𝜆
italic-ϕ
𝛼
𝐸
2
𝜆
1
g(\alpha,E,\lambda,\phi)=\alpha E+2(\lambda-1)
italic_g ( italic_α , italic_E , italic_λ , italic_ϕ ) = italic_α italic_E + 2 ( italic_λ - 1 )
 and mobility edge corresponds to 
g
=
0
𝑔
0
g=0
italic_g = 0
. Let us again assume that Alice wants to figure out the mobility edge but only has access to IPR or fractal dimension data, so she decides to use KAN to help her with the task. Alice wants the model to be as small as possible, so she could either start from a large model and use auto-pruning to get a small model, or she could guess a reasonable small model based on her understanding of the complexity of the given problem. Either way, let us assume she arrives at a 
[
4
,
2
,
1
,
1
]
4
2
1
1
[4,2,1,1]
[ 4 , 2 , 1 , 1 ]
 KAN. First, she sets the last activation to be sigmoid because this is a classification problem. She trains her KAN with some sparsity regularization to accuracy 98.7% and visualizes the trained KAN in Figure 
4.6
 (a) step 1. She observes that 
ϕ
italic-ϕ
\phi
italic_ϕ
 is not picked up on at all, which makes her realize that the mobility edge is independent of 
ϕ
italic-ϕ
\phi
italic_ϕ
 (agreeing with Eq. (
4.8
)). In addition, she observes that almost all other activation functions are linear or quadratic, so she turns on automatic symbolic snapping, constraining the library to be only linear or quadratic. After that, she immediately gets a network which is already symbolic (shown in Figure 
4.6
 (a) step 2), with comparable (even slightly better) accuracy 98.9%. By using 
symbolic_formula
 functionality, Alice conveniently gets the symbolic form of 
g
𝑔
g
italic_g
, shown in Table 
6
 GAAM-KAN auto (row three). Perhaps she wants to cross out some small terms and snap coefficient to small integers, which takes her close to the true answer.






This hypothetical story for Alice would be completely different if she is using a symbolic regression method. If she is lucky, SR can return the exact correct formula. However, the vast majority of the time SR does not return useful results and it is impossible for Alice to “debug” or interact with the underlying process of symbolic regression. Furthermore, Alice may feel uncomfortable/inexperienced to provide a library of symbolic terms as prior knowledge to SR before SR is run. By constrast in KANs, Alice does not need to put any prior information to KANs. She can first get some clues by staring at a trained KAN and only then it is her job to decide which hypothesis she wants to make (e.g., “all activations are linear or quadratic”) and implement her hypothesis in KANs. Although it is not likely for KANs to return the correct answer immediately, KANs will always return something useful, and Alice can collaborate with it to refine the results.






Modified Andre-Aubry Model (MAAM)
 The last class of models we consider is defined by the Hamiltonian 
[
44
]








H
=
∑
n
≠
n
′
t
⁢
e
−
p
⁢
|
n
−
n
′
|
⁢
(
c
n
†
⁢
c
n
′
+
H.c.
)
+
∑
n
V
n
⁢
(
λ
,
ϕ
)
⁢
c
n
†
⁢
c
n
,
𝐻
subscript
𝑛
superscript
𝑛
′
𝑡
superscript
𝑒
𝑝
𝑛
superscript
𝑛
′
subscript
superscript
𝑐
†
𝑛
subscript
𝑐
superscript
𝑛
′
H.c.
subscript
𝑛
subscript
𝑉
𝑛
𝜆
italic-ϕ
subscript
superscript
𝑐
†
𝑛
subscript
𝑐
𝑛
\displaystyle H=\sum_{n\neq n^{\prime}}te^{-p|n-n^{\prime}|}\left(c^{\dagger}_%
{n}c_{n^{\prime}}+\text{H.c.}\right)+\sum_{n}V_{n}(\lambda,\phi)c^{\dagger}_{n%
}c_{n},
italic_H = ∑ start_POSTSUBSCRIPT italic_n ≠ italic_n start_POSTSUPERSCRIPT ′ end_POSTSUPERSCRIPT end_POSTSUBSCRIPT italic_t italic_e start_POSTSUPERSCRIPT - italic_p | italic_n - italic_n start_POSTSUPERSCRIPT ′ end_POSTSUPERSCRIPT | end_POSTSUPERSCRIPT ( italic_c start_POSTSUPERSCRIPT † end_POSTSUPERSCRIPT start_POSTSUBSCRIPT italic_n end_POSTSUBSCRIPT italic_c start_POSTSUBSCRIPT italic_n start_POSTSUPERSCRIPT ′ end_POSTSUPERSCRIPT end_POSTSUBSCRIPT + H.c. ) + ∑ start_POSTSUBSCRIPT italic_n end_POSTSUBSCRIPT italic_V start_POSTSUBSCRIPT italic_n end_POSTSUBSCRIPT ( italic_λ , italic_ϕ ) italic_c start_POSTSUPERSCRIPT † end_POSTSUPERSCRIPT start_POSTSUBSCRIPT italic_n end_POSTSUBSCRIPT italic_c start_POSTSUBSCRIPT italic_n end_POSTSUBSCRIPT ,




(4.9)






where 
t
𝑡
t
italic_t
 is the strength of the exponentially decaying coupling in space, 
c
n
⁢
(
c
n
†
)
subscript
𝑐
𝑛
subscript
superscript
𝑐
†
𝑛
c_{n}(c^{\dagger}_{n})
italic_c start_POSTSUBSCRIPT italic_n end_POSTSUBSCRIPT ( italic_c start_POSTSUPERSCRIPT † end_POSTSUPERSCRIPT start_POSTSUBSCRIPT italic_n end_POSTSUBSCRIPT )
 is the annihilation (creation) operator at site 
n
𝑛
n
italic_n
 and the potential energy 
V
n
subscript
𝑉
𝑛
V_{n}
italic_V start_POSTSUBSCRIPT italic_n end_POSTSUBSCRIPT
 is given by








V
n
⁢
(
λ
,
ϕ
)
=
λ
⁢
cos
⁡
(
2
⁢
π
⁢
n
⁢
b
+
ϕ
)
,
subscript
𝑉
𝑛
𝜆
italic-ϕ
𝜆
2
𝜋
𝑛
𝑏
italic-ϕ
\displaystyle V_{n}(\lambda,\phi)=\lambda\cos(2\pi nb+\phi),
italic_V start_POSTSUBSCRIPT italic_n end_POSTSUBSCRIPT ( italic_λ , italic_ϕ ) = italic_λ roman_cos ( 2 italic_π italic_n italic_b + italic_ϕ ) ,




(4.10)






As before, to introduce quasiperiodicity, we set 
b
𝑏
b
italic_b
 to be irrational (the golden ratio). For these models, the mobility edge is given by the closed form expression 
[
44
]
,








λ
⁢
cosh
⁡
(
p
)
=
E
+
t
=
E
+
t
1
⁢
exp
⁢
(
p
)
𝜆
𝑝
𝐸
𝑡
𝐸
subscript
𝑡
1
exp
𝑝
\displaystyle\lambda\cosh(p)=E+t=E+t_{1}{\rm exp}(p)
italic_λ roman_cosh ( italic_p ) = italic_E + italic_t = italic_E + italic_t start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT roman_exp ( italic_p )




(4.11)






where we define 
t
1
≡
t
⁢
exp
⁢
(
−
p
)
subscript
𝑡
1
𝑡
exp
𝑝
t_{1}\equiv t{\rm exp}(-p)
italic_t start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT ≡ italic_t roman_exp ( - italic_p )
 as the nearest neighbor hopping strength, and we set 
t
1
=
1
subscript
𝑡
1
1
t_{1}=1
italic_t start_POSTSUBSCRIPT 1 end_POSTSUBSCRIPT = 1
 below.






Figure 4.6: 
Human-KAN collaboration to discover mobility edges of GAAM and MAAM. The human user can choose to be lazy (using the auto mode) or more involved (using the manual mode). More details in text.






Let us assume Alice wants to figure out the mobility edge for MAAM. This task is more complicated and requires more human wisdom. As in the last example, Alice starts from a 
[
4
,
2
,
1
,
1
]
4
2
1
1
[4,2,1,1]
[ 4 , 2 , 1 , 1 ]
 KAN and trains it but gets an accuracy around 75% which is less than acceptable. She then chooses a larger 
[
4
,
3
,
1
,
1
]
4
3
1
1
[4,3,1,1]
[ 4 , 3 , 1 , 1 ]
 KAN and successfully gets 98.4% which is acceptable (Figure 
4.6
 (b) step 1). Alice notices that 
ϕ
italic-ϕ
\phi
italic_ϕ
 is not picked up on by KANs, which means that the mobility edge is independent of the phase factor 
ϕ
italic-ϕ
\phi
italic_ϕ
 (agreeing with Eq. (
4.11
)). If Alice turns on the automatic symbolic regression (using a large library consisting of exp, tanh etc.), she would get a complicated formula in Tabel 
6
-MAAM-KAN auto, which has 97.1% accuracy. However, if Alice wants to find a simpler symbolic formula, she will want to use the manual mode where she does the symbolic snapping by herself. Before that she finds that the 
[
4
,
3
,
1
,
1
]
4
3
1
1
[4,3,1,1]
[ 4 , 3 , 1 , 1 ]
 KAN after training can then be pruned to be 
[
4
,
2
,
1
,
1
]
4
2
1
1
[4,2,1,1]
[ 4 , 2 , 1 , 1 ]
, while maintaining 
97.7
%
percent
97.7
97.7\%
97.7 %
 accuracy (Figure 
4.6
 (b)). Alice may think that all activation functions except those dependent on 
p
𝑝
p
italic_p
 are linear or quadratic and snap them to be either linear or quadratic manually by using 
fix_symbolic
. After snapping and retraining, the updated KAN is shown in Figure 
4.6
 (c) step 3, maintaining 
97.7
%
percent
97.7
97.7\%
97.7 %
 accuracy. From now on, Alice may make two different choices based on her prior knowledge. In one case, Alice may have guessed that the dependence on 
p
𝑝
p
italic_p
 is 
cosh
cosh
{\rm cosh}
roman_cosh
, so she sets the activations of 
p
𝑝
p
italic_p
 to be 
cosh
cosh
{\rm cosh}
roman_cosh
 function. She retrains KAN and gets 96.9% accuracy (Figure 
4.6
 (c) Step 4A). In another case, Alice does not know the 
cosh
⁢
p
cosh
𝑝
{\rm cosh}\ p
roman_cosh italic_p
 dependence, so she pursues simplicity and again assumes the functions of 
p
𝑝
p
italic_p
 to be quadratic. She retrains KAN and gets 95.4% accuracy (Figure 
4.6
 (c) Step 4B). If she tried both, she would realize that 
cosh
cosh
{\rm cosh}
roman_cosh
 is better in terms of accuracy, while quadratic is better in terms of simplicity. The formulas corresponding to these steps are listed in Table 
6
. It is clear that the more manual operations are done by Alice, the simpler the symbolic formula is (which slight sacrifice in accuracy). KANs have a “knob" that a user can tune to trade-off between simplicity and accuracy (sometimes simplicity can even lead to better accuracy, as in the GAAM case).












5 
Related works




Kolmogorov-Arnold theorem and neural networks.
 The connection between the Kolmogorov-Arnold theorem (KAT) and neural networks is not new in the literature  
[
50
, 
51
, 
8
, 
9
, 
10
, 
11
, 
12
, 
13
]
, but the pathological behavior of inner functions makes KAT appear unpromising in practice 
[
50
]
. Most of these prior works stick to the original 2-layer width-(
2
⁢
n
+
1
2
𝑛
1
2n+1
2 italic_n + 1
) networks, which were limited in expressive power and many of them are even predating back-propagation. Therefore, most studies were built on theories with rather limited or artificial toy experiments. Our contribution lies in generalizing the network to arbitrary widths and depths, revitalizing and contexualizing them in today’s deep learning stream, as well as highlighting its potential role as a foundation model for AI + Science.






Neural Scaling Laws (NSLs).
 NSLs are the phenomena where test losses behave as power laws against model size, data, compute etc 
[
52
, 
53
, 
54
, 
55
, 
17
, 
56
, 
57
, 
58
]
. The origin of NSLs still remains mysterious, but competitive theories include intrinsic dimensionality 
[
52
]
, quantization of tasks 
[
57
]
, resource theory 
[
58
]
, random features 
[
56
]
, compositional sparsity 
[
50
]
, and maximu arity 
[
18
]
. This paper contributes to this space by showing that a high-dimensional function can surprisingly scale as a 1D function (which is the best possible bound one can hope for) if it has a smooth Kolmogorov-Arnold representation. Our paper brings fresh optimism to neural scaling laws, since it promises the fastest scaling exponent ever. We have shown in our experiments that this fast neural scaling law can be achieved on synthetic datasets, but future research is required to address the question whether this fast scaling is achievable for more complicated tasks (e.g., language modeling): Do KA representations exist for general tasks? If so, does our training find these representations in practice?






Mechanistic Interpretability (MI).
 MI is an emerging field that aims to mechanistically understand the inner workings of neural networks 
[
59
, 
60
, 
61
, 
62
, 
63
, 
64
, 
65
, 
66
, 
5
]
. MI research can be roughly divided into passive and active MI research. Most MI research is passive in focusing on understanding existing neural networks trained with standard methods. Active MI research attempts to achieve interpretability by designing intrinsically interpretable architectures or developing training methods to explicitly encourage interpretability 
[
65
, 
66
]
. Our work lies in the second category, where the model and training method are by design interpretable.






Learnable activations.
 The idea of learnable activations in neural networks is not new in machine learning. Trainable activations functions are learned in a differentiable way 
[
67
, 
13
, 
68
, 
69
]
 or searched in a discrete way 
[
70
]
. Activation function are parametrized as polynomials 
[
67
]
, splines 
[
13
, 
71
, 
72
]
, sigmoid linear unit 
[
68
]
, or neural networks 
[
69
]
. KANs use B-splines to parametrize their activation functions. We also present our preliminary results on learnable activation networks (LANs), whose properties lie between KANs and MLPs and their results are deferred to Appendix 
B
 to focus on KANs in the main paper.






Symbolic Regression.
 There are many off-the-shelf symbolic regression methods based on genetic algorithms (Eureka 
[
73
]
, GPLearn 
[
74
]
, PySR 
[
75
]
), neural-network based methods (EQL 
[
76
]
, OccamNet 
[
77
]
), physics-inspired method (AI Feynman 
[
20
, 
21
]
), and reinforcement learning-based methods 
[
78
]
. KANs are most similar to neural network-based methods, but differ from previous works in that our activation functions are continuously learned before symbolic snapping rather than manually fixed 
[
73
, 
77
]
.






Physics-Informed Neural Networks (PINNs) and Physics-Informed Neural Operators (PINOs).

In Subsection 
3.4
, we demonstrate that KANs can replace the paradigm of using MLPs for imposing PDE loss when solving PDEs. We refer to Deep Ritz Method 
[
79
]
, PINNs 
[
22
, 
23
]
 for PDE solving, and Fourier Neural operator 
[
80
]
, PINOs 
[
81
, 
82
, 
83
]
, DeepONet 
[
84
]
 for operator learning methods learning the solution map. There is potential to replace MLPs with KANs in all the aforementioned networks.






AI for Mathematics.
 As we saw in Subsection 
4.3
, AI has recently been applied to several problems in Knot theory, including detecting whether a knot is the unknot 
[
85
, 
86
]
 or a ribbon knot 
[
30
]
, and predicting knot invariants and uncovering relations among them 
[
87
, 
88
, 
89
, 
29
]
. For a summary of data science applications to datasets in mathematics and theoretical physics see e.g. 
[
90
, 
91
]
, and for ideas how to obtain rigorous results from ML techniques in these fields, see 
[
92
]
.










6 
Discussion




In this section, we discuss KANs’ limitations and future directions from the perspective of mathematical foundation, algorithms and applications.






Mathematical aspects:
 Although we have presented preliminary mathematical analysis of KANs (Theorem 
2.1
), our mathematical understanding of them is still very limited. The Kolmogorov-Arnold representation theorem has been studied thoroughly in mathematics, but the theorem corresponds to KANs with shape 
[
n
,
2
⁢
n
+
1
,
1
]
𝑛
2
𝑛
1
1
[n,2n+1,1]
[ italic_n , 2 italic_n + 1 , 1 ]
, which is a very restricted subclass of KANs. Does our empirical success with deeper KANs imply something fundamental in mathematics? An appealing generalized Kolmogorov-Arnold theorem could define “deeper” Kolmogorov-Arnold representations beyond depth-2 compositions, and potentially relate smoothness of activation functions to depth. Hypothetically, there exist functions which cannot be represented smoothly in the original (depth-2) Kolmogorov-Arnold representations, but might be smoothly represented with depth-3 or beyond. Can we use this notion of “Kolmogorov-Arnold depth” to characterize function classes?






Algorithmic aspects:
 We discuss the following:






(1)




Accuracy. Multiple choices in architecture design and training are not fully investigated so alternatives can potentially further improve accuracy. For example, spline activation functions might be replaced by radial basis functions or other local kernels. Adaptive grid strategies can be used.








(2)




Efficiency. One major reason why KANs run slowly is because different activation functions cannot leverage batch computation (large data through the same function). Actually, one can interpolate between activation functions being all the same (MLPs) and all different (KANs), by grouping activation functions into multiple groups (“multi-head”), where members within a group share the same activation function.








(3)




Hybrid of KANs and MLPs. KANs have two major differences compared to MLPs:






(i)




activation functions are on edges instead of on nodes,








(ii)




activation functions are learnable instead of fixed.








Which change is more essential to explain KAN’s advantage? We present our preliminary results in Appendix 
B
 where we study a model which has (ii), i.e., activation functions are learnable (like KANs), but not (i), i.e., activation functions are on nodes (like MLPs). Moreover, one can also construct another model with fixed activations (like MLPs) but on edges (like KANs).








(4)




Adaptivity. Thanks to the intrinsic locality of spline basis functions, we can introduce adaptivity in the design and training of KANs to enhance both accuracy and efficiency: see the idea of multi-level training like multigrid methods as in 
[
93
, 
94
]
, or domain-dependent basis functions like multiscale methods as in 
[
95
]
.












Application aspects:
 We have presented some preliminary evidences that KANs are more effective than MLPs in science-related tasks, e.g., fitting physical equations and PDE solving. We expect that KANs may
also be promising for solving Navier-Stokes equations, density functional theory, or any other tasks that can be formulated as regression or PDE solving. We would also like to apply KANs to machine-learning-related tasks, which would require integrating KANs into current architectures, e.g., transformers – one may propose “kansformers” which replace MLPs by KANs in transformers.






KAN as a “language model” for AI + Science
 The reason why large language models are so transformative is because they are useful to anyone who can speak natural language. The language of science is functions. KANs are composed of interpretable functions, so when a human user stares at a KAN, it is like communicating with it using the language of functions. This paragraph aims to promote the AI-Scientist-Collaboration paradigm rather than our specific tool KANs. Just like people use different languages to communicate, we expect that in the future KANs will be just one of the languages for AI + Science, although KANs will be one of the very first languages that would enable AI and human to communicate. However, enabled by KANs, the AI-Scientist-Collaboration paradigm has never been this easy and convenient, which leads us to rethink the paradigm of how we want to approach AI + Science: Do we want AI scientists, or do we want AI that helps scientists? The intrinsic difficulty of (fully automated) AI scientists is that it is hard to make human preferences quantitative, which would codify human preferences into AI objectives. In fact, scientists in different fields may feel differently about which functions are simple or interpretable. As a result, it is more desirable for scientists to have an AI that can speak the scientific language (functions) and can conveniently interact with inductive biases of individual scientist(s) to adapt to a specific scientific domain.






Final takeaway: Should I use KANs or MLPs?






Currently, the biggest bottleneck of KANs lies in its slow training. KANs are usually 10x slower than MLPs, given the same number of parameters. We should be honest that we did not try hard to optimize KANs’ efficiency though, so we deem KANs’ slow training more as an engineering problem to be improved in the future rather than a fundamental limitation. If one wants to train a model fast, one should use MLPs. In other cases, however, KANs should be comparable or better than MLPs, which makes them worth trying. The decision tree in Figure 
6.1
 can help decide when to use a KAN. In short, if you care about interpretability and/or accuracy, and slow training is not a major concern, we suggest trying KANs.






Figure 6.1: 
Should I use KANs or MLPs?








Acknowledgement




We would like to thank Mikail Khona, Tomaso Poggio, Pingchuan Ma, Rui Wang, Di Luo, Sara Beery, Catherine Liang and Matthieu Darcy for fruitful discussion and constructive suggestions. Z.L., F.R., J.H., M.S. and M.T. are supported by IAIFI through NSF grant PHY-2019786. The work of FR is in addition supported by the NSF grant PHY-2210333 and by startup funding from Northeastern University. Y.W and T.H are supported by the NSF Grant DMS-2205590 and the Choi Family Gift Fund. S. V. and M. S. acknowledge support from the U.S. Office of Naval Research (ONR) Multidisciplinary University Research Initiative (MURI) under Grant No. N00014-20-1-2325 on Robust Photonic Materials with Higher-Order Topological Protection.








References






[1]



Simon Haykin.




Neural networks: a comprehensive foundation
.




Prentice Hall PTR, 1994.








[2]



George Cybenko.




Approximation by superpositions of a sigmoidal function.




Mathematics of control, signals and systems
, 2(4):303–314, 1989.








[3]



Kurt Hornik, Maxwell Stinchcombe, and Halbert White.




Multilayer feedforward networks are universal approximators.




Neural networks
, 2(5):359–366, 1989.








[4]



Ashish Vaswani, Noam Shazeer, Niki Parmar, Jakob Uszkoreit, Llion Jones, Aidan N Gomez, Łukasz Kaiser, and Illia Polosukhin.




Attention is all you need.




Advances in neural information processing systems
, 30, 2017.








[5]



Hoagy Cunningham, Aidan Ewart, Logan Riggs, Robert Huben, and Lee Sharkey.




Sparse autoencoders find highly interpretable features in language models.




arXiv preprint arXiv:2309.08600
, 2023.








[6]



A.N. Kolmogorov.




On the representation of continuous functions of several variables as superpositions of continuous functions of a smaller number of variables.




Dokl. Akad. Nauk
, 108(2), 1956.








[7]



Jürgen Braun and Michael Griebel.




On a constructive proof of kolmogorov’s superposition theorem.




Constructive approximation
, 30:653–675, 2009.








[8]



David A Sprecher and Sorin Draghici.




Space-filling curves and kolmogorov superposition-based neural networks.




Neural Networks
, 15(1):57–67, 2002.








[9]



Mario Köppen.




On the training of a kolmogorov network.




In 
Artificial Neural Networks—ICANN 2002: International Conference Madrid, Spain, August 28–30, 2002 Proceedings 12
, pages 474–479. Springer, 2002.








[10]



Ji-Nan Lin and Rolf Unbehauen.




On the realization of a kolmogorov network.




Neural Computation
, 5(1):18–20, 1993.








[11]



Ming-Jun Lai and Zhaiming Shen.




The kolmogorov superposition theorem can break the curse of dimensionality when approximating high dimensional functions.




arXiv preprint arXiv:2112.09963
, 2021.








[12]



Pierre-Emmanuel Leni, Yohan D Fougerolle, and Frédéric Truchetet.




The kolmogorov spline network for image processing.




In 
Image Processing: Concepts, Methodologies, Tools, and Applications
, pages 54–78. IGI Global, 2013.








[13]



Daniele Fakhoury, Emanuele Fakhoury, and Hendrik Speleers.




Exsplinet: An interpretable and expressive spline-based neural network.




Neural Networks
, 152:332–346, 2022.








[14]



Tomaso Poggio, Andrzej Banburski, and Qianli Liao.




Theoretical issues in deep networks.




Proceedings of the National Academy of Sciences
, 117(48):30039–30045, 2020.








[15]



Henry W Lin, Max Tegmark, and David Rolnick.




Why does deep and cheap learning work so well?




Journal of Statistical Physics
, 168:1223–1247, 2017.








[16]



Hongyi Xu, Funshing Sin, Yufeng Zhu, and Jernej Barbič.




Nonlinear material design using principal stretches.




ACM Transactions on Graphics (TOG)
, 34(4):1–11, 2015.








[17]



Utkarsh Sharma and Jared Kaplan.




A neural scaling law from the dimension of the data manifold.




arXiv preprint arXiv:2004.10802
, 2020.








[18]



Eric J Michaud, Ziming Liu, and Max Tegmark.




Precision machine learning.




Entropy
, 25(1):175, 2023.








[19]



Carl De Boor and Carl De Boor.




A practical guide to splines
, volume 27.




springer-verlag New York, 1978.








[20]



Silviu-Marian Udrescu and Max Tegmark.




Ai feynman: A physics-inspired method for symbolic regression.




Science Advances
, 6(16):eaay2631, 2020.








[21]



Silviu-Marian Udrescu, Andrew Tan, Jiahai Feng, Orisvaldo Neto, Tailin Wu, and Max Tegmark.




Ai feynman 2.0: Pareto-optimal symbolic regression exploiting graph modularity.




Advances in Neural Information Processing Systems
, 33:4860–4871, 2020.








[22]



Maziar Raissi, Paris Perdikaris, and George E Karniadakis.




Physics-informed neural networks: A deep learning framework for solving forward and inverse problems involving nonlinear partial differential equations.




Journal of Computational physics
, 378:686–707, 2019.








[23]



George Em Karniadakis, Ioannis G Kevrekidis, Lu Lu, Paris Perdikaris, Sifan Wang, and Liu Yang.




Physics-informed machine learning.




Nature Reviews Physics
, 3(6):422–440, 2021.








[24]



Ronald Kemker, Marc McClure, Angelina Abitino, Tyler Hayes, and Christopher Kanan.




Measuring catastrophic forgetting in neural networks.




In 
Proceedings of the AAAI conference on artificial intelligence
, volume 32, 2018.








[25]



Bryan Kolb and Ian Q Whishaw.




Brain plasticity and behavior.




Annual review of psychology
, 49(1):43–64, 1998.








[26]



David Meunier, Renaud Lambiotte, and Edward T Bullmore.




Modular and hierarchically modular organization of brain networks.




Frontiers in neuroscience
, 4:7572, 2010.








[27]



James Kirkpatrick, Razvan Pascanu, Neil Rabinowitz, Joel Veness, Guillaume Desjardins, Andrei A Rusu, Kieran Milan, John Quan, Tiago Ramalho, Agnieszka Grabska-Barwinska, et al.




Overcoming catastrophic forgetting in neural networks.




Proceedings of the national academy of sciences
, 114(13):3521–3526, 2017.








[28]



Aojun Lu, Tao Feng, Hangjie Yuan, Xiaotian Song, and Yanan Sun.




Revisiting neural networks for continual learning: An architectural perspective, 2024.








[29]



Alex Davies, Petar Veličković, Lars Buesing, Sam Blackwell, Daniel Zheng, Nenad Tomašev, Richard Tanburn, Peter Battaglia, Charles Blundell, András Juhász, et al.




Advancing mathematics by guiding human intuition with ai.




Nature
, 600(7887):70–74, 2021.








[30]



Sergei Gukov, James Halverson, Ciprian Manolescu, and Fabian Ruehle.




Searching for ribbons with machine learning, 2023.








[31]



P. Petersen.




Riemannian Geometry
.




Graduate Texts in Mathematics. Springer New York, 2006.








[32]



Philip W Anderson.




Absence of diffusion in certain random lattices.




Physical review
, 109(5):1492, 1958.








[33]



David J Thouless.




A relation between the density of states and range of localization for one dimensional random systems.




Journal of Physics C: Solid State Physics
, 5(1):77, 1972.








[34]



Elihu Abrahams, PW Anderson, DC Licciardello, and TV Ramakrishnan.




Scaling theory of localization: Absence of quantum diffusion in two dimensions.




Physical Review Letters
, 42(10):673, 1979.








[35]



Ad Lagendijk, Bart van Tiggelen, and Diederik S Wiersma.




Fifty years of anderson localization.




Physics today
, 62(8):24–29, 2009.








[36]



Mordechai Segev, Yaron Silberberg, and Demetrios N Christodoulides.




Anderson localization of light.




Nature Photonics
, 7(3):197–204, 2013.








[37]



Z Valy Vardeny, Ajay Nahata, and Amit Agrawal.




Optics of photonic quasicrystals.




Nature photonics
, 7(3):177–187, 2013.








[38]



Sajeev John.




Strong localization of photons in certain disordered dielectric superlattices.




Physical review letters
, 58(23):2486, 1987.








[39]



Yoav Lahini, Rami Pugatch, Francesca Pozzi, Marc Sorel, Roberto Morandotti, Nir Davidson, and Yaron Silberberg.




Observation of a localization transition in quasiperiodic photonic lattices.




Physical review letters
, 103(1):013901, 2009.








[40]



Sachin Vaidya, Christina Jörg, Kyle Linn, Megan Goh, and Mikael C Rechtsman.




Reentrant delocalization transition in one-dimensional photonic quasicrystals.




Physical Review Research
, 5(3):033170, 2023.








[41]



Wojciech De Roeck, Francois Huveneers, Markus Müller, and Mauro Schiulaz.




Absence of many-body mobility edges.




Physical Review B
, 93(1):014203, 2016.








[42]



Xiaopeng Li, Sriram Ganeshan, JH Pixley, and S Das Sarma.




Many-body localization and quantum nonergodicity in a model with a single-particle mobility edge.




Physical review letters
, 115(18):186601, 2015.








[43]



Fangzhao Alex An, Karmela Padavić, Eric J Meier, Suraj Hegde, Sriram Ganeshan, JH Pixley, Smitha Vishveshwara, and Bryce Gadway.




Interactions and mobility edges: Observing the generalized aubry-andré model.




Physical review letters
, 126(4):040603, 2021.








[44]



J Biddle and S Das Sarma.




Predicted mobility edges in one-dimensional incommensurate optical lattices: An exactly solvable model of anderson localization.




Physical review letters
, 104(7):070601, 2010.








[45]



Alexander Duthie, Sthitadhi Roy, and David E Logan.




Self-consistent theory of mobility edges in quasiperiodic chains.




Physical Review B
, 103(6):L060201, 2021.








[46]



Sriram Ganeshan, JH Pixley, and S Das Sarma.




Nearest neighbor tight binding models with an exact mobility edge in one dimension.




Physical review letters
, 114(14):146601, 2015.








[47]



Yucheng Wang, Xu Xia, Long Zhang, Hepeng Yao, Shu Chen, Jiangong You, Qi Zhou, and Xiong-Jun Liu.




One-dimensional quasiperiodic mosaic lattice with exact mobility edges.




Physical Review Letters
, 125(19):196604, 2020.








[48]



Yucheng Wang, Xu Xia, Yongjian Wang, Zuohuan Zheng, and Xiong-Jun Liu.




Duality between two generalized aubry-andré models with exact mobility edges.




Physical Review B
, 103(17):174205, 2021.








[49]



Xin-Chi Zhou, Yongjian Wang, Ting-Fung Jeffrey Poon, Qi Zhou, and Xiong-Jun Liu.




Exact new mobility edges between critical and localized states.




Physical Review Letters
, 131(17):176401, 2023.








[50]



Tomaso Poggio.




How deep sparse networks avoid the curse of dimensionality: Efficiently computable functions are compositionally sparse.




CBMM Memo
, 10:2022, 2022.








[51]



Johannes Schmidt-Hieber.




The kolmogorov–arnold representation theorem revisited.




Neural networks
, 137:119–126, 2021.








[52]



Jared Kaplan, Sam McCandlish, Tom Henighan, Tom B Brown, Benjamin Chess, Rewon Child, Scott Gray, Alec Radford, Jeffrey Wu, and Dario Amodei.




Scaling laws for neural language models.




arXiv preprint arXiv:2001.08361
, 2020.








[53]



Tom Henighan, Jared Kaplan, Mor Katz, Mark Chen, Christopher Hesse, Jacob Jackson, Heewoo Jun, Tom B Brown, Prafulla Dhariwal, Scott Gray, et al.




Scaling laws for autoregressive generative modeling.




arXiv preprint arXiv:2010.14701
, 2020.








[54]



Mitchell A Gordon, Kevin Duh, and Jared Kaplan.




Data and parameter scaling laws for neural machine translation.




In 
ACL Rolling Review - May 2021
, 2021.








[55]



Joel Hestness, Sharan Narang, Newsha Ardalani, Gregory Diamos, Heewoo Jun, Hassan Kianinejad, Md Mostofa Ali Patwary, Yang Yang, and Yanqi Zhou.




Deep learning scaling is predictable, empirically.




arXiv preprint arXiv:1712.00409
, 2017.








[56]



Yasaman Bahri, Ethan Dyer, Jared Kaplan, Jaehoon Lee, and Utkarsh Sharma.




Explaining neural scaling laws.




arXiv preprint arXiv:2102.06701
, 2021.








[57]



Eric J Michaud, Ziming Liu, Uzay Girit, and Max Tegmark.




The quantization model of neural scaling.




In 
Thirty-seventh Conference on Neural Information Processing Systems
, 2023.








[58]



Jinyeop Song, Ziming Liu, Max Tegmark, and Jeff Gore.




A resource model for neural scaling law.




arXiv preprint arXiv:2402.05164
, 2024.








[59]



Catherine Olsson, Nelson Elhage, Neel Nanda, Nicholas Joseph, Nova DasSarma, Tom Henighan, Ben Mann, Amanda Askell, Yuntao Bai, Anna Chen, et al.




In-context learning and induction heads.




arXiv preprint arXiv:2209.11895
, 2022.








[60]



Kevin Meng, David Bau, Alex Andonian, and Yonatan Belinkov.




Locating and editing factual associations in gpt.




Advances in Neural Information Processing Systems
, 35:17359–17372, 2022.








[61]



Kevin Ro Wang, Alexandre Variengien, Arthur Conmy, Buck Shlegeris, and Jacob Steinhardt.




Interpretability in the wild: a circuit for indirect object identification in GPT-2 small.




In 
The Eleventh International Conference on Learning Representations
, 2023.








[62]



Nelson Elhage, Tristan Hume, Catherine Olsson, Nicholas Schiefer, Tom Henighan, Shauna Kravec, Zac Hatfield-Dodds, Robert Lasenby, Dawn Drain, Carol Chen, et al.




Toy models of superposition.




arXiv preprint arXiv:2209.10652
, 2022.








[63]



Neel Nanda, Lawrence Chan, Tom Lieberum, Jess Smith, and Jacob Steinhardt.




Progress measures for grokking via mechanistic interpretability.




In 
The Eleventh International Conference on Learning Representations
, 2023.








[64]



Ziqian Zhong, Ziming Liu, Max Tegmark, and Jacob Andreas.




The clock and the pizza: Two stories in mechanistic explanation of neural networks.




In 
Thirty-seventh Conference on Neural Information Processing Systems
, 2023.








[65]



Ziming Liu, Eric Gan, and Max Tegmark.




Seeing is believing: Brain-inspired modular training for mechanistic interpretability.




Entropy
, 26(1):41, 2023.








[66]



Nelson Elhage, Tristan Hume, Catherine Olsson, Neel Nanda, Tom Henighan, Scott Johnston, Sheer ElShowk, Nicholas Joseph, Nova DasSarma, Ben Mann, Danny Hernandez, Amanda Askell, Kamal Ndousse, Andy Jones, Dawn Drain, Anna Chen, Yuntao Bai, Deep Ganguli, Liane Lovitt, Zac Hatfield-Dodds, Jackson Kernion, Tom Conerly, Shauna Kravec, Stanislav Fort, Saurav Kadavath, Josh Jacobson, Eli Tran-Johnson, Jared Kaplan, Jack Clark, Tom Brown, Sam McCandlish, Dario Amodei, and Christopher Olah.




Softmax linear units.




Transformer Circuits Thread
, 2022.




https://transformer-circuits.pub/2022/solu/index.html.








[67]



Mohit Goyal, Rajan Goyal, and Brejesh Lall.




Learning activation functions: A new paradigm for understanding neural networks.




arXiv preprint arXiv:1906.09529
, 2019.








[68]



Prajit Ramachandran, Barret Zoph, and Quoc V Le.




Searching for activation functions.




arXiv preprint arXiv:1710.05941
, 2017.








[69]



Shijun Zhang, Zuowei Shen, and Haizhao Yang.




Neural network architecture beyond width and depth.




Advances in Neural Information Processing Systems
, 35:5669–5681, 2022.








[70]



Garrett Bingham and Risto Miikkulainen.




Discovering parametric activation functions.




Neural Networks
, 148:48–65, 2022.








[71]



Pakshal Bohra, Joaquim Campos, Harshit Gupta, Shayan Aziznejad, and Michael Unser.




Learning activation functions in deep (spline) neural networks.




IEEE Open Journal of Signal Processing
, 1:295–309, 2020.








[72]



Shayan Aziznejad and Michael Unser.




Deep spline networks with control of lipschitz regularity.




In 
ICASSP 2019-2019 IEEE International Conference on Acoustics, Speech and Signal Processing (ICASSP)
, pages 3242–3246. IEEE, 2019.








[73]



Renáta Dubcáková.




Eureqa: software review.




Genetic Programming and Evolvable Machines
, 12:173–178, 2011.








[74]



Gplearn.




https://github.com/trevorstephens/gplearn
.




Accessed: 2024-04-19.








[75]



Miles Cranmer.




Interpretable machine learning for science with pysr and symbolicregression. jl.




arXiv preprint arXiv:2305.01582
, 2023.








[76]



Georg Martius and Christoph H Lampert.




Extrapolation and learning equations.




arXiv preprint arXiv:1610.02995
, 2016.








[77]



Owen Dugan, Rumen Dangovski, Allan Costa, Samuel Kim, Pawan Goyal, Joseph Jacobson, and Marin Soljačić.




Occamnet: A fast neural model for symbolic regression at scale.




arXiv preprint arXiv:2007.10784
, 2020.








[78]



Terrell N. Mundhenk, Mikel Landajuela, Ruben Glatt, Claudio P. Santiago, Daniel faissol, and Brenden K. Petersen.




Symbolic regression via deep reinforcement learning enhanced genetic programming seeding.




In A. Beygelzimer, Y. Dauphin, P. Liang, and J. Wortman Vaughan, editors, 
Advances in Neural Information Processing Systems
, 2021.








[79]



Bing Yu et al.




The deep ritz method: a deep learning-based numerical algorithm for solving variational problems.




Communications in Mathematics and Statistics
, 6(1):1–12, 2018.








[80]



Zongyi Li, Nikola Kovachki, Kamyar Azizzadenesheli, Burigede Liu, Kaushik Bhattacharya, Andrew Stuart, and Anima Anandkumar.




Fourier neural operator for parametric partial differential equations.




arXiv preprint arXiv:2010.08895
, 2020.








[81]



Zongyi Li, Hongkai Zheng, Nikola Kovachki, David Jin, Haoxuan Chen, Burigede Liu, Kamyar Azizzadenesheli, and Anima Anandkumar.




Physics-informed neural operator for learning partial differential equations.




ACM/JMS Journal of Data Science
, 2021.








[82]



Nikola Kovachki, Zongyi Li, Burigede Liu, Kamyar Azizzadenesheli, Kaushik Bhattacharya, Andrew Stuart, and Anima Anandkumar.




Neural operator: Learning maps between function spaces with applications to pdes.




Journal of Machine Learning Research
, 24(89):1–97, 2023.








[83]



Haydn Maust, Zongyi Li, Yixuan Wang, Daniel Leibovici, Oscar Bruno, Thomas Hou, and Anima Anandkumar.




Fourier continuation for exact derivative computation in physics-informed neural operators.




arXiv preprint arXiv:2211.15960
, 2022.








[84]



Lu Lu, Pengzhan Jin, Guofei Pang, Zhongqiang Zhang, and George Em Karniadakis.




Learning nonlinear operators via deeponet based on the universal approximation theorem of operators.




Nature machine intelligence
, 3(3):218–229, 2021.








[85]



Sergei Gukov, James Halverson, Fabian Ruehle, and Piotr Sułkowski.




Learning to Unknot.




Mach. Learn. Sci. Tech.
, 2(2):025035, 2021.








[86]



L. H. Kauffman, N. E. Russkikh, and I. A. Taimanov.




Rectangular knot diagrams classification with deep learning, 2020.








[87]



Mark C Hughes.




A neural network approach to predicting and computing knot invariants.




Journal of Knot Theory and Its Ramifications
, 29(03):2050005, 2020.








[88]



Jessica Craven, Vishnu Jejjala, and Arjun Kar.




Disentangling a deep learned volume formula.




JHEP
, 06:040, 2021.








[89]



Jessica Craven, Mark Hughes, Vishnu Jejjala, and Arjun Kar.




Illuminating new and known relations between knot invariants.




11 2022.








[90]



Fabian Ruehle.




Data science applications to string theory.




Phys. Rept.
, 839:1–117, 2020.








[91]



Y.H. He.




Machine Learning in Pure Mathematics and Theoretical Physics
.




G - Reference,Information and Interdisciplinary Subjects Series. World Scientific, 2023.








[92]



Sergei Gukov, James Halverson, and Fabian Ruehle.




Rigor with machine learning from field theory to the poincaréconjecture.




Nature Reviews Physics
, 2024.








[93]



Shumao Zhang, Pengchuan Zhang, and Thomas Y Hou.




Multiscale invertible generative networks for high-dimensional bayesian inference.




In 
International Conference on Machine Learning
, pages 12632–12641. PMLR, 2021.








[94]



Jinchao Xu and Ludmil Zikatanov.




Algebraic multigrid methods.




Acta Numerica
, 26:591–721, 2017.








[95]



Yifan Chen, Thomas Y Hou, and Yixuan Wang.




Exponentially convergent multiscale finite element method.




Communications on Applied Mathematics and Computation
, pages 1–17, 2023.








[96]



Vincent Sitzmann, Julien Martel, Alexander Bergman, David Lindell, and Gordon Wetzstein.




Implicit neural representations with periodic activation functions.




Advances in neural information processing systems
, 33:7462–7473, 2020.














Appendix








Appendix A 
KAN Functionalities




Table 
7
 includes common functionalities that users may find useful.










Functionality


Descriptions






model.train(dataset)


training model on dataset






model.plot()


plotting






model.prune()


pruning






model.fix_symbolic(l,i,j,fun)




 






fix the activation function 
ϕ
l
,
i
,
j
subscript
italic-ϕ
𝑙
𝑖
𝑗
\phi_{l,i,j}
italic_ϕ start_POSTSUBSCRIPT italic_l , italic_i , italic_j end_POSTSUBSCRIPT




to be the symbolic function 
fun








model.suggest_symbolic(l,i,j)




 






suggest symbolic functions that match




the numerical value of 
ϕ
l
,
i
,
j
subscript
italic-ϕ
𝑙
𝑖
𝑗
\phi_{l,i,j}
italic_ϕ start_POSTSUBSCRIPT italic_l , italic_i , italic_j end_POSTSUBSCRIPT








model.auto_symbolic()




 






use top 1 symbolic suggestions from 
suggest_symbolic




to replace all activation functions








model.symbolic_formula()


return the symbolic formula






Table 7: 
KAN functionalities










Appendix B 
Learnable activation networks (LANs)






B.1 
Architecture




Besides KAN, we also proposed another type of learnable activation networks (LAN), which are almost MLPs but with learnable activation functions parametrized as splines. KANs have two main changes to standard MLPs: (1) the activation functions become learnable rather than being fixed; (2) the activation functions are placed on edges rather than nodes. To disentangle these two factors, we also propose learnable activation networks (LAN) which only has learnable activations but still on nodes, illustrated in Figure 
B.1
.






For a LAN with width 
N
𝑁
N
italic_N
, depth 
L
𝐿
L
italic_L
, and grid point number 
G
𝐺
G
italic_G
, the number of parameters is 
N
2
⁢
L
+
N
⁢
L
⁢
G
superscript
𝑁
2
𝐿
𝑁
𝐿
𝐺
N^{2}L+NLG
italic_N start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT italic_L + italic_N italic_L italic_G
 where 
N
2
⁢
L
superscript
𝑁
2
𝐿
N^{2}L
italic_N start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT italic_L
 is the number of parameters for weight matrices and 
N
⁢
L
⁢
G
𝑁
𝐿
𝐺
NLG
italic_N italic_L italic_G
 is the number of parameters for spline activations, which causes little overhead in addition to MLP since usually 
G
≪
N
much-less-than
𝐺
𝑁
G\ll N
italic_G ≪ italic_N
 so 
N
⁢
L
⁢
G
≪
N
2
⁢
L
much-less-than
𝑁
𝐿
𝐺
superscript
𝑁
2
𝐿
NLG\ll N^{2}L
italic_N italic_L italic_G ≪ italic_N start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT italic_L
. LANs are similar to MLPs so they can be initialized from pretrained MLPs and fine-tuned by allowing learnable activation functions. An example is to use LAN to improve SIREN, presented in Section  
B.3
.






Comparison of LAN and KAN.

Pros of LANs:






(1)




LANs are conceptually simpler than KANs. They are closer to standard MLPs (the only change is that activation functions become learnable).








(2)




LANs scale better than KANs. LANs/KANs have learnable activation functions on nodes/edges, respectively. So activation parameters in LANs/KANs scale as 
N
𝑁
N
italic_N
/
N
2
superscript
𝑁
2
N^{2}
italic_N start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT
, where 
N
𝑁
N
italic_N
 is model width.








Cons of LANs:






(1)




LANs seem to be less interpretable (weight matrices are hard to interpret, just like in MLPs);








(2)




LANs also seem to be less accurate than KANs, but still more accurate than MLPs. Like KANs, LANs also admit grid extension if theLANs’ activation functions are parametrized by splines.
















B.2 
LAN interpretability results




Figure B.1: 
Training of a learnable activation network (LAN) on the toy example 
f
⁢
(
x
,
y
)
=
exp
⁢
(
sin
⁢
(
π
⁢
x
)
+
y
2
)
𝑓
𝑥
𝑦
exp
sin
𝜋
𝑥
superscript
𝑦
2
f(x,y)={\rm exp}({\rm sin}(\pi x)+y^{2})
italic_f ( italic_x , italic_y ) = roman_exp ( roman_sin ( italic_π italic_x ) + italic_y start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT )
.






Figure B.2: 
LANs on synthetic examples. LANs do not appear to be very interpretable. We conjecture that the weight matrices leave too many degree of freedoms.






We present preliminary interpretabilty results of LANs in Figure 
B.2
. With the same examples in Figure 
4.1
 for which KANs are perfectly interpretable, LANs seem much less interpretable due to the existence of weight matrices. First, weight matrices are less readily interpretable than learnable activation functions. Second, weight matrices bring in too many degrees of freedom, making learnable activation functions too unconstrained. Our preliminary results with LANs seem to imply that getting rid of linear weight matrices (by having learnable activations on edges, like KANs) is necessary for interpretability.










B.3 
Fitting Images (LAN)




Figure B.3: 
A SIREN network (fixed sine activations) can be adapted to LANs (learnable activations) to improve image representations.






Implicit neural representations view images as 2D functions 
f
⁢
(
x
,
y
)
𝑓
𝑥
𝑦
f(x,y)
italic_f ( italic_x , italic_y )
, where the pixel value 
f
𝑓
f
italic_f
 is a function of two coordinates of the pixel 
x
𝑥
x
italic_x
 and 
y
𝑦
y
italic_y
. To compress an image, such an implicit neural representation (
f
𝑓
f
italic_f
 is a neural network) can achieve impressive compression of parameters while maintaining almost original image quality. SIREN 
[
96
]
 proposed to use MLPs with periodic activation functions to fit the function 
f
𝑓
f
italic_f
. It is natural to consider other activation functions, which are allowed in LANs. However, since we initialize LAN activations to be smooth but SIREN requires high-frequency features, LAN does not work immediately. Note that each activation function in LANs is a sum of the base function and the spline function, i.e., 
ϕ
⁢
(
x
)
=
b
⁢
(
x
)
+
spline
⁢
(
x
)
italic-ϕ
𝑥
𝑏
𝑥
spline
𝑥
\phi(x)=b(x)+{\rm spline}(x)
italic_ϕ ( italic_x ) = italic_b ( italic_x ) + roman_spline ( italic_x )
, we set 
b
⁢
(
x
)
𝑏
𝑥
b(x)
italic_b ( italic_x )
 to sine functions, the same setup as in SIREN but let 
spline
⁢
(
x
)
spline
𝑥
{\rm spline}(x)
roman_spline ( italic_x )
 be trainable. For both MLP and LAN, the shape is [2,128,128,128,128,128,1]. We train them with the Adam optimizer, batch size 4096, for 5000 steps with learning rate 
10
−
3
superscript
10
3
10^{-3}
10 start_POSTSUPERSCRIPT - 3 end_POSTSUPERSCRIPT
 and 5000 steps with learning rate 
10
−
4
superscript
10
4
10^{-4}
10 start_POSTSUPERSCRIPT - 4 end_POSTSUPERSCRIPT
. As shown in Figure 
B.3
, the LAN (orange) can achieve higher PSNR than the MLP (blue) due to the LAN’s flexibility to fine tune activation functions. We show that it is also possible to initialize a LAN from an MLP and further fine tune the LAN (green) for better PSNR. We have chosen 
G
=
5
𝐺
5
G=5
italic_G = 5
 in our experiments, so the additional parameter increase is roughly 
G
/
N
=
5
/
128
≈
4
%
𝐺
𝑁
5
128
percent
4
G/N=5/128\approx 4\%
italic_G / italic_N = 5 / 128 ≈ 4 %
 over the original parameters.












Appendix C 
Dependence on hyperparameters




We show the effects of hyperparamters on the 
f
⁢
(
x
,
y
)
=
exp
⁢
(
sin
⁢
(
π
⁢
x
)
+
y
2
)
𝑓
𝑥
𝑦
exp
sin
𝜋
𝑥
superscript
𝑦
2
f(x,y)={\rm exp}({\rm sin}(\pi x)+y^{2})
italic_f ( italic_x , italic_y ) = roman_exp ( roman_sin ( italic_π italic_x ) + italic_y start_POSTSUPERSCRIPT 2 end_POSTSUPERSCRIPT )
 case in Figure 
C.1
. To get an interpretable graph, we want the number of active activation functions to be as small (ideally 3) as possible.






(1)




We need entropy penalty to reduce the number of active activation functions. Without entropy penalty, there are many duplicate functions.








(2)




Results can depend on random seeds. With some unlucky seed, the pruned network could be larger than needed.








(3)




The overall penalty strength 
λ
𝜆
\lambda
italic_λ
 effectively controls the sparsity.








(4)




The grid number 
G
𝐺
G
italic_G
 also has a subtle effect on interpretability. When 
G
𝐺
G
italic_G
 is too small, because each one of activation function is not very expressive, the network tends to use the ensembling strategy, making interpretation harder.








(5)




The piecewise polynomial order 
k
𝑘
k
italic_k
 only has a subtle effect on interpretability. However, it behaves a bit like the random seeds which do not display any visible pattern in this toy example.












Figure C.1: 
Effects of hyperparameters on interpretability results.










Appendix D 
Feynman KANs




We include more results on the Feynman dataset (Section 
3.3
). Figure 
D.1
 shows the pareto frontiers of KANs and MLPs for each Feynman dataset. Figure 
D.3
 and 
D.2
 visualize minimal KANs (under the constraint test RMSE 
<
10
−
2
absent
superscript
10
2
<10^{-2}
< 10 start_POSTSUPERSCRIPT - 2 end_POSTSUPERSCRIPT
) and best KANs (with the lowest test RMSE loss) for each Feynman equation fitting task.






Figure D.1: 
The Pareto Frontiers of KANs and MLPs for Feynman datasets.






Figure D.2: 
Best Feynman KANs






Figure D.3: 
Minimal Feynman KANs










Appendix E 
Remark on grid size




For both PDE and regression tasks, when we choose the training data on uniform grids, we witness a sudden increase in training loss (i.e., sudden drop in performance) when the grid size is updated to a large level, comparable to the different training points in one spatial direction. This could be due to implementation of B-spline in higher dimensions and needs further investigation.










Appendix F 
KANs for special functions




We include more results on the special function dataset (Section 
3.2
). Figure 
F.2
 and 
F.1
 visualize minimal KANs (under the constraint test RMSE 
<
10
−
2
absent
superscript
10
2
<10^{-2}
< 10 start_POSTSUPERSCRIPT - 2 end_POSTSUPERSCRIPT
) and best KANs (with the lowest test RMSE loss) for each special function fitting task.






Figure F.1: 
Best special KANs






Figure F.2: 
Minimal special KANs












Generated  on Tue Apr 30 17:42:36 2024 by 
L
a
T
e
XML









