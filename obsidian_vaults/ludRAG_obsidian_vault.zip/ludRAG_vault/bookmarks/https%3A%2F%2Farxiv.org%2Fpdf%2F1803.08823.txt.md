A high-bias, low-variance introduction to Machine Learning for physicists
Pankaj Mehta, Ching-Hao Wang, Alexandre G. R. Day, and Clint Richardson
Department of Physics,
Boston University,
Boston, MA 02215,
USA
Marin Bukov
Department of Physics,
University of California,
Berkeley, CA 94720,
USAy
Charles K. Fisher
Unlearn.AI, San Francisco,
CA 94108
David J. Schwab
Initiative for the Theoretical Sciences,
The Graduate Center,
City University of New York,
365 Fifth Ave., New York,
NY 10016
(Dated: May 29, 2019)
Machine Learning (ML) is one of the most exciting and dynamic areas of modern re-
search and application. The purpose of this review is to provide an introduction to the
core concepts and tools of machine learning in a manner easily understood and intuitive
to physicists. The review begins by covering fundamental concepts in ML and modern
statistics such as the bias-variance tradeoﬀ, overﬁtting, regularization, generalization,
and gradient descent before moving on to more advanced topics in both supervised
and unsupervised learning. Topics covered in the review include ensemble models, deep
learningandneuralnetworks, clusteringanddatavisualization, energy-basedmodels(in-
cluding MaxEnt models and Restricted Boltzmann Machines), and variational methods.
Throughout, we emphasize the many natural connections between ML and statistical
physics. A notable aspect of the review is the use of Python Jupyter notebooks to in-
troduce modern ML/statistical packages to readers using physics-inspired datasets (the
Ising Model and Monte-Carlo simulations of supersymmetric decays of proton-proton
collisions). We conclude with an extended outlook discussing possible uses of machine
learning for furthering our understanding of the physical world as well as open problems
in ML where physicists may be able to contribute.
CONTENTS
I. Introduction 3
A. What is Machine Learning? 3
B. Why study Machine Learning? 4
C. Scope and structure of the review 4
II. Why is Machine Learning diﬃcult? 6
A. Setting up a problem in ML and data science 6
B. Polynomial Regression 6
III. Basics of Statistical Learning Theory 10
A. Three simple schematics that summarize the basic
intuitions from Statistical Learning Theory 10
pankajm@bu.edu
ymgbukov@berkeley.eduB. Bias-Variance Decomposition 12
IV. Gradient Descent and its Generalizations 13
A. Gradient Descent and Newton’s method 13
B. Limitations of the simplest gradient descent
algorithm 15
C. Stochastic Gradient Descent (SGD) with
mini-batches 16
D. Adding Momentum 17
E. Methods that use the second moment of the
gradient 17
F. Comparison of various methods 18
G. Gradient descent in practice: practical tips 19
V. Overview of Bayesian Inference 19
A. Bayes Rule 20
B. Bayesian Decisions 20
C. Hyperparameters 20
VI. Linear Regression 21arXiv:1803.08823v3  [physics.comp-ph]  27 May 2019
2
A. Least-square regression 21
B. Ridge-Regression 22
C. LASSO and Sparse Regression 23
D. Using Linear Regression to Learn the Ising
Hamiltonian 24
E. Convexity of regularizer 25
F. Bayesian formulation of linear regression 27
G. Recap and a general perspective on regularizers 28
VII. Logistic Regression 29
A. The cross-entropy as a cost function for logistic
regression 29
B. Minimizing the cross entropy 30
C. Examples of binary classiﬁcation 30
1. Identifying the phases of the 2D Ising model 30
2. SUSY 32
D. Softmax Regression 34
E. An Example of SoftMax Classiﬁcation: MNIST
Digit Classiﬁcation 34
VIII. Combining Models 35
A. Revisiting the Bias-Variance Tradeoﬀ for
Ensembles 35
1. Bias-Variance Decomposition for Ensembles 35
2. Summarizing the Theory and Intuitions behind
Ensembles 38
B. Bagging 39
C. Boosting 40
D. Random Forests 41
E. Gradient Boosted Trees and XGBoost 42
F. Applications to the Ising model and
Supersymmetry Datasets 44
IX. An Introduction to Feed-Forward Deep Neural
Networks (DNNs) 45
A. Neural Network Basics 46
1. The basic building block: neurons 46
2. Layering neurons to build deep networks:
network architecture. 47
B. Training deep networks 48
C. The Backpropagation algorithm 49
1. Deriving and implementing the
backpropagation equations 50
2. Computing gradients in deep networks: what
can go wrong with backprop? 51
D. Regularizing neural networks and other practical
considerations 52
1. Implicit regularization using SGD:
initialization, hyper-parameter tuning, and
Early Stopping 52
2. Dropout 52
3. Batch Normalization 52
E. Deep neural networks in practice: examples 53
1. Deep learning packages 53
2. Approaching the learning problem 54
3. SUSY dataset 55
4. Phases of the 2D Ising model 55
X. Convolutional Neural Networks (CNNs) 56
A. The structure of convolutional neural networks 56
B. Example: CNNs for the 2D Ising model 58
C. Pre-trained CNNs and transfer learning 58
XI. High-level Concepts in Deep Neural Networks 60
A. Organizing deep learning workﬂows using the
bias-variance tradeoﬀ 60
B. Why neural networks are so successful: three
high-level perspectives on neural networks 61
1. Neural networks as representation learning 61
2. Neural networks can exploit large amounts of
data 613. Neural networks scale up well
computationally 62
C. Limitations of supervised learning with deep
networks 62
XII. Dimensional Reduction and Data Visualization 63
A. Some of the challenges of high-dimensional data 63
B. Principal component analysis (PCA) 64
C. Multidimensional scaling 66
D. t-SNE 66
XIII. Clustering 68
A. Practical clustering methods 69
1.K-means 69
2. Hierarchical clustering: Agglomerative
methods 70
3. Density-based (DB) clustering 71
B. Clustering and Latent Variables via the Gaussian
Mixture Models 72
C. Clustering in high dimensions 74
XIV. Variational Methods and Mean-Field Theory
(MFT) 75
A. Variational mean-ﬁeld theory for the Ising
model 76
B. Expectation Maximization (EM) 78
XV. Energy Based Models: Maximum Entropy (MaxEnt)
Principle, Generative models, and Boltzmann
Learning 80
A. An overview of energy-based generative models 80
B. Maximum entropy models: the simplest
energy-based generative models 81
1. MaxEnt models in statistical mechanics 81
2. From statistical mechanics to machine
learning 82
3. Generalized Ising Models from MaxEnt 83
C. Cost functions for training energy-based models 83
1. Maximum likelihood 84
2. Regularization 84
D. Computing gradients 85
E. Summary of the training procedure 86
XVI. Deep Generative Models: Hidden Variables and
Restricted Boltzmann Machines (RBMs) 86
A. Why hidden (latent) variables? 86
B. Restricted Boltzmann Machines (RBMs) 87
C. Training RBMs 89
1. Gibbs sampling and contrastive divergence
(CD) 89
2. Practical Considerations 90
D. Deep Boltzmann Machine 90
E. Generative models in practice: examples 91
1. MNIST 91
2. Example: 2D Ising Model 92
F. Generative models in physics 92
XVII. Variational AutoEncoders (VAEs) and Generative
Adversarial Networks (GANs) 94
A. The limitations of maximizing Likelihood 94
B. Generative models and adversarial learning 96
C. Variational Autoencoders (VAEs) 97
1. VAEs as variational models 97
2. Training via the reparametrization trick 98
3. Connection to the information bottleneck 99
D. VAE with Gaussian latent variables and Gaussian
encoder 100
1. Implementing the Gaussian VAE 100
2. VAEs for the MNIST dataset 101
3. VAEs for the 2D Ising model 101
3
XVIII. Outlook 103
A. Research at the intersection of physics and ML 103
B. Topics not covered in review 104
C. Rebranding Machine Learning as “Artiﬁcial
Intelligence” 105
D. Social Implications of Machine Learning 105
XIX. Acknowledgments 106
A. Overview of the Datasets used in the Review 106
1. Ising dataset 106
2. SUSY dataset 106
3. MNIST Dataset 107
References 107
I. INTRODUCTION
Machine Learning (ML), data science, and statistics
are ﬁelds that describe how to learn from, and make pre-
dictions about, data. The availability of big datasets is
a hallmark of modern science, including physics, where
data analysis has become an important component of di-
verse areas, such as experimental particle physics, ob-
servational astronomy and cosmology, condensed matter
physics, biophysics, and quantum computing. Moreover,
ML and data science are playing increasingly important
rolesinmanyaspectsofmoderntechnology, rangingfrom
biotechnology to the engineering of self-driving cars and
smart devices. Therefore, having a thorough grasp of the
concepts and tools used in ML is an important skill that
is increasingly relevant in the physical sciences.
The purpose of this review is to serve as an introduc-
tion to foundational and state-of-the-art techniques in
ML and data science for physicists. The review seeks to
ﬁnd a middle ground between a short overview and a full-
length textbook. While there exist many wonderful ML
textbooks(Abu-Mostafa et al.,2012;Bishop,2006;Fried-
manet al.,2001;Murphy,2012), theyarelengthyanduse
specializedlanguagethatisoftenunfamiliartophysicists.
Thisreviewbuildsupontheconsiderableknowledgemost
physicists already possess in statistical physics in order
to introduce many of the major ideas and techniques
used in modern ML. We take a physics-inspired peda-
gogical approach, emphasizing simple examples (e.g., re-
gression and clustering), before delving into more ad-
vanced topics. The intention of this review and the
accompanying Jupyter notebooks (available at https:
//physics.bu.edu/~pankajm/MLnotebooks.html ) is to
give the reader the requisite background knowledge to
follow and apply these techniques to their own areas of
interest.
While this review is written with a physics background
in mind, we aim for it to be useful to anyone with some
background in statistical physics, and it is suitable for
both graduate students and researchers as well as ad-
vanced undergraduates. The review is based on an ad-
vanced topics graduate course taught at Boston Univer-sityinFallof2016. Assuch, itassumesaleveloffamiliar-
itywithseveraltopicsfoundingraduatephysicscurricula
(partition functions, statistical mechanics) and a ﬂuency
in mathematical techniques such as linear algebra, multi-
variate calculus, variational methods, probability theory,
and Monte-Carlo methods. It also assumes a familiar-
ity with basic computer programming and algorithmic
design.
A. What is Machine Learning?
Most physicists learn the basics of classical statistics
early on in undergraduate laboratory courses. Classical
statistics is primarily concerned with how to use data
to estimate the value of an unknown quantity. For in-
stance, estimating the speed of light using measurements
obtained with an interferometer is one such example that
relies heavily on techniques from statistics.
Machine Learning is a subﬁeld of artiﬁcial intelligence
withthegoalofdevelopingalgorithmscapableoflearning
from data automatically. In particular, an artiﬁcially in-
telligent agent needs to be able to recognize objects in its
surroundings and predict the behavior of its environment
in order to make informed choices. Therefore, techniques
in ML tend to be more focused on prediction rather than
estimation. For example, how do we use data from the
interferometry experiment to predict what interference
patternwouldbeobservedunderadiﬀerentexperimental
setup? In addition, methods from ML tend to be applied
to more complex high-dimensional problems than those
typically encountered in a classical statistics course.
Despite these diﬀerences, estimation and prediction
problems can be cast into a common conceptual frame-
work. In both cases, we choose some observable quantity
xofthesystemwearestudying(e.g., aninterferencepat-
tern)thatisrelatedtosomeparameters (e.g., thespeed
of light) of a model p(xj)that describes the probability
of observingxgiven. Now, we perform an experiment
toobtainadataset Xandusethesedatatoﬁtthemodel.
Typically, “ﬁtting” the model involves ﬁnding ^that pro-
vides the best explanation for the data. In the case when
“ﬁtting” refers to the method of least squares, the esti-
mated parameters maximize the probability of observ-
ing the data (i.e., ^=argmaxfp(Xj)g).Estimation
problems are concerned with the accuracy of ^, whereas
prediction problems are concerned with the ability of the
model to predict new observations (i.e., the accuracy of
p(xj^)). Although the goals of estimation and prediction
are related, they often lead to diﬀerent approaches. As
this review is aimed as an introduction to the concepts of
ML, we will focus on prediction problems and refer the
reader to one of many excellent textbooks on classical
statistics for more information on estimation (Lehmann
and Casella, 2006; Lehmann and Romano, 2006; Wasser-
man, 2013; Witte and Witte, 2013).
4
B. Why study Machine Learning?
The last three decades have seen an unprecedented in-
crease in our ability to generate and analyze large data
sets. This “big data” revolution has been spurred by an
exponential increase in computing power and memory
commonly known as Moore’s law. Computations that
were unthinkable a few decades ago can now be routinely
performed on laptops. Specialized computing machines
(such as GPU-based machines) are continuing this trend
towards cheap, large-scale computation, suggesting that
the “big data” revolution is here to stay.
This increase in our computational ability has been ac-
companied by new techniques for analyzing and learning
from large datasets. These techniques draw heavily from
ideas in statistics, computational neuroscience, computer
science, and physics. Similar to physics, modern ML
places a premium on empirical results and intuition over
the more formal treatments common in statistics, com-
puter science, and mathematics. This is not to say that
proofs are not important or undesirable. Rather, many
of the advances of the last two decades – especially in
ﬁelds like deep learning – do not have formal justiﬁca-
tions (much like there still exists no mathematically well-
deﬁned concept of the Feynman path-integral in d>1).
Physicists are uniquely situated to beneﬁt from and
contribute to ML. Many of the core concepts and tech-
niques used in ML – such as Monte-Carlo methods, simu-
lated annealing, variational methods – have their origins
in physics. Moreover, “energy-based models” inspired by
statistical physics are the backbone of many deep learn-
ing methods. For these reasons, there is much in modern
ML that will be familiar to physicists.
Physicists and astronomers have also been at the fore-
front of using “big data”. For example, experiments such
as CMS and ATLAS at the LHC generate petabytes of
data per year. In astronomy, projects such as the Sloan
Digital Sky Survey (SDSS) routinely analyze and release
hundreds of terabytes of data measuring the properties of
nearly a billion stars and galaxies. Researchers in these
ﬁelds are increasingly incorporating recent advances in
ML and data science, and this trend is likely to acceler-
ate in the future.
Besides applications to physics, part of the goal of this
review is to serve as an introductory resource for those
looking to transition to more industry-oriented projects.
Physicists have already made many important contribu-
tions to modern big data applications in an industrial
setting (Metz, 2017). Data scientists and ML engineers
in industry use concepts and tools developed for ML to
gain insight from large datasets. A familiarity with ML
is a prerequisite for many of the most exciting employ-
ment opportunities in the ﬁeld, and we hope this review
will serve as a useful introduction to ML for physicists
beyond an academic setting.C. Scope and structure of the review
Any review on ML must simultaneously accomplish
two related but distinct goals. First, it must convey the
rich theoretical foundations underlying modern ML. This
task is made especially diﬃcult because ML is very broad
and interdisciplinary, drawing on ideas and intuitions
from many ﬁelds including statistics, computational neu-
roscience, and physics. Unfortunately, this means mak-
ing choices about what theoretical ideas to include in the
review. This review emphasizes connections with sta-
tistical physics, physics-inspired Bayesian inference, and
computational neuroscience models. Thus, certain ideas
(e.g., gradient descent, expectation maximization, varia-
tional methods, and deep learning and neural networks)
are covered extensively, while other important ideas are
given less attention or even omitted entirely (e.g., statis-
tical learning, support vector machines, kernel methods,
Gaussian processes). Second, any ML review must give
thereader thepractical know-howto startusing thetools
and concepts of ML for practical problems. To accom-
plish this, we have written a series of Jupyter notebooks
to accompany this review. These python notebooks in-
troduce the nuts-and-bolts of how to use, code, and im-
plement the methods introduced in the main text. Luck-
ily, there are numerous great ML software packages avail-
able in Python (scikit-learn, tensorﬂow, Pytorch, Keras)
and we have made extensive use of them. We have also
made use of a new package, Paysage, for energy-based
generative models which has been co-developed by one
of the authors (CKF) and maintained by Unlearn.AI (a
company aﬃliated with two of the authors: CKF and
PM). The purpose of the notebooks is to both familiarize
physicists with these resources and to serve as a starting
point for experimenting and playing with ideas.
ML can be divided into three broad categories: super-
vised learning, unsupervised learning, and reinforcement
learning. Supervised learning concerns learning from la-
beled data (for example, a collection of pictures labeled
ascontaining a cat ornot containing a cat ). Common
supervised learning tasks include classiﬁcation and re-
gression. Unsupervised learning is concerned with ﬁnd-
ing patterns and structure in unlabeled data. Examples
of unsupervised learning include clustering, dimensional-
ity reduction, and generative modeling. Finally, in rein-
forcement learning an agent learns by interacting with an
environment and changing its behavior to maximize its
reward. For example, a robot can be trained to navigate
in a complex environment by assigning a high reward to
actions that help the robot reach a desired destination.
We refer the interested reader to the classic book by Sut-
ton and Barto Reinforcement Learning: an Introduction
(Sutton and Barto, 1998). While useful, the distinction
between the three types of ML is sometimes fuzzy and
ﬂuid, and many applications often combine them in novel
and interesting ways. For example, the recent success
5
of Google DeepMind in developing ML algorithms that
excel at tasks such as playing Go and video games em-
ploy deep reinforcement learning, combining reinforce-
ment learning with supervised learning methods based
on deep neural networks.
Here, we limit our focus to supervised and unsuper-
vised learning. The literature on reinforcement learning
is extensive and uses ideas and concepts that, to a large
degree, are distinct from supervised and unsupervised
learning tasks. For this reason, to ensure cohesiveness
and limit the length of this review, we have chosen not
to discuss reinforcement learning. However, this omis-
sion should not be mistaken for a value judgement on
the utility of reinforcement learning for solving physical
problems. For example, some of the authors have used
inspiration from reinforcement learning to tackle diﬃcult
problems in quantum control (Bukov, 2018; Bukov et al.,
2018).
In writing this review, we have tried to adopt a style
that reﬂects what we consider to be the best of the
physics tradition. Physicists understand the importance
of well-chosen examples for furthering our understand-
ing. It is hard to imagine a graduate course in statistical
physics without the Ising model. Each new concept that
is introduced in statistical physics (mean-ﬁeld theory,
transfer matrix techniques, high- and low-temperature
expansions, therenormalizationgroup, etc.) isappliedto
the Ising model. This allows for the progressive building
of intuition and ultimately a coherent picture of statisti-
cal physics. We have tried to replicate this pedagogical
approach in this review by focusing on a few well-chosen
techniques – linear and logistic regression in the case of
supervised learning and clustering in the case of unsu-
pervised learning – to introduce the major theoretical
concepts.
In this same spirit, we have chosen three interest-
ing datasets with which to illustrate the various algo-
rithms discussed here. (i) The SUSY data set consists
of5;000;000Monte-Carlo samples of proton-proton col-
lisions decaying to either signal or background processes,
which are both parametrized with 18features. The sig-
nal process is the production of electrically-charged su-
persymmetric particles, which decay to Wbosons and an
electrically-neutral supersymmetric particle, invisible to
the detector, while the background processes are various
decays involving only Standard Model particles (Baldi
et al., 2014). (ii) The Ising data set consists of 104
states of the 2D Ising model on a 4040square lat-
tice, obtained using Monte-Carlo (MC) sampling at a
few ﬁxed temperatures T. (iii) The MNIST dataset com-
prises 70000handwritten digits, each of which comes in
a square image, divided into a 2828pixel grid. The
ﬁrst two datasets were chosen to reﬂect the various sub-
disciplinesofphysics(high-energyexperiment,condensed
matter) where we foresee techniques from ML becom-
ing an increasingly important tool for research. TheMNIST dataset, on the other hand, introduces the ﬂa-
vor of present-day ML problems. By re-analyzing the
same datasets with multiple techniques, we hope readers
will be able to get a sense of the various, inevitable trade-
oﬀs involved in choosing how to analyze data. Certain
techniques work better when data is limited while others
may be better suited to large data sets with many fea-
tures. A short description of these datasets are given in
the Appendix.
This review draws generously on many wonderful text-
books on ML and we encourage the reader to con-
sult them for further information. They include Abu
Mostafa’s masterful Learning from Data , which intro-
duces the basic concepts of statistical learning theory
(Abu-Mostafa et al., 2012), the more advanced but
equally good The Elements of Statistical Learning by
Hastie, Tibshirani, andFriedman(Friedman et al.,2001),
Michael Nielsen’s indispensable Neural Networks and
Deep Learning which serves as a wonderful introduction
to the neural networks and deep learning (Nielsen, 2015)
and David MacKay’s outstanding Information Theory,
Inference, and Learning Algorithms which introduced
Bayesian inference and information theory to a whole
generation of physicists (MacKay, 2003). More com-
prehensive (and much longer) books on modern ML
techniques include Christopher Bishop’s classic Pattern
Recognition and Machine Learning (Bishop, 2006) and
the more recently published Machine Learning: A Prob-
abilistic Perspective by Kevin Murphy (Murphy, 2012).
Finally, one of the great successes of modern ML is deep
learning, and some of the pioneers of this ﬁeld have writ-
ten a textbook for students and researchers entitled Deep
Learning (Goodfellow et al., 2016). In addition to these
textbooks, we have consulted numerous research papers,
reviews, and web resources. Whenever possible, we have
tried to point the reader to key papers and other refer-
ences that we have found useful in preparing this review.
However, we are neither capable of nor have we made any
eﬀort to make a comprehensive review of the literature.
The review is organized as follows. We begin by
introducing polynomial regression as a simple example
that highlights many of the core ideas of ML. The next
few chapters introduce the language and major concepts
needed to make these ideas more precise including tools
from statistical learning theory such as overﬁtting, the
bias-variance tradeoﬀ, regularization, and the basics of
Bayesian inference. The next chapter builds on these
examples to discuss stochastic gradient descent and its
generalizations. We then apply these concepts to linear
and logistic regression, followed by a detour to discuss
how we can combine multiple statistical techniques to
improve supervised learning, introducing bagging, boost-
ing, random forests, and XG Boost. These ideas, though
fairly technical, lie at the root of many of the advances
in ML over the last decade. The review continues with
a thorough discussion of supervised deep learning and
6
neural networks, as well as convolutional nets. We then
turn our focus to unsupervised learning. We start with
data visualization and dimensionality reduction before
proceeding to a detailed treatment of clustering. Our
discussion of clustering naturally leads to an examina-
tion of variational methods and their close relationship
with mean-ﬁeld theory. The review continues with a
discussion of deep unsupervised learning, focusing on
energy-based models, such as Restricted Boltzmann Ma-
chines (RBMs) and Deep Boltzmann Machines (DBMs).
Then we discuss two new and extremely popular model-
ing frameworks for unsupervised learning, generative ad-
versarial networks (GANs) and variational autoencoders
(VAEs). We conclude the review with an outlook and
discussion of promising research directions at the inter-
section physics and ML.
II. WHY IS MACHINE LEARNING DIFFICULT?
A. Setting up a problem in ML and data science
Many problems in ML and data science starts with
the same ingredients. The ﬁrst ingredient is the dataset
D= (X;y)whereXisamatrixofindependentvariables
andyis a vector of dependent variables. The second is
the modelf(x;), which is a function f:x!yof the
parameters. That is,fis a function used to predict an
output from a vector of input variables. The ﬁnal ingre-
dient is the cost function C(y;f(X;))that allows us to
judgehowwellthemodelperformsontheobservations y.
The model is ﬁt by ﬁnding the value of that minimizes
the cost function. For example, one commonly used cost
function is the squared error. Minimizing the squared er-
ror cost function is known as the method of least squares,
and is typically appropriate for experiments with Gaus-
sian measurement errors.
ML researchers and data scientists follow a standard
recipe to obtain models that are useful for prediction
problems. We will see why this is necessary in the fol-
lowing sections, but it is useful to present the recipe up
front to provide context. The ﬁrst step in the analysis
is torandomly divide the dataset Dinto two mutually
exclusive groupsDtrainandDtestcalled the training and
test sets. The fact that this must be the ﬁrst step should
be heavily emphasized – performing some analysis (such
as using the data to select important variables) before
partitioning the data is a common pitfall that can lead to
incorrect conclusions. Typically, the majority of the data
are partitioned into the training set (e.g., 90%) with the
remaindergoingintothetestset. Themodelisﬁtbymin-
imizing the cost function using only the data in the train-
ing set ^= arg minfC(ytrain;f(Xtrain;))g. Finally,
the performance of the model is evaluated by computing
the cost function using the test set C(ytest;f(Xtest;^)).
The value of the cost function for the best ﬁt modelon the training set is called the in-sample error Ein=
C(ytrain;f(Xtrain;))and the value of the cost func-
tion on the test set is called the out-of-sample error
Eout=C(ytest;f(Xtest;)).
One of the most important observations we can make
is that the out-of-sample error is almost always greater
than the in-sample error, i.e. EoutEin. We explore
this point further in Sec. VI and its accompanying note-
book. Splitting the data into mutually exclusive train-
ing and test sets provides an unbiased estimate for the
predictive performance of the model – this is known as
cross-validation in the ML and statistics literature. In
many applications of classical statistics, we start with a
mathematical model that we assume to be true (e.g., we
may assume that Hooke’s law is true if we are observing
a mass-spring system) and our goal is to estimate the
value of some unknown model parameters (e.g., we do
not know the value of the spring stiﬀness). Problems in
ML, by contrast, typically involve inference about com-
plex systems where we do not know the exact form of the
mathematical model that describes the system. There-
fore, it is not uncommon for ML researchers to have mul-
tiple candidate models that need to be compared. This
comparison is usually done using Eout; the model that
minimizes this out-of-sample error is chosen as the best
model (i.e. model selection). Note that once we select
the best model on the basis of its performance on Eout,
the real-world performance of the winning model should
be expected to be slightly worse because the test data
was now used in the ﬁtting procedure.
B. Polynomial Regression
In the previous section, we mentioned that multiple
candidate models are typically compared using the out-
of-sample error Eout. It may be at ﬁrst surprising that
the model that has the lowest out-of-sample error Eout
usuallydoes not have the lowest in-sample error Ein.
Therefore, if our goal is to obtain a model that is use-
ful for prediction we may not want to choose the model
that provides the best explanation for the current obser-
vations. At ﬁrst glance, the observation that the model
providing the best explanation for the current dataset
probably will not provide the best explanation for future
datasets is very counter-intuitive.
Moreover, the discrepancy between EinandEoutbe-
comesmoreandmoreimportant, asthecomplexityofour
data, and the models we use to make predictions, grows.
As the number of parameters in the model increases,
we are forced to work in high-dimensional spaces. The
“curse of dimensionality” ensures that many phenomena
that are absent or rare in low-dimensional spaces become
generic. For example, the nature of distance changes in
high dimensions, as evidenced in the derivation of the
Maxwell distribution in statistical physics where the fact
7
0.0 0.2 0.4 0.6 0.8 1.0
x−4−2024y
Ntrain=10,σ=0 (train)
Training
Linear
Poly 3
Poly 10
0.00 0.25 0.50 0.75 1.00 1.25
x0.00.51.01.52.02.5y
Ntest=20,σ=0 (pred.)
test
linear
3rd order
10th order
0.0 0.2 0.4 0.6 0.8 1.0
x−4−2024y
Ntrain=10,σ=0 (train)
Training
Linear
Poly 3
Poly 10
0.00 0.25 0.50 0.75 1.00 1.25
x0204060y
Ntest=20,σ=0 (pred.)
Test
linear
3rd order
10th order
FIG. 1Fitting versus predicting for noiseless data .Ntrain = 10points in the range x2[0;1]were generated from a
linear model (top) or tenth-order polynomial (bottom). This data was ﬁt using three model classes: linear models (red), all
polynomials of order 3 (yellow), all polynomials of order 10 (green) and used to make prediction on Ntest= 20new data points
withxtest2[0;1:2](shown on right). Notice that in the absence of noise ( = 0), given enough data points that ﬁtting and
predicting are identical.
that all the volume of a d-dimensional sphere of radius
ris contained in a small spherical shell around ris ex-
ploited. Almost all critical points of a function (i.e., the
points where all derivatives vanish) are saddles rather
than maxima or minima (an observation ﬁrst made in
physics in the context of the p-spin spherical spin glass).
For all these reasons, it turns out that for complicated
models studied in ML, predicting and ﬁtting are very
diﬀerent things (Bickel et al., 2006).
To develop some intuition about why we need to pay
close attention to out-of-sample performance, we will
consider a simple one-dimensional problem – polynomial
regression. Our task is a simple one, ﬁtting data with
polynomials of diﬀerent order. We will explore how our
ability to predict depends on the number of data pointswe have, the “noise” in the data generation process, and
our prior knowledge about the system. The goal is to
build intuition about why prediction is diﬃcult in prepa-
ration for introducing general strategies that overcome
these diﬃculties.
Before reading the rest of the section, we strongly en-
courage the reader to read Notebook 1 and complete the
accompanying exercises.
Consider a probabilistic process that assigns a label yi
to an observation xi. The data are generated by drawing
samples from the equation
yi=f(xi) +i; (1)
wheref(xi)is some ﬁxed (but possibly unknown) func-
tion, andiis a Gaussian, uncorrelated noise variable,
8
0.0 0.2 0.4 0.6 0.8 1.0
x−4−2024y
Ntrain=100,σ=1 (train)
Training
Linear
Poly 3
Poly 10
0.00 0.25 0.50 0.75 1.00 1.25
x−10−505101520y
Ntest=20,σ=1 (pred.)
Test
linear
3rd order
10th order
0.0 0.2 0.4 0.6 0.8 1.0
x−4−2024y
Ntrain=100,σ=1 (train)
Training
Linear
Poly 3
Poly 10
0.00 0.25 0.50 0.75 1.00 1.25
x−10−505101520y
Ntest=20,σ=1 (pred.)
Test
linear
3rd order
10th order
FIG. 2Fitting versus predicting for noisy data .Ntrain = 100noisy data points ( = 1) in the range x2[0;1]were
generated from a linear model (top) or tenth-order polynomial (bottom). This data was ﬁt using three model classes: linear
models (red), all polynomials of order 3 (yellow), all polynomials of order 10 (green) and used to make prediction on Ntest= 20
new data points with xtest2[0;1:2](shown on right). Notice that even when the data was generated using a tenth order
polynomial, the linear and third order polynomials give better out-of-sample predictions, especially beyond the xrange over
which the model was trained.
such that
hii= 0;
hiji=ij2:
We will refer to the f(xi)as the function used to generate
the data, and as the noise strength. The larger is the
noisier the data; = 0corresponds to the noiseless case.
To make predictions, we will consider a family of func-
tionsf(x;)that depend on some parameters .
These functions represent the model class that we are us-
ing to model the data and make predictions. Note that
we choose the model class without knowing the function
f(x). Thef(x;)encode the features we choose to
represent the data. In the case of polynomial regressionwe will consider three diﬀerent model classes: (i) all poly-
nomials of order 1 which we denote by f1(x;1), (ii) all
polynomials up to order 3 which we denote by f3(x;3),
and (iii) all polynomials of order 10, f10(x;10). Notice
that these three model classes contain diﬀerent number
of parameters. Whereas f1(x;1)has only two parame-
ters (the coeﬃcients of the zeroth and ﬁrst order terms
in the polynomial), f3(x;3)andf10(x;10)have four
and eleven parameters, respectively. This reﬂects the
fact that these three models have diﬀerent model com-
plexities. If we think of each term in the polynomial as a
“feature” in our model, then increasing the order of the
polynomialweﬁtincreasesthenumberoffeatures. Using
a more complex model class may give us better predic-
9
tive power, but only if we have a large enough sample
size to accurately learn the model parameters associated
with these extra features from the training dataset.
To learn the parameters , we will train our models
on atraining dataset and then test the eﬀectiveness of
the model on a diﬀerent dataset, the test dataset . Since
we are interested only in gaining intuition, we will simply
plot the ﬁtted polynomials and compare the predictions
of our ﬁts for the test data with the true values. As we
willseebelow, themodelsthatgivethebestﬁttoexisting
data do not necessarily make the best predictions even
for a simple task like polynomial regression.
To illustrate these ideas, we encourage the reader to
experiment with the accompanying notebook to gener-
ate data using a linear function f(x) = 2xand a tenth
order polynomial f(x) = 2x 10x5+ 15x10and ask
how the size of the training dataset Ntrainand the noise
strengthaﬀect the ability to make predictions. Obvi-
ously, more data and less noise leads to better predic-
tions. To train the models (linear, third-order, tenth-
order), we uniformly sampled the interval x2[0;1]and
constructed Ntraintraining examples using (1). We then
ﬁt the models on these training samples using standard
least-squares regression. To visualize the performance of
the three models, we plot the predictions using the best
ﬁt parameters for a test set where xare drawn uniformly
fromtheinterval x2[0;1:2]. Noticethatthetestinterval
is slightly larger than the training interval.
Figure 1 shows the results of this procedure for the
noiseless case, = 0. Even using a small training set
withNtrain= 10examples, we ﬁnd that the model class
that generated the data also provides the best ﬁt and the
most accurate out-of-sample predictions. That is, the
linear model performs the best for data generated from a
linear polynomial (the third and tenth order polynomials
perform similarly), and the tenth order model performs
the best for data generated from a tenth order polyno-
mial. While this may be expected, the results are quite
diﬀerent for larger noise strengths.
Figure 2 shows the results of the same procedure for
noisy data, = 1, and a larger training set, Ntrain= 100.
As in the noiseless case, the tenth order model provides
the best ﬁt to the data (i.e., the lowest Ein). In contrast,
thetenthordermodelnowmakestheworstout-of-sample
predictions (i.e., the highest Eout). Remarkably, this is
true even if the data were generated using a tenth order
polynomial.
At small sample sizes, noise can create ﬂuctuations in
the data that look like genuine patterns. Simple mod-
els (like a linear function) cannot represent complicated
patterns in the data, so they are forced to ignore the
ﬂuctuations and to focus on the larger trends. Complex
models with many parameters, such as the tenth order
polynomial in our example, can capture both the global
trends and noise-generated patterns at the same time. In
this case, the model can be tricked into thinking that thenoise encodes real information. This problem is called
“overﬁtting” and leads to a steep drop-oﬀ in predictive
performance.
We can guard against overﬁtting in two ways: we can
use less expressive models with fewer parameters, or we
cancollectmoredatasothatthelikelihoodthatthenoise
appears patterned decreases. Indeed, when we increase
the size of the training data set by two orders of mag-
nitude toNtrain = 104(see Figure 3) the tenth order
polynomial clearly gives both the best ﬁts and the most
predictive power over the entire training range x2[0;1],
and even slightly beyond to approximately x1:05.
This is our ﬁrst experience with what is known as the
bias-variance tradeoﬀ, c.f. Sec. III.B. When the amount
of training data is limited as it is when Ntrain = 100,
one can often get better predictive performance by using
a less expressive model (e.g., a lower order polynomial)
rather than the more complex model (e.g., the tenth-
order polynomial). The simpler model has more “bias”
but is less dependent on the particular realization of the
training dataset, i.e. less “variance”. Finally we note that
even with ten thousand data points, the model’s perfor-
mancequicklydegradesbeyondtheoriginaltrainingdata
range. This demonstrates the diﬃculty of predicting be-
yond the training data we mentioned earlier.
This simple example highlights why ML is so diﬃcult
and holds some universal lessons that we will encounter
repeatedly in this review:
•Fitting is not predicting. Fitting existing data well
is fundamentally diﬀerent from making predictions
about new data.
•Usingacomplexmodelcanresultinoverﬁtting. In-
creasing a model’s complexity (i.e number of ﬁtting
parameters) will usually yield better results on the
training data. However when the training data size
is small and the data are noisy, this results in over-
ﬁttingand can substantially degrade the predictive
performance of the model.
•For complex datasets and small training sets, sim-
ple models can be better at prediction than com-
plex models due to the bias-variance tradeoﬀ. It
takes less data to train a simple model than a com-
plex one. Therefore, even though the correct model
isguaranteedtohavebetterpredictiveperformance
for an inﬁnite amount of training data (less bias),
the training errors stemming from ﬁnite-size sam-
pling (variance) can cause simpler models to out-
perform the more complex model when sampling is
limited.
•It is diﬃcult to generalize beyond the situations
encountered in the training data set.
10
0.0 0.2 0.4 0.6 0.8 1.0
x−4−2024y
Ntrain=10000,σ=1 (train)
Training
Linear
Poly 3
Poly 10
0.00 0.25 0.50 0.75 1.00 1.25
x−10−505101520y
Ntest=100,σ=1 (pred.)
Test
linear
3rd order
10th order
FIG. 3Fitting versus predicting for noisy data .Ntrain = 104noisy data points ( = 1) in the range x2[0;1]were
generated from a tenth-order polynomial. This data was ﬁt using three model classes: linear models (red), all polynomials
of order 3 (yellow), all polynomials of order 10 (green) and used to make prediction on Ntest= 100new data points with
xtest2[0;1:2](shown on right). The tenth order polynomial gives good predictions but the model’s predictive power quickly
degrades beyond the training data range.
III. BASICS OF STATISTICAL LEARNING THEORY
In this section, we brieﬂy summarize and discuss the
sense in which learning is possible, with a focus on su-
pervised learning. We begin with an unknown function
y=f(x)and ﬁx a hypothesis setHconsisting of all func-
tions we are willing to consider, deﬁned also on the do-
main off. This set may be uncountably inﬁnite (e.g. if
there are real-valued parameters to ﬁt). The choice of
which functions to include in Husually depends on our
intuition about the problem of interest. The function
f(x)produces a set of pairs (xi;yi),i= 1:::N, which
serve as the observable data. Our goal is to select a func-
tion from the hypothesis set h2Hthat approximates
f(x)as best as possible, namely, we would like to ﬁnd
h2 Hsuch thathfin some strict mathematical
sense which we specify below. If this is possible, we say
that welearnedf(x). But if the function f(x)can, in
principle, take any value on unobserved inputs, how is it
possible to learn in any meaningful sense?
The answer is that learning is possible in the restricted
sensethattheﬁttedmodelwillprobablyperformapprox-
imatelyaswellonnewdataasitdidonthetrainingdata.
Once an appropriate error function Eis chosen for the
problem under consideration (e.g. sum of squared errors
in linear regression), we can deﬁne two distinct perfor-
mance measures of interest. The in-sample error, Ein,
and the out-of-sample or generalization error, Eout. Re-
call from Sec II that both metrics are required due to the
distinction between ﬁtting and predicting.
This raises a natural question: Can we say somethinggeneral about the relationship between EinandEout?
Surprisingly, the answer is ‘Yes’. We can in fact say
quite a bit. This is the domain of statistical learning
theory, and we give a brief overview of the main results
in this section. Our goal is to brieﬂy introduce some of
the major ideas from statistical learning theory because
of the important role they have played in shaping how we
think about machine learning. However, this is a highly
technical and theoretical ﬁeld, so we will just skim over
some introductory topics. A more thorough introduction
to statistical learning theory can be found in the intro-
ductory textbook by Abu Mostafa (Abu-Mostafa et al.,
2012).
A. Three simple schematics that summarize the basic
intuitions from Statistical Learning Theory
The basic intuitions of statistical learning can be sum-
marized in three simple schematics. The ﬁrst schematic,
shown in Figure 4, shows the typical out-of-sample er-
ror,Eout, and in-sample error, Ein, as a function of the
amount of training data. In making this graph, we have
assumed that the true data is drawn from a suﬃciently
complicated distribution, so that we cannot exactly learn
the function f(x). Hence, after a quick initial drop (not
shown in ﬁgure), the in-sample error will increase with
the number of data points, because our models are not
powerful enough to learn the true function we are seeking
to approximate. In contrast, the out-of-sample error will
decrease with the number of data points. As the number
11
Eout
EinError
Number ofdata points{
}}Variance
Bias
FIG. 4Schematic of typical in-sample and out-of-
sample error as a function of training set size . The
typical in-sample or training error, Ein, out-of-sample or gen-
eralization error, Eout, bias, variance, and diﬀerence of errors
as a function of the number of training data points. The
schematic assumes that the number of data points is large (in
particular, the schematic does not show the initial drop in
Einfor small amounts of data), and that our model cannot
exactly ﬁt the true function f(x).
of data points gets large, the sampling noise decreases
and the training data set becomes more representative
of the true distribution from which the data is drawn.
For this reason, in the inﬁnite data limit, the in-sample
and out-of-sample errors must approach the same value,
which is called the “bias” of our model.
The bias represents the best our model could do if we
had an inﬁnite amount of training data to beat down
sampling noise. The bias is a property of the kind of
functions, or model class, we are using to approximate
f(x). In general, the more complex the model class we
use, the smaller the bias. However, we do not generally
have an inﬁnite amount of data. For this reason, to get
best predictive power it is better to minimize the out-of-
sample error, Eout, rather than the bias. As shown in
Figure 4,Eoutcan be naturally decomposed into a bias,
which measures how well we can hypothetically do in the
inﬁnite data limit, and a variance, which measures the
typical errors introduced in training our model due to
sampling noise from having a ﬁnite training set.
The ﬁnal quantity shown in Figure 4 is the diﬀerence
between the generalization and training error. It mea-
sures how well our in-sample error reﬂects the out-of-
sample error, and measures how much worse we would
do on a new data set compared to our training data. For
this reason, the diﬀerence between these errors is pre-
cisely the quantity that measures the diﬀerence between
Error
Model Complexity
Optimum 
BiasVarianceEoutFIG. 5Bias-Variance tradeoﬀ and model complexity.
This schematic shows the typical out-of-sample error Eoutas
functionofthemodelcomplexityforatrainingdatasetofﬁxed
size. Notice how the bias always decreases with model com-
plexity, but the variance, i.e. ﬂuctuation in performance due
to ﬁnite size sampling eﬀects, increases with model complex-
ity. Thus, optimal performance is achieved at intermediate
levels of model complexity.
ﬁtting and predicting. Models with a large diﬀerence be-
tween the in-sample and out-of-sample errors are said to
“overﬁt” the data. One of the lessons of statistical learn-
ing theory is that it is not enough to simply minimize
the training error, because the out-of-sample error can
still be large. As we will see in our discussion of regres-
sion in Sec. VI, this insight naturally leads to the idea of
“regularization”.
The second schematic, shown in Figure 5, shows the
out-of-sample, or test, error Eoutas a function of “model
complexity”. Model complexity is a very subtle idea
and deﬁning it precisely is one of the great achieve-
mentsofstatisticallearningtheory. Inmanycases, model
complexity is related to the number of parameters we
are using to approximate the true function f(x)1. In
the example of polynomial regression discussed above,
higher-order polynomials are more complex than the lin-
ear model. If we consider a training dataset of a ﬁxed
size,Eoutwill be a non-monotonic function of the model
complexity, and is generally minimized for models with
intermediate complexity. The underlying reason for this
is that, even though using a more complicated model
always reduces the bias, at some point the model be-
comes too complex for the amount of training data and
the generalization error becomes large due to high vari-
ance. Thus, to minimize Eoutand maximize our predic-
tive power, it may be more suitable to use a more bi-
1Thereare,ofcourse,exceptions. Oneneatexampleinthecontext
of one-dimensional regression in given in (Friedman et al., 2001),
Figure 7.5.
12
x x
x xx x
xx
x
xx
xx
x
x
xx
xxx
xxx
xx
xx
xx
xxxx
xxxxx
xx
xx
xxxTrue model
Low variance,
high-bias modelHigh variance,low-bias model
FIG. 6Bias-Variance tradeoﬀ. Another useful depiction
of the bias-variance tradeoﬀ is to think about how Eoutvaries
as we consider diﬀerent training data sets of a ﬁxed size. A
more complex model (green) will exhibit larger ﬂuctuations
(variance) due to ﬁnite size sampling eﬀects than the sim-
pler model (black). However, the average over all the trained
models (bias) is closer to the true model for the more complex
model.
ased model with small variance than a less-biased model
withlargevariance. Thisimportantconceptiscommonly
called the bias-variance tradeoﬀ and gets at the heart of
why machine learning is diﬃcult.
Another way to visualize the bias-variance tradeoﬀ is
shown in Figure 6. In this ﬁgure, we imagine training
a complex model (shown in green) and a simpler model
(shown in black) many times on diﬀerent training sets
of a ﬁxed size N. Due to the sampling noise from hav-
ing ﬁnite size data sets, the learned models will diﬀer for
each choice of training sets. In general, more complex
models need a larger amount of training data. For this
reason, the ﬂuctuations in the learned models (variance)
will be much larger for the more complex model than the
simpler model. However, if we consider the asymptotic
performance as we increase the size of the training set
(the bias), it is clear that the complex model will even-
tually perform better than the simpler model. Thus, de-
pending on the amount of training data, it may be morefavorable to use a less complex, high-bias model to make
predictions.
B. Bias-Variance Decomposition
In this section, we dig further into the central prin-
ciple that underlies much of machine learning: the bias-
variancetradeoﬀ. Wewilldiscussthebias-variancetrade-
oﬀinthecontextofcontinuouspredictionssuchasregres-
sion. However, manyoftheintuitionsandideasdiscussed
here also carry over to classiﬁcation tasks. Consider a
datasetD= (X;y)consisting of the Npairs of indepen-
dent and dependent variables. Let us assume that the
true data is generated from a noisy model
y=f(x) + (2)
whereis normally distributed with mean zero and stan-
dard deviation .
Assumethatwehaveastatisticalprocedure(e.g. least-
squares regression) for forming a predictor f(x;^)that
gives the prediction of our model for a new data point x.
This estimator is chosen by minimizing a cost function
which we take to be the squared error
C(y;f(X;)) =X
i(yi f(xi;))2:(3)
Therefore, the estimates for the parameters,
^D= arg min
C(y;f(X;)): (4)
are a function of the dataset, D. We would obtain a
diﬀerent errorC(yj;f(Xj;^Dj))for each dataset Dj=
(yj;Xj)in a universe of possible datasets obtained by
drawingNsamples from the true data distribution. We
denote an expectation value over all of these datasets as
ED.
We would also like to average over diﬀerent instances
of the “noise” and we denote the expectation value over
the noise by E. Thus, we can decompose the expected
generalization error as
ED;[C(y;f(X;^D))] = ED;"X
i(yi f(xi;^D))2#
=ED;"X
i(yi f(xi) +f(xi) f(xi;^D))2#
=X
iE[(yi f(xi))2] +ED;[(f(xi) f(xi;^D))2] + 2E[yi f(xi)]ED[f(xi) f(xi;^D)]
=X
i2
+ED[(f(xi) f(xi;^D))2]; (5)
where in the last line we used the fact that our noise has zero mean and variance 2
and the sum over iapplies to all
13
terms. It is also helpful to further decompose the second term as follows:
ED[(f(xi) f(xi;^D))2] =ED[ff(xi) ED[f(xi;^D)] +ED[f(xi;^D)] f(xi;^D)g2]
=ED[ff(xi) ED[f(xi;^D)]g2] +ED[ff(xi;^D) ED[f(xi;^D)]g2]
+2ED[ff(xi) ED[f(xi;^D)]gff(xi;^D) ED[f(xi;^D)]g]
= (f(xi) ED[f(xi;^D)])2+ED[ff(xi;^D) ED[f(xi;^D)]g2]: (6)
The ﬁrst term is called the bias
Bias2=X
i(f(xi) ED[f(xi;^D)])2(7)
and measures the deviation of the expectation value of
our estimator (i.e. the asymptotic value of our estimator
intheinﬁnitedatalimit)fromthetruevalue. Thesecond
term is called the variance
Var =X
iED[(f(xi;^D) ED[f(xi;^D)])2];(8)
and measures how much our estimator ﬂuctuates due
to ﬁnite-sample eﬀects. Combining these expressions,
we see that the expected out-of-sample error, Eout:=
ED;[C(y;f(X;^D))], can be decomposed as
Eout=Bias2+Var+Noise; (9)
withNoise =P
i2
.
The bias-variance tradeoﬀ summarizes the fundamen-
tal tension in machine learning, particularly supervised
learning, between the complexity of a model and the
amount of training data needed to train it. Since data
is often limited, in practice it is often useful to use a
less-complex model with higher bias – a model whose
asymptotic performance is worse than another model –
because it is easier to train and less sensitive to sampling
noise arising from having a ﬁnite-sized training dataset
(smaller variance). This is the basic intuition behind the
schematics in Figs. 4, 5, and 6.
IV. GRADIENT DESCENT AND ITS GENERALIZATIONS
Almost every problem in ML and data science starts
with the same ingredients: a dataset X, a modelg(),
which is a function of the parameters , and a cost func-
tionC(X;g())that allows us to judge how well the
modelg()explains the observations X. The model is ﬁt
byﬁndingthevaluesof thatminimizethecostfunction.
In this section, we discuss one of the most powerful
and widely used classes of methods for performing this
minimization – gradient descent and its generalizations.
The basic idea behind these methods is straightforward:
iteratively adjust the parameters in the direction where
the gradient of the cost function is large and negative.
In this way, the training procedure ensures the parame-
ters ﬂow towards a localminimum of the cost function.However, in practice gradient descent is full of surprises
and a series of ingenious tricks have been developed by
the optimization and machine learning communities to
improve the performance of these algorithms.
The underlying reason why training a machine learn-
ing algorithm is diﬃcult is that the cost functions we
wish to optimize are usually complicated, rugged, non-
convex functions in a high-dimensional space with many
local minima. To make things even more diﬃcult, we
almost never have access to the true function we wish
to minimize: instead, we must estimate this function di-
rectly from data. In modern applications, both the size
of the dataset and the number of parameters we wish to
ﬁt is often enormous (millions of parameters and exam-
ples). The goal of this chapter is to explain how gradient
descent methods can be used to train machine learning
algorithms even in these diﬃcult settings.
This chapter seeks to both introduce commonly used
methods and give intuition for why they work. We
also include some practical tips for improving the per-
formance of stochastic gradient descent (Bottou, 2012;
LeCunet al., 1998b). To help the reader gain more in-
tuition about gradient descent and its variants, we have
developed a Jupyter notebook that allows the reader to
visualize how these algorithms perform on two dimen-
sional surfaces. The reader is encouraged to experi-
ment with the accompanying notebook whenever a new
method is introduced (especially to explore how changing
hyper-parameters can aﬀect performance). The reader
may also wish to consult useful reviews that cover these
topics (Ruder, 2016) and this blog http://ruder.io/
optimizing-gradient-descent/ .
A. Gradient Descent and Newton’s method
We begin by introducing a simple ﬁrst-order gradient
descent method and comparing and contrasting it with
another algorithm, Newton’s method. Newton’s method
is intimately related to many algorithms (conjugate gra-
dient, quasi-Newton methods) commonly used in physics
for optimization problems. Denote the function we wish
to minimize by E().
In the context of machine learning, E()is just the
cost function E() =C(X;g()). As we shall see for
linear and logistic regression in Secs. VI, VII, this energy
function can almost always be written as a sum over n
14
−4−2 0 2 4
x−5.0−2.50.02.55.0y
η=0.1
η=0.5
η=1
η=1.01
FIG. 7Gradient descent exhibits three qualitatively
diﬀerent regimes as a function of the learning rate.
Result of gradient descent on surface z=x2+y2 1for
learning rate of = 0:1;0:5;1:01. Notice that the trajectory
converges to the global minima in multiple steps for small
learning rates ( = 0:1). Increasing the learning rate fur-
ther (= 0:5) causes the trajectory to oscillate around the
global minima before converging. For even larger learning
rates (= 1:01) the trajectory diverges from the minima. See
corresponding notebook for details.
data points,
E() =nX
i=1ei(xi;): (10)
For example, for linear regression eiis just the mean
square-error for data point i; for logistic regression, it is
the cross-entropy. To make analogy with physical sys-
tems, we will often refer to this function as the “energy”.
In the simplest gradient descent (GD) algorithm, we
update the parameters as follows. Initialize the parame-
ters to some value 0and iteratively update the param-
eters according to the equation
vt=trE(t);
t+1=t vt (11)
whererE()is the gradient of E()w.r.t.and we
have introduced a learning rate ,t, that controls how big
a step we should take in the direction of the gradient at
time stept. It is clear that for suﬃciently small choice of
the learning rate tthis methods will converge to a local
minimum (in all directions) of the cost function. How-
ever, choosing a small tcomes at a huge computational
cost. The smaller t, the more steps we have to take to
reach the local minimum. In contrast, if tis too large,
we can overshoot the minimum and the algorithm be-
comes unstable (it either oscillates or even moves away
from the minimum). This is shown in Figure 7. In prac-
tice, one usually speciﬁes a “schedule” that decreases t
at long times. Common schedules include power law and
exponential decay in time.
To better understand this behavior and highlight some
of the shortcomings of GD, it is useful to contrast GDwith Newton’s method which is the inspiration for many
widely employed optimization methods. In Newton’s
method, we choose the step vfor the parameters in such
a way as to minimize a second-order Taylor expansion to
the energy function
E(+v)E() +rE()v+1
2vTH()v;
whereH()is the Hessian matrix of second derivatives.
Diﬀerentiating this equation respect to vand noting that
for the optimal value voptwe expectrE(+vopt) = 0,
yields the following equation
0 =rE() +H()vopt: (12)
Rearranging this expression results in the desired update
rules for Newton’s method
vt=H 1(t)rE(t) (13)
t+1=t vt: (14)
Since we have no guarantee that the Hessian is well con-
ditioned, in almost all applications of Netwon’s method,
one replaces the inverse of the Hessian H 1(t)by some
suitably regularized pseudo-inverse such as [H(t)+I] 1
witha small parameter (Battiti, 1992).
For the purposes of machine learning, Newton’s
method is not practical for two interrelated reasons.
First, calculating a Hessian is an extremely expensive
numerical computation. Second, even if we employ ﬁrst-
order approximation methods to approximate the Hes-
sian (commonly called quasi-Newton methods), we must
store and invert a matrix with n2entries, where nis the
number of parameters. For models with millions of pa-
rameters such as those commonly employed in the neu-
ral network literature, this is close to impossible with
present-day computational power. Despite these practi-
cal shortcomings, Newton’s method gives many impor-
tant intuitions about how to modify GD algorithms to
improve their performance. Notice that, unlike in GD
where the learning rate is the same for all parameters,
Newton’s method automatically “adapts” the learning
rate of diﬀerent parameters depending on the Hessian
matrix. Since the Hessian encodes the curvature of the
surface we are trying to ﬁnd the minimum of – more
speciﬁcally, the singular values of the Hessian are in-
verselyproportionaltothesquaresofthelocalcurvatures
of the surface – Newton’s method automatically adjusts
the step size so that one takes larger steps in ﬂat di-
rections with small curvature and smaller steps in steep
directions with large curvature.
Our derivation of Newton’s method also allows us to
develop intuition about the role of the learning rate in
GD. Let us ﬁrst consider the special case of using GD
to ﬁnd the minimum of a quadratic energy function of
a single parameter (LeCunet al., 1998b). Given the
current value of our parameter , we can ask what is
15
E(θ)
θ
θminE(θ)
θ
θminE(θ)
θ
θminE(θ)
θ
θminη<ηopt η=ηopt
η>ηopt η>2ηoptA B
CD
FIG. 8Eﬀect of learning rate on convergence . For a
one dimensional quadratic potential, one can show that there
exists four diﬀerent qualitative behaviors for gradient descent
(GD) as a function of the learning rate depending on the
relationship between andopt= [@2
E()] 1. (a) For <
opt, GD converges to the minimum. (b) For =opt, GD
converges in a single step. (c) For opt<  < 2opt, GD
oscillates around the minima and eventually converges. (d)
For>2opt, GD moves away from the minima. This ﬁgure
is adapted from (LeCun et al., 1998b).
the optimal choice of the learning rate opt, whereopt
is deﬁned as the value of that allows us to reach the
minimum of the quadratic energy function in a single
step (see Figure 8). To ﬁnd opt, we expand the energy
function to second order around the current value
E(+v) =E(c) +@E()v+1
2@2
E()v2:(15)
Diﬀerentiating with respect to vand setting min= v
yields
min= [@2
E()] 1@E(): (16)
Comparing with (11) gives,
opt= [@2
E()] 1: (17)
Onecanshowthattherearefourqualitativelydiﬀerent
regimes possible (see Fig. 8) (LeCun et al., 1998b). If
< opt, then GD will take multiple small steps to reach
the bottom of the potential. For =opt, GD reaches
the bottom of the potential in a single step. If opt<
 < 2opt, then the GD algorithm will oscillate across
bothsidesofthepotentialbeforeeventuallyconvergingto
the minimum. However, when  >2opt, the algorithm
actually diverges!
It is straightforward to generalize this to the multidi-
mensional case. The natural multidimensional general-
ization of the second derivative is the Hessian H(). Wecan always perform a singular value decomposition (i.e.
a rotation by an orthogonal matrix for quadratic minima
where the Hessian is symmetric, see Sec. VI.B for a brief
introduction to SVD) and consider the singular values
fgof the Hessian. If we use a single learning rate for all
parameters, in analogy with (17), convergence requires
that
<2
max; (18)
wheremaxis the largest singular value of the Hessian.
If the minimum eigenvalue mindiﬀers signiﬁcantly from
the largest value max, then convergence in the min-
direction will be extremely slow! One can actually show
that the convergence time scales with the condition num-
ber=max=min(LeCunet al., 1998b).
B. Limitations of the simplest gradient descent algorithm
The last section hints at some of the major shortcom-
ingsofthesimpleGDalgorithmdescribedin(11). Before
proceeding, we brieﬂy summarize these limitations and
discuss general strategies for modifying GD to overcome
these deﬁciencies.
•GD ﬁnds local minima of the cost function. Since
the GD algorithm is deterministic, if it converges,
it will converge to a local minimum of our energy
function. Because in ML we are often dealing with
extremely rugged landscapes with many local min-
ima, this can lead to poor performance. A similar
problem is encountered in physics. To overcome
this, physicists often use methods like simulated
annealing that introduce a ﬁctitious “temperature”
which is eventually taken to zero. The “tempera-
ture” term introduces stochasticity in the form of
thermal ﬂuctuations that allow the algorithm to
thermally tunnel over energy barriers. This sug-
gests that, in the context of ML, we should modify
GD to include stochasticity.
•Gradients are computationally expensive to calcu-
late for large datasets . In many cases in statistics
and ML, the energy function is a sum of terms,
with one term for each data point. For example, in
linear regression, E/Pn
i=1(yi wTxi)2; for lo-
gistic regression, the square error is replaced by the
cross entropy, see Secs. VI, VII. Thus, to calculate
the gradient we have to sum over allndata points.
Doing this at every GD step becomes extremely
computationally expensive. An ingenious solution
to this, discussed below, is to calculate the gra-
dients using small subsets of the data called “mini
batches”. This has the added beneﬁt of introducing
stochasticity into our algorithm.
16
•GD is very sensitive to choices of the learning rates .
As discussed above, GD is extremely sensitive to
the choice of learning rates. If the learning rate is
very small, the training process takes an extremely
long time. For larger learning rates, GD can di-
verge and give poor results. Furthermore, depend-
ing on what the local landscape looks like, we have
to modify the learning rates to ensure convergence.
Ideally, we would “adaptively” choose the learning
rates to match the landscape.
•GD treats all directions in parameter space uni-
formly. Another major drawback of GD is that
unlike Newton’s method, the learning rate for GD
isthesameinalldirectionsinparameterspace. For
thisreason, themaximumlearningrateissetbythe
behavior of the steepest direction and this can sig-
niﬁcantlyslowdowntraining. Ideally,wewouldlike
to take large steps in ﬂat directions and small steps
in steep directions. Since we are exploring rugged
landscapes where curvatures change, this requires
us to keep track of not only the gradient but second
derivativesoftheenergyfunction(noteasdiscussed
above, the ideal scenario would be to calculate the
Hessian but this proves to be too computationally
expensive).
•GD is sensitive to initial conditions. One conse-
quence of the local nature of GD is that initial con-
ditionsmatter. Dependingonwhereonestarts, one
will end up at a diﬀerent local minimum. There-
fore, it is very important to think about how one
initializes the training process. This is true for GD
as well as more complicated variants of GD intro-
duced below.
•GD can take exponential time to escape saddle
points, even with random initialization. Aswemen-
tioned, GD is extremely sensitive to the initial con-
dition since it determines the particular local min-
imum GD would eventually reach. However, even
with a good initialization scheme, through random-
ness (to be introduced later), GD can still take ex-
ponential time to escape saddle points, which are
prevalent in high-dimensional spaces, even for non-
pathological objective functions (Du et al., 2017).
Indeed, there are modiﬁed GD methods developed
recently to accelerate the escape. The details of
these boosted method are beyond the scope of this
review, and we refer avid readers to (Jin et al.,
2017) for details.
In the next few subsections, we will introduce variants
of GD that address many of these shortcomings. These
generalized gradient descent methods form the backbone
of much of modern deep learning and neural networks,
see Sec IX. For this reason, the reader is encouraged toreally experiment with diﬀerent methods in landscapes
of varying complexity using the accompanying notebook.
C. Stochastic Gradient Descent (SGD) with mini-batches
One of the most widely-applied variants of the gra-
dient descent algorithm is stochastic gradient descent
(SGD)(Bottou, 2012; Williams and Hinton, 1986). As
the name suggests, unlike ordinary GD, the algorithm
is stochastic. Stochasticity is incorporated by approx-
imating the gradient on a subset of the data called a
minibatch2. The size of the minibatches is almost al-
ways much smaller than the total number of data points
n, with typical minibatch sizes ranging from ten to a
few hundred data points. If there are npoints in total,
and the mini-batch size is M, there will be n=Mmini-
batches. Let us denote these minibatches by Bkwhere
k= 1;:::;n=M . Thus, in SGD, at each gradient descent
step we approximate the gradient using a single mini-
batchBk,
rE() =nX
i=1rei(xi;) !X
i2Bkrei(xi;):(19)
We then cycle over all k= 1;:::;n=M minibatches one
at a time, and use the mini-batch approximation to the
gradient to update the parameters at every step k. A
full iteration over all ndata points – in other words using
alln=Mminibatches – is called an epoch. For notational
convenience, we will denote the mini-batch approxima-
tion to the gradient by
rEMB() =X
i2Bkrei(xi;): (20)
With this notation, we can rewrite the SGD algorithm as
vt=trEMB();
t+1=t vt: (21)
Thus, in SGD, we replace the actual gradient over the
full data at each gradient descent step by an approxima-
tion to the gradient computed using a minibatch. This
has two important beneﬁts. First, it introduces stochas-
ticity and decreases the chance that our ﬁtting algorithm
gets stuck in isolated local minima. Second, it signiﬁ-
cantly speeds up the calculation as one does not have
to use allndata points to approximate the gradient.
Empirical and theoretical work suggests that SGD has
additional beneﬁts. Chief among these is that introduc-
ing stochasticity is thought to act as a natural regular-
izer that prevents overﬁtting in deep, isolated minima
(Bishop, 1995a; Keskar et al., 2016).
2Traditionally, SGD was reserved for the case where you train on
a single example – in other words minibatches of size 1. However,
we will use SGD to mean any approximation to the gradient on
a subset of the data.
17
D. Adding Momentum
In practice, SGD is almost always used with a “mo-
mentum” or inertia term that serves as a memory of the
direction we are moving in parameter space. This is typ-
ically implemented as follows
vt=vt 1+trE(t)
t+1=t vt; (22)
where we have introduced a momentum parameter ,
with 01, and for brevity we dropped the ex-
plicit notation to indicate the gradient is to be taken
over a diﬀerent mini-batch at each step. We call this al-
gorithm gradient descent with momentum (GDM). From
these equations, it is clear that vtis a running average
of recently encountered gradients and (1 ) 1sets the
characteristic time scale for the memory used in the av-
eraging procedure. Consistent with this, when = 0,
this just reduces down to ordinary SGD as described in
Eq. (21). An equivalent way of writing the updates is
t+1=t trE(t); (23)
where we have deﬁned t=t t 1. In what should
be a familiar scenario to many physicists, momentum
based methods were ﬁrst introduced in old, largely for-
gotten (until recently) Soviet papers (Nesterov, 1983;
Polyak, 1964).
Before proceeding further, let us try to get more in-
tuition from these equations. It is helpful to consider a
simple physical analogy with a particle of mass mmoving
in a viscous medium with viscous damping coeﬃcient 
and potential E(w)(Qian, 1999). If we denote the par-
ticle’s position by w, then its motion is described by
md2w
dt2+dw
dt= rwE(w): (24)
We can discretize this equation in the usual way to get
mwt+t 2wt+wt t
(t)2+wt+t wt
t= rwE(w):
(25)
Rearranging this equation, we can rewrite this as
wt+t= (t)2
m+trwE(w) +m
m+twt:(26)
Notice that this equation is identical to Eq. (23) if we
identify the position of the particle, w, with the parame-
ters. This allows us to identify the momentum param-
eter and learning rate with the mass of the particle and
the viscous damping as:
=m
m+t;  =(t)2
m+t:(27)Thus, as the name suggests, the momentum parameter
is proportional to the mass of the particle and eﬀec-
tively provides inertia. Furthermore, in the large vis-
cosity/small learning rate limit, our memory time scales
as(1 ) 1m=(t).
Why is momentum useful? SGD momentum helps
the gradient descent algorithm gain speed in directions
with persistent but small gradients even in the presence
of stochasticity, while suppressing oscillations in high-
curvature directions. This becomes especially important
in situations where the landscape is shallow and ﬂat in
some directions and narrow and steep in others. It has
been argued that ﬁrst-order methods (with appropriate
initial conditions) can perform comparable to more ex-
pensive second order methods, especially in the context
of complex deep learning models (Sutskever et al., 2013).
Empirical studies suggest that the beneﬁts of including
momentum are especially pronounced in complex models
in the initial “transient phase” of training, rather than
during a subsequent ﬁne-tuning of a coarse minimum.
The reason for this is that, in this transient phase, corre-
lations in the gradient persist across many gradient de-
scent steps, accentuating the role of inertia and memory.
These beneﬁcial properties of momentum can some-
times become even more pronounced by using a slight
modiﬁcation of the classical momentum algorithm called
Nesterov Accelerated Gradient (NAG) (Nesterov, 1983;
Sutskever et al., 2013). In the NAG algorithm, rather
than calculating the gradient at the current parameters,
rE(t), one calculates the gradient at the expected
value of the parameters given our current momentum,
rE(t+vt 1). This yields the NAG update rule
vt=vt 1+trE(t+vt 1)
t+1=t vt: (28)
One of the major advantages of NAG is that it allows for
the use of a larger learning rate than GDM for the same
choice of.
E. Methods that use the second moment of the gradient
In stochastic gradient descent, with and without mo-
mentum, we still have to specify a “schedule” for tuning
the learning rate tas a function of time. As discussed in
the context of Newton’s method, this presents a number
of dilemmas. The learning rate is limited by the steepest
direction which can change depending on the current po-
sition in the landscape. To circumvent this problem, ide-
allyouralgorithmwouldkeeptrackofcurvatureandtake
large steps in shallow, ﬂat directions and small steps in
steep, narrow directions. Second-order methods accom-
plish this by calculating or approximating the Hessian
andnormalizingthelearningratebythecurvature. How-
ever, this is very computationally expensive for models
with extremely large number of parameters. Ideally, we
18
would like to be able to adaptively change the step size
to match the landscape without paying the steep compu-
tational price of calculating or approximating Hessians.
Recently, a number of methods have been introduced
that accomplish this by tracking not only the gradient,
but also the second moment of the gradient. These
methods include AdaGrad (Duchi et al., 2011), AdaDelta
(Zeiler, 2012), RMSprop (Tieleman and Hinton, 2012),
and ADAM (Kingma and Ba, 2014). Here, we discuss
the last two as representatives of this class of algorithms.
In RMSprop, in addition to keeping a running average
of the ﬁrst moment of the gradient, we also keep track of
the second moment denoted by st=E[g2
t]. The update
rule for RMSprop is given by
gt=rE() (29)
st=st 1+ (1 )g2
t
t+1=t tgtpst+;
wherecontrols the averaging time of the second mo-
ment and is typically taken to be about = 0:9,tis a
learning rate typically chosen to be 10 3, and10 8
is a small regularization constant to prevent divergences.
Multiplication and division by vectors is understood as
an element-wise operation. It is clear from this formula
that the learning rate is reduced in directions where the
gradient is consistently large. This greatly speeds up the
convergence by allowing us to use a larger learning rate
for ﬂat directions.
A related algorithm is the ADAM optimizer. In
ADAM, we keep a running average of both the ﬁrst and
second moment of the gradient and use this information
to adaptively change the learning rate for diﬀerent pa-
rameters. In addition to keeping a running average of the
ﬁrst and second moments of the gradient (i.e. mt=E[gt]
andst=E[g2
t], respectively), ADAM performs an addi-
tional bias correction to account for the fact that we are
estimating the ﬁrst two moments of the gradient using a
running average (denoted by the hats in the update rule
below). The update rule for ADAM is given by (where
multiplication and division are once again understood to
be element-wise operations)
gt=rE() (30)
mt=1mt 1+ (1 1)gt
st=2st 1+ (1 2)g2
t
^mt=mt
1 (1)t
^st=st
1 (2)t
t+1=t t^mtp^st+;
(31)
where1and2set the memory lifetime of the ﬁrst and
second moment and are typically taken to be 0:9and0:99respectively, and (j)tdenotesjto the power t. The
parameters andhave the same role as in RMSprop.
Like in RMSprop, the eﬀective step size of a parameter
depends on the magnitude of its gradient squared. To
understand this better, let us rewrite this expression in
terms of the variance 2
t=^st (^mt)2. Consider a single
parametert. The update rule for this parameter is given
by
t+1= t^mtp
2
t+ ^m2
t+: (32)
We now examine diﬀerent limiting cases of this expres-
sion. Assume that our gradient estimates are consistent
so that the variance is small. In this case our update
rule tends to t+1! t(here we have assumed that
^mt). This is equivalent to cutting oﬀ large persis-
tent gradients at 1and limiting the maximum step size
in steep directions. On the other hand, imagine that the
gradient is widely ﬂuctuating between gradient descent
steps. In this case 2^m2
tso that our update becomes
t+1! t^mt=t. In other words, we adapt our learn-
ing rate so that it is proportional to the signal-to-noise
ratio (i.e. the mean in units of the standard deviation).
From a physics standpoint, this is extremely desirable:
the standard deviation serves as a natural adaptive scale
for deciding whether a gradient is large or small. Thus,
ADAM has the beneﬁcial eﬀects of (i) adapting our step
sizesothatwecutoﬀlargegradientdirections(andhence
prevent oscillations and divergences), and (ii) measuring
gradients in terms of a natural length scale, the stan-
dard deviation t. The discussion above also explains
empirical observations showing that the performance of
both ADAM and RMSprop is drastically reduced if the
square root is omitted in the update rule. It is also
worth noting that recent studies have shown adaptive
methods like RMSProp, ADAM, and AdaGrad to gener-
alize worse than SGD in classiﬁcation tasks, though they
achieve smaller training error. Such discussion is beyond
the scope of this review so we refer readers to (Wilson
et al., 2017) for more details.
F. Comparison of various methods
To better understand these methods, it is helpful to
visualize the performance of the ﬁve methods discussed
above – gradient descent (GD), gradient descent with
momentum (GDM), NAG, ADAM, and RMSprop. To
do so, we will use Beale’s function:
f(x;y) = (1:5 x+xy)2(33)
+(2:25 x+xy2)2+ (2:625 x+xy3)2:
This function has a global minimum at (x;y) = (3;0:5)
and an interesting structure that can be seen in Fig. 9.
The ﬁgure shows the results of using all ﬁve methods
19
−4−2 0 2 4
x−4−2024yGD
GDM
NAG
RMS
ADAMS
FIG. 9Comparison of GD and its generalization for
Beale’s function . Trajectories from gradient descent (GD;
blackline), gradientdescentwithmomentum(GDM;magenta
line), NAG(cyan-dashedline), RMSprop(bluedash-dotline),
and ADAM (red line) for Nsteps = 104. The learning rate
for GD, GDM, NAG is = 10 6and= 10 3for ADAM
and RMSprop. = 0:9for RMSprop, 1= 0:9and2=
0:99for ADAM, and = 10 8for both methods. Please see
corresponding notebook for details.
forNsteps = 104steps for three diﬀerent initial condi-
tions. In the ﬁgure, the learning rate for GD, GDM, and
NAG are set to = 10 6whereas RMSprop and ADAM
have a learning rate of = 10 3. The learning rates
for RMSprop and ADAM can be set signiﬁcantly higher
than the other methods due to their adaptive step sizes.
For this reason, ADAM and RMSprop tend to be much
quicker at navigating the landscape than simple momen-
tum based methods (see Fig. 9). Notice that in some
cases (e.g. initial condition of ( 1;4)), the trajectories
do not ﬁnd the global minimum but instead follow the
deep, narrowravinethatoccursalong y= 1. Thiskindof
landscape structure is generic in high-dimensional spaces
where saddle points proliferate. Once again, the adaptive
step size and momentum of ADAM and RMSprop allows
these methods to traverse the landscape faster than the
simpler ﬁrst-order methods. The reader is encouraged to
consult the corresponding Jupyter notebook and experi-
ment with changing initial conditions, the cost function
surface being minimized, and hyper-parameters to gain
more intuition about all these methods.
G. Gradient descent in practice: practical tips
We conclude this chapter by compiling some practical
tips from experts for getting the best performance from
gradient descent based algorithms, especially in the con-
textofdeepneuralnetworksdiscussedlaterinthereview,
see Secs. IX, and XVI.B. This section draws heavily on
best practices laid out in (Bottou, 2012; LeCun et al.,
1998b; Tieleman and Hinton, 2012).
•Randomize the data when making mini-batches . Itis always important to randomly shuﬄe the data
when forming mini-batches. Otherwise, the gra-
dient descent method can ﬁt spurious correlations
resulting from the order in which data is presented.
•Transform your inputs . As we discussed above,
learning becomes diﬃcult when our landscape has
a mixture of steep and ﬂat directions. One simple
trick for minimizing these situations is to standard-
ize the data by subtracting the mean and normaliz-
ing the variance of input variables. Whenever pos-
sible, also decorrelate the inputs. To understand
why this is helpful, consider the case of linear re-
gression. It is easy to show that for the squared
error cost function, the Hessian of the energy ma-
trix is just the correlation matrix between the in-
puts. Thus, by standardizing the inputs, we are
ensuring that the landscape looks homogeneous in
all directions in parameter space. Since most deep
networks can be viewed as linear transformations
followed by a non-linearity at each layer, we expect
this intuition to hold beyond the linear case.
•Monitor the out-of-sample performance. Always
monitor the performance of your model on a valida-
tion set (a small portion of the training data that is
held out of the training process to serve as a proxy
for the test set – see Sec. XI for more on validation
sets). If the validation error starts increasing, then
the model is beginning to overﬁt. Terminate the
learning process. This early stopping signiﬁcantly
improves performance in many settings.
•Adaptive optimization methods do not always have
good generalization. As we mentioned, recent stud-
ies have shown that adaptive methods such as
ADAM,RMSprop, andAdaGradtendtohavepoor
generalization compared to SGD or SGD with mo-
mentum, particularly in the high-dimensional limit
(i.e. the number of parameters exceeds the number
of data points) (Wilson et al., 2017). Although it is
not clear at this stage why sophisticated methods,
such as ADAM, RMSprop, and AdaGrad, perform
so well in training deep neural networks such as
generative adversarial networks (GANs) (Goodfel-
lowet al., 2014) [see Sec. XVII], simpler procedures
like properly-tuned plain SGD may work equally
well or better in some applications.
V. OVERVIEW OF BAYESIAN INFERENCE
Statistical modeling usually revolves around estima-
tion or prediction (Jaynes, 1996). Bayesian methods are
based on the fairly simple premise that probability can
be used as a mathematical framework for describing un-
certainty. This is not that diﬀerent in spirit from the
20
main idea of statistical mechanics in physics, where we
use probability to describe the behavior of large systems
where we cannot know the positions and momenta of all
the particles even if the system itself is fully determinis-
tic (at least classically). In practice, Bayesian inference
provides a set of principles and procedures for learning
from data and for describing uncertainty. In this section,
we give a gentle introduction to Bayesian inference, with
specialemphasisonitslogic(i.e.Bayesianreasoning)and
provide a connection to ML discussed in Sec. II and III.
For a technical account of Bayesian inference in general,
we refer readers to (Barber, 2012; Gelman et al., 2014).
A. Bayes Rule
To solve a problem using Bayesian methods, we have
to specify two functions: the likelihood function p(Xj),
which describes the probability of observing a dataset
Xfor a given value of the unknown parameters , and
theprior distribution p(), which describes any knowl-
edge we have about the parameters before we collect the
data. Note that the likelihood should be considered as
a function of the parameters with the data Xheld
ﬁxed. The prior distribution and the likelihood function
are used to compute the posterior distribution p(jX)
via Bayes’ rule:
p(jX) =p(Xj)p()R
d0p(Xj0)p(0): (34)
Theposteriordistributiondescribesourknowledgeabout
the unknown parameter after observing the data X.
In many cases, it will not be possible to analytically
compute the normalizing constant in the denominator of
the posterior distribution, i.e. p(X) =R
dp(Xj)p(),
and Markov Chain Monte Carlo (MCMC) methods are
needed to draw random samples from p(jX).
The likelihood function p(Xj)is a common feature
of both classical statistics and Bayesian inference, and
is determined by the model and the measurement noise.
Many common statistical procedures such as least-square
ﬁtting can be cast as Maximum Likelihood Estimation
(MLE). In MLE, one chooses the parameters ^that max-
imize the likelihood (or equivalently the log-likelihood
since log is a monotonic function) of the observed data:
^= arg max
logp(Xj): (35)
In other words, in MLE we choose the parameters that
maximize the probability of seeing the observed data
given our generative model. MLE is an important con-
cept in both frequentist and Bayesian statistics.
The prior distribution, by contrast, is uniquely
Bayesian. There are two general classes of priors: if we
do not have any specialized knowledge about before welook at the data then we would like to select an unin-
formative prior that reﬂects our ignorance, otherwise we
should select an informative prior that accurately reﬂects
the knowledge we have about . This review will focus
oninformative priors that are commonly used for ML
applications. However, there is a large literature on un-
informative priors, including reparameterization invari-
ant priors, that would be of interest to physicists and
we refer the interested reader to (Berger and Bernardo,
1992; Gelman et al., 2014; Jaynes, 1996; Jeﬀreys, 1946;
Mattingly et al., 2018).
Using an informative prior tends to decrease the vari-
ance of the posterior distribution while, potentially, in-
creasing its bias. This is beneﬁcial if the decrease in
variance is larger than the increase in bias. In high-
dimensional problems, it is reasonable to assume that
many of the parameters will not be strongly relevant.
Therefore, many of the parameters of the model will
be zero or close to zero. We can express this belief
using two commonly used priors: the Gaussian prior
p(j) =Q
jq

2e 2
jis used to express the assump-
tion that many of the parameters will be small, and the
Laplace prior p(j) =Q
j
2e jjjis used to express the
assumption that many of the parameters will be zero.
We’ll come back to this point later in Sec. VI.F.
B. Bayesian Decisions
The above section presents the tools for computing the
posterior distribution p(jX), which uses probability as
a framework for expressing our knowledge about the pa-
rameters. In most cases, however, we need to summa-
rize our knowledge and pick a single “best” value for the
parameters. In principle, the speciﬁc value of the param-
eters should be chosen to maximize a utility function.
In practice, however, we usually use one of two choices:
the posterior mean hi=R
dp(jX), or the poste-
rior mode ^MAP = arg maxp(jX). Often,hiis called
the Bayes estimate and ^MAPis called the maximum-a-
posteriori or MAP estimate. While the Bayes estimate
minimizes the mean-squared error, the MAP estimate is
often used instead because it is easier to compute.
C. Hyperparameters
The Gaussian and Laplace prior distributions, used to
express the assumption that many of the model parame-
ters will be small or zero, both have an extra parameter
. Thishyperparameter ornuisance variable has to be
chosen somehow. One standard Bayesian approach is to
deﬁne another prior distribution for – usually using an
uninformative prior – and to average the posterior distri-
bution over all choices of . This is called a hierarchical
prior. Computing averages, however, often requires long
21
Markov Chain Monte Carlo simulations that are compu-
tationally intensive. Therefore, it is simpler if we can
ﬁnd a good value of using an optimization procedure
instead. Wewilldiscusshowthisisdoneinpracticewhen
discussing linear regression in Sec. VI.
VI. LINEAR REGRESSION
In Section II, we performed our ﬁrst numerical ML
experiments by ﬁtting datasets generated by polynomi-
als in the presence of diﬀerent levels of additive noise.
We used the ﬁtted parameters to make predictions on
‘unseen’ observations, allowing us to gauge the perfor-
mance of our model on new data. These experiments
highlighted the fundamental tension common to all ML
models between how well we ﬁt the training dataset and
predictions on new data. The optimal choice of predictor
depended on, among many other things, the functions
used to ﬁt the data and the underlying noise level. In
Section III, we formalized this by introducing the notion
of model complexity and the bias-variance decomposi-
tion, and discussed the statistical meaning of learning.
In this section, we take a closer look at these ideas in the
simple setting of linear regression.
As in Section II, ﬁtting a given set of samples (yi;xi)
means relating the independent variables xito their re-
sponsesyi. For example, suppose we want to see how
the voltage across two sides of a metal slab Vchanges
in response to the applied electric current I. Normally
we would ﬁrst make a bunch of measurements labeled
byiand plot them on a two-dimensional scatterplot,
(Vi;Ii). The next step is to assume, either from an oracle
or from theoretical reasoning, some modelsthat might
explain the measurements and measuring their perfor-
mance. Mathematically, this amounts to ﬁnding some
functionfsuch thatVi=f(Ii;w), wherewis some pa-
rameter (e.g. the electrical resistance Rof the metal slab
in the case of Ohm’s law). We then try to minimize the
errors made in explaining the given set of measurements
based on our model fby tuning the parameter w. To
do so, we need to ﬁrst deﬁne the error function (formally
called the loss function ) that characterizes the deviation
of our prediction from the actual response.
Before formulating the problem, let us set up the no-
tation. Suppose we are given a dataset with nsam-
plesD=f(yi;x(i))gn
i=1, wherex(i)is thei-th obser-
vation vector while yiis its corresponding (scalar) re-
sponse. We assume that every sample has pfeatures,
namely,x(i)2Rp. Letfbe the true function/model
that generated these samples via yi=f(x(i);wtrue) +i,
wherewtrue2Rpis a parameter vector and iis some
i.i.d. white noise with zero mean and ﬁnite variance.
Conventionally, we cast all samples into an npma-
trix,X2Rnp, called the design matrix , with the rows
Xi;:=x(i)2Rp;;i= 1;;nbeing observations andthe columns X:;j2Rn;j= 1;pbeing measured fea-
tures. Bear in mind that this function fis never known
to us explicitly, though in practice we usually presume
its functional form. For example, in linear regression , we
assumeyi=f(x(i);wtrue) +i=wT
truex(i)+ifor some
unknown but ﬁxed wtrue2Rp.
We want to ﬁnd a function gwith parameters wﬁt
to the dataDthat can best approximate f. When this
is done, meaning we have found a ^wsuch thatg(x;^w)
yields our best estimate of f, we can use this gto make
predictions about the response y0for a new data point
x0, as we did in Section II.
It will be helpful for our discussion of linear regres-
sion to deﬁne one last piece of notation. For any real
numberp1, we deﬁne the Lpnorm of a vector
x= (x1;;xd)2Rdto be
jjxjjp= (jx1jp++jxdjp)1
p (36)
A. Least-square regression
Ordinary least squares linear regression (OLS) is de-
ﬁned as the minimization of the L 2norm of the diﬀerence
between the response yiand the predictor g(x(i);w) =
wTx(i):
min
w2RpjjXw yjj2
2= min
w2RpnX
i=1(wTx(i) yi)2:(37)
In other words, we are looking to ﬁnd the wwhich mini-
mizestheL2error. Geometricallyspeaking, thepredictor
functiong(x(i);w) =wTx(i)deﬁnes a hyperplane in Rp.
Minimizing the least squares error is therefore equivalent
to minimizing the sum of all projections (i.e. residuals)
for all points x(i)to this hyperplane (see Fig. 10). For-
mally, we denote the solution to this problem as ^wLS:
^wLS= arg min
w2RpjjXw yjj2
2; (38)
which, after straightforward diﬀerentiation, leads to
^wLS= (XTX) 1XTy: (39)
Note that we have assumed that XTXis invertible,
which is often the case when np. Formally speak-
ing, ifrank (X) =p, namely, thepredictors X:;1;:::;X:;p
(i.e. columns of X) are linearly independent, then ^wLSis
unique. In the case of rank (X)<p, which happens when
p > n,XTXis singular, implying there are inﬁnitely
many solutions to the least squares problem, Eq. (38).
In this case, one can easily show that if w0is a solution,
w0+is also a solution for any which satisﬁes X=0
(i.e.2null(X)). Having determined the least squares
solution, we can calculate ^y, the best ﬁt of our data X,
as^y=X^wLS=PXy, wherePX=X(XTX) 1XT,
22
c.f. Eq. (37). Geometrically, PXis the projection matrix
which acts on yand projects it onto the column space
ofX, which is spanned by the predictors X:;1;;X:;p
(see FIG. 11). Notice that we found the optimal solu-
tion ^wLSin one shot, without doing any sort of iterative
optimization like that discussed in Section IV.
Rp
FIG. 10 Geometric interpretation of least squares regression.
The regression function gdeﬁnes a hyperplane in Rp(green
solid line, here we have p= 2) while the residual of data point
x(i)(hollowcircles)isitsprojectionontothishyperplane(bar-
ended dashed line).
In Section III we explained that the diﬀerence between
learning and ﬁtting lies in the prediction on “unseen"
data. It is therefore necessary to examine the out-of-
sample error. For a more reﬁned argument on the role
of out-of-sample errors in linear regression, we encour-
age the reader to do the exercises in the corresponding
Jupyter notebooks. The upshot is, following our deﬁni-
tion of Einand Eoutin Section III, the average in-sample
and out-of-sample error can be shown to be
Ein=2
1 p
n
(40)
Eout=2
1 +p
n
; (41)
provided we obtain the least squares solution ^wLSfrom
i.i.d. samples Xandygenerated through y=Xw true+
3. Therefore, we can calculate the average generaliza-
tion error explicitly:
jEin Eoutj= 22p
n: (42)
This imparts an important message: if we have pn
(i.e. high-dimensional data), the generalization error is
extremelylarge, meaningthemodelisnotlearning. Even
when we have pn, we might still not learn well due
to the intrinsic noise 2. One way to ameliorate this
is, as we shall see in the following few sections, to use
regularization. We will mainly focus on two forms of
3This requires that is a noise vector whose elements are i.i.d. of
zero mean and variance 2, and is independent of the samples
X.regularization: the ﬁrst one employs an L2penalty and
is called Ridge regression , while the second uses an L1
penalty and is called LASSO.
span( {X1,··· , Xp})y
ˆyy−ˆy
FIG. 11 The projection matrix PXprojects the response
vectoryonto the column space spanned by the columns of
X,span (fX:;1;;X:;pg)(purplearea),thusformingaﬁtted
vector ^y. The residuals in Eq. (37) are illustrated by the red
vectory ^y.
B. Ridge-Regression
In this section, we study the eﬀect of adding to the
least squares loss function a regularizer deﬁned as the L2
norm of the parameter vector we wish to optimize over.
In other words, we want to solve the following penalized
regression problem called Ridge regression :
^wRidge() = arg min
w2Rp 
jjXw yjj2
2+jjwjj2
2
:(43)
This problem is equivalent to the following constrained
optimization problem
^wRidge(t) = arg min
w2Rp:jjwjj2
2tjjXw yjj2
2:(44)
This means that for any t0and solution ^wRidgein
Eq. (44), there exists a value 0such that ^wRidge
solves Eq. (43), and vice versa4. With this equivalence, it
is obvious that by adding a regularization term, jjwjj2
2,
to our least squares loss function, we are eﬀectively con-
straining the magnitude of the parameter vector learned
from the data.
To see this, let us solve Eq. (43) explicitly. Diﬀerenti-
ating w.r.t.w, we obtain,
^wRidge() = (XTX+Ipp) 1XTy:(45)
4Note that the equivalence between the penalized and the con-
strained (regularized) form of least square optimization does not
always hold. It holds for Ridge and LASSO (introduced later),
but not for best subset selection which is deﬁned by choosing a
L0norm:jjwjj0. In this case, for every  > 0and any ^wBS
that solves the penalized form of best subset selection, there is a
valuet0such that ^wBSalso solves that constrained form of
best subset selection, but the converse is not true.
23
In fact, when Xis orthogonal, one can simplify this ex-
pression further:
^wRidge() =^wLS
1 +;for orthogonal X;(46)
where ^wLSis the least squares solution given by Eq. (39).
This implies that the ridge estimate is merely the least
squares estimate scaled by a factor (1 +) 1.
Can we derive a similar relation between the ﬁtted
vector ^y=X^wRidgeand the prediction made by least
squares linear regression? To answer this, let us do a sin-
gular value decomposition (SVD) on X. Recall that the
SVD of an npmatrixXhas the form
X=UDVT; (47)
whereU2RnpandV2Rppare orthogonal matrices
such that the columns of Uspan the column space of
Xwhile the columns of Vspan the row space of X.
D2Rpp=diag(d1;d2;;dp)isadiagonalmatrixwith
entriesd1d2dp0called the singular values of
X. Note thatXis singular if there is at least one dj= 0.
By writingXin terms of its SVD, one can recast the
Ridge estimator Eq. (45) as
^wRidge =V(D2+I) 1DUTy;(48)
which implies that the Ridge predictor satisﬁes
^yRidge =X^wRidge
=UD(D2+I) 1DUTy
=pX
j=1U:;jd2
j
d2
j+UT
:jy (49)
UUTy (50)
=X^y^yLS; (51)
whereU:;jare the columns of U. Note that in the in-
equality step we assumed 0and used SVD to sim-
plify Eq. (39). By comparing Eq. (49) with Eq. (51), it is
clear that in order to compute the ﬁtted vector ^y, both
Ridge and least squares linear regression have to project
yto the column space of X. The only diﬀerence is that
Ridge regression further shrinks each basis component j
by a factor d2
j=(d2
j+). We encourage the reader to do
the exercises in Notebook 3 to develop further intuition
about how Ridge regression works.
C. LASSO and Sparse Regression
Inthissection, westudytheeﬀectsofaddingan L1reg-
ularization penalty, conventionally called LASSO, which
stands for “least absolute shrinkage and selection opera-
tor”. Concretely, LASSO in the penalized form is deﬁned
by the following regularized regression problem:
^wLASSO () = arg min
w2RpjjXw yjj2
2+jjwjj1:(52)As in Ridge regression, there is another formulation for
LASSO based on constrained optimization, namely,
^wLASSO (t) = arg min
w2Rp:jjwjj1tjjXw yjj2
2:(53)
The equivalence interpretation is the same as in Ridge
regression, namely, for any t0and solution ^wLASSOin
Eq. (53), there is a value 0such that ^wLASSOsolves
Eq. (52), and vice versa. However, to get the analytic
solution of LASSO, we cannot simply take the gradient
of Eq. (52) with respect to w, since theL1-regularizer is
not everywhere diﬀerentiable, in particular at any point
wherewj= 0(see Fig. 13). Nonetheless, LASSO is a
convex problem. Therefore, we can invoke the so-called
“subgradient optimality condition" (Boyd and Vanden-
berghe, 2004; Rockafellar, 2015) in optimization theory
to obtain the solution. To keep the notation simple, we
only show the solution assuming Xis orthogonal:
^wLASSO
j () =sign( ^wLS
j)(j^wLS
jj )+;for orthogonal X;
(54)
where (x)+denotes the positive part of xand ^wLS
jis
thej-th component of least squares solution. In Fig. 12,
we compare the Ridge solution Eq. (46) with LASSO
solution Eq. (54). As we mentioned above, the Ridge
solution is the least squares solution scaled by a factor
of(1 +). Here LASSO does something conventionally
called “soft-thresholding" (see Fig. 12). We encourage
interested readers to work out the exercises in Notebook
3 to explore what this function does.
1 +λλscaled by LASSO Ridge 
λλ
FIG. 12 [Adapted from (Friedman et al., 2001)] Comparing
LASSO and Ridge regression. The black 45 degree line is
the unconstrained estimate for reference. The estimators are
shown by red dashed lines. For LASSO, this corresponds to
the soft-thresholding function Eq. (54) while for Ridge regres-
sion the solution is given by Eq. (46)
How diﬀerent are the solutions found using LASSO
and Ridge regression? In general, LASSO tends to give
sparse solutions, meaning many components of ^wLASSO
are zero. An intuitive justiﬁcation for this result is pro-
vided in Fig. 13. In short, to solve a constrained op-
timization problem with a ﬁxed regularization strength
t0, for example, Eq. (44) and Eq. (53), one ﬁrst carves
outthe“feasibleregion"speciﬁedbytheregularizerinthe
fw1;;wdgspace. This means that a solution ^w0is le-
gitimate only if it falls in this region. Then one proceeds
24
by plotting the contours of the least squares regressors in
an increasing manner until the contour touches the fea-
sible region. The point where this occurs is the solution
to our optimization problem (see Fig. 13 for illustration).
Loosely speaking, since the L1regularizer of LASSO has
sharp protrusions (i.e. vertices) along the axes, and be-
cause the regressor contours are in the shape of ovals (it
is quadratic in w), their intersection tends to occur at
the vertex of the feasibility region, implying the solution
vector will be sparse.
w1w2 w2
w1ˆwˆw
LASSO Ridge tt
FIG. 13 [Adapted from (Friedman et al., 2001)] Illustra-
tion of LASSO (left) and Ridge regression (right). The blue
concentric ovals are the contours of the regression function
while the red shaded regions represent the constraint func-
tions: (left)jw1j+jw2jtand (right) w2
1+w2
2t. In-
tuitively, since the constraint function of LASSO has more
protrusions, the ovals tend to intersect the constraint at the
vertex, as shown on the left. Since the vertices correspond to
parameter vectors wwith only one non-vanishing component,
LASSO tends to give sparse solution.
In Notebook 3, we analyze a Diabetes dataset using
both LASSO and Ridge regression to predict the dia-
betes outcome one year forward (Efron et al., 2004). In
Figs. 14, 15, we show the performance of both methods
and the solutions ^wLASSO (),^wRidge()explicitly. More
details of this dataset and our regression implementation
can be found in Notebook 3.
D. Using Linear Regression to Learn the Ising Hamiltonian
To gain deeper intuition about what kind of physics
problems linear regression allows us to tackle, consider
the following problem of learning the Hamiltonian for
the Ising model. Imagine you are given an ensemble of
random spin conﬁgurations, and assigned to each state
its energy, generated from the 1D Ising model:
H= JLX
j=1SjSj+1 (55)
whereJis the nearest-neighbor spin interaction, and
Sj2 f 1gis a spin variable. Let’s assume the data
was generated with J= 1. You are handed the data
setD= (fSjgL
j=1;Ej)without knowledge of what the
102
101
100101102
0.00.20.40.60.81.0PerformanceTrain (Ridge)
Test (Ridge)
Train (LASSO)
Test (LASSO)FIG. 14 Performance of LASSO and ridge regression on the
diabetes dataset measured by the R2coeﬃcient of determina-
tion. The best possible performance is R2= 1. See Notebook
3.
102
101
100101102
0100200300400500600|wi|Ridge
102
101
100101102
0100200300400500600LASSO
FIG. 15 Regularization parameter aﬀects the weights (fea-
tures) we learned in both Ridge regression (left) and LASSO
regression (right) on the Diabetes dataset. Curves with dif-
ferent colors correspond to diﬀerent wi’s (features). Notice
LASSO, unlike Ridge, sets feature weights to zero leading to
sparsity. See Notebook 3.
numbersEjmean, and the conﬁguration fSjgL
j=1can be
interpreted in many ways: the outcome of coin tosses,
black-and-white pixels of an image, the binary represen-
tation of integers, etc. Your goal is to learn a model that
predictsEjfrom the spin conﬁgurations.
Without any prior knowledge about the origin of the
data set, physics intuition may suggest to look for a spin
model with pairwise interactions between every pair of
variables. That is, we choose the following model class:
Hmodel [Si] = LX
j=1LX
k=1Jj;kSi
jSi
k; (56)
The goal is to determine the interaction matrix Jj;kby
applying linear regression on the data set D. This is a
25
well-deﬁned problem, since the unknown Jj;kenters lin-
early into the deﬁnition of the Hamiltonian. To this end,
we cast the above ansatz into the more familiar linear-
regression form:
Hmodel [Si] =XiJ: (57)
The vectors Xirepresent all two-body interactions
fSi
jSi
kgL
j;k=1, and the index iruns over the samples in
the dataset. To make the analogy complete, we can also
represent the dot product by a single index p=fj;kg,
i.e.XiJ=Xi
pJp. Note that the regression model does
not include the minus sign. In the following, we apply
ordinary least squares, Ridge, and LASSO regression to
the problem, and compare their performance.
10−410−2100102104
λ0.00.20.40.60.81.0R2Train (OLS)
Test (OLS)
Train (Ridge)
Test (Ridge)
Train (LASSO)
Test (LASSO)
FIG. 16 Performance of OLS, Ridge and LASSO regression
on the Ising model as measured by the R2coeﬃcient of de-
termination. Optimal performance is R2= 1.See Notebook
4.
Figure. 16 shows the R2of the three regression models.
R2= 1 Pn
i=1ytrue
i ypred
i2
Pn
i=1ytrue
i 1
nPn
i=1ypred
i2:(58)
Let us make a few remarks: (i) the regularization pa-
rameteraﬀects the Ridge and LASSO regressions at
scales separated by a few orders of magnitude. Notice
that this is diﬀerent for the data considered in the di-
abetes dataset, cf. Fig. 14. Therefore, it is considered
good practice to always check the performance for the
given model and data as a function of . (ii) While
the OLS and Ridge regression test curves are monotonic,
the LASSO test curve is not – suggesting an optimal
LASSO regularization parameter is 10 2. At this
sweet spot, the Ising interaction weights Jcontains only
nearest-neighbor terms (as did the model the data was
generated from).
ChoosingwhethertouseRidgeorLASSOregressionin
this case turns out to be similar to ﬁxing gauge degrees of
freedom. Recall that the uniform nearest-neighbor inter-
actions strength Jj;k=Jwhich we used to generate thedata, was set to unity, J= 1. Moreover, Jj;kwas NOT
deﬁned to be symmetric (we only used the Jj;j+1but
never theJj;j 1elements). Figure. 17 shows the matrix
representation of the learned weights Jj;k. Interestingly,
OLSandRidgeregressionlearnnearlysymmetricweights
J 0:5. This is not surprising, since it amounts to tak-
ingintoaccountboththe Jj;j+1andtheJj;j 1terms, and
the weights are distributed symmetrically between them.
LASSO, on the other hand, tends to break this symme-
try (see matrix elements plots for = 0:01)5. Thus,
we see how diﬀerent regularization schemes can lead to
learning equivalent models but in diﬀerent ‘gauges’. Any
information we have about the symmetry of the unknown
model that generated the data should be reﬂected in the
deﬁnition of the model and the choice of regularization.
In addition to the diabetes dataset in Notebook 3, we
encourage the reader to work out Notebook 4 in which
linear regression is applied to the one-dimensional Ising
model.
E. Convexity of regularizer
In the previous section, we mentioned that the analyt-
ical solution of LASSO can be found by invoking its con-
vexity. In this section, we provide a gentle introduction
to convexity theory and highlight a few properties which
can help us understand the diﬀerences between LASSO
and Ridge regression. First, recall that a set CRnis
calledconvexif for anyx;y2Candt2[0;1],
tx+ (1 t)y2C: (59)
In other words, every line segment joining x;ylies en-
tirely inC. A function f:Rn!Ris called con-
vex if its domain, dom (f), is a convex set, and for any
x;y2dom(f)andt2[0;1]we have
f(tx+ (1 t)y)tf(x) + (1 t)f(y);(60)
That is, the function lies on or below the line segment
joining its evaluation at xandy. This function fis
calledstrictly convex if this inequality holds strictly for
x6=yandt2(0;1). Now, it turns out that for con-
vex functions, any local minimizer is a global minimizer .
Algorithmically, this means that in the optimization pro-
cedure, as long as we are “going down the hill” and agree
to stop when we reach a minimum, then we have hit
the global minimum. In addition to this, there is an
abundance of rich theory regarding convex duality and
optimality, which allow us to understand the solutions
evenbeforesolvingtheproblemitself. Wereferinterested
5Look closer, and you will see that LASSO actually splits the
weights rather equally for the periodic boundary condition ele-
ment at the edges of the anti-diagonal.
26
FIG. 17 Learned interaction matrix Jijfor the Ising model ansatz in Eq. (56) for ordinary least squares (OLS) regression
(left), Ridge regression (middle) and LASSO (right) at diﬀerent regularization strengths . OLS is-independent but is shown
for comparison throughout.See Notebook 4.
27
readers to (Boyd and Vandenberghe, 2004; Rockafellar,
2015).
Now let us examine the two regularizers we introduced
earlier. A close inspection reveals that LASSO and Ridge
regressions are both convex problems but only Ridge re-
gression is a strictly convex problem (assuming  > 0).
From convexity theory, this means that we always have a
unique solution for Ridge but not necessary for LASSO.
In fact, it was recently shown that under mild conditions,
such as demanding general position for columns of X,
the LASSO solution is indeed unique (Tibshirani et al.,
2013). Apart from this theoretical characterization, (Zou
and Hastie, 2005) introduced the notion of Elastic Net to
retain the desirable properties of both LASSO and Ridge
regression, which is now one of the standard tools for
regression analysis and machine learning. We refer to
reader to explore this in Notebook 2.
F. Bayesian formulation of linear regression
InSectionV,wegaveanoverviewofBayesianinference
and phrased it in the context of learning and uncertainty
quantiﬁcation. In this section we formulate least squares
regression from a Bayesian point of view. We shall see
that regularization in learning will emerge naturally as
part of the Bayesian inference procedure.
From the setup of linear regression, the data Dused to
ﬁt the regression model is generated through y=xTw+
. We often assume that is a Gaussian noise with mean
zero and variance 2. To connect linear regression to the
Bayesian framework, we often write the model as
p(yjx;) =N(yj(x);2(x)): (61)
In other words, our regression model is deﬁned by a con-
ditional probability that depends not only on data xbut
on some model parameters . For example, if the mean
is a linear function of xgiven by=xTw, and the
variance is ﬁxed 2(x) =2, then= (w;2).
Instatistics, manyproblemsrelyonestimationofsome
parameters of interest. For example, suppose we are
giventheheightdataof 20juniorstudentsfromaregional
high school, but what we are interested in is the average
height of all high school juniors in the whole county. It
is conceivable that the data we are given are not rep-
resentative of the student population as a whole. It is
therefore necessary to devise a systematic way to pre-
form reliable estimation. Here we present the maximum
likelihood estimation (MLE) , and show that MLE for 
is the one that minimizes the mean squared error (MSE)
used in OLS, see Sec.VI.A.
MLE is deﬁned by maximizing the log-likelihood
w.r.t. the parameters :
^arg max
logp(Dj): (62)Usingtheassumptionthatsamplesarei.i.d., wecanwrite
thelog-likelihood as
l()logp(Dj) =nX
i=1logp(yijx(i);):(63)
Note that the conditional dependence of the response
variableyion the independent variable x(i)in the likeli-
hood function is made explicit since in regression the ob-
served value of data, yi, is predicted based on x(i)using
a model that is assumed to be a probability distribution
that depends on unknown parameter . This distribu-
tion, when endowed with , can, as we hope, potentially
explain our prediction on yi. By deﬁnition, such distri-
bution is the likelihood function we discussed in Sec. V.
Note that this is consistent with the formal statistical
treatment of regression where the goal is to estimate the
conditional expectation of the dependent variable given
the value of the independent variable (sometimes called
the covariate) (Wasserman, 2013). We stress that this
notation does notimplyx(i)is unknown– it is still part
of the observed data!
Using Eq. (61), we get
l() = 1
22nX
i=1
yi wTx(i)2
 n
2log 
22
= 1
22jjXw yjj2
2+const. (64)
By comparing Eq. (38) and Eq. (64), it is clear that per-
forming least squares is the same as maximizing the log-
likelihood of this model.
What about adding regularization? In Section V, we
introduced the maximum a posteriori probability (MAP)
estimate. Here we show that it actually corresponds to
regularized linear regression, where the choice of prior
determines the type of regularization. Recall Bayes’ rule
p(jD)/p(Dj)p(): (65)
Now instead of maximizing the log-likelihood, l() =
logp(Dj), let us maximize the log posterior, logp(jD).
Invoking Eq. (65), the MAP estimator becomes
^MAParg max
logp(Dj) + logp():(66)
In Sec. V.C, we discussed that a common choice for the
prior is a Gaussian distribution. Consider the Gaussian
prior6with zero mean and variance 2, namely,p(w) =
6Indeed, aGaussianprioristhe conjugate prior thatgivesaGaus-
sian posterior. For a given likelihood, conjugacy guarantees the
preservation of prior distribution at the posterior level. For ex-
ample, for a Gaussian (Geometric) likelihood with a Gaussian
(Beta) prior, the posterior distribution is still Gaussian (Beta)
distribution.
28
Q
jN(wjj0;2). Then, we can recast the MAP estimator
into
^MAParg max
2
4 1
22nX
i=1(yi wTx(i))2 1
22nX
j=1w2
j3
5
= arg max

 1
22jjXw yjj2
2 1
22jjwjj2
2
:(67)
Note that we dropped constant terms that do not de-
pend on the maximization parameters . The equiva-
lence between MAP estimation with a Gaussian prior
andRidgeregressionisestablishedbycomparingEq.(67)
and Eq. (44) with 2=2. We relegate the analogous
derivation for LASSO to an exercise in Notebook 3.
G. Recap and a general perspective on regularizers
In this section, we explored least squares linear regres-
sion with and without regularization. We motivated the
needforregularizationduetopoorgeneralization, inpar-
ticular in the “high-dimensional limit" ( pn). Instead
of showing the average in-sample and out-of-sample er-
rors for the regularized problem explicitly, we conducted
numerical experiments in Notebook 3 on the diabetes
dataset and showed that regularization typically leads
to better generalization. Due to the equivalence between
the constrained and penalized form of regularized regres-
sion(inLASSOandRidge, butnotgenerallytrueincases
such as L0penalization), we can regard the regularized
regression problem as an un-regularized problem but on
a constrained set of parameters. Since the size of the al-
lowed parameter space (e.g. w2Rpwhen un-regularized
vs.w2CRpwhen regularized) is roughly a proxy for
model complexity, solving the regularized problem is in
eﬀect solving the un-regularized problem with a smaller
modelcomplexityclass. Thisimpliesthatwe’relesslikely
to overﬁt.
We also showed the connection between using a reg-
ularization function and the use of priors in Bayesian
inference. This connection can be used to develop more
intuition about why regularization implies we are less
likely to overﬁt the data: Let’s say you are a young
Physics student taking a laboratory class where the goal
of the experiment is to measure the behavior of several
diﬀerent pendula and use that to predict the formula
(i.e. model) that determines the period of oscillation.
In your investigation you would probably record many
things (hopefully including the length and mass!) in an
eﬀort to give yourself the best possible chance of deter-
mining the unknown relationship, perhaps writing down
the temperature of the room, any air currents, if the ta-
ble were vibrating, etc. What you have done is create a
high-dimensional dataset for yourself. However you actu-
ally possess an even higher-dimensional dataset than you
probably would admit to yourself. For example you areprobably aware of the time of day, that it is a Wednes-
day, your friend Alice being in attendance, your friend
Bob being absent with a cold, the country in which you
are doing the experiment, and the planet you are on, but
you almost assuredly haven’t written these down in your
notebook. Why not? The reason is because you entered
theclassroomwithstronglyheldpriorbeliefsthatnoneof
those things aﬀect the physics which takes place in that
room. Even of the things you did write down in an eﬀort
to be a careful scientist you probably hold some doubt
as to their importance to your result and what is serving
you here is the intuition that probably only a few things
matter in the physics of pendula. Hence again you are
approaching the experiment with prior beliefs about how
many features you will need to pay attention to in order
to predict what will happen when you swing an unknown
pendulum. This example might seem a bit contrived, but
the point is that we live in a high-dimensional world of
informationandwhilewehavegoodintuitionaboutwhat
to write down in our notebook for well-known problems,
often in the ﬁeld of ML we cannot say with any conﬁ-
dence a priori whatthe small list of things to write down
will be, but we can at least use regularization to help us
enforce that the list not be too long so that we don’t end
up predicting that the period of a pendulum depends on
Bob having a cold on Wednesdays.
Of course, in both LASSO and Ridge regression there
is a parameter involved. In principle, this hyper-
parameter is usually predetermined, which means that
it is not part of the regression process. As we saw in
Fig. 15, our learning performance and solution depends
strongly on , thus it is vital to choose it properly. As
we discussed in Sec. V.C, one approach is to assume an
uninformative prior on the hyper-parameters, p(), and
average the posterior over all choices of following this
distribution. However, this comes with a large computa-
tional cost. Therefore, it is simpler to choose the regular-
ization parameter through some optimization procedure.
We’d like to emphasize that linear regression can be
applied to model non-linear relationship between input
and response. This can be done by replacing the input
xwith some nonlinear function (x). Note that doing
so preserves the linearity as a function of the parame-
tersw, since model is deﬁned by the their inner product
T(x)w. This method is known as basis function expan-
sion(Bishop, 2006; Murphy, 2012).
Recent years have also seen a surge of interest in un-
derstanding generalized linear regression models from a
statistical physics perspective. Much of this research has
focused on understanding high-dimensional linear regres-
sion and compressed sensing (Donoho, 2006) (see (Ad-
vaniet al., 2013; Zdeborová and Krzakala, 2016) for ac-
cessible reviews for physicists). On a technical level,
this research imports and extends the machinery of spin
glass physics (replica method, cavity method, and mes-
sage passing) to analyze high-dimensional linear models
29
1 2 3
(1,0,0,0) (0,1,0,0) (0,0,1,0) (0,0,0,1)0
FIG. 18 Pictorial representation of four data categories la-
beled by the integers 0through 3(above), or by one-hot vec-
tors with binary inputs (below).
(Advani and Ganguli, 2016; Fisher and Mehta, 2015a,b;
Krzakala et al., 2014, 2012a,b; Ramezanali et al., 2015;
Zdeborová and Krzakala, 2016). This is a rich area
of activity at the intersection of physics, computer sci-
ence, information theory, and machine learning and in-
terested readers are encouraged to consult the literature
for further information (see also (Mezard and Montanari,
2009)).
VII. LOGISTIC REGRESSION
So far we have focused on learning from datasets for
which there is a “continuous” output. For example, in
linear regression we were concerned with learning the co-
eﬃcients of a polynomial to predict the response of a
continuous variable yion unseen data based on its inde-
pendent variables xi. However, a wide variety of prob-
lems, such as classiﬁcation, are concerned with outcomes
taking the form of discrete variables (i.e. categories).
For example, we may want to detect if there is a cat or
a dog in an image. Or given a spin conﬁguration of, say,
the2DIsing model, we would like to identify its phase
(e.g. ordered/disordered). In this section, we introduce
logistic regression which deals with binary, dichotomous
outcomes (e.g. True or False, Success or Failure, etc.).
We encourage the reader to use the opportunity to build
their intuition about the inner workings of logistic regres-
sion, as this will prove valuable later on in the study of
modern supervised Deep Learning models (see Sec. IX).
This section is structured as follows: ﬁrst, we deﬁne
logistic regression and derive its corresponding cost func-
tion (the cross entropy) using a Bayesian approach, and
discuss its minimization. Then, we generalize logistic re-
gression to the case of multiple categories which is called
SoftMax regression . We demonstrate how to apply logis-
tic regression using three diﬀerent problems: (i) classify-
ing phases of the 2DIsing model, (ii) learning features
in the SUSY dataset, and (iii) MNIST handwritten digit
classiﬁcation.
Throughout this section, we consider the case where
the dependent variables yi2Zare discrete and only
take values from m= 0;:::;M 1(which enumerate
theMclasses), see Fig. 18. The goal is to predict the
FIG. 19 Classifying data in the simplest case of only two
categories, labeled “noise” and “signal” (or “cats” and “dogs”),
is the subject of Logistic Regression.
output classes from the design matrix X2Rnpmade of
nsamples, each of which bears pfeatures. The primary
goalistoidentifytheclassestowhichnewunseensamples
belong.
Before delving into the details of logistic regression, it
is helpful to consider a slightly simpler classiﬁer: a lin-
ear classiﬁer that categorizes examples using a weighted
linear-combination of the features and an additive oﬀset:
si=xT
iw+b0xT
iw; (68)
where we use the short-hand notation xi= (1;xi)and
w= (b0;w). This function takes values on the entire real
axis. In the case of logistic regression, however, the labels
yiare discrete variables. One simple way to get a discrete
output is to have sign functions that map the output of
a linear regressor to f0;1g,(si) =sign(si) = 1ifsi0
and0otherwise. Indeed, this is commonly known as the
“perceptron” in the machine learning literature.
A. The cross-entropy as a cost function for logistic regression
The perceptron is an example of a “hard classiﬁcation”:
each datapoint is assigned to a category (i.e. yi= 0or
yi= 1). Even though the perceptron is an extremely
simple model, it is favorable in many cases (e.g. when
dealing with noisy data) to have a “soft” classiﬁer that
outputs the probability of a given category. For example,
given xi, the classiﬁer returns the probability of being in
categorym. Onesuchfunctionisthelogistic(orsigmoid)
function:
(s) =1
1 + e s: (69)
Note that 1 (s) =( s), which will be useful shortly.
In many cases, it is favorable to work with a “soft” clas-
siﬁer.
Logistic regression is the canonical example of a soft
classiﬁer. In logistic regression, the probability that a
30
data pointxibelongs to a category yi=f0;1gis given
by
P(yi= 1jxi;) =1
1 + e xT
i;
P(yi= 0jxi;) = 1 P(yi= 1jxi;);(70)
where=ware the weights we wish to learn from the
data. Togainsomeintuitionfortheseequations, consider
a collection of non-interacting two-state systems coupled
to a thermal bath (e.g. a collection of atoms that can be
in two states). Furthermore, denote the state of system
iby a binary variable: yi2 f0;1g. From elementary
statistical mechanics, we know that if the two states have
energies0and1the probability for ﬁnding the system
in a stateyiis:
P(yi= 1) =e 0
e 0+ e 1=1
1 + e ;
P(yi= 1) = 1 P(yi= 0): (71)
Notice that in these expressions, as is often the case in
physics, only energy diﬀerences are observable. If the
diﬀerence in energies between two states is given by =
xT
iw, we recover the expressions for logistic regression.
We shall use this mapping between partition functions
and classiﬁcation to generalize the logistic regressor to
SoftMax regression in Sec. VII.D. Notice that in terms
of the logistic function, we can write
P(yi= 1) =(xT
iw) = 1 P(yi= 0):(72)
We now deﬁne the cost function for logistic regression
using Maximum Likelihood Estimation (MLE). Recall,
thatinMLEwechooseparameterstomaximizetheprob-
ability of seeing the observed data. Consider a dataset
D=f(yi;xi)gwith binary labels yi2f0;1gfrom which
the data points are drawn independently. The likelihood
of observing the data under our model is just:
P(Djw) =nY
i=1
(xT
iw)yi
1 (xT
iw)1 yi
(73)
from which we can readily compute the log-likelihood:
l(w) =nX
i=1yilog(xT
iw) + (1 yi) log
1 (xT
iw)
:
(74)
The maximum likelihood estimator is deﬁned as the set
of parameters that maximize the log-likelihood:
^w= arg max
nX
i=1yilog(xT
iw)+(1 yi) log
1 (xT
iw)
:
(75)Since the cost (error) function is just the negative log-
likelihood, for logistic regression we ﬁnd
C(w) = l(w) (76)
=nX
i=1 yilog(xT
iw) (1 yi) log
1 (xT
iw)
:
The right-hand side in Eq. (76) is known in statistics as
thecross entropy .
Having speciﬁed the cost function for logistic regres-
sion, we note that, just as in linear regression, in practice
we usually supplement the cross-entropy with additional
regularization terms, usually L1andL2regularization
(see Sec. VI for discussion of these regularizers).
B. Minimizing the cross entropy
Thecrossentropyisaconvexfunctionoftheweights w
and, therefore, any local minimizer is a global minimizer.
Minimizing this cost function leads to the following equa-
tion
0=rC(w) =nX
i=1
(xT
iw) yi
xi;(77)
where we made use of the logistic function identity
@z(s) =(s)[1 (s)]. Equation(77)deﬁnesatranscen-
dental equation for w, the solution of which, unlike linear
regression, cannot be written in a closed form. For this
reason, one must use numerical methods such as those
introduced in Sec. IV to solve this optimization problem.
C. Examples of binary classiﬁcation
Let us now show how to use logistic regression in
practice. In this section, we showcase two pedagogi-
cal examples to train a logistic regressor to classify bi-
nary data. Each example comes with a corresponding
Jupyter notebook, see https://physics.bu.edu/ panka-
jm/MLnotebooks.html.
1. Identifying the phases of the 2D Ising model
Thegoalofthisexampleistoshowhowonecanemploy
logistic regression to classify the states of the 2DIsing
model according to their phase of matter.
The Hamiltonian for the classical Ising model is given
by
H= JX
hijiSiSj; S j2f 1g;(78)
where the lattice site indices i;jrun over all nearest
neighbors of a 2Dsquare lattice, and Jis an interaction
31
0 200
10
20
30ordered phase
0 200
10
20
30critical region
0 200
10
20
30disordered phase
FIG. 20 Examples of typical states of the 2DIsing model for three diﬀerent temperatures in the ordered phase ( T=J = 0:75,
left), the critical region ( T=J = 2:25, middle) and the disordered phase ( T=J = 4:0, right). The linear system dimension is
L= 40sites.
energy scale. We adopt periodic boundary conditions.
Onsager proved that this model undergoes a phase tran-
sition in the thermodynamic limit from an ordered fer-
romagnet with all spins aligned to a disordered phase at
the critical temperature Tc=J= 2=log(1 +p
2)2:26.
For any ﬁnite system size, this critical point is smeared
out to a critical region around Tc.
An interesting question to ask is whether one can
trainastatisticalclassiﬁertodistinguishbetweenthetwo
phases of the Ising model. If successful, this can be used
to locate the position of the critical point in more compli-
catedmodelswhereanexactanalyticalsolutionhassofar
remained elusive (Morningstar and Melko, 2017; Zhang
et al., 2017b). In other words, given an Ising state, we
would like to classify whether it belongs to the ordered or
the disordered phase, without any additional information
other than the spin conﬁguration itself. This categorical
machine learning problem is well suited for logistic re-
gression, and will thus consist of recognizing whether a
given state is ordered by looking at its bit conﬁgurations.
Notice that, for the purposes of applying logistic regres-
sion, the2DspinstateoftheIsingmodelwillbeﬂattened
out to a 1D array, so it will not be possible to learn in-
formation about the structure of the contiguous ordered
2D domains [see Fig. 20]. Such information can be incor-
porated using deep convolutional neural networks, see
Section IX.
Tothisend,weconsiderthe 2DIsingmodelona 4040
square lattice, and use Monte-Carlo (MC) sampling to
prepare 104states at every ﬁxed temperature Tout of
a pre-deﬁned set. We furthermore assign a label to each
state according to its phase: 0if the state is disordered,
and1if it is ordered.
It is well-known that near the critical temperature Tc,
theferromagneticcorrelationlengthdiverges,whichleadsto, among other things, critical slowing down of the MC
algorithm. Perhaps identifying the phases is also harder
in the critical region. With this in mind, consider the
following three types of states: ordered ( T=J < 2:0),
near-critical ( 2:0T=J2:5)and disordered ( T=J >
2:5). We use both ordered and disordered states to train
the logistic regressor and, once the supervised training
procedure is complete, we will evaluate the performance
of our classiﬁcation model on unseen ordered, disordered,
and near-critical states.
Here, we deploy the liblinear routine (the default for
Scikit’s logistic regression) and stochastic gradient de-
scent (SGD, see Sec. IV for details) to optimize the logis-
tic regression cost function with L2regularization. We
deﬁne the accuracy of the classiﬁer as the percentage of
correctly classiﬁed data points. Comparing the accuracy
on the training and test data, we can study the degree
of overﬁtting. The ﬁrst thing to notice in Fig. 21 is the
small degree of overﬁtting, as suggested by the training
(blue) and test (red) accuracy curves being very close to
each other. Interestingly, the liblinear minimizer outper-
formsSGDon the training and test data, but not on the
near-critical data for certain values of the regularization
strength. Moreover, similar to the linear regression
examples, we ﬁnd that there exists a sweet spot for the
SGD regularization strength that results in optimal
performance of the logistic regressor, at about 10 1.
We might expect that the diﬃculty of the phase recogni-
tion problem depends on the temperature of the queried
sample. Looking at the states in the near-critical region,
c.f. Fig. 20, it is no longer easy for a trained human eye
to distinguish between the ferromagnetic and the disor-
dered phases close to Tc. Therefore, it is interesting to
also compare the training and test accuracies to the ac-
curacy of the near-critical state predictions. (Recall that
32
10−410−2100102104
λ0.40.50.60.7accuracy
train
test
critical
FIG. 21 Accuracy as a function of the regularization param-
eterin classifying the phases of the 2D Ising model on the
training (blue), test (red), and critical (green) data. The solid
anddashedlinescomparethe‘liblinear’and‘SGD’solvers, re-
spectively.
the model is not trained on near-critical states.) Indeed,
theliblinear accuracy is about 7%smaller for the criti-
cal states (green curves) compared to the test data (red
line).
Finally, it is important to note that all of Scikit’s logis-
tic regression solvers have in-built regularizers. We did
not emphasize the role of the regularizers in this section,
but they are crucial in order to prevent overﬁtting. We
encourage the interested reader to play with the diﬀerent
regularization types and numerical solvers in Notebook 6
and compare model performances.
2. SUSY
In high energy physics experiments, such as the AT-
LAS and CMS detectors at the CERN LHC, one major
hope is the discovery of new particles. To accomplish this
task, physicists attempt to sift through events and clas-
sify them as either a signal of some new physical process
or particle, or as a background event from already un-
derstood Standard Model processes. Unfortunately, we
don’t know for sure what underlying physical process oc-
curred (the only information we have access to are the
ﬁnal state particles). However, we can attempt to de-
ﬁne parts of phase space that will have a high percentage
of signal events. Typically this is done by using a se-
ries of simple requirements on the kinematic quantities
of the ﬁnal state particles, for example having one or
more leptons with large amounts of momentum that are
transverse to the beam line ( pT). Instead, here we will
use logistic regression in an attempt to ﬁnd the relative
probabilitythataneventisfromasignalorabackground
event. Rather than using the kinematic quantities of ﬁ-nal state particles directly, we will use the output of our
logistic regression to deﬁne a part of phase space that is
enriched in signal events (see Jupyter notebookNotebook
5).
The dataset we are using comes from the UC Irvine
ML repository and has been produced using Monte Carlo
simulations to contain events with two leptons (electrons
or muons) (Baldi et al., 2014). Each event has the value
of 18 kinematic variables (“features”). The ﬁrst 8 fea-
tures are direct measurements of ﬁnal state particles, in
this case the pT, pseudo-rapidity , and azimuthal an-
gleof two leptons in the event and the amount of
missing transverse momentum (MET) together with its
azimuthal angle. The last ten features are higher or-
der functions of the ﬁrst 8 features; these features are
derived by physicists to help discriminate between the
two classes. These high-level features can be thought of
as the physicists’ attempt to use non-linear functions to
classify signal and background events, having been de-
veloped with formidable theoretical eﬀort. Here, we will
use only logistic regression to attempt to classify events
as either signal (that is, coming from a SUSY process)
or background (events from some already observed Stan-
dard Model process). Later on in the review, in Sec. IX,
we shall revisit the same problem with the tools of Deep
Learning.
As stated before, we never know the true underlying
process, and hence the goal in these types of analyses
is to ﬁnd regions enriched in signal events. If we ﬁnd
an excess of events above what is expected, we can have
conﬁdence that they are coming from the type of sig-
nal we are searching for. Therefore, the two metrics of
import are the eﬃciency of signal selection, and the back-
ground rejection achieved (also called detection/rejection
rates and similar to recall/precision). Oftentimes, rather
than thinking about just a single working point, perfor-
mance is characterized by Receiver Operator Charecter-
istic curves (ROC curves). These ROC curves plot signal
eﬃciency versus background rejection at various thresh-
olds of some discriminating variable. Here that variable
will be the output signal probability of our logistic re-
gression. Figure 22 shows examples of these outputs for
true signal events (left) and background events (right)
usingL2regularization with a regularization parameter
of10 5.
Notice that while the majority of signal events receive
high probabilities of passing our discriminator and the
majority of background events receive low probabilities,
some signal events look background-like, and some back-
ground events look signal-like to our discriminator. This
is further reason to characterize performance of our selec-
tion in terms of ROC curves. Figure 23 shows examples
of these curves using L2regularization for many diﬀerent
regularization parameters using two diﬀerent ML python
packages, either TensorFlow (top) or Sci-Kit Learn (bot-
tom), whenusingthefullsetof 18inputvariables. Notice
33
FIG. 22 The probability of an event being a classiﬁed as a signal event for true signal events (left, blue) and background events
(right, red).
there is minimal overﬁtting, in part because we trained
on such a large dataset (4.5 million events). More impor-
tantly, however, is the underlying data we are working
with: each input variable is an important feature.
FIG. 23 ROC curves for a variety of regularization parame-
ters with L2 regularization using TensorFlow (top) or Sci-Kit
Learn (bottom).
While ﬁgure 23 shows nice discrimination power be-
tween signal and background events, the adoption of ML
techniques adds complication to any analysis. Given thatwe’ve already come up with a set of discriminating vari-
ables, including higher order ones derived from theories
about SUSY particles, it’s worth reﬂecting on whether
there is utility to the increased sophistication of ML. To
show why we would want to use such a technique, recall
that, even to the learning algorithm, some signal events
and background events look similar. We can illustrate
this directly by looking at a plot comparing the pTspec-
trum of the two highest pTleptons (often referred to as
the leading and sub-leading leptons) for both signal and
background events. Figure 24 shows these two distribu-
tions, and one can see that while somesignal events are
easily distinguished, many live in the same part of phase
space as the background. This eﬀect can also be seen by
looking at ﬁgure 22 where you can see that some signal
events look like background events and vice-versa.
FIG. 24 Comparison of leading vs. sub-leading lepton pTfor
signal (blue) and background events (red). Recall that these
variables have been scaled to have a mean of one.
One could then ask how much discrimination power
is obtained by simply putting diﬀerent requirements on
the input variables rather than using ML techniques. In
order to compare this strategy (often referred to as cut-
34
basedintheﬁeldofHEP)toourregressionresults, diﬀer-
ent ROC curves have been made for each of the following
cases: logistic regression with just the simple kinematic
variables, logistic regression with the full set of variables,
and simply putting a requirement on the leading lepton
pT. Figure 25 shows that there is a clear performance
beneﬁt from using logistic regression. Note also that in
the cut-based approach we have only used one variable
where we could have put requirements on all of them.
While putting more requirements would indeed increase
background rejection, it would also decrease signal eﬃ-
ciency. Hence, the cut-based approach will never yield as
strong discrimination as the logistic regression we have
performed. One other interesting point about these re-
sultsisthatthehigher-ordervariablesnoticeablyhelpthe
ML techniques. In later sections, we will return to this
point to see if more sophisticated techniques can provide
further improvement.
FIG. 25 A comparison of discrimination power from using lo-
gistic regression with only simple kinematic variables (green),
logistic regression using both simple and higher-order kine-
maticvariables(purple), andacut-basedapproachthatvaries
the requirements on the leading lepton pT.
D. Softmax Regression
So far we have focused only on binary classiﬁcation,
in which the labels are dichotomous variables. Here we
generalize logistic regression to multi-class classiﬁcation.
One approach is to treat the label as a vector yi2ZM
2,
namely a binary string of length Mwith only one com-
ponent ofyibeing 1and the rest zero. For example,
yi= (1;0;;0)means data the sample xibelongs to
class 17, cf. Fig. 18. Following the notation in Sec. VII.A,
7For an alternative mathematical description of the categories,
which labels the classes by integers, see http://ufldl.stanford.
edu/wiki/index.php/Softmax_Regression .
0 5 10 15 20 25
0
5
10
15
20
25FIG. 26 An example of an input datapoint from the MNIST
data set. Each datapoint is a 2828-pixel image of a hand-
written digit, with its corresponding label belonging to one
of the 10digits. Each pixel contains a greyscale value repre-
sented by an integer between 0and255.
the probability of xibeing in class m0is given by
P(yim0= 1jxi;fwkgM 1
k=0) =e xT
iwm0
PM 1
m=0e xT
iwm;(79)
whereyim0[yi]m0refers to the m0-th component of vec-
toryi. This is known as the SoftMax function. There-
fore, the likelihood of this M-class classiﬁer is simply
(cf. Sec. VII.A):
P(DjfwkgM 1
k=0) =nY
i=1M 1Y
m=0[P(yim= 1jxi;wm)]yim
[1 P(yim= 1jxi;wm)]1 yim(80)
from which we can deﬁne the cost function in a similar
fashion:
C(w) = nX
i=1M 1X
m=0yimlogP(yim= 1jxi;wm)
+ (1 yim) log (1 P(yim= 1jxi;wm)):(81)
As expected, for M= 1, we recover the cross entropy for
logistic regression, cf. Eq. (76).
E. An Example of SoftMax Classiﬁcation: MNIST Digit
Classiﬁcation
A paradigmatic example of SoftMax regression is to
classify handwritten digits from the MNIST dataset.
35
Yann LeCun and collaborators ﬁrst collected and pro-
cessed 70000handwritten digits, each of which is laid
out on a 2828-pixel grid. Every pixel assumes one
of256grayscale values, interpolating between white and
black. A representative input sample is show in Fig. 26.
Since there are 10categories for the digits 0through 9,
this corresponds to SoftMax regression with M= 10. We
encourage readers to experiment with Notebook 7 to ex-
plore SoftMax regression applied to MNIST. We include
in Fig. 27 the learned weights wk, wherekcorresponds to
class labels (i.e. digits). We shall come back to SoftMax
regression in Sec. IX.
VIII. COMBINING MODELS
One of the most powerful and widely-applied ideas in
modern machine learning is the use of ensemble methods
that combine predictions from multiple, often weak, sta-
tistical models to improve predictive performance (Diet-
terichet al., 2000). Ensemble methods, such as random
forests (Breiman, 2001; Geurts et al., 2006; Ho, 1998),
and boosted gradient trees, such as XGBoost (Chen and
Guestrin, 2016; Friedman, 2001), undergird many of the
winningentriesindatasciencecompetitionssuchasKag-
gle, especially on structured datasets8. Even in the con-
text of neural networks, see Sec. IX, it is common to
combine predictions from multiple neural networks to in-
crease performance on tough image classiﬁcation tasks
(Heet al., 2015; Ioﬀe and Szegedy, 2015).
In this section, we give an overview of ensemble meth-
ods and provide rules of thumb for when and why they
work. On one hand, the idea of training multiple models
and then using a weighted sum of the predictions of the
all these models is very natural. After all, the idea of the
“wisdom of the crowds” can be traced back, at least, to
the writings of Aristotle in Politics. On the other hand,
one can also imagine that the ensemble predictions can
be much worse than the predictions from each of the in-
dividual models that constitute the ensemble, especially
when pooling reinforces weak but correlated deﬁciencies
in each of the individual predictors. Thus, it is impor-
tant to understand when we expect ensemble methods to
work.
In order to do this, we will revisit the bias-variance
trade-oﬀ, discussed in Sec. III, and generalize it to con-
sider an ensemble of classiﬁers. We will show that the
key to determining when ensemble methods work is the
degree of correlation between the models in the ensemble
(Louppe, 2014). Armed with this intuition, we will intro-
duce some of the most widely-used and powerful ensem-
blemethodsincludingbagging(Breiman,1996), boosting
8Neural networks generally perform better than ensemble meth-
ods on unstructured data, images, and audio.(Freundet al., 1999; Freund and Schapire, 1995; Schapire
and Freund, 2012), random forests (Breiman, 2001),
and gradient boosted trees such as XGBoost (Chen and
Guestrin, 2016).
A. Revisiting the Bias-Variance Tradeoﬀ for Ensembles
The bias-variance tradeoﬀ summarizes the fundamen-
tal tension in machine learning between the complexity
of a model and the amount of training data needed to ﬁt
it (see Sec. III). Since data is often limited, in practice
it is frequently useful to use a less complex model with
higher bias – a model whose asymptotic performance is
worse than another model – because it is easier to train
and less sensitive to sampling noise arising from having a
ﬁnite-sized training dataset (i.e. smaller variance). Here,
we will revisit the bias-variance tradeoﬀ in the context
of ensembles, drawing upon the beautiful discussion in
Ref. (Louppe, 2014).
A key property that will emerge from this analysis is
the correlation between models that constitute the en-
semble. The degree of correlation between models9is
important for two distinct reasons. First, holding the en-
semble size ﬁxed, averaging the predictions of correlated
models reduces the variance less than averaging uncor-
related models. Second, in some cases, correlations be-
tween models within an ensemble can result in an in-
creasein bias, oﬀsetting any potential reduction in vari-
ance gained from ensemble averaging. We will discuss
this in the context of bagging below. One of the most
dramatic examples of increased bias from correlations is
the catastrophic predictive failure of almost all derivative
models used by Wall Street during the 2008 ﬁnancial cri-
sis.
1. Bias-Variance Decomposition for Ensembles
We will discuss the bias-variance tradeoﬀ in the con-
text of continuous predictions such as regression. How-
ever, many of the intuitions and ideas discussed here also
carry over to classiﬁcation tasks. Before discussing en-
sembles, let us brieﬂy review the bias-variance tradeoﬀ in
thecontextofasinglemodel. Consideradatasetconsist-
ing of data XL=f(yj;xj);j= 1:::Ng. Let us assume
that the true data is generated from a noisy model
y=f(x) +; (82)
whereis a normally distributed with mean zero and
standard deviation .
9For example, the correlation coeﬃcient between the predictions
made by two randomized models based on the same training set
but with diﬀerent random seeds, see Sec. VIII.A.1 for precise
deﬁnition.
36
Class 0
 Class 1
 Class 2
 Class 3
 Class 4
Class 5
 Class 6
 Class 7
 Class 8
 Class 9classiﬁcation weights vector wjfor digit class j
FIG. 27 Visualization of the weights wjafter training a SoftMax Regression model on the MNIST dataset (see Notebook
7). We emphasize that SoftMax Regression does not have explicit 2Dspatial knowledge; the model learns from data points
ﬂattened out in a one-dimensional array.
Assume that we have a statistical procedure (e.g. least-
squares regression) for forming a predictor ^gL(x)that
gives the prediction of our model for a new data point x
given that we trained the model using a dataset L. This
estimator is chosen by minimizing a cost function which,
for the sake of concreteness, we take to be the squared
error
C(X;g(x)) =X
i(yi ^gL(xi))2: (83)
The datasetLis drawn from some underlying distribu-
tion that describes the data. If we imagine drawing many
datasetsfLjgof the same size as Lfrom this distribu-
tion, we know that the corresponding estimators ^gLj(x)
will diﬀer from each other due to stochastic eﬀects aris-
ing from sampling noise. For this reason, we can view
our estimator ^gL(x)as a random variable and deﬁne an
expectationvalue ELintheusualway. Notethatthesub-
script denotes that the expectation is taken over L. In
practice, ELis computed by by drawing inﬁnitely many
diﬀerent datasets fLjgof the same size, ﬁtting the corre-
sponding estimator, and then averaging the results. We
will also average over diﬀerent instances of the “noise” .
The expectation value over the noise will be denoted by
E.
As discussed in Sec. III, we can decompose the ex-
pected generalization error as
EL;[C(X;g(x))] =Bias2+Var+Noise: (84)where the bias,
Bias2=X
i(f(xi) EL[^gL(xi)])2;(85)
measures the deviation of the expectation value of our es-
timator (i.e. the asymptotic value of our estimator in the
limit of inﬁnite data) from the true value. The variance
Var =X
iEL[(^gL(xi) EL[^gL(xi)])2];(86)
measures how much our estimator ﬂuctuates due to
ﬁnite-sample eﬀects. The noise term
Noise =X
i2
i(87)
is the part of the error due to intrinsic noise in the data
generation process that no statistical estimator can over-
come.
Let us now generalize this to ensembles of estimators.
Given a dataset XLand hyper-parameters that param-
eterize members of our ensemble, we will consider a pro-
cedure that deterministically generates a model ^gL(xi;)
given XLand. We assume that the includes some
random parameters that introduce stochasticity into our
ensemble (e.g. an initial condition for stochastic gradient
descent or a random subset of features or data points
used for training.) Concretely, with a giving dataset L,
one has a learning algorithm Athat generates a model
37
A(;L)based on a deterministic procedure which intro-
duced stochasticity through in its execution on dataset
L. We will be concerned with the expected prediction
error of the aggregate ensemble predictor
^gA
L(xi;fg) =1
MMX
m=1^gL(xi;m):(88)
For future reference, let us deﬁne the mean, variance,
and covariance (i.e. the connected correlation function in
the language of physics), and the normalized correlation
coeﬃcient of a single randomized model ^gL(x;m)as:
EL;m[^gL(x;m)] =L;m(x)
EL;m[^gL(x;m)2] EL;m[^gL(x;)]2=2
L;m(x)
EL;m[^gL(x;m)^gL(x;m0)] E[^gL(x;m)]2=CL;m;m0(x)
(x) =CL;m;m0(x)
2
L;: (89)Note that the expectation EL;m[]is computed over the
joint distribution of Landm. Also, by deﬁnition, we
assumem6=m0inCL;m;m0.
We can now ask about the expected generalization
(out-of-sample) error for the ensemble
EL;;
C(X;^gA
L(x))
=EL;;"X
i(yi ^gA
L(xi;fg))2#
:
(90)
As in the single estimator case, we decompose the error
into a noise term, a bias-term, and a variance term. To
see this, note that
EL;;[C(X;^gA
L(x))] = EL;;"X
i(yi f(xi) +f(xi) ^gA
L(xi;fg))2#
=X
iEL;;[(yi f(xi))2+ (f(xi) ^gA
L(xi;fg))2+ 2(yi f(xi))(f(xi) ^gA
L(xi;fg))]
=X
i2
i+X
iEL;[(f(xi) ^gA
L(xi;fg))2]; (91)
where in the last line we have used the fact that E[yi] =f(xi)to eliminate the last term. We can further decompose
the second term as
EL;[(f(xi) ^gA
L(xi;fg))2] =EL;[(f(xi) EL;[^gA
L(xi;fg)] +EL;[^gA
L(xi;fg)] ^gA
L(xi;fg))2]
=EL;[(f(xi) EL;[^gA
L(xi;fg)])2] +EL;[(EL;[^gA
L(xi;fg)] ^gA
L(xi;fg))2]
+ 2EL;[(EL;[^gA
L(xi;fg)] ^gA
L(xi;fg))(f(xi) EL;[^gA
L(xi;fg)])]
= (f(xi) EL;[^gA
L(xi;fg)])2+EL;[(^gA
L(xi;fg) EL;[^gA
L(xi;fg)])2]
Bias2(xi) +Var(xi); (92)
where we have deﬁned the bias of an aggregate predictor
as
Bias2(x)(f(x) EL;[^gA
L(x;fg)])2(93)
and the variance as
Var(x)EL;[(^gA
L(x;fg) EL;[^gA
L(x;fg)])2]:(94)So far the calculation for ensembles is almost iden-
tical to that of a single estimator. However, since the
aggregate estimator is a sum of estimators, its variance
implicitly depends on the correlations between the indi-
vidual estimators in the ensemble. Using the deﬁnition
of the aggregate estimator Eq. (88) and the deﬁnitions in
Eq. (89), we see that
Var(x) =EL;[(^gA
L(x;fg) EL;[^gA
L(x;fg)])2]
=1
M22
4X
m;m0EL;[^gL(x;m)^gL(x;m0)] M2X
i[L;(x)]23
5
=(x)2
L;+1 (x)
M2
L;: (95)
38
Aggregating different linear 
hypotheses Linear perceptron hypothesis 
FIG. 28 Why combining models? On the left we show that
by combining simple linear hypotheses (grey lines) one can
achieve better and more ﬂexible classiﬁcations (dark line),
which is in stark contrast to the case in which one only uses
a single perceptron hypothesis as shown on the right.
Thislastformulaisthekeytounderstandingthepower
of random ensembles. Notice that by using large ensem-
bles (M!1), we can signiﬁcantly reduce the variance,
and for completely random ensembles where the mod-
els are uncorrelated ( (x) = 0), maximally suppresses
the variance! Thus, using the aggregate predictor beats
down ﬂuctuations due to ﬁnite-sample eﬀects. The key,
as the formula indicates, is to decorrelate the models as
much as possible while still using a very large ensemble.
One can be worried that this comes at the expense of a
very large bias. This turns out not to be the case. When
models in the ensemble are completely random, the bias
of the aggregate predictor is just the expected bias of a
single model
Bias2(x) = (f(x) EL;[^gA
L(x;fg)])2
= (f(x) 1
MMX
m=1EL;[^gL(x;m)])2(96)
= (f(x) L;)2: (97)
Thus, for a random ensemble one can always add more
models without increasing the bias. This observation lies
behind the immense power of random forest methods dis-
cussed below. For other methods, such as bagging, we
will see that the bootstrapping procedure actually does
increase the bias. But in many cases, this increase in bias
is negligible compared to the reduction in variance.
2. Summarizing the Theory and Intuitions behind Ensembles
Before discussing speciﬁc methods, let us brieﬂy sum-
marize why ensembles have proven so successful in many
ML applications. Dietterich (Dietterich et al., 2000)
identiﬁes three distinct shortcomings that are ﬁxed by
ensemble methods: statistical, computational, and rep-
resentational. These are explained in the following dis-
cussion from Ref. (Louppe, 2014):The ﬁrst reason is statistical. When the
learning set is too small, a learning algorithm
can typically ﬁnd several models in the hy-
pothesis spaceHthat all give the same per-
formanceonthetrainingdata. Providedtheir
predictions are uncorrelated, averaging sev-
eral models reduces the risk of choosing the
wrong hypothesis. The second reason is com-
putational. Many learning algorithms rely on
some greedy assumption or local search that
maygetstuckinlocaloptima. Assuch,anen-
semble made of individual models built from
many diﬀerent starting points may provide
a better approximation of the true unknown
function than any of the single models. Fi-
nally, the third reason is representational. In
most cases, for a learning set of ﬁnite size, the
true function cannot be represented by any
of the candidate models in H. By combin-
ing several models in an ensemble, it may be
possible to expand the space of representable
functions and to better model the true func-
tion.
The increase in representational power of ensembles
can be simply visualized. For example, the classiﬁcation
task shown in Fig. 28 reveals that it is more advanta-
geous to combine a group of simple hypotheses (verti-
cal or horizontal lines) than to utilize a single arbitrary
linear classiﬁer. This of course comes with the price of
introducing more parameters to our learning procedure.
But if the problem itself can never be learned through a
simple hypothesis, then there is no reason to avoid ap-
plying a more complex model. Since ensemble methods
reduce the variance and are often easier to train than a
single complex model, they are a powerful way of increas-
ing representational power (also called expressivity in the
ML literature).
Our analysis also gives several intuitions for how we
should construct ensembles. First, we should try to ran-
domize ensemble construction as much as possible to re-
duce the correlations between predictors in the ensemble.
This ensures that our variance will be reduced while min-
imizing an increase in bias due to correlated errors. Sec-
ond, the ensembles will work best for procedures where
the error of the predictor is dominated by the variance
and not the bias. Thus, these methods are especially well
suited for unstable procedures whose results are sensitive
to small changes in the training dataset.
Finally, we note that although the discussion above
was derived in the context of continuous predictors such
as regression, the basic intuition behind using ensembles
applies equally well to classiﬁcation tasks. Using an en-
semble allows one to reduce the variance by averaging the
result of many independent classiﬁers. As with regres-
sion, this procedure works best for unstable predictors
39
for which errors are dominated by variance due to ﬁnite
sampling rather than bias.
B. Bagging
BAGGing, orBootstrapAGGregation, ﬁrstintroduced
by Leo Breiman, is one of the most widely employed and
simplest ensemble-inspired methods (Breiman, 1996).
Imagine we have a very large dataset Lthat we could
partition into Msmaller data sets which we label
fL1;:::;LMg. If each partition is suﬃciently large to
learn a predictor, we can create an ensemble aggregate
predictor composed of predictors trained on each subset
of the data. For continuous predictors like regression,
this is just the average of all the individual predictors:
^gA
L(x) =1
MMX
i=1gLi(x): (98)
For classiﬁcation tasks where each predictor predicts a
class labelj2f1;:::;Jg, this is just a majority vote of
all the predictors,
^gA
L(x) = arg max
jMX
i=1I[gLi(x) =j];(99)
whereI[gLi(x) =j]is an indicator function that is equal
to one ifgLi(x) =jand zero otherwise. From the the-
oretical discussion above, we know that this can signiﬁ-
cantly reduce the variance without increasing the bias.
While simple and intuitive, this form of aggregation
clearlyworksonlywhenwehaveenoughdataineachpar-
titioned setLi. To see this, one can consider the extreme
limit whereLicontains exactly one point. In this case,
thebasehypothesis gLi(x)(e.g.linearregressor)becomes
extremely poor and the procedure above fails. One way
to circumvent this shortcoming is to resort to empir-
ical bootstrapping , a resampling technique in statis-
tics introduced by Efron (Efron, 1979) (see accompany-
ing box and Fig. 29). The idea of empirical bootstrap-
ping is to use sampling with replacement to create new
“bootstrapped” datasets fLBS
1;:::;LBS
Mgfrom our origi-
nal datasetL. These bootstrapped datasets share many
points, but due to the sampling with replacement, are
all somewhat diﬀerent from each other. In the bagging
procedure, we create an aggregate estimator by replac-
ing theMindependent datasets by the Mbootstrapped
estimators:
^gBS
L(x) =1
MMX
i=1gLBS
i(x): (100)
and
^gBS
L(x) = arg max
jMX
i=1I[gLBS
i(x) =j]:(101)This bootstrapping procedure allows us to construct an
approximate ensemble and thus reduce the variance. For
unstable predictors, this can signiﬁcantly improve the
predictive performance. The price we pay for using boot-
strappedtrainingdatasets,asopposedtoreallypartition-
ingthedataset, isanincreaseinthebiasofourbaggedes-
timators. Toseethis, notethatasthenumberofdatasets
Mgoes to inﬁnity, the expectation with respect to the
bootstrapped samples converges to the empirical distri-
bution describing the training data set pL(x)(e.g. a delta
function at each datapoint in L) which in general is dif-
ferent from the true generative distribution for the data
p(x).
In Fig. 30 we demonstrate bagging with a perceptron
(linear classiﬁer) as the base classiﬁer that constitutes
the elements of the ensemble. It is clear that, although
each individual classiﬁer in the ensemble performs poorly
at classiﬁcation, bagging these estimators yields reason-
ably good predictive performance. This raises questions
likewhy bagging works andhow many bootstrap samples
are needed . As mentioned in the discussion above, bag-
ging is eﬀective on “unstable” learning algorithms where
small changes in the training set result in large changes
in predictions (Breiman, 1996). When the procedure is
unstable, the prediction error is dominated by the vari-
ance and one can exploit the aggregation component of
bagging to reduce the prediction error. In contrast, for
a stable procedure the accuracy is limited by the bias
introduced by using bootstrapped datasets. This means
that there is an instability-to-stability transition point
beyond which bagging stops improving our prediction.
40
D={X1,· · ·,Xn}D(1)D(2)D(B) .   .   .   .   .   .   .   .   .   .   . M(B)
n M(2)
n M(1)
n
Training 
samples Bootstrap 
samples Bootstrap 
replications ˆMn(D)
σσ
FIG. 29 Shown here is the procedure of empirical bootstrap-
ping. The goal is to assess the accuracy of a statistical quan-
tity of interest, which in the main text is illustrated as the
sample median ^Mn(D). We start from a given dataset Dand
bootstrapBsizendatasetsD?(1);;D?(B)called the boot-
strap samples. Then we compute the statistical quantity of
interest on these bootstrap samples to get the median M?(k)
n,
fork= 1;;B. These are then used to evaluate the accu-
racy of ^Mn(D)(see also box on Bootstrapping in main text).
It can be shown that in the n!1limit the distribution
ofM?(k)
nwould be a Gaussian centered around ^Mn(D)with
variance2deﬁned by Eq. (102) scales as 1=n.Brief Introduction to Bootstrapping
Suppose we are given a ﬁnite set of ndata points
D=fX1;;Xngas training samples and our
job is to construct measures of conﬁdence for our
sample estimates (e.g. the conﬁdence interval or
mean-squared error of sample median estimator).
To do so, one ﬁrst samples npointswith re-
placement fromDto get a new set D?(1)=
fX?(1)
1;;X?(1)
ng, called a bootstrap sample ,
which possibly contains repetitive elements. Then
we repeat the same procedure to get in total B
such sets:D?(1);;D?(B). The next step is to
use theseBbootstrap sets to get the bootstrap
estimate of the quantity of interest. For example,
letM?(k)
n=Median (D?(k))be the sample median
of bootstrap data D?(k). Then we can construct
the variance of the distribution of bootstrap medi-
ans as :
dVarB(Mn) =1
B 1BX
k=1
M?(k)
n M?
n2
;(102)
where
M?
n=1
BBX
k=1M?(k)
n (103)
is the mean of the median of all bootstrap sam-
ples. Speciﬁcally, Bickel and Freedman (Bickel and
Freedman, 1981) and Singh (Singh, 1981) showed
that in the n!1limit, the distribution of the
bootstrap estimate will be a Gaussian centered
around ^Mn(D) =Median (X1;;Xn)with stan-
dard deviation proportional to 1=pn. This means
that the bootstrap distribution ^M?
n ^Mnapproxi-
mates fairly well the sampling distribution ^Mn M
from which we obtain the training data D. Note
thatMis the median based on which the true dis-
tributionDis generated. In other words, if we plot
the histogram of fM?(k)
ngB
k=1, we will see that in
the largenlimit it can be well ﬁtted by a Gaus-
sian which sharp peaks at ^Mn(D)and vanishing
variance whose deﬁnition is given by Eq. (102) (see
Fig. 29).
C. Boosting
Another powerful and widely used ensemble method is
Boosting. In bagging, the contribution of all predictors
is weighted equally in the bagged (aggregate) predictor.
However, in principle, there are myriad ways to combine
diﬀerent predictors. In some problems one might prefer
to use an autocratic approach that emphasizes the best
predictors, while in others it might be better to opt for
41
−1.0 −0.5 0.0 0.5 1.0
x1−3−2−1012345x2Bagging: o, T rue label: x
FIG. 30 Bagging applied to the perceptron learning
algorithm (PLA) . Training data size n= 500, number of
bootstrap datasets B= 25, each contains 50points. Col-
ors corresponds to diﬀerent classes while the marker indicates
how these points are labelled: cross for true label and circle
for that obtained by bagging. Each gray dashed line indicates
the prediction made, based on every bootstrap set while the
dark dashed black line is the average of these.
more‘democratic’waysasisdoneinbagging. Inallcases,
the idea is to build a strong predictor by combining many
weaker classiﬁers.
In boosting, an ensemble of weak classiﬁers fgk(x)g
is combined into an aggregate, boosted classiﬁer. How-
ever, unlike bagging, each classiﬁer is associated with a
weightkthat indicates how much it contributes to the
aggregate classiﬁer
gA(x) =MX
K=1kgk(x); (104)
whereP
kk= 1. For the reasons outlined above, boost-
ing, like all ensemble methods, works best when we com-
bine simple, high-variance classiﬁers into a more complex
whole.
Here, we focus on “adaptive boosting” or AdaBoost,
ﬁrst proposed by Freund and Schapire in the mid 1990s
(Freundet al., 1999; Freund and Schapire, 1995; Schapire
and Freund, 2012). The basic idea behind AdaBoost,
is to form the aggregate classiﬁer in an iterative pro-
cess. Importantly, at each iteration we reweight the error
function to "highlight" data points where the aggregate
classiﬁer performs poorly (so that in the next round the
procedure put more emphasis on making those right.) In
this way, we can successively ensure that our classiﬁer
has good performance over the whole dataset.
We now discuss the AdaBoost procedure in greater
detail. Suppose that we are given a data set L=
f(xi;yi); i= 1;;Ngwherexi2Xandyi2Y =
f+1; 1g. Our objective is to ﬁnd an optimal hypoth-esis/classiﬁer g:X ! Y to classify the data. Let
H=fg:X !Yg be the family of classiﬁers available
in our ensemble. In the AdaBoost setting, we are con-
cerned with the classiﬁers that perform somehow better
than “tossing a fair coin”. This means that for each clas-
siﬁer, the family Hcan predict yicorrectly at least half
of the time.
We construct the boosted classiﬁer as follows:
•Initializewt=1(xn) = 1=N;n = 1;;N.
•Fort= 1;T(desired termination step), do:
1. Select a hypothesis gt2Hthat minimizes the
weighted error
t=NX
i=1wt(xi)1(gt(xi)6=yi) (105)
2. Lett=1
2ln1 t
t, update the weight for each
dataxnby
wt+1(xn) wt(xn)exp[ tyngt(xn)]
Zt;
whereZt=PN
n=1wt(xn)e tyngt(xn)ensures
all weights add up to unity.
•OutputgA(x) =signPT
t=1tgt(x)
There are many theoretical and empirical studies on the
performance of AdaBoost but they are beyond the scope
of this review. We refer interested readers to the exten-
sive literature on boosting (Freund et al., 1999).
D. Random Forests
x= ( x1, x2, x3)Data 
y={                    } 
x1≥0
x2≥0 x3≥0True
True TrueFalse
False False
FIG. 31 Example of a decision tree. For an input observation
x, its labelyis predicted by traversing it from the root all
the way down the leaves, following branches it satisﬁes.
We now brieﬂy review one of the most widely used and
versatilealgorithmsindatascienceandmachinelearning,
Random Forests (RF). Random Forests is an ensemble
42
method widely deployed for complex classiﬁcation tasks.
A random forest is composed of a family of (randomized)
tree-based classiﬁer decision trees (discussed below). De-
cision trees are high-variance, weak classiﬁers that can
be easily randomized, and as such, are ideally suited for
ensemble-based methods. Below, we give a brief high-
level introduction to these ideas.
A decision tree uses a series of questions to hierarchi-
cally partition the data. Each branch of the decision tree
consists of a question that splits the data into smaller
subsets (e.g. is some feature larger than a given num-
ber? See Fig. 31), with the leaves (end points) of the
tree corresponding to the ultimate partitions of the data.
When using decision trees for classiﬁcation, the goal is
to construct trees such that the partitions are informa-
tive about the class label (see Fig. 31). It is clear that
more complex decision trees lead to ﬁner partitions that
give improved performance on the training set. How-
ever, this generally leads to over-ﬁtting10, limiting the
out-of-sample performance. For this reason, in practice
almost all decision trees use some form of regularization
(e.g. maximum depth for the tree) to control complex-
ity and reduce overﬁtting. Decision trees also have ex-
tremely high variance, and are often extremely sensitive
to many details of the training data. This is not surpris-
ing since decision trees are learned by partitioning the
training data. Therefore, individual decision trees are
weak classiﬁers. However, these same properties make
them ideal for incorporation in an ensemble method.
In order to create an ensemble of decision trees, we
must introduce a randomization procedure. As discussed
above, the power of ensembles to reduce variance only
manifests when randomness reduces correlations between
the classiﬁers within the ensemble. Randomness is usu-
ally introduced into random forests in one of three dis-
tinct ways. The ﬁrst is to use bagging and simply “bag”
the decision trees by training each decision tree on a dif-
ferent bootstrapped dataset (Breiman, 2001). Strictly
speaking, this procedure does not constitute a random
forest but rather a bagged decision tree. The second
procedure is to only use a diﬀerent random subset of
the features at each split in the tree. This “feature
bagging” is the distinguishing characteristic of random
forests (Breiman, 2001; Ho, 1998). Using feature bag-
ging reduces correlations between decision trees that can
arise when only a few features are strongly predictive
of the class label. Finally, extremized random forests
(ERFs) combine ordinary and feature bagging with an
extreme randomization procedure where splitting is done
randomly instead of using optimality criteria (see for de-
tails Refs. (Geurts et al., 2006; Louppe, 2014)). Even
10One extreme limit is an n node tree, with nbeing the number
of data point in the dataset given.
FIG. 32 Classifying Iris dataset with aggregation models for
scikit learn tutorial. This dataset seeks to classify iris ﬂow-
ers into three types (labeled in red, blue, or yellow) based on
a measurement of four features: septal length septal width,
petal length, and petal width. To visualize the decision sur-
face, we trained classiﬁers using only two of the four potential
features (e..g septal length, septal width). Each row corre-
sponds to a diﬀerent subset of two features and the columns
to a Decision Tree with 10-fold CV (ﬁrst column), Random
Forest with 30 trees and 10-fold CV (second column) and
AdaBoost with 30 base hypotheses (third column). Decision
surface learned is highlighted by color shades. See the corre-
sponding tutorial for more details (Pedregosa et al., 2011)
though this reduces the predictive power of each indi-
vidual decision tree, it still often improves the predictive
power of the ensemble because it dramatically reduces
correlations between members and prevents overﬁtting.
Examples of the kind of decision surfaces found by de-
cision trees, random forests, and Adaboost are shown in
Fig.32. Weinvitethereadertocheckoutthecorrespond-
ing scikit-learn tutorial for more details of how these are
implemented in python (Pedregosa et al., 2011).
There are many diﬀerent types of decision trees and
training procedures. A full discussion of decision trees
(and random forests) lies beyond the scope of this review
and we refer readers to the extensive literature on these
topics (Lim et al., 2000; Loh, 2011; Louppe, 2014). Re-
cently, decision trees were applied in high-energy physics
to study to learn non-Higgsable gauge groups (Wang and
Zhang, 2018).
E. Gradient Boosted Trees and XGBoost
Before we turn to applications of these techniques, we
brieﬂy discuss one ﬁnal class of ensemble methods that
has become increasingly popular in the last few years:
Gradient-Boosted Trees (ChenandGuestrin,2016;Fried-
man, 2001). The basic idea of gradient-boosted trees is
to use intuition from boosting and gradient descent (in
particular Newton’s method, see Sec. IV) to construct
43
ensembles of decision trees. Like in boosting, the ensem-
bles are created by iteratively adding new decision trees
to the ensemble. In gradient boosted trees, one critical
component is the a cost function that measures the per-
formance of our ensemble. At each step, we compute
the gradient of the cost function with respect to the pre-
dicted value of the ensemble and add trees that move us
in the direction of the gradient. Of course, this requires
a clever way of mapping gradients to decision trees. We
give a brief overview of how this is done within XGBoost
(Extreme Gradient Boosting), which has recently been
applied, to classify and rank transcription factor binding
in DNA sequences (Li et al., 2018). Below, we follow
closely the XGboost tutorial.
Our starting point is a clever parametrization of de-
cision trees. Here, we use notation where the deci-
sion tree makes continuous predictions (regression trees),
though this can also easily be generalized to classiﬁca-
tion tasks. We parametrize a decision tree j, denoted
asgj(x), withTleaves by two quantities: a function
q(x)that maps each data point to one of the leaves of
the tree,q:x2Rd!f1;2:::;Tgand a weight vector
w2RTthat assigns a predicted value to each leaf. In
other words, the j-th decision tree’s prediction for the
datapoint xiis simply:gj(xi) =wq(xi).
In addition to a parametrization of decision trees, we
also have to specify a cost function which measures pre-
dictions. The prediction of our ensemble for a datapoint
(yi;xi)is given by
^yi=gA(xi) =MX
j=1gj(xi); gj2F (106)
wheregj(xi)is the prediction of the j-th decision tree on
datapoint xi,Mis the number of members of the ensem-
ble, andF=fg(x) =wq(x)gis the space of trees. As
discussed in the context of random trees above, without
regularization, decision trees tend to overﬁt the data by
dividing it into smaller and smaller partitions. For this
reason, our cost function is generally composed of two
terms, a term that measures the goodness of predictions
on each datapoint, li(yi;^yi), which is assumed to be dif-
ferentiable and convex, and for each tree in the ensemble,
a regularization term 
(gj)that does not depend on the
data:
C(X;gA) =NX
i=1l(yi;^yi) +MX
j=1
(gj);(107)
where the index iruns over data points and the index j
runs over decision trees in our ensemble. In XGBoost,
the regularization function is chosen to be

(g) =T+
2jjwjj2
2; (108)
withandregularization parameters that must be
chosen appropriately. Notice that this regularization pe-nalizes both large weights on the leaves (similar to L2-
regularization) and having large partitions with many
leaves.
As in boosting, we form the ensemble iteratively. For
this reason, we deﬁne a family of predictors ^y(t)
ias
^y(t)
i=tX
j=1gj(xi) = ^y(t 1)
i +gt(xi):(109)
Note that by deﬁnition y(M)
i=gA(xi). The central idea
is that for large t, each decision tree is a small pertur-
bation to the predictor (of order 1=T) and hence we can
performaTaylorexpansiononourlossfunctiontosecond
order:
Ct=NX
i=1l(yi;^y(t 1)
i +gt(xi)) + 
(gt)
Ct 1+ Ct; (110)
with
Ct=aigt(xi) +1
2bigt(xi)2+ 
(gt);(111)
where
ai=@^y(t 1)
il(yi;^y(t 1)
i); (112)
bi=@2
^y(t 1)
il(yi;^y(t 1)
i): (113)
We then choose the t-th decision tree gtto minimize Ct.
This is almost identical to how we derived the Newton
method update in the section on gradient descent, see
Sec. IV.
We can actually derive an expression for the param-
eters ofgtthat minimize Ctanalytically. To simplify
notation, it is useful to deﬁne the set of points xithat get
mapped to leaf j:Ij=fi:qt(xi) =jgand the functions
Bj=P
i2IjbiandAj=P
i2Ijai. Notice that in terms
of these quantities, we can write
Ct=TX
j=1[Ajwj+1
2(Bj+)w2
j] +T; (114)
where we made the t-dependence of all parameters im-
plicit. Note that comes from the regularization term,

(gt), through Eq.(108). To ﬁnd the optimal wj, just as
in Newton’s method we take the gradient of the above
expression with respect to wjand set this equal to zero,
to get
wopt
j= Aj
Bj+: (115)
Plugging this expression into Ctgives
Copt
t= 1
2TX
j=1A2
j
Bj++T: (116)
44
Itisclearthat Copt
tmeasuresthein-sampleperformance
ofgtand we should ﬁnd the decision tree that minimizes
this value. In principle, one could enumerate all possi-
ble trees over the data and ﬁnd the tree that minimizes
Copt
t. However, in practice this is impossible. Instead,
an approximate greedy algorithm is run that optimizes
one level of the tree at a time by trying to ﬁnd optimal
splits of the data. This leads to a tree that is a good
local minimum of Copt
twhich is then added to the en-
semble. We emphasize that this is only a very high level
sketch of how the algorithm works. In practice, addi-
tional regularization such as shrinkage(Friedman, 2002)
and feature subsampling(Breiman, 2001; Friedman et al.,
2003) is also used. In addition, there are many numerical
and technical tricks used for the approximate algorithm
and how to ﬁnd splits of the data that give good decision
trees (Chen and Guestrin, 2016).
F. Applications to the Ising model and Supersymmetry
Datasets
We now illustrate some of these ideas using two exam-
ples drawn from physics: (i) classifying the phases of the
spin conﬁgurations of the 2D-Ising model above and be-
lowthecriticaltemperatureusingrandomforestsand(ii)
classifying Monte-Carlo simulations of collision events in
the SUSY dataset as supersymmetric or standard using
an XGBoost implementation of gradient-boosted trees.
Both examples were analyzed in Sec. VII.C using logistic
regression. Here we show that on the Ising dataset, the
RFs perform signiﬁcantly better than logistic regression
models whereas gradient boosted trees seem to yield an
accuracy of about 80%, comparable to published results.
ThetwoaccompanyingJupyternotebooksdiscusspracti-
cal details of implementing these examples and the read-
ers are encouraged to experiment with the notebooks.
The Ising dataset used for classiﬁcation by RFs here
is identical to that used to study logistic regression in
Sec. VII.C. We assign a label to each state according to
itsphase: 0ifthestateisdisordered, and 1ifitisordered.
We divide the dataset into three categories according to
the temperature at which samples are drawn: ordered
(T=J < 2:0), near-critical ( 2:0T=J2:5)and disor-
dered (T=J > 2:5) (see Figure 20). We use the ordered
and disordered states to train a random forest and eval-
uate our learned model on a test set of unseen ordered
and disordered states (test sets). We also ask how well
our RF can predict the phase of samples drawn in the
critical region (i.e. predict whether the temperature of
a critical sample is above or below the critical tempera-
ture). Since our model is never trained on samples in the
critical region, prediction in this region is a test of the
algorithm’s ability to generalize to new regions in phase
space.
The results of ﬁts using RFs to predict phases are
10 20 30 40 50 60 70 80 90 100
Nestimators0.650.700.750.800.850.900.951.00AccuracyTrain (coarse)
Test (coarse)
Critical (coarse)
Train (fine)
Test (fine)
Critical (coarse)
10 20 30 40 50 60 70 80 90 100
Nestimators0102030405060708090Run time (s)
Fine
CoarseFIG.33 UsingRandomForests(RFs)toclassifyIsingPhases.
(Top) Accuracy of RFs for classifying the phase of samples
from the Ising mode for the training set (blue), test set (red),
and critical region (green) using coarse trees with a few leaves
(triangles) and ﬁne decision trees with many leaves (ﬁlled cir-
cles). RFs were trained on samples from ordered and disor-
deredphasesbutwere nottrainedonsamplesfromthecritical
region. (Bottom) The time it takes to train RFs scales lin-
early with the number of estimators in the ensemble. For the
upper panel, note that the train case (blue) overlaps with the
test case (red). Here ‘ﬁne’ and ‘coarse’ refer to trees with 2
and 10,000 leaves, respectively. For implementation details,
see Jupyter notebooks 9
shown in Figure 33. We used two types of RF classiﬁers,
one where the ensemble consists of coarse decision trees
with a few leaves and another with ﬁner decision trees
with many leaves (see corresponding notebook). RFs
have extremely high accuracy on the training and test
sets (over 99%) for both coarse and ﬁne trees. How-
ever, notice that the RF consisting of coarse trees per-
formextremelypoorlyonsamplesfromthecriticalregion
whereas the RF with ﬁne trees classiﬁes critical samples
with an accuracy of nearly 85%. Interestingly, and unlike
with logistic regression, this performance in the critical
region requires almost no parameter tuning. This is be-
cause, as discussed above, RFs are largely immune to
overﬁtting problems even as the number of estimators in
theensemblebecomeslarge. Increasingthenumberofes-
timators in the ensemble does increase performance but
at a large cost in computational time (Fig. 33 bottom).
In the second application of ensemble methods to
45
0 100 200 300 400 500
F scoreM_Delta_RM_TR_2lepton 2 phiMT2lepton 1 phiRM_RS_Rlepton 2 pTlepton 1 pTcos(theta_r1)missing energy philepton 1 etalepton 2 etadPhi_r_bMET_relmissing energy magnitudeaxial METFeatures
273283290314314319331346348351352361396416443461505517Feature importance
FIG. 34 Feature Importance Scores in SUSY dataset from
applying XGBoost to 100;000samples. See Notebook 10 for
more details.
physics-related datasets, we used the XGBoost imple-
mentation of gradient boosted trees to classify Monte-
Carlo collisions from the SUSY dataset. With default
parameters using a small subset of the data ( 100;000out
of the full 5;000;000samples), we were able to achieve
a classiﬁcation accuracy of about 79%, which could be
improved to nearly 80% after some ﬁne-tuning (see ac-
companying notebook). This is comparable to published
results (Baldi et al., 2014) and those obtained using lo-
gistic regression in earlier chapters. One nice feature of
ensemble methods such as XGBoost is that they auto-
matically allow us to calculate feature scores (Fscores)
that rank the importance of various features for clas-
siﬁcation. The higher the Fscore, the more important
the feature for classiﬁcation. Figure 34 shows the feature
scores from our XGBoost algorithm for the production of
electrically-chargedsupersymmetricparticles( )which
decay toWbosons and an electrically neutral supersym-
metric particle 0, which is invisible to the detector. The
features are a mix of eight directly measurable quanti-
ties from the detector, as well as ten hand crafted fea-
tures chosen using physics knowledge. Consistent with
the physics of these supersymmetric decays in the lepton
channel, we ﬁnd that the most informative features for
classiﬁcation are the missing transverse energy along the
vector deﬁned by the charged leptons (Axial MET) and
the missing energy magnitude due to 0.
IX. AN INTRODUCTION TO FEED-FORWARD DEEP
NEURAL NETWORKS (DNNS)
Over the last decade, neural networks have emerged
as the one of most powerful and widely-used supervised
learning techniques. Deep Neural Networks (DNNs)have
a long history (Bishop, 1995b; Schmidhuber, 2015), but
re-emerged to prominence after a rebranding as “DeepLearning” in the mid 2000s (Hinton et al., 2006; Hinton
and Salakhutdinov, 2006). DNNs truly caught the atten-
tion of the wider machine learning community and indus-
try in 2012 when Alex Krizhevsky, Ilya Sutskever, and
Geoﬀ Hinton used a GPU-based DNN model (AlexNet)
to lower the error rate on the ImageNet Large Scale
Visual Recognition Challenge (ILSVRC) by an incred-
ible twelve percent from 28% to 16% (Krizhevsky et al.,
2012). Just three years later, a machine learning group
from Microsoft achieved an error of 3.57% using an ultra-
deep residual neural network (ResNet) with 152 layers
(Heet al., 2016)! Since then, DNNs have become the
workhorse technique for many image and speech recogni-
tion based machine learning tasks. The large-scale indus-
trial deployment of DNNs has given rise to a number of
high-level libraries and packages (Caﬀe, Keras, Pytorch,
TensorFlow, etc.) that make it easy to quickly code and
deploy DNNs.
Conceptually, it is helpful to divide neural networks
into four categories: (i) general purpose neural net-
works for supervised learning, (ii) neural networks de-
signed speciﬁcally for image processing, the most promi-
nent example of this class being Convolutional Neural
Networks (CNNs), (iii) neural networks for sequential
data such as Recurrent Neural Networks (RNNs), and
(iv) neural networks for unsupervised learning such as
Deep Boltzmann Machines. Here, we will limit our dis-
cussions to the ﬁrst two categories (unsupervised learn-
ing is discussed later in the review). Though increas-
ingly important for many applications such as audio and
speech recognition, for the sake of brevity, we omit a dis-
cussion of sequential data and RNNs from this review.
For an introduction to RNNs and LSTM networks see
Chris Olah’s blog, https://colah.github.io/posts/2015-
08-Understanding-LSTMs/, and Chapter 13 of (Bishop,
2006) as well as the introduction to RNNs in Chapter 10
of (Goodfellow et al., 2016) for sequential data.
Due to the number of recent books on deep learning
(see for example Michael Nielsen’s introductory online
book (Nielsen, 2015) and the more advanced (Goodfel-
lowet al., 2016)), the goal of this section is to give a
high-level introduction to the basic ideas behind DNNs,
and provide some practical knowledge for coding simple
neural nets for supervised learning tasks (see the accom-
panying Notebooks). This section assumes the reader
is familiar with the basic concepts introduced in earlier
sections on logistic and linear regression. Throughout,
we strive to provide intuition behind the inner workings
of DNNs, as well as highlight limitations of present-day
algorithms.
The inﬂux of corporate and industrial interests has
rapidly transformed the ﬁeld in the last few years. This
massive inﬂux of money and researchers has given rise to
new dogmas and best practices that change rapidly. As
with most intellectual ﬁelds experiencing rapid expan-
sion, many commonly accepted heuristics many turn out
46
not to be as powerful as thought (Wilson et al., 2017),
and widely held beliefs not as universal as once imagined
(Leeet al., 2017; Zhang et al., 2016). This is especially
true in modern neural networks where results are largely
empirical and heuristic and lack the ﬁrm footing of many
earlier machine learning methods. For this reason, in
this review we have chosen to emphasize tried and true
fundamentals, while pointing out what, from our current
vantage point, seem like promising new techniques. The
ﬁeld is rapidly evolving and readers are urged to read
papers and to implement these algorithms themselves in
order to gain a deep appreciation for the incredible power
of modern neural networks, especially in the context of
image, speech, and natural language processing, as well
as limitations of the current methods.
In physics, DNNs and CNNs have already found
numerous applications. In statistical physics, they
have been applied to detect phase transitions in 2D
Ising (Tanaka and Tomiya, 2017a) and Potts (Li
et al., 2017) models, lattice gauge theories (Wetzel and
Scherzer, 2017), and diﬀerent phases of polymers (Wei
et al.,2017). Ithasalsobeenshownthatdeepneuralnet-
works can be used to learn free-energy landscapes (Sidky
and Whitmer, 2017). At the same time, methods from
statistical physics have been applied to the ﬁeld of deep
learning to study the thermodynamic eﬃciency of learn-
ing rules (Goldt and Seifert, 2017), to explore the hy-
pothesis space that DNNs span, make analogies between
training DNNs and spin glasses (Baity-Jesi et al., 2018;
Baldassi et al., 2017), and to characterize phase transi-
tions with respect to network topology in terms of er-
rors (Li and Saad, 2017). In relativistic hydrodynam-
ics, deep learning has been shown to capture features
of non-linear evolution and has the potential to accel-
erate numerical simulations (Huang et al., 2018), while
in mechanics CNNs have been used to predict eigenval-
ues of photonic crystals (Finol et al., 2018). Deep CNNs
were employed in lensing reconstruction of the cosmic
microwave background (Caldeira et al., 2018). Recently,
DNNs have been used to improve the eﬃciency of Monte-
Carlo algorithms (Shen et al., 2018).
Deep learning has also found interesting applications
in quantum physics. Various quantum phase transi-
tions (Arai et al., 2017; Broecker et al., 2017; Iakovlev
et al., 2018; van Nieuwenburg et al., 2017b; Suchs-
land and Wessel, 2018) can be detected and studied
using DNNs and CNNs, including the transverse-ﬁeld
Ising model (Ohtsuki and Ohtsuki, 2017), topological
phases (Yoshioka et al., 2017; Zhang et al., 2017a,b)
and non-invasive topological quality control (Caio et al.,
2019). DNNs found applications even in non-equilibrium
many-bodylocalization(vanNieuwenburg et al.,2017a,b;
Schindler et al., 2017; Venderley et al., 2017), and the
characterization of photoexcited quantum states (Shinjo
et al., 2019). Experimentally, DNNs were recently em-
ployed in cold atoms to identify critical points (Remet al.,2018). RepresentingquantumstatesasDNNs(Gao
et al., 2017; Gao and Duan, 2017; Levine et al., 2017;
Saito and Kato, 2017) and quantum state tomogra-
phy (Torlai et al., 2018) are among some of the impres-
sive achievements to reveal the potential of deep learn-
ing to facilitate the study of quantum systems. Machine
learning techniques involving neural networks were also
used to study quantum and fault-tolerant error correc-
tion (Baireuther et al., 2017; Breuckmann and Ni, 2017;
ChamberlandandRonagh,2018;Davaasuren et al.,2018;
Krastanov and Jiang, 2017; Maskara et al., 2018), es-
timate rates of coherent and incoherent quantum pro-
cesses (Greplova et al., 2017), to obtain spectra of 1=f-
noise in spin-qubit devices (Zhang and Wang, 2018), and
the recognition of state and charge conﬁgurations and
auto-tuning in quantum dots (Kalantre et al., 2017). In
quantum information theory, it has been shown that one
can perform gate decompositions with the help of neural
nets (Swaddle et al., 2017). In lattice quantum chromo-
dynamics, DNNs have been used to learn action param-
eters in regions of parameter space where principal com-
ponent analysis fails (Shanahan et al., 2018). CNNs were
applied to data from a high-energy experiment to iden-
tify particle interactions in sampling calorimeters used
commonly in neutrino physics (Aurisano et al., 2016).
Last but not least, DNNs also found place in the study
of quantum control (Yang et al., 2017), and in scattering
theory to learn the s-wave scattering length (Wu et al.,
2018) of potentials.
A. Neural Network Basics
Neural networks (also called neural nets) are neural-
inspired nonlinear models for supervised learning. As
we will see, neural nets can be viewed as natural, more
powerful extensions of supervised learning methods such
as linear and logistic regression and soft-max methods.
1. The basic building block: neurons
The basic unit of a neural net is a stylized “neu-
ron”ithat takes a vector of dinput features x=
(x1;x2;:::;xd)and produces a scalar output ai(x). A
neural network consists of many such neurons stacked
into layers, with the output of one layer serving as the
input for the next (see Figure 35). The ﬁrst layer in the
neural net is called the input layer, the middle layers are
often called “hidden layers”, and the ﬁnal layer is called
the output layer.
The exact function aivaries depending on the type of
non-linearity used in the neural network. However, in
essentially all cases aican be decomposed into a linear
operationthatweightstherelativeimportanceofthevar-
ious inputs, and a non-linear transformation i(z)which
47
input w xlinear nonlinearity
outputx1
x2
x3w1
w2
w3
{{{
input
layerhidden
layers
output
layerBA
.+ b
FIG. 35Basic architecture of neural networks. (A)
The basic components of a neural network are stylized neu-
rons consisting of a linear transformation that weights the
importance of various inputs, followed by a non-linear activa-
tion function. (b) Neurons are arranged into layers with the
output of one layer serving as the input to the next layer.
is usually the same for all neurons. The linear trans-
formation in almost all neural networks takes the form
of a dot product with a set of neuron-speciﬁc weights
w(i)= (w(i)
1;w(i)
2;:::;w(i)
d)followed by re-centering with
a neuron-speciﬁc bias b(i):
z(i)=w(i)x+b(i)=xTw(i);(117)
where x= (1;x)andw(i)= (b(i);w(i)). In terms of z(i)
and the non-linear function i(z), we can write the full
input-output function as
ai(x) =i(z(i)); (118)
see Figure 35.
Historically in the neural network literature, common
choices of nonlinearities included step-functions (percep-
trons), sigmoids (i.e. Fermi functions), and the hyper-
bolic tangent. More recently, it has become more com-
mon to use rectiﬁed linear units (ReLUs), leaky recti-
ﬁed linear units (leaky ReLUs), and exponential linear
units (ELUs) (see Figure 36). Diﬀerent choices of non-
linearities lead to diﬀerent computational and training
properties for neurons. The underlying reason for this is
that we train neural nets using gradient descent based
methods, see Sec. IV, that require us to take derivatives
of the neural input-output function with respect to the
weightsw(i)and the bias b(i).
Notice that the derivatives of the aforementioned non-
linearities(z)have very diﬀerent properties. The
derivative of the perceptron is zero everywhere except
where the input is zero. This discontinuous behavior
makes it impossible to train perceptrons using gradientdescent. For this reason, until recently the most pop-
ular choice of non-linearity was the tanh function or a
sigmoid/Fermi function. However, this choice of non-
linearity has a major drawback. When the input weights
become large, as they often do in training, the activation
function saturates and the derivative of the output with
respect to the weights tends to zero since @=@z!0
forz1. Such “vanishing gradients” are a feature of
any saturating activation function (top row of Fig. 36),
making it harder to train deep networks. In contrast, for
a non-saturating activation function such as ReLUs or
ELUs, the gradients stay ﬁnite even for large inputs.
2. Layering neurons to build deep networks: network
architecture.
Thebasicideaofallneuralnetworksistolayerneurons
in a hierarchical fashion, the general structure of which is
known as the network architecture (see Fig. 35). In the
simplest feed-forward networks, each neuron in the in-
put layer of the neurons takes the inputs xand produces
an outputai(x)that depends on its current weights, see
Eq.(118). Theoutputsoftheinputlayerarethentreated
as the inputs to the next hidden layer . This is usually
repeated several times until one reaches the top or output
layer. The output layer is almost always a simple clas-
siﬁer of the form discussed in earlier sections: a logistic
regression or soft-max function in the case of categorical
data (i.e. discrete labels) or a linear regression layer in
the case of continuous outputs. Thus, the whole neural
network can be thought of as a complicated nonlinear
transformation of the inputs xinto an output ^ythat de-
pends on the weights and biases of all the neurons in the
input, hidden, and output layers.
The use of hidden layers greatly expands the represen-
tationalpowerofaneuralnetwhencomparedwithasim-
ple soft-max or linear regression network. Perhaps, the
most formal expression of the increased representational
power of neural networks (also called the expressivity) is
the universal approximation theorem which states that a
neural network with a single hidden layer can approxi-
mate any continuous, multi-input/multi-output function
with arbitrary accuracy. The reader is strongly urged
to read the beautiful graphical proof of the theorem in
Chapter 4 of Nielsen’s free online book (Nielsen, 2015).
The basic idea behind the proof is that hidden neurons
allow neural networks to generate step functions with ar-
bitrary oﬀsets and heights. These can then be added
together to approximate arbitrary functions. The proof
also makes clear that the more complicated a function,
the more hidden units (and free parameters) are needed
to approximate it. Hence, the applicability of the ap-
proximation theorem to practical situations should not
be overemphasized. In condensed matter physics, a good
analogy are matrix product states, which can approxi-
48
-5 0 5-101Perceptron
-5 0 5-101Sigmoid
-5 0 5-101Tanh
-5 0 50246ReLU
-5 0 50246Leaky ReLU
-5 0 50246ELU
FIG.36Possiblenon-linearactivationfunctionsforneurons. InmodernDNNs, ithasbecomecommontousenon-linear
functions that do not saturate for large inputs (bottom row) rather than saturating functions (top row).
mate any quantum many-body state to an arbitrary ac-
curacy, provided the bond dimension can be increased
arbitrarily – a severe requirement not met in any useful
practical implementation of the theory.
Modern neural networks generally contain multiple
hidden layers (hence the “deep” in deep learning). There
are many ideas of why such deep architectures are fa-
vorable for learning. Increasing the number of layers in-
creasesthenumberofparametersandhencetherepresen-
tational power of neural networks. Indeed, recent numer-
ical experiments suggests that as long as the number of
parameters is larger than the number of data points, cer-
tain classes of neural networks can ﬁt arbitrarily labeled
random noise samples (Zhang et al., 2016). This suggests
thatlargeneuralnetworksofthekindusedinpracticecan
express highly complex functions. Adding hidden layers
isalsothoughttoallowneuralnetstolearnmorecomplex
features from the data. Work on convolutional networks
suggeststhattheﬁrstfewlayersofaneuralnetworklearn
simple, “low-level” features that are then combined into
higher-level, more abstract features in the deeper layers.
Other works suggest that it is computationally and al-
gorithmically easier to train deep networks rather than
shallow, wider nets, though this is still an area of major
controversy and active research (Mhaskar et al., 2016).
Choosing the exact network architecture for a neural
network remains an art that requires extensive numer-
ical experimentation and intuition, and is often times
problem-speciﬁc. Both the number of hidden layers and
the number of neurons in each layer can aﬀect the per-
formance of a neural network. There seems to be no
single recipe for the right architecture for a neural netthat works best. However, a general rule of thumb that
seems to be emerging is that the number of parameters in
the neural net should be large enough to prevent under-
ﬁtting (see theoretical discussion in (Advani and Saxe,
2017)).
Empirically, the best architecture for a problem de-
pends on the task, the amount and type of data that is
available, and the computational resources at one’s dis-
posal. Certain architectures are easier to train, while
others might be better at capturing complicated depen-
dencies in the data and learning relevant input features.
Finally, there have been numerous works that move be-
yond the simple deep, feed-forward neural network ar-
chitectures discussed here. For example, modern neural
networks for image segmentation often incorporate “skip
connections” that skip layers of the neural network (He
et al., 2016). This allows information to directly propa-
gate to a hidden or output layer, bypassing intermediate
layers and often improving performance.
B. Training deep networks
In the previous section, we introduced the basic ar-
chitecture for neural networks. Here we discuss how to
eﬃciently train large neural networks. Luckily, the basic
procedure for training neural nets is the same as we used
for training simpler supervised learning algorithms, such
as logistic and linear regression: construct a cost/loss
function and then use gradient descent to minimize the
cost function and ﬁnd the optimal weights and biases.
Neural networks diﬀer from these simpler supervised pro-
49
cedures in that generally they contain multiple hidden
layers that make taking the gradient computationally
more diﬃcult. We will return to this in Sec. IX.C which
discusses the “backpropagation” algorithm for computing
gradients.
Like all supervised learning procedures, the ﬁrst thing
one must do to train a neural network is to specify a
loss function. Given a data point (xi;yi),xi2Rd+1,
the neural network makes a prediction ^yi(w), where w
are the parameters of the neural network. Recall that
in most cases, the top output layer of our neural net
is either a continuous predictor or a classiﬁer that makes
discrete (categorical) predictions. Depending on whether
one wants to make continuous or categorical predictions,
one must utilize a diﬀerent kind of loss function.
For continuous data, the loss functions that are com-
monlyusedtotrainneuralnetworksareidenticaltothose
used in linear regression, and include the mean squared
error
E(w) =1
nnX
i=1(yi ^yi(w))2; (119)
wherenis the number of data points, and the mean-
absolute error (i.e. L1norm)
E(w) =1
nX
ijyi ^yi(w)j: (120)
Thefullcostfunctionoftenincludesadditionaltermsthat
implement regularization (e.g. L1orL2regularizers), see
Sec. VI.
For categorical data, the most commonly used loss
function is the cross-entropy (Eq. (76) and Eq. (81)),
since the output layer is often taken to be a logistic clas-
siﬁer for binary data with two types of labels, or a soft-
max classiﬁer if there are more than two types of labels.
The cross-entropy was already discussed extensively in
earlier sections on logistic regression and soft-max classi-
ﬁers, see Sec. VII. Recall that for classiﬁcation of binary
data, the output of the top layer of the neural network is
the probability ^yi(w) =p(yi= 1jxi;w)that data point
iis predicted to be in category 1. The cross-entropy be-
tween the true labels yi2f0;1gand the predictions is
given by
E(w) = nX
i=1yilog ^yi(w) + (1 yi) log [1 ^yi(w)]:
More generally, for categorical data, ycan take on M
values so that y2f0;1;:::;M 1g. For each datapoint
i, deﬁne a vector yimcalled a ‘one-hot’ vector, such that
yim=(
1;ifyi=m
0;otherwise:(121)
We can also deﬁne the probability that the neural net-
workassignsadatapointtocategory m:^yim(w) =p(yi=mjxi;w). Then, the categorical cross-entropy is deﬁned
as
E(w) = nX
i=1M 1X
m=0yimlog ^yim(w)
+(1 yim) log [1 ^yim(w)]:(122)
As in linear and logistic regression, this loss function is
often supplemented by additional terms that implement
regularization.
Having deﬁned an architecture and a cost function, we
must now train the model. Similar to other supervised
learning methods, we make use of gradient descent-based
methods to optimize the cost function. Recall that the
basic idea of gradient descent is to update the parame-
terswto move in the direction of the gradient of the cost
functionrwE(w). In Sec. IV, we discussed numerous
optimizers that implement variations of stochastic gra-
dient descent (SGD, Nesterov, RMSProp, Adam, etc.)
Most modern neural network packages, such as Keras,
allow the user to specify which of these optimizers they
would like to use in order to train the neural network.
Depending on the architecture, data, and computational
resources, diﬀerent optimizers may work better on the
problem, though vanilla SGD is a good ﬁrst choice.
Finally, we note that unlike in linear and logistic re-
gression, calculating the gradients for a neural network
requires a specialized algorithm, called Backpropagation
(often abbreviated backprop) which forms the heart of
any neural network training procedure. Backpropaga-
tion has been discovered multiple times independently
but was popularized for modern neural networks in 1985
(Rumelhart and Zipser, 1985). We will turn to the back-
propagation algorithm in the next section. Before read-
ing it, the reader is strongly encouraged to play with
Notebook 11 in order to gain some intuition about how
to build a DNN in practice using the high-level Keras
Python package. Notebook 11 discusses a simple exam-
plewherewebuildafeed-forwarddeepneuralnetworkfor
classifying hand-written digits from the MNIST dataset.
Figures 37 and 38 show the accuracy and the loss as a
function of the training episodes.
C. The Backpropagation algorithm
In the last section, we saw how to deploy a high-level
package, Keras, to design and train a simple neural net-
work. This training procedure requires us to be able to
calculate the derivative of the cost function with respect
to all the parameters of the neural network (the weights
and biases of all the neurons in the input, hidden, and
visible layers). A brute force calculation is out of the
question since it requires us to calculate as many gradi-
ents as parameters at each step of the gradient descent.
The backpropagation algorithm (Rumelhart and Zipser,
50
0 2 4 6 8
epoch0.8500.8750.9000.9250.9500.975model accuracytrain
test
FIG.37 ModelaccuracyofaDNNtostudytheMNISTprob-
lem as a function of the training epochs (see Notebook 11).
Besides the input and output layers, the DNN has four layers
of size (100,400,400,50) with diﬀerent nonlinearities (z).
0 2 4 6 8
epoch0.10.20.30.40.5model losstrain
test
FIG.38 ModellossofaDNNtostudytheMNISTproblemas
a function of the training epochs (see Notebook 11). Besides
the input and output layers, the DNN has four layers of size
(100,400,400,50) with diﬀerent nonlinearities (z).
1985)isacleverprocedurethatexploitsthelayeredstruc-
ture of neural networks to more eﬃciently compute gra-
dients (for a more detailed discussion with Python code
examples see Chapter 2 of (Nielsen, 2015)).
1. Deriving and implementing the backpropagation equations
At its core, backpropagation is simply the ordinary
chain rule for partial diﬀerentiation, and can be summa-
rized using four equations. In order to see this, we must
ﬁrst establish some useful notation. We will assume that
there areLlayers in our network with l= 1;:::;Lin-
dexing the layer. Denote by wl
jkthe weight for the con-nection from the k-th neuron in layer l 1to thej-th
neuron in layer l. We denote the bias of this neuron by
bl
j. By construction, in a feed-forward neural network the
activational
jof thej-th neuron in the l-th layer can be
related to the activities of the neurons in the layer l 1
by the equation
al
j= X
kwl
jkal 1
k+bl
j!
=(zl
j);(123)
where we have deﬁned the linear weighted sum
zl
j=X
kwl
jkal 1
k+bl
j: (124)
By deﬁnition, the cost function Edepends directly on
theactivitiesoftheoutputlayer aL
j. Itofcoursealso indi-
rectlydependsonalltheactivitiesofneuronsinlowerlay-
ers in the neural network through iteration of Eq. (123).
Let us deﬁne the error L
jof thej-th neuron in the L-th
layer as the change in cost function with respect to the
weighted input zL
j
L
j=@E
@zL
j: (125)
This deﬁnition is the ﬁrst of the four backpropagation
equations.
We can analogously deﬁne the error of neuron jin
layerl,l
j, as the change in the cost function w.r.t. the
weighted input zl
j:
l
j=@E
@zl
j=@E
@al
j0(zl
j); (I)
where0(x)denotes the derivative of the non-linearity
()with respect to its input evaluated at x. Notice
that the error function l
jcan also be interpreted as the
partial derivative of the cost function with respect to the
biasbl
j, since
l
j=@E
@zl
j=@E
@bl
j@bl
j
@zl
j=@E
@bl
j; (II)
where in the last line we have used the fact that
@bl
j=@zl
j= 1, cf. Eq. (124). This is the second of the
four backpropagation equations.
Wenowderivetheﬁnaltwobackpropagationequations
using the chain rule. Since the error depends on neurons
in layerlonly through the activation of neurons in the
subsequent layer l+ 1, we can use the chain rule to write
l
j=@E
@zl
j=X
k@E
@zl+1
k@zl+1
k
@zl
j
=X
kl+1
k@zl+1
k
@zl
j
= X
kl+1
kwl+1
kj!
0(zl
j): (III)
51
This is the third backpropagation equation. The ﬁnal
equation can be derived by diﬀerentiating of the cost
function with respect to the weight wl
jkas
@E
@wl
jk=@E
@zl
j@zl
j
@wl
jk= l
jal 1
k(IV)
Together, Eqs. (I), (II), (III), and (IV) deﬁne the four
backpropagation equations relating the gradients of the
activations of various neurons al
j, the weighted inputs
zl
j=P
kwl
jkal 1
k+bl
j,andtheerrors l
j. Theseequations
can be combined into a simple, computationally eﬃcient
algorithm to calculate the gradient with respect to all
parameters (Nielsen, 2015).
The Backpropagation Algorithm
1.Activation at input layer: calculate the activa-
tionsa1
jof all the neurons in the input layer.
2.Feedforward: starting with the ﬁrst layer, exploit
the feed-forward architecture through Eq. (123) to
computezlandalfor each subsequent layer.
3.Error at top layer: calculate the error of the top
layer using Eq. (I). This requires to know the ex-
pression for the derivative of both the cost function
E(w) =E(aL)and the activation function (z).
4.“Backpropagate” the error: use Eq. (III) to
propagate the error backwards and calculate l
jfor
all layers.
5.Calculate gradient: use Eqs. (II) and (IV) to
calculate@E
@bl
jand@E
@wl
jk.
We can now see where the name backpropagation
comes from. The algorithm consists of a forward pass
from the bottom layer to the top layer where one calcu-
lates the weighted inputs and activations of all the neu-
rons. One then backpropagates the error starting with
thetoplayerdowntotheinputlayerandusestheseerrors
tocalculatethedesiredgradients. Thisdescriptionmakes
clear the incredible utility and computational eﬃciency
of the backpropagation algorithm. We can calculate all
the derivatives using a single “forward” and “backward”
passoftheneuralnetwork. Thiscomputationaleﬃciency
is crucial since we must calculate the gradient with re-
spect to all parameters of the neural net at each step
of gradient descent. These basic ideas also underly al-
most all modern automatic diﬀerentiation packages such
as Autograd (Pytorch).
2. Computing gradients in deep networks: what can go wrong
with backprop?
Armed with backpropagation and gradient descent, it
seemslikeitshouldbestraightforwardtotrainanyneuralnetwork. However, until fairly recently it was widely be-
lieved that training deep networks was an extremely dif-
ﬁcult task. One reason for this was that even with back-
propagation, gradient descent on large networks is ex-
tremely computationally expensive. However, the great
advancesincomputationalhardware(andthewidespread
use of GPUs) has made this a much less vexing prob-
lem than even a decade ago. It is hard to understate
the impact these advances in computing have had on the
practical utility of neural networks.
On a more technical and mathematical note, another
problem that occurs in deep networks, which transmit
information through many layers, is that gradients can
vanish or explode. This is, appropriately, known as the
problem of vanishing or exploding gradients . This prob-
lem is especially pronounced in neural networks that try
to capture long-range dependencies, such as Recurrent
Neural Networks for sequential data. We can illustrate
this problem by considering a simple network with one
neuron in each layer. We further assume that all weights
are equal, and denote them by w. The behavior of the
backpropagation equations for such a network can be in-
ferred from repeatedly using Eq. (III):
1
j= L
jL 1Y
j=0w0(zj) = L
j(w)LL 1Y
j=00(zj);(126)
where L
jis the error in the L-th topmost layer, and
(w)Lis the weight to the power L. Let us now also
assume that the magnitude 0(zj)is fairly constant and
we can approximate 0(zj)0
0. In this case, notice
that for large L, the error 1
jhas very diﬀerent behavior
depending on the value of w0
0. Ifw0
0>1, the errors
and the gradient blow up. On the other hand, if w0
0<1
the errors and gradients vanish. Only when the weights
satisfyw0
01and the neurons are not saturated will
the gradient stay well behaved for deep networks.
This basic behavior holds true even in more compli-
cated networks. Rather than considering a single weight,
we can ask about the eigenvalues (or singular values) of
the weight matrices wl
jk. In order for the gradients to
be ﬁnite for deep networks, we need these eigenvalues to
stay near unity even after many gradient descent steps.
In modern feedforward and ReLU neural networks, this
is achieved by initializing the weights for the gradient de-
scent in clever ways and using non-linearities that do not
saturate, such as ReLUs (recall that for saturating func-
tions,0!0, which will cause the gradient to vanish).
Proper initialization and regularization schemes such as
gradient clipping (cutting-oﬀ gradients with very large
values), and batch normalization also help mitigate the
vanishing and exploding gradient problem.
52
D. Regularizing neural networks and other practical
considerations
DNNs, like all supervised learning algorithms, must
navigate the bias-variance tradeoﬀ. Regularization tech-
niques play an important role in ensuring that DNNs
generalize well to new data. The last ﬁve years have seen
a wealth of new specialized regularization techniques for
DNNsbeyondthesimple L1andL2penaltiesdiscussedin
the context of linear and logistic regression, see Secs. VI
and VII. These new techniques include Dropout and
Batch Normalization. In addition to these specialized
regularization techniques, large DNNs seem especially
well-suited to implicit regularization that already takes
place in the Stochastic Gradient Descent (SGD) (Wilson
et al., 2017), cf. Sec. IV. The implicit stochasticity and
local nature of SGD often prevent overﬁtting of spurious
correlations in the training data, especially when com-
bined with techniques such as Early Stopping. In this
section, we give a brief overview of these regularization
techniques.
1. Implicit regularization using SGD: initialization,
hyper-parameter tuning, and Early Stopping
The most commonly employed and eﬀective optimizer
for training neural networks is SGD (see Sec. IV for other
alternatives). SGD acts as an implicit regularizer by in-
troducing stochasticity (from the use of mini-batches)
that prevents overﬁtting. In order to achieve good per-
formance, it is important that the weight initialization is
chosen randomly, in order to break any leftover symme-
tries. One common choice is drawing the weights from a
Gaussian centered around zero with some variance that
scales inversely with number of inputs to the neuron (He
et al., 2015; Sutskever et al., 2013). Since SGD is a lo-
cal procedure, as networks get deeper, choosing a good
weight initialization becomes increasingly important to
ensure that the gradients are well behaved. Choosing
an initialization with a variance that is too large or too
small will cause gradients to vanish and the network to
train poorly – even a factor of 2can make a huge diﬀer-
ence in practice (He et al., 2015). For this reason, it is
important to experiment with diﬀerent variances.
The second important thing is to appropriately choose
the learning rate or step-size by searching over ﬁve log-
arithmic grid points (Wilson et al., 2017). If the best
performance occurs at the edge of the grid, repeat this
procedure until the optimal learning rate is in the middle
of the grid parameters. Finally, it is common to center
or whiten the input data (just as we did for linear and
logistic regression).
Another important form of regularization that is of-
ten employed in practice is Early Stopping. The idea of
EarlyStoppingistodividethetrainingdataintotwopor-tions, the dataset we train on, and a smaller validation
setthat serves as a proxy for out-of-sample performance
on the test set. As we train the model, we plot both the
training error and the validation error. We expect the
training error to continuously decrease during training.
However, the validation error will eventually increase due
to overﬁtting. The basic idea of early stopping is to halt
the training procedure when the validation error starts to
rise. This Early Stopping procedure ensures that we stop
the training and avoid ﬁtting sample speciﬁc features in
the data. Early Stopping is a widely used essential tool
in the deep learning regularization toolbox.
2. Dropout
Another important regularization schemed that has
been widely adopted in the neural networks literature
is Dropout (Srivastava et al., 2014). The basic idea of
Dropout is to prevent overﬁtting by reducing spurious
correlations between neurons within the network by in-
troducing a randomization procedure similar to that un-
derlying ensemble models such as Bagging. Recall that
the basic idea behind ensemble methods is to train an en-
semble of models that are created using a randomization
procedure to ensure that the members of the ensemble
are uncorrelated, see Sec. VIII. This reduces the vari-
ance of statistical predictions without creating too much
additional bias.
Inthecontextofneuralnetworks, itisextremelycostly
to train an ensemble of networks, both from the point of
view of the amount of data needed, as well as computa-
tional resources and parameter tuning required. Dropout
circumnavigates these problems by randomly dropping
out neurons (along with their connections) from the neu-
ral network during each step of the training (see Figure
39). Typically, for each mini-batch in the gradient de-
scent step, a neuron is dropped from the neural network
with a probability p. The gradient descent step is then
performed only on the weights of the “thinned” network
of individual predictors.
Since during training, on average weights are only
present a fraction pof the time, predictions are made
by reweighing the weights by p:wtest=pwtrain.The
learned weights can be viewed as some “average” weight
over all possible thinned neural network. This averag-
ing of weights is similar in spirit to the Bagging proce-
dure discussed in the context of ensemble models, see
Sec. VIII.
3. Batch Normalization
Batch Normalization is a regularization scheme that
has been quickly adopted by the neural network com-
munity since its introduction in 2015 (Ioﬀe and Szegedy,
53
X
Standard
Neural Net
After applying
Dropout
FIG. 39Dropout During the training procedure neurons
are randomly “dropped out” of the neural network with some
probability pgiving rise to a thinned network. This prevents
overﬁtting by reducing correlations among neurons and re-
ducing the variance in a method similar in spirit to ensemble
methods.
2015). ThebasicinspirationbehindBatchNormalization
is the long-known observation that training in neural net-
works works best when the inputs are centered around
zero with respect to the bias. The reason for this is that
it prevents neurons from saturating and gradients from
vanishing in deep nets. In the absence of such center-
ing, changes in parameters in lower layers can give rise
to saturation eﬀects in higher layers, and vanishing gra-
dients. The idea of Batch Normalization is to introduce
additional new “BatchNorm” layers that standardize the
inputs by the mean and variance of the mini-batch.
Consider a layer lwithdneurons whose inputs are
(zl
1;:::;zl
d). We standardize each dimension so that
zl
k !^zl
k=zl
k E[zl
k]q
Var[zl
k]; (127)
where the mean and variance are taken over all sam-
ples in the mini-batch. One problem with this procedure
is that it may change the representational power of the
neural network. For example, for tanhnon-linearities, it
may force the network to live purely in the linear regime
aroundz= 0. Since non-linearities are crucial to the
representational power of DNNs, this could dramatically
alter the power of the DNN.
For this reason, one introduces two new parameters l
k
andl
kfor each neuron that can additionally shift and
scale the normalized input
^zl
k !^ zl
k=l
k^zl
k+l
k: (128)
One can think of Eqs. (127) and (128) as adding new
extra layers ^ zl
kin the deep net architecture. Hence, thenew parameters l
kandl
kcan be learned just like the
weights and biases using backpropagation (since this is
just an extra layer for the chain rule). We initialize the
neural network so that at the beginning of training the
inputsarebeingstandardized. Backpropagationthenad-
justsandduring training.
In practice, Batch Normalization considerably im-
proves the learning speed by preventing gradients from
vanishing. However, it also seems to serve as a power-
ful regularizer for reasons that are not fully understood.
One plausible explanation is that in batch normalization,
the gradient for a sample depends not only on the sam-
ple itself but also on all the properties of the mini-batch.
Since a single sample can occur in diﬀerent mini-batches,
this introduces additional randomness into the training
procedure which seems to help regularize training.
E. Deep neural networks in practice: examples
Now that we have gained suﬃcient high-level back-
ground knowledge about deep neural nets, let us discuss
how to use them in practice.
1. Deep learning packages
In Notebook 11, we demonstrated that the numerical
implementation of DNNs is greatly facilitated by open
source python packages, such as Keras, TensorFlow, Py-
torch, and others. The complexity and learning curves
for these packages diﬀer, depending on the user’s level of
familiarity with Python. The reader should keep mind
mind that there are DNN packages written in other lan-
guages, such as Caﬀe which uses C++, but we do not
discuss them in this review for brevity.
Keras is a high-level framework which does not require
any knowledge about the inner workings of the underly-
ing deep learning algorithms. Coding DNNs in Keras is
particularly simple, see Notebook 11, and allows one to
quickly grasp the big picture behind the theoretical con-
cepts which we introduced above. However, for advanced
applications, which may require more direct control over
the operations in between the layers, Keras’ high-level
design may turn out insuﬃcient.
If one opens up the Keras black box, one will ﬁnd that
it wraps the functionality of another package – Tensor-
Flow11. Over the last years, TensorFlow, which is sup-
ported by Google, has been gaining popularity and has
become the preferred library for deep learning. It is fre-
quently used in Kaggle competitions, university classes,
and industry. In TensorFlow one constructs data ﬂow
11While Keras can also be used with a Theano backend, we do not
discuss this here since Theano support has been discontinued.
54
graphs, the nodes of which represent mathematical oper-
ations, while the edges encode multidimensional tensors
(data arrays). A deep neural net can then be thought of
as a graph with a particular architecture and connectiv-
ity. One needs to understand this concept well before one
can truly unleash TensorFlow’s full potential. The learn-
ing curve can sometimes be rather steep for TensorFlow
beginners, and requires a certain degree of perseverance
and devoted time to internalize the underlying ideas.
There are, however, many other open source packages
which allow for control over the inter- and intra-layer op-
erations, without the need to introduce computational
graphs. Such an example is Pytorch, which oﬀers li-
braries for automatic diﬀerentiation of tensors at GPU
speed. As we discussed above, manipulating neural nets
boils down to fast array multiplication and contraction
operations and, therefore, the torch.nn library often
does the job of providing enough access and controlla-
bility to manipulate the linear algebra operations under-
lying deep neural nets.
For the beneﬁt of the reader, we have prepared Jupyter
notebooks for DNNs using all three packages for the deep
learning problems we discuss below. We invite the reader
to carefully examine the diﬀerences in the code which
should help them decide on which package they prefer to
use.
2. Approaching the learning problem
Letusnowanalyzeatypicalprocedureforusingneural
networks to solve supervised learning problems. As can
be seen already from the code snippets in Notebook 11,
constructing a deep neural network to solve ML problems
is a multiple-stage process. Generally, one can identify a
set of key steps:
1.Collect and pre-process the data.
2.Deﬁne the model and its architecture.
3.Choose the cost function and the optimizer.
4.Train the model.
5.Evaluate and studythe model performance
on the test data.
6.Use the validation data to adjust the hyper-
parameters (and, if necessary, network ar-
chitecture) to optimize performance for the
speciﬁc dataset.
At this point a few remarks are in order. While we
treat Step 1 above as consisting mainly of loading and
reshaping a dataset prepared ahead of time, we empha-
size that obtaining a suﬃcient amount of data is a typical
challenge in many applications. Oftentimes insuﬃcientdata serves as a major bottleneck on the ultimate per-
formance of DNNs. In such cases one can consider data
augmentation, i.e. distorting data samples from the ex-
isting dataset in some way to enhance size the dataset.
Obviously, if one knows how to do this, one already has
partial information about the important features in the
data.
One of the ﬁrst questions we are typically faced with is
how to determine the sizes of the training and test data
sets. The MNIST dataset, which has 10classiﬁcation
categories, uses 80%of the available data for training
and20%for testing. On the other hand, the ImageNet
data which has 1000categories is split 50% 50%. As
a rule of thumb, the more classiﬁcation categories there
are in the task, the closer the sizes of the training and
test datasets should be in order to prevent overﬁtting.
Once the size of the training set is ﬁxed, it is common to
reserve 20%of it for validation, which is used to ﬁne-tune
the hyperparameters of the model.
Also related to data preprocessing is the standardiza-
tion of the dataset. It has been found empirically that if
the original values of the data diﬀer by orders of magni-
tude, training can be slowed down or impeded. This can
be traced back to the vanishing and exploding gradient
problem in backprop discussed in Sec. IX.C. To avoid
such unwanted eﬀects, one often resorts to two tricks:
(i) all data should be mean-centered, i.e. from every data
point we subtract the mean of the entire dataset, and (ii)
rescale the data, for which there are two ways: if the data
is approximately normally distributed, one can rescale by
thestandarddeviation. Otherwise, itistypicallyrescaled
by the maximum absolute value so the rescaled data lies
within the interval [ 1;1]. Rescaling ensures that the
weights of the DNN are of a similar order of magnitude
(noticethesimilarityofthisideatoBatchNormalization,
cf. Sec. IX.D.3).
The next issue is how to choose the right hyperparam-
eters to start training the model. According to Bengio,
the optimal learning rate is often an order of magnitude
lower than the smallest learning rate that blows up the
loss (Bengio, 2012). One should also keep in mind that,
depending on how ambitious of a problem one is dealing
with, training the model can take a considerable amount
of time. This can severely slow down any progress on
improving the model in Step 6. Therefore, it is usu-
ally a good idea to play with a small enough fraction of
the training data to get a rough feeling about the cor-
rect hyperparameter regimes, the usefulness of the DNN
architecture, and to debug the code. The size of this
small ‘play set’ should be such that training on it can
be done fast and in real time to allow to quickly adjust
the hyperparameters. A typical strategy of exploring the
hyperparameter landscape is to use grid searches.
Whereas it is always possible to view Steps 1-5 as
generic and independent of the particular problem we
are trying to solve, it is only when these steps are put
55
1e-05 0.0001 0.001 0.01 0.1
learningrate1000
10000
100000
200000datasetsize54.5%
44.6%
42.7%
56.7%51.5%
65.0%
48.8%
59.9%74.5%
74.6%
74.1%
76.0%77.5%
77.0%
78.6%
78.9%65.5%
78.2%
79.6%
79.9%
0%20%40%60%80%100%
accuracy (%)
FIG. 40 Grid search results for the test set accuracy of the
DNN for the SUSY problem as a function of the learning rate
and the size of the dataset. The data used includes all high-
and low-level features.
together in Step 6 that the real beneﬁt of deep learning
is revealed, compared to less sophisticated methods such
as regression or bagging, see Secs. VI, VII, and VIII. The
optimalchoiceofnetworkarchitecture, costfunction, and
optimizer is determined by the properties of the training
and test datasets, which are usually revealed when we
try to improve the model.
While there is no “one-size-ﬁts-them-all” recipe to ap-
proach ML problems, we believe that the above list gives
a good overview and can be a useful guideline to the lay-
man. Furthermore, as it becomes clear, this ‘recipe’ can
be applied to generic supervised learning tasks, not just
DNNs. We refer the reader to Sec. XI for more useful
hints and tips on how to use the validation data during
the training process.
3. SUSY dataset
As a ﬁrst example from physics, we discuss a DNN
approach to the SUSY dataset already introduced in the
contextoflogisticregressioninSec.VII.C.2, andBagging
in Sec. VIII.F. For a detailed description of the SUSY
dataset and the corresponding classiﬁcation problem, we
refer the reader to Sec. VII.C.2. There is an interest in
using deep learning methods to automate the discovery
of collision features from data. Benchmark results using
Bayesian Decision Trees from a standard physics pack-
age, and ﬁve-layer neural networks using Dropout were
presented in the original paper (Baldi et al., 2014); they
demonstrate the ability of deep learning to bypass the
need of using hand-crafted high-level features. Our goal
here is to study systematically the accuracy of a DNN
classiﬁerasafunctionofthelearningrateandthedataset
size.Unlike the MNIST example where we used Keras, here
weusetheopportunitytointroducethePytorchpackage,
see the corresponding notebook. We leave the discussion
of the code-speciﬁc details for the accompanying note-
book.
To classify the SUSY collision events, we construct a
DNN with two dense hidden layers of 200and100neu-
rons, respectively. We use ReLU activation between the
input and the hidden layers, and a sofmax output layer.
We apply dropout regularization on the weights of the
DNN. Similar to MNIST, we use the cross-entropy as a
cost function and minimize it using SGD with batches of
size10%of the training data size. We train the DNN for
10epochs.
Figure 40 shows the accuracy of our DNN on the test
data as a function of the learning rate and the size of the
dataset. It is considered good practice to start with a
logarithmic scale to search through the hyperparameters,
to get an overall idea for the order of magnitude of the
optimal values. In this example, the performance peaks
atthelargestsizeofthedatasetandalearningrateof 0:1,
andisoftheorderof 80%. Sincetheoptimalperformance
is obtained at the edge of the grid, we encourage the
reader to extend the grid size to beat our result. For
comparison, in the original study (Baldi et al., 2014),
the authors achieved 89%by using the entire dataset
with 5;000;000points and a more sophisticated network
architecture, trained using GPUs.
4. Phases of the 2D Ising model
As a second example from physics, we discuss a DNN
approach to the Ising dataset introduced in Sec. VII.C.1.
We study the problem of classifying the states of the 2D
Ising model with a DNN (Tanaka and Tomiya, 2017a),
focussing on the model performance as a function of both
the number of hidden neurons and the learning rate.
The discussion is accompanied by a notebook written in
TensorFlow. As in the previous example, the interested
reader can ﬁnd the discussion of the code-speciﬁc details
in the notebook.
To classify whether a given spin conﬁguration is in the
ordered or disordered phase, we construct a minimalistic
model for a DNN with a single hidden layer containing
a number of hidden neurons. The network architecture
thus includes a ReLU-activated input layer, the hidden
layer, and the softmax output layer. We pick the cate-
gorical cross-entropy as a cost function and minimize it
using SGD with mini-batches of size 100. We train the
DNN for 100epochs.
Figure 41 shows the outcome of a grid search over a
log-spacedlearningrateandthenumberofneuronsinthe
hidden layer. We see that about 10neurons are enough
at a learning rate of 0:1to get to a very high accuracy on
the test set. However, if we aim at capturing the physics
56
1e-06 1e-05 0.0001 0.001 0.01 0.1
learningrate1
10
100
1000hiddenneurons50.5%
60.7%
68.9%
79.2%49.3%
43.1%
70.8%
53.9%50.8%
28.0%
85.1%
84.2%49.7%
75.6%
93.3%
97.9%52.0%
95.7%
99.7%
99.8%68.4%
99.2%
99.9%
99.9%
0%20%40%60%80%100%
accuracy (%)
1e-06 1e-05 0.0001 0.001 0.01 0.1
learningrate1
10
100
1000hiddenneurons50.2%
68.6%
67.6%
67.6%50.1%
46.4%
63.9%
51.9%49.8%
39.3%
55.5%
56.2%49.2%
74.5%
67.1%
59.9%53.7%
83.7%
73.1%
74.0%60.1%
84.2%
93.7%
96.0%
0%20%40%60%80%100%
accuracy (%)
FIG. 41 Grid search results for the test set accuracy (top)
and the critical set accuracy (bottom) of the DNN for the
Ising classiﬁcation problem as a function of the learning rate
and the number of hidden neurons.
close to criticality, clearly more neurons are required to
reliably learn the more complex correlations in the Ising
conﬁgurations.
X. CONVOLUTIONAL NEURAL NETWORKS (CNNS)
One of the core lessons of physics is that we should ex-
ploit symmetries and invariances when analyzing physi-
cal systems. Properties such as locality and translational
invariance are often built directly into the physical laws.
Our statistical physics models often directly incorporate
everything we know about the physical system being an-
alyzed. For example, we know that in many cases it is
suﬃcient to consider only local couplings in our Hamilto-
nians, or work directly in momentum space if the system
is translationally invariant. This basic idea, tailoring our
analysistoexploitadditionalstructure, isakeyfeatureof
modern physical theories from general relativity, throughgauge theories, to critical phenomena.
Like physical systems, many datasets and supervised
learning tasks also possess additional symmetries and
structure. For instance, consider a supervised learning
task where we want to label images from some dataset as
being pictures of cats or not. Our statistical procedure
must ﬁrst learn features associated with cats. Because
a cat is a physical object, we know that these features
are likely to be local (groups of neighboring pixels in the
two-dimensional image corresponding to whiskers, tails,
eyes, etc). We also know that the cat can be anywhere
in the image. Thus, it does not really matter where in
thepicturethesefeaturesoccur(thoughrelativepositions
of features likely do matter). This is a manifestation of
translational invariance that is built into our supervised
learning task. This example makes clear that, like many
physical systems, many ML tasks (especially in the con-
text of computer vision and image processing) also pos-
sess additional structure, such as locality and translation
invariance.
The all-to-all coupled neural networks in the previous
sectionfailtoexploitthisadditionalstructure. Forexam-
ple, considertheimageofthedigit‘four’fromtheMNIST
dataset shown in Fig. 26. In the all-to-all coupled neural
networks used there, the 2828image was considered
a one-dimensional vector of size 282= 796. This clearly
throws away lots of the spatial information contained in
the image. Not surprisingly, the neural networks com-
munity realized these problems and designed a class of
neural network architectures, convolutional neural net-
works or CNNs, that take advantage of this additional
structure (locality and translational invariance) (LeCun
et al., 1995). Furthermore, what is especially interest-
ing from a physics perspective is the recent ﬁnding that
these CNN architectures are intimately related to mod-
els such as tensor networks (Stoudenmire, 2018; Stouden-
mire and Schwab, 2016) and, in particular, MERA-like
architectures that are commonly used in physical mod-
els for quantum condensed matter systems (Levine et al.,
2017).
A. The structure of convolutional neural networks
A convolutional neural network is a translationally in-
variant neural network that respects locality of the in-
put data. CNNs are the backbone of many modern deep
learning applications and here we just give a high-level
overview of CNNs that should allow the reader to delve
directly into the specialized literature. The reader is also
strongly encouraged to consult the excellent, succinct
notesfortheStanfordCS231nConvolutionalNeuralNet-
works class developed by Andrej Karpathy and Fei-Fei Li
(https://cs231n.github.io/ ). We have drawn heavily
on the pedagogical style of these notes in crafting this
section.
57
Convolution Coarse-graining
(pooling)Convolution Coarse-graining
(pooling)Fully 
Connected
Layer
WHD
FIG. 42 Architecture of a Convolutional Neural Network (CNN). The neurons in a CNN are arranged in three
dimensions: height ( H), width (W), and depth ( D). For the input layer, the depth corresponds to the number of channels (in
this case 3 for RGB images). Neurons in the convolutional layers calculate the convolution of the image with a local spatial
ﬁlter (e.g. 33pixel grid, times 3 channels for ﬁrst layer) at a given location in the spatial (W;H )-plane. The depth Dof the
convolutional layer corresponds to the number of ﬁlters used in the convolutional layer. Neurons at the same depth correspond
to the same ﬁlter. Neurons in the convolutional layer mix inputs at diﬀerent depths but preserve the spatial location. Pooling
layers perform a spatial coarse graining (pooling step) at each depth to give a smaller height and width while preserving the
depth. The convolutional and pooling layers are followed by a fully connected layer and classiﬁer (not shown).
There are two kinds of basic layers that make up a
CNN: a convolution layer that computes the convolu-
tion of the input with a bank of ﬁlters (as a math-
ematical operation, see this practical guide to image
kernels: http://setosa.io/ev/image-kernels/ ), and
pooling layers that coarse-grain the input while main-
taining locality and spatial structure, see Fig. 42. For
two-dimensional data, a layer lis characterized by three
numbers: height Hl, widthWl, and depth Dl12. The
height and width correspond to the sizes of the two-
dimensional spatial (Wl;Hl)-plane (in neurons), and the
depthDl(marked by the diﬀerent colors in Fig. 42) –
to the number of ﬁlters in that layer. All neurons corre-
sponding to a particular ﬁlter have the same parameters
(i.e. shared weights and bias).
In general, we will be concerned with local spatial
ﬁlters (often called a receptive ﬁeld in analogy with
neuroscience) that take as inputs a small spatial patch
of the previous layer at all depths. For instance, a
square ﬁlter of size Fis a three-dimensional array of
sizeFFDl 1. The convolution consists of running
this ﬁlter over all locations in the spatial plane. To
demonstrate how this works in practice, let us a consider
the simple example consisting of a one-dimensional
input of depth 1, shown in Fig. 43. In this case, a ﬁlter
of sizeF11can be speciﬁed by a vector of weights
wof lengthF. The stride, S, encodes by how many
neurons we translate the ﬁlter by when performing
the convolution. In addition, it is common to pad
12The depth Dlis often called “number of channels”, to distin-
guish it from the depth of the neural network itself, i.e. the total
number of layers (which can be convolutional, pooling or fully-
connected), cf. Fig. 42.the input with Pzeros (see Fig. 43). For an input
of widthW, the number of neurons (outputs) in the
layer is given by (W F+ 2P)=S+ 1. We invite the
reader to check out this visualization of the convolution
procedure, https://github.com/vdumoulin/conv_
arithmetic/blob/master/README.md , for a square
input of unit depth. After computing the ﬁlter, the
output is passed through a non-linearity, a ReLU in Fig.
43. In practice, one often inserts a BatchNorm layer
before the non-linearity, cf. Sec. IX.D.3.
These convolutional layers are interspersed with pool-
ing layers that coarse-grain spatial information by per-
formingasubsamplingateachdepth. Onecommonpool-
ing operation is the max pool. In a max pool, the spatial
dimensions are coarse-grained by replacing a small region
(say22neurons) by a single neuron whose output is the
maximum value of the output in the region. In physics,
this pooling step is very similar to the decimation step
of RG (Iso et al., 2018; Koch-Janusz and Ringel, 2017;
Linet al., 2017; Mehta and Schwab, 2014). This gener-
ally reduces the dimension of outputs. For example, if
the region we pool over is 22, then both the height
and the width of the output layer will be halved. Gen-
erally, pooling operations do not reduce the depth of the
convolutional layers because pooling is performed sepa-
rately at each depth. A simple example of a max-pooling
operation is shown in Fig. 44. There are some studies
suggesting that pooling might be unnecessary (Springen-
berget al., 2014), but pooling layers remain a staple of
most CNNs.
In a CNN, the convolution and max-pool layers are
generally followed by an all-to-all connected layer and a
high-level classiﬁer such as a soft-max. This allows us
to train CNNs as usual using the backprop algorithm,
cf. Sec. IX.C. From a backprop perspective, CNNs are
58
almost identical to fully connected neural network archi-
tectures except with tied parameters.
Apart from introducing additional structure, such as
translational invariance and locality, this convolutional
structurealsohasimportantpracticalandcomputational
beneﬁts. All neurons at a given layer represent the same
ﬁlter, and hence can all be described by a single set of
weights and biases. This reduces the number of free pa-
rametersbyafactorof HWateachlayer. Forexample,
for a layer with D= 102andH=W= 102, this gives
a reduction in parameters of nearly 106! This allows for
the training of much larger models than would otherwise
be possible with fully connected layers. We are familiar
with similar phenomena in physics: e.g. in translation-
ally invariant systems we can parametrize all eigenmodes
by specifying only their momentum (wave number) and
functional form ( sin,cos, etc.), while without translation
invariance much more information is required.
B. Example: CNNs for the 2D Ising model
The inclusion of spatial structure in CNNs is an im-
portant feature that can be exploited when designing
neural networks for studying physical systems. In the
accompanying notebook, we used Pytorch to implement
a simple CNN composed of a single convolutional layer
followed by a soft-max layer. Every input data point
(i.e. Ising conﬁguration) is shaped as a two-dimensional
array. We varied the output depth (i.e. the number of
output channels) of the convolutional layer from unity –
a single set of weights and one bias – to an output depth
of50distinct weights and biases. The CNN was then
trained using SGD for ﬁve epochs using a training set
consisting of samples from far in the paramagnetic and
ordered phases. The results are shown in Fig. 45. The
CNN achieved a 100% accuracy on the test set for all
architectures, even for a CNN with depth one. We also
checked the performance of the CNN on samples drawn
from the near-critical region for temperatures Tslightly
above and below the critical temperature Tc. The CNN
performed admirably even on these critical samples with
an accuracy of between 80%and90%. As is the case
with all ML and neural networks, the performance on
parts of the data that are missing from the training set
is considerably worse than on test data that is similar
to the training data. This highlights the importance of
properly constructing an accurate training dataset and
the considerable obstacles of generalizing to novel situ-
ations. We encourage the interested reader to explore
the corresponding notebook and design better CNN ar-
chitectures with improved generalization performance on
the near-critical set.
The reader may wish to check out the second part of
the MNIST notebook for a discussion of CNNs applied to
the digit recognition using the high-level Keras package.
W=5F=3
S=2
(units to shift
filter by)S=1
(units to shift
filter by)
P=1bias=-2ReLU 
(unit slope)
inputoutput0
0weight=[1,-1,1]
1 
3-122
1 
1 
-1 
6 
-4 -1 
-1 
-3 
4 4 
-6 0 
0 
0 0 
W=6F=4
P=0bias=-1 ReLU 
(unit slope)
inputoutputweight=[1,-1,2,1]
1 
0
-2-122
2 
 1 
 1 
1 
 0 
 0 (a)
(b)FIG. 43Two examples to illustrate a one-dimensional
convolutional layer with ReLU nonlinearity . Convolu-
tional layer for a spatial ﬁlter of size Ffor a one-dimensional
input of width Wwith stride Sand padding Pfollowed by a
ReLU non-linearity.
Regarding the SUSY dataset, we stress that the absence
of spatial locality in the collision features renders apply-
ing CNNs to that problem inadequate.
C. Pre-trained CNNs and transfer learning
The immense success of CNNs for image recognition
hasresultedinthetrainingofhugenetworksonenormous
datasets, often by large industrial research teams from
59
..
...
.3 0
1 0
2 3
4 121
2
0 1 11
1  10
3
4
2 5
1 1
1 0
3 11 1
0 102
1 01
5
32
FIG. 44Illustration of Max Pooling . Illustration of max-
pooling over a 22region. Notice that pooling is done at
each depth (vertical axis) separately. The number of outputs
is halved along each dimension due to this coarse-graining.
Google, Microsoft, Amazon, etc. Many of these mod-
els are known by name: AlexNet, GoogLeNet, ResNet,
InceptionNet, VGGNet, etc. Most researchers and prac-
titioners do not have the resources, data, or time to train
networks on this scale. Luckily, the trained models have
been released and are now available in standard packages
such as the Torch Vision library in Pytorch or the Caﬀe
framework. These models can be used directly as a basis
for ﬁne-tuning in diﬀerent supervised image recognition
tasks through a process called transfer learning.
The basic idea behind transfer learning is that the ﬁl-
ters (receptive ﬁelds) learned by the convolution layers
of these networks should be informative for most im-
age recognition based tasks, not just the ones they were
originally trained for. In other words, we expect that,
since images reﬂect the natural world, the ﬁlters learned
by these CNNs should transfer over to new tasks with
only slight modiﬁcations and ﬁne-tuning. In practice,
this turns out to be true for many tasks one might be
interested in.
There are three distinct ways one can take a pre-
trainedCNNandrepurposeitforanewtask. Thefollow-
ing discussion draws heavily on the notes from the course
1510 20 50
Depth of hidden layer60708090100110Accuracy
test
criticalFIG. 45Single-layer convolutional network for classi-
fying phases in the Ising mode . Accuracy on test set and
critical samples for a convolutional neural network with sin-
gle layer of varying depth with ﬁlters of size 2, max-pool layer
with receptive ﬁeld of size 2, followed by soft-max classiﬁer.
Noticethatthetestaccuracyis 100%evenforaCNNofdepth
one with a single set of weights. Accuracy on the near-critical
dataset is signiﬁcantly below that for the test set.
CS231n mentioned in the introduction to this section.
•Use CNN as ﬁxed feature detector at top
layer.If the new dataset we want to train on is
small and similar to the original dataset, we can
simply use the CNN as a ﬁxed feature detector
and retrain our classiﬁer. In other words, we re-
movetheclassiﬁer(soft-max)layeratthetopofthe
CNNandreplaceitwithanewclassiﬁer(linearsup-
port vector machine (SVM) or soft-max) relevant
to our supervised learning problem. In this proce-
dure, the CNN serves as a ﬁxed map from images
to relevant features (the outputs of the top fully-
connected layer right before the original classiﬁer).
This procedure prevents overﬁtting on small, simi-
lar datasets and is often a useful starting point for
transfer learning.
•Use CNN as ﬁxed feature detector at inter-
mediate layer. If the dataset is small and quite
diﬀerent from the dataset used to train the origi-
nal image, the features at the top level might not
be suitable for our dataset. In this case, one may
want to instead use features in the middle of the
CNN to train our new classiﬁer. These features are
thought to be less ﬁne-tuned and more universal
(e.g. edge detectors). This is motivated by the idea
that CNNs learn increasingly complex features the
deeper one goes in the network (see discussion on
representational learning in next section).
•Fine-tune the CNN. If the dataset is large, in
60
addition to replacing and retraining the classiﬁer
in the top layer, we can also ﬁne-tune the weights
of the original CNN using backpropagation. One
may choose to freeze some of the weights in the
CNN during the procedure or retrain all of them
simultaneously.
All these procedures can be carried out easily by us-
ing packages such as Caﬀe or the Torch Vision library
in PyTorch. PyTorch provides a nice python notebook
that serves as tutorial on transfer learning. The reader
is strongly urged to read the Pytorch tutorials carefully
if interested in this topic.
XI. HIGH-LEVEL CONCEPTS IN DEEP NEURAL
NETWORKS
In the previous sections, we introduced deep neural
networks and discussed how we can use these networks
toperformsupervisedlearning. Here, wetakeastepback
and discuss some high-level questions about the practice
andperformanceofneuralnetworks. Theﬁrstpartofthis
section presents a deep learning workﬂow inspired by the
bias-variance tradeoﬀ. This workﬂow is especially rele-
vant to industrial applications where one is often trying
to employ neural networks to solve a particular problem.
In the second part of this section, we shift gears and ask
the question, why have neural networks been so success-
ful?We provide three diﬀerent high-level explanations
that reﬂect current dogmas. Finally, we end the section
bydiscussingthelimitationsofsupervisedlearningmeth-
ods and current neural network architectures.
A. Organizing deep learning workﬂows using the bias-variance
tradeoﬀ
Imagine that you are given some data and asked
to design a neural network for learning how to per-
form a supervised learning task. What are the best
practices for organizing a systematic workﬂow that
allows us to eﬃciently do this? Here, we present
a simple deep learning workﬂow inspired by think-
ing about the bias-variance tradeoﬀ (see Figure 46).
This section draws heavily on Andrew Ng’s tuto-
rial at the Deep Learning School (available online
at https://www.youtube.com/watch?v=F1ka6a13S9I)
which readers are strongly encouraged to watch.
The ﬁrst thing we would like to do is divide the data
into three parts. A training set, a validation or dev
(development) set, and a test set. The test set is the
data on which we want to make predictions. The dev set
is a subset of the training data we use to check how well
we are doing out-of-sample, after training the model on
the training dataset. We use the validation error as aproxy for the test error in order to make tweaks to our
model. It is crucial that we do not use any of the test
data to train the algorithm. This is a cardinal sin in
ML. We thus suggest the following workﬂow:
Estimate optimal error rate (Bayes rate).— The
ﬁrst thing one should establish is the diﬃculty of the
task and the best performance one can expect to achieve.
No algorithm can do better than the “signal” in the
dataset. For example, it is likely much easier to classify
objects in high-resolution images than in very blurry,
low-resolution images. Thus, one needs to establish
a proxy or baseline for the optimal performance that
can be expected from any algorithm. In the context of
Bayesian statistics, this is often called the Bayes rate.
Since we do not know this a priori, we must get an
estimate of this. For many tasks such as speech or object
recognition, we can approximate this by the performance
of humans on the task. For a more specialized task,
we would like to ask how well experts, trained at the
task, perform. This expert performance then serves as a
proxy for our Bayes rate.
Minimize underﬁtting (bias) on training data
set.—After we have established the Bayes rate, we want
to make sure that we are using a suﬃciently complex
model to avoid underﬁtting on the training dataset.
In practice, this means comparing the training error
rate to the Bayes rate. Since the training error does
not care about generalization (variance), our model
should approach the Bayes rate on the training set. If
it does not, the bias of the DNN model is too large
and one should try training the model longer and/or
using a larger model. Finally, if none of these techniques
work, it is likely that the model architecture is not
well suited to the dataset, and one should modify the
neural architecture in some way to better reﬂect the un-
derlying structure of the data (symmetries, locality, etc.).
Make sure you are not overﬁtting.— Next, we
run our algorithm on the validation or dev set. If the
error is similar to the training error rate and Bayes rate,
we are done. If it is not, then we are overﬁtting the
training data. Possible solutions include, regularization
and, importantly, collecting more data. Finally, if
none of these work, one likely has to change the DNN
architecture.
If the validation and test sets are drawn from the same
distributions, then good performance on the validation
set should lead to similarly good performance on the
test set. (Of course performance will typically be slightly
worse on the test set because the hyperparameters were
ﬁt to the validation set.) However, sometimes the train-
ing data and test data diﬀer in subtle ways because, for
example, they are collected using slightly diﬀerent meth-
61
Training	error	high?	Bigger	model	Train	longer	New	model	architecture	Yes	
No	Underﬁ9ng	Valida;on	error	high?	
Overﬁ9ng	Yes	More	data	Regulariza;on	New	model	architecture	
No	DONE!	Establish	proxy	for	op;mal	error	rate	(e.g.	expert	performance)	
FIG. 46 Organizing a workﬂow for Deep Learning.
Schematic illustrating a deep learning workﬂow inspired by
navigating the bias-variance tradeoﬀ (Figure based on An-
drew Ng’s talk at the 2016 Deep Learning School available at
https://www.youtube.com/watch?v=F1ka6a13S9I .) In this
diagram, we have assumed that there in no mismatch be-
tween the distributions the training and test sets are drawn
from.
ods, or because it is cheaper to collect data in one way
versus another. In this case, there can be a mismatch
between the training and test data. This can lead to
the neural network overﬁtting these small diﬀerences be-
tween the test and training sets, and a poor performance
on the test set despite having a good performance on
the validation set. To rectify this, Andrew Ng suggests
making two validation or dev sets, one constructed from
the training data and one constructed from the test data.
The diﬀerence between the performance of the algorithm
on these two validation sets quantiﬁes the train-test mis-
match. This can serve as another important diagnostic
when using DNNs for supervised learning.
B. Why neural networks are so successful: three high-level
perspectives on neural networks
Havingdiscussedthebasicsofneuralnetworks, wecon-
clude by giving three complementary perspectives on the
success of DNNs and Deep Learning. This high-level dis-
cussion reﬂects various dogmas and intuitions about the
success of DNNs and is in no way deﬁnitive or conclusive.
As the reader was already warned in the introduction to
DNNs, the ﬁeld is rapidly expanding and many of these
perspectives may turn out to be only partially true or
even false. Nonetheless, we include them here as a guide-
post for readers.1. Neural networks as representation learning
One important and powerful aspect of the deep learn-
ing paradigm is the ability to learn relevant features
of the data with relatively little domain knowledge, i.e.
with minimal hand-crafting. Often, the power of deep
learning stems from its ability to act like a black box
that can take in a large stream of data and ﬁnd good
features that capture properties of the data we are in-
terested in. This ability to learn good representations
with very little hand-tuning is one of the most attractive
properties of DNNs. Many of the other supervised learn-
ing algorithms discussed here (regression-based models,
ensemble methods such as random forests or gradient-
boosted trees) perform comparably or even better than
neural networks but when using hand-crafted features
with small-to-intermediate sized datasets.
The hierarchical structure of deep learning models is
thought to be crucial to their ability to represent com-
plex, abstract features. For example, consider the use
of CNNs for image classiﬁcation tasks. The analysis of
CNNs suggests that the lower-levels of the neural net-
works learn elementary features, such as edge detectors,
which are then combined into higher levels of the net-
works into more abstract, higher-level features (e.g. the
famous example of a neuron that “learned to respond to
cats”) (Le, 2013). More recently, it has been shown that
CNNs can be thought of as performing tensor decompo-
sitions on the data similar to those commonly used in
numerical methods in modern quantum condensed mat-
ter (Cohen et al., 2016).
One of the interesting consequences of this line of
thinking is the idea that one can train a CNN on one
largedatasetandthefeaturesitlearnsshouldalsobeuse-
ful for other supervised tasks. This results in the ability
to learn important and salient features directly from the
data and then transfer this knowledge to a new task. In-
deed, this ability to learn important, higher-level, coarse-
grained features is reminiscent of ideas like the renormal-
ization group (RG) in physics where the RG ﬂows sep-
arate out relevant and irrelevant directions, and certain
unsupervised deep learning architectures have a natural
interpretationintermsofvariationalRGschemes(Mehta
and Schwab, 2014).
2. Neural networks can exploit large amounts of data
Withtheadventofsmartphonesandtheinternet,there
has been an explosion in the amount of data being gen-
erated. This data-rich environment favors supervised
learning methods that can fully exploit this rich data
world. One important reason for the success of DNNs
is that they are able to exploit the additional signal in
largedatasetsfordiﬃcultsupervisedlearningtasks. Fun-
damentally, modern DNNs are unique in that they con-
62
Amount of DataPerformanceLarge NN
Medium NN
Small NN
Traditional 
(e.g. logistic reg)Small
data
regime 
FIG. 47Large neural networks can exploit the vast
amount of data now available. Schematic of how neural
network performance depends on amount of available data
(Figure based on Andrew Ng’s talk at the 2016 Deep Learn-
ing School available at https://www.youtube.com/watch?v=
F1ka6a13S9I .)
tain millions of parameters, yet can still be trained on
existing hardwares. The complexity of DNNs (in terms
of parameters) combined with their simple architecture
(layer-wise connections) hit a sweet spot between expres-
sivity (ability to represent very complicated functions)
and trainability (ability to learn millions of parameters).
Indeed, the ability of large DNNs to exploit huge
datasets is thought to diﬀer from many other commonly
employed supervised learning methods such as Support
Vector Machines (SVMs). Figure 47 shows a schematic
depicting the expected performance of DNNs of diﬀer-
ent sizes with the number of data samples and compares
them to supervised learning algorithms such as SVMs or
ensemble methods. When the amount of data is small,
DNNs oﬀer no substantial beneﬁt over these other meth-
ods and often perform worse. However, large DNNs seem
to be able to exploit additional data in a way other meth-
ods cannot. The fact that one does not have to hand
engineer features makes the DNN even more well suited
for handling large datasets. Recent theoretical results
suggest that as long as a DNN is large enough, it should
generalize well and not overﬁt (Advani and Saxe, 2017).
In the data-rich world we live in (at least in the context
of images, videos, and natural language), this is a recipe
for success. In other areas where data is more limited,
deeplearningarchitectureshave(atleastsofar)beenless
successful.3. Neural networks scale up well computationally
A ﬁnal feature that is thought to underlie the success
of modern neural networks is that they can harness the
immense increase in computational capability that has
occurred over the last few decades. The architecture of
neural networks naturally lends itself to parallelization
and the exploitation of fast but specialized processors
such as graphical processing units (GPUs). Google and
NVIDIA set on a course to develop TPUs (tensor pro-
cessing units) which will be speciﬁcally designed for the
mathematical operations underlying deep learning archi-
tectures. Thelayeredarchitectureofneuralnetworksalso
makesiteasytousemoderntechniquessuchasautomatic
diﬀerentiation that make it easy to quickly deploy them.
Algorithms such as stochastic gradient descent and the
use of mini-batches make it easy to parallelize code and
trainmuchlargerDNNsthanwasthoughtpossibleﬁfteen
years ago. Furthermore, many of these computational
gainsarequicklyincorporatedintomodernpackageswith
industrial resources. This makes it easy to perform nu-
merical experiments on large datasets, leading to further
engineering gains.
C. Limitations of supervised learning with deep networks
Like all statistical methods, supervised learning using
neural networks has important limitations. This is es-
pecially important when one seeks to apply these meth-
ods, especially to physics problems. Like all tools, DNNs
are not a universal solution. Often, the same or better
performance on a task can be achieved by using a few
hand-engineered features (or even a collection of random
features). This is especially important for hard physics
problems where data (or Monte-Carlo samples) may be
hard to come by.
Here we list some of the important limitations of su-
pervised neural network based models.
•Need labeled data.— Like all supervised learn-
ing methods, DNNs for supervised learning require
labeled data. Often, labeled data is harder to ac-
quire than unlabeled data (e.g. one must pay for
human experts to label images).
•Supervised neural networks are extremely
data intensive.— DNNs are data hungry. They
perform best when data is plentiful. This is doubly
so for supervised methods where the data must also
be labeled. The utility of DNNs is extremely lim-
ited if data is hard to acquire or the datasets are
small (hundreds to a few thousand samples). In
this case, the performance of other methods that
utilize hand-engineered features can exceed that of
DNNs.
63
•Homogeneous data.— Almost all DNNs deal
with homogeneous data of one type. It is very hard
to design architectures that mix and match data
types (i.e. some continuous variables, some discrete
variables, sometimeseries). Inapplicationsbeyond
images, video, and language, this is often what is
required. In contrast, ensemble models like random
forests or gradient-boosted trees have no diﬃculty
handling mixed data types.
•Many physics problems are not about
prediction.— In physics, we are often not inter-
ested in solving prediction tasks such as classiﬁ-
cation. Instead, we want to learn something about
theunderlyingdistributionthatgeneratesthedata.
In this case, it is often diﬃcult to cast these ideas in
a supervised learning setting. While the problems
are related, it’s possible to make good predictions
with a “wrong” model. The model might or might
not be useful for understanding the physics.
Some of these remarks are particular to DNNs, oth-
ers are shared by all supervised learning methods. This
motivates the use of unsupervised methods which in part
circumnavigate these problems.
XII. DIMENSIONAL REDUCTION AND DATA
VISUALIZATION
Unsupervised learning is concerned with discovering
structure in unlabeled data. In this section, we will be-
gin our foray into unsupervised learning by way of data
visualization. Data visualization methods are important
for modeling as they can be used to identify correlated or
redundant features along with irrelevant features (noise)
from raw or processed data. Conceivably, being able to
identify and capture such characteristics in a dataset can
help in designing better predictive models. For data in-
volving a relatively small number of features, studying
pair-wise correlations (i.e. pairwise scatter plots of all
features) may suﬃce in performing a complete analysis.
This rapidly becomes impractical for datasets involving
a large number of measured featured (such as images).
Thus, in practice, we often have to perform dimensional
reduction , namely, projectorembedthedataontoalower
dimensional space, which we refer to as the latent space .
As we will discuss, part of the complication of dimen-
sional reduction lies in the fact that low-dimensional rep-
resentations of high-dimensional data necessarily incurs
information lost. Below, we introduce some common lin-
ear and nonlinear methods for performing dimensional
reduction with applications in data visualization of high-
dimensional data.A. Some of the challenges of high-dimensional data
Before we begin exploring some speciﬁc dimensional
reduction techniques, it is useful to highlight some of the
generic diﬃculties encountered when dealing with high-
dimensional data.
a. High-dimensional data lives near the edge of sample space.
Geometry in high-dimensional space can be counterintu-
itive. One example that is pertinent to machine learning
is the following. Consider data distributed uniformly at
random in a D-dimensional hypercube C= [ e=2;e=2]D,
whereeistheedgelength. Consideralsoa D-dimensional
hypersphereSof radiuse=2centered at the origin and
contained within C. The probability that a data point x
drawn uniformly at random in Cis contained within S
is well approximated by the ratio of the volume of Sto
that ofC:p(kxk2< e= 2)(1=2)D. Thus, as the di-
mension of the feature space Dincreases,pgoes to zero
exponentially fast. In other words, most of the data will
concentrate outside the hypersphere, in the corners of
the hypercube. In physics, this basic observation under-
lies many properties of ideal gases such as the Maxwell
distribution and the equipartition theorem (see Chapter
3 of (Sethna, 2006) for instance).
b. Real-world data vs. uniform distribution. Fortunately,
real-world data is not random or uniformly distributed!
In fact, real data usually lives in a much lower dimen-
sional space than the original space in which the fea-
tures are being measured. This is sometimes referred to
as the “blessing of non-uniformity” (in opposition to the
curse of dimensionality). Data will typically be locally
smooth, meaning that a local variation of the data will
not incur a change in the target variable (Bishop, 2006).
This idea is central to statistical physics and ﬁeld the-
ories, where properties of systems with an astronomical
number of degrees of freedom can be well characterized
by low-dimensional “order parameters” or eﬀective de-
grees of freedom. Another instantiation of this idea is
manifest in the description of the bulk properties of a
gas of weakly interacting particles, which can be sim-
ply described by the thermodynamic variables (temper-
ature, pressure, etc.) that enter the equation of state
rather than the enormous number of dynamical variables
(i.e. position and momentum) of each particle in the gas.
c. Intrinsic dimensionality and the crowding problem. Are-
current objective of dimensional reduction techniques is
topreservetherelativepairwisedistances(ordeﬁnedsim-
ilarities) between data points from the original space to
the latent space. This is a natural requirement, since
we would like for nearby data points (as measured in the
64
a)b)
FIG. 48 The “Swiss roll”. Data distributed in a three-
dimensional space (a) that can eﬀectively be described on a
two-dimensional surface (b). A common goal of dimensional
reduction techniques is to preserve ordination in the data:
points that are close-by in the original space are also near-by
in the mapped (latent) space. This is true of the mapping (a)
to (b) as can be seen by inspecting the color gradient.
originalspace)toremainclose-byafterthecorresponding
mapping to the latent space.
Consider the example of the “Swiss roll” presented in
FIG. 48a. There, the relevant structure of the data cor-
responds to nearby points with similar colors and is en-
coded in the “unrolled” data in the latent space, see FIG.
48b. Clearly, in this example a two-dimensional space
is suﬃcient to capture almost the entirety of the infor-
mation in the data. A concept which stems from signal
processing that is relevant to our current exposition is
that of the intrinsic dimensionality of the data. Quali-
tatively, it refers to the minimum number of dimensions
required to capture the signal in the data. In the case
of the Swiss roll, it is 2 since the Swiss roll can eﬀec-
tively be parametrized using only two parameters, i.e.
X2f(x1sin(x1);x1cos(x1);x2)g. The minimum num-
ber of parameters required for such a parametrization is
theintrinsic dimensionality of the data (Bennett, 1969).
Attempting to represent data in a space of dimension-
ality lower than its intrinsic dimensionality can lead to
a “crowding” problem (Maaten and Hinton, 2008) (see
schematic, FIG. 49). In short, because we are attempting
to satisfy too many constraints (e.g. preserve all relative
distancesoftheoriginalspace), thisresultsinatrivialso-
lution for the latent space where all mapped data points
collapse to the center of the map.
To alleviate this, one needs to weaken the constraints
imposed on the visualization scheme. Powerful methods
such as t-distributed stochastic embedding (Maaten and
Hinton, 2008) (in short, t-SNE, see section XII.D) and
uniformmanifoldapproximationandprojection(UMAP)
(McInnes et al., 2018) have been devised to circumvent
this issue in various ways.
2D1DFIG. 49 Illustration of the crowding problem. (Left) A two-
dimensional dataset Xconsisting of 3 equidistant points.
(Right) Mapping Xto a one-dimensional space while try-
ing to preserve relative distances leads to a collapse of the
mapped data points.
B. Principal component analysis (PCA)
A ubiquitous method for dimensional reduction, data
visualization and analysis is Principal Component Anal-
ysis (PCA). The goal of PCA is to perform an orthog-
onal transformation of the data in order to ﬁnd high-
variance directions. PCA is inspired by the observation
that in many cases, the relevant information in a signal
is contained in the directions with largest13variance (see
FIG. 50). Directions with small variance are ascribed to
“noise” and can potentially be removed or ignored.
noisesignal
FIG. 50 PCA seeks to ﬁnd the set of orthogonal directions
with largest variance. This can be seen as “ﬁtting” an ellipse
to the data with the major axis corresponding to the ﬁrst
principal component (direction of largest variance). PCA as-
sumes that directions with large variance correspond to the
true signal in the data while directions with low variance cor-
respond to noise.
13This assumes that the features are measured and compared using
the same units.
65
FIG. 51 (a) The ﬁrst 2 principal component of the Ising
dataset with temperature indicated by the coloring. PCA
was performed on a joined dataset of 1000 samples taken at
each temperatures T= 0:25;0:5;;4:0. Almost all the vari-
ance is explained in the ﬁrst component which corresponds
to the magnetization order parameter (linear combination of
the features with weights all roughly equal). The paramag-
netic phase corresponds to the middle cluster and the left and
right clusters correspond to the symmetry-related ferromag-
netic phases (b) Log of the spectrum of the covariance matrix
versus rank ordering. Only one dimension has high-variance.
Surprisingly, such PCA-based projections often cap-
ture a lot of the large scale structure of many datasets.
For example, Figure 51 shows the projection of samples
drawn from the 2D Ising model at various temperatures
on the ﬁrst two principal components. Despite living in
a1600dimensional space (the samples are 4040spin
conﬁgurations), a single principal component (i.e. a sin-
gle direction in this 1600 dimensional space) can cap-
ture 50% of the variability contained in our samples.
In fact, one can verify that this direction weights all
1600spins nearly equally and thus corresponds to the
magnetization order parameter. Thus, even without any
prior physical knowledge, one can extract relevant order
parameters using a simple PCA-based projection. Re-cently, a correspondence between PCA and Renormal-
ization Group ﬂows across the phase transition in the 2D
Ising model (Foreman et al., 2017) and in a more general
setting (Bradde and Bialek, 2017) has been proposed.
In statistical physics, PCA has also found application
in detecting phase transitions (Wetzel, 2017), e.g. in the
XY model on frustrated triangular and union jack lat-
tices (Wang and Zhai, 2017). PCA was also used to clas-
sify dislocation patterns in crystals (Papanikolaou et al.,
2017; Wang and Zhai, 2018), and to ﬁnd correlations in
the shear ﬂow of athermal amorphous solids (Ruscher
and Rottler, 2018). PCA is widely employed in biolog-
ical physics when working with high-dimensional data.
Physics has also inspired PCA-based algorithms to infer
relevant features in unlabelled data (Bény, 2018). Con-
cretely, consider Ndata points,fx1;:::xNgthat live in
ap-dimensional feature space Rp. Without loss of gener-
ality, we assume that the empirical mean x=N 1P
ixi
of these data points is zero14. Denote the Npdesign
matrixasX= [x1;x2;:::;xN]Twhoserowsarethedata
points and columns correspond to diﬀerent features. The
pp(symmetric) covariance matrix is therefore
(X) =1
N 1XTX: (129)
Notice that the j-th diagonal entry of (X)corresponds
to the variance of the j-th feature and (X)ijmeasures
the covariance (i.e. connected correlation in the language
of physics) between feature iand feature j.
We are interested in ﬁnding a new basis for the data
that emphasizes highly variable directions while reducing
redundancy between basis vectors. In particular, we will
look for a linear transformation that reduces the covari-
ance between diﬀerent features. To do so, we ﬁrst per-
form singular value decomposition (SVD) on the design
matrixX, namely,X=USVT, whereSis a diagonal
matrix of singular value si, the orthogonal matrix Ucon-
tains (as its columns) the left singular vectors of X, and
similarlyVcontains (as its columns) the right singular
vectors ofX. With this, one can rewrite the covariance
matrix as
(X) =1
N 1VSUTUSVT
=VS2
N 1
VT
VVT: (130)
where is a diagonal matrix with eigenvalues iin the
decreasing order along the diagonal (i.e. eigendecompo-
sition). It is clear that the right singular vectors of X
(i.e. the columns of V) are principal directions of (X),
14We can always center around the mean: x xi x
66
and the singular values of Xare related to the eigenval-
ues of the covariance matrix (X)viai=s2
i=(N 1).
To reduce the dimensionality of data from pto~p<p, we
ﬁrstconstructthe p~pprojectionmatrix ~Vp0by selecting
the singular components with the ~plargest singular val-
ues. The projection of the data from pto a~pdimensional
space is simply ~Y=X~Vp0. The same idea is central
to matrix-product-state-like techniques used to compress
the number of components in quantum wavefunctions in
studies of low-dimensional many-body lattice systems.
The singular vector with the largest singular value (i.e
the largest variance) is referred to as the ﬁrst principal
component; the singular vector with the second largest
singular value as the second principal component, and so
on. An important quantity is the ratio i=Pp
i=1iwhich
is referred as the percentage of the explained variance
contained in a principal component (see FIG. 51.b).
It is common in data visualization to present the data
projected on the ﬁrst few principal components. This is
valid as long as a large part of the variance is explained
in those components. Low values of explained variance
may imply that the intrinsic dimensionality of the data is
high or simply that it cannot be captured by a linear rep-
resentation. For a detailed introduction to PCA, see the
tutorials by Shlens (Shlens, 2014) and Bishop (Bishop,
2006).
C. Multidimensional scaling
Multidimensionalscaling(MDS)isanon-lineardimen-
sional reduction technique which preserves the pairwise
distance or dissimilarity dijbetween data points (Cox
and Cox, 2000). Moving forward, we use the term “dis-
tance” and“dissimilarity” interchangeably. Therearetwo
types of MDS: metric and non-metric. In metric MDS,
the distance is computed under a pre-deﬁned metric and
the latent coordinates ~Yare obtained by minimizing the
diﬀerence between the distance measured in the original
space (dij(X)) and that in the latent space ( dij(Y)):
~Y= arg min
YX
i<jwijjdij(X) dij(Y)j;(131)
wherewij0are weight values. The weight matrix wij
is a set of free parameters that specify the level of conﬁ-
dence (or precision) in the value of dij(X). If Euclidean
metric is used, MDS gives the same result as PCA and is
usually referred to as classical scaling (Torgerson, 1958).
ThusMDSisoftenconsideredasageneralizationofPCA.
In non-metric MDS, dijcan be any distance matrix. The
objective function is then to preserve the ordination in
the data, i.e. if d12(X)< d13(X)in the original space,
theninthelatentspaceweshouldhave d12(Y)<d13(Y).
Both MDS and PCA can be implemented using stan-
dard Python packages such as Scikit. MDS algorithms
typically have a scaling of O(N3)whereNcorrespondsto the number of data points, and are thus very limited
in their application to large datasets. However, sample-
based methods have been introduce to reduce this scaling
toO(NlogN)(Yanget al., 2006). In the case of PCA,
a complete decomposition has a scaling of O(Np2+p3),
wherepis the number of features. Note that the ﬁrst
termNp2is due to the computation of covariance ma-
trix Eq.(129) while the second, p3, stems from eigenvalue
decomposition. NothethatPCAcanbeimprovedtobear
complexityO(Np2+p)if only the ﬁrst few principal com-
ponents are desired (using iterative approaches). PCA
and MDS are often among the ﬁrst data visualization
techniques one resorts to.
D. t-SNE
It is often desirable to preserve local structures in
high-dimensional datasets. However, when dealing with
datasets having clusters delimitated by complicated sur-
faces or datasets with a large number of clusters, preserv-
ing local structures becomes diﬃcult using linear tech-
niques such as PCA. Many non-linear techniques such as
non-classical MDS (Cox and Cox, 2000), self-organizing
map (Kohonen, 1998), Isomap (Tenenbaum et al., 2000)
and Locally Linear Embedding (Roweis and Saul, 2000)
have been proposed and to address this class of problems.
These techniques are generally good at preserving local
structures in the data but typically fail to capture struc-
tures at the larger scale such as the clusters in which the
data is organized (Maaten and Hinton, 2008).
Recently,t-stochasticneighborembedding(t-SNE)has
emerged as one of the go-to methods for visualizing high-
dimensional data. It has been shown to oﬀer insight-
ful visualization for many benchmark high-dimensional
datasets (Maaten and Hinton, 2008). t-SNE is a non-
parametric15method that constructs non-linear embed-
dings. Each high-dimensional training point is mapped
tolow-dimensionalembeddingcoordinates, whichareop-
timized in a way to preserve the local structure in the
data.
When used appropriately, t-SNE is a powerful tech-
nique for unraveling the hidden structure of high-
dimensional datasets while at the same time preserv-
ing locality. In physics, t-SNE has recently been used
to reduce the dimensionality and classify spin conﬁgu-
rations, generated with the help of Monte Carlo sim-
ulations, for the Ising (Carrasquilla and Melko, 2017)
andFermi-Hubbardmodelsatﬁnitetemperatures(Ch’ng
et al., 2017). It was also applied to study clustering tran-
sitions in glass-like problems in the context of quantum
15It does not explicitly parametrize feature extraction required to
compute the embedding coordinates. Thus it cannot be applied
to ﬁnd the coordinate of new data points.
67
control (Day et al., 2019).
The idea of stochastic neighbor embedding is to asso-
ciate a probability distribution to the neighborhood of
each data (note x2Rp,pis the number of features):
pijj=exp( jjxi xjjj2=22
i)P
k6=iexp( jjxi xkjj2=22
i);(132)
wherepijjcan be interpreted as the likelihood that xjis
xi’s neighbor (thus we take piji= 0).iare free band-
width parameters that are usually determined by ﬁxing
the local entropy H(pi)of each data point:
H(pi) X
jpjjilog2pjji: (133)
Thelocalentropyisthensettoequalaconstantacross all
data points  = 2H(pi), where is called the perplexity .
The perplexity constraint determines i8iand implies
that points in regions of high-density will have smaller
i.
Using Gaussian likelihoods in pijjimplies that only
points that are nearby xicontribute to its probability
distribution. While this ensures that the similarity for
nearby points is well represented, this can be a prob-
lem for points that are far away from xi(i.e. outliers):
they have exponentially vanishing contributions to the
distribution, which in turn means that their embedding
coordinates are ambiguous (Maaten and Hinton, 2008).
One way around this is to deﬁne a symmetrized distri-
butionpij(pijj+pjji)=(2N). Thisguarantees thatP
jpij>1=(2N)for all data points xi, resulting in each
data point ximaking a signiﬁcant contribution to the
cost function to be deﬁned below.
t-SNE constructs a similarprobability distribution qij
in a low dimensional latent space (with coordinates Y=
fyig; yi2Rp0, wherep0<pis the dimension of the latent
space):
qij=(1 +jjyi yjjj2) 1
P
k6=i(1 +jjyi ykjj2) 1:(134)
The crucial point to note is that qijis chosen to be a long
tail distribution. This preserves short distance informa-
tion(relativeneighborhoods)whilestronglyrepellingtwo
points that are far apart in the original space (see FIG.
52). In order to ﬁnd the latent space coordinates yi, t-
SNE minimizes the Kullback-Leibler divergence between
qijandpij:
C(Y) =DKL(pjjq)X
ijpijlogpij
qij
:(135)
This minimization is done via gradient descent (see sec-
tion IV). We can gain further insights on what the em-
bedding cost-function Cis capturing by computing thegradient of (135) with respect to yiexplicitly:
@yiC=X
j6=i4pijqijZi(yi yj) X
j6=i4q2
ijZi(yi yj);
=Fattractive;i Frepulsive;i; (136)
whereZi= 1=(P
k6=i(1 +jjyk yijj2) 1). We have sepa-
rated the gradient of point yiinto an attractive Fattractive
and repulsive term Frepulsive. Notice that Fattractive;iin-
duces a signiﬁcant attractive force only between points
that are nearby point iin theoriginal space since it in-
volves thepijterm. Finding the embedding coordinates
yiis thus equivalent to ﬁnding the equilibrium conﬁgura-
tion of particles interacting through the forces in (136).
x1y1x2y2
qpshort-taillong-taily1y2x2x1x0,y0yi= arg miny|p(xi) q(y)|
FIG. 52 Illustration of the t-SNE embedding. xipoints cor-
respond to the original high-dimensional points while the yi
points are the corresponding low-dimensional map points pro-
duced by t-SNE. Here we consider two points, x1,x2, that are
respectively “close” and “far” from x0. The high-dimensional
Gaussian (short-tail) distribution p(x)ofx0’s neighbors is
shown in blue. The low-dimensional Cauchy (fat-tail) distri-
butionq(y)ofx0’s neighbors is shown in red. The map point
yi, are obtained by minimizing the diﬀerence jq(y) p(xi)j
(similar to minimizing the KL divergence). We see that point
x1ismappedtoshortdistances jy1 y0j. Incontrast, far-away
points such as x2are mapped to relatively large distances
jy2 y0j.
Below, we list some important properties that one
should bear in mind when analyzing t-SNE plots.
•t-SNE can rotate data . The KL divergence is in-
variant under rotations in the latent space, since it
only depends on the distance between points. For
this reason, t-SNE plots that are rotations of each
other should be considered equivalent.
•t-SNE results are stochastic . In applying gradient
descent the solution will depend on the initial seed.
Thus, themapobtainedmayvarydependingonthe
seed used and diﬀerent t-SNE runs will give slightly
diﬀerent results.
68
•t-SNE generally preserves short distance informa-
tion. As a rule of thumb, one should expect that
nearby points on the t-SNE map are also closeby in
the original space, i.e. t-SNE tends to preserve or-
dination (but not actual distances). For a pictorial
explanation of this, we refer the reader to Figure
52.
•Scales are deformed in t-SNE .Sinceascale-freedis-
tribution is used in the latent space, one should not
put too much emphasis on the meaning of the size
of any clusters observed in the latent space.
•t-SNE is computationally intensive . Finally, a
direct implementation of t-SNE has an algorith-
mic complexity of O(N2)which is only appli-
cable to small to medium data sets. Improved
scaling of the form O(NlogN)can be achieved
at the cost of approximating Eq. (135) by us-
ing the Barnes-Hut method (Van Der Maaten,
2014) forN-body simulations (Barnes and Hut,
1986). More recently extremely eﬃcient t-
SNE implementation making use of fast Fourier
transforms for kernel summations in (136) have
been made available on https://github.com/
KlugerLab/FIt-SNE (Linderman et al., 2017).
As an illustration, in Figure 53 we applied t-SNE to
a Gaussian mixture model consisting of thirty Gaus-
sians, whose means are uniformly distributed in forty-
dimensional space. We compared the results to a random
two-dimensional projection and PCA. It is clear that un-
like more naïve dimensional reduction techniques, both
PCA and t-SNE can identify the presence of well-formed
clusters. The t-SNE visualization cleanly separates all
the clusters while certain clusters blend together in the
PCA plot. This is a direct consequence of the fact that
t-SNE keeps nearby points close together while repelling
points that are far apart.
Figure 54 shows t-SNE and PCA plots for the MNIST
dataset of ten handwritten numerical digits (0-9). It is
clear that the non-linear nature of t-SNE makes it much
better at capturing and visualizing the complicated cor-
relations between digits, compared to PCA.
XIII. CLUSTERING
In this section, we continue our discussion of unsuper-
vised learning methods. Unsupervised learning is con-
cerned with discovering structure in unlabeled data (for
instance learning local structures for data visualization,
see section XII). The lack of labels make unsupervised
learning much more diﬃcult and subtle than its super-
vised counterpart. What is somewhat surprising is that
even without labels it is still possible to uncover and ex-
ploit the hidden structure in the data. Perhaps, the sim-
plest example of unsupervised learning is clustering. The
FIG.53 DiﬀerentvisualizationsofaGaussianmixtureformed
ofK= 30mixtures in a D= 40dimensional space. The
Gaussians have the same covariance but have means drawn
uniformly at random in the space [ 10;10]40. (a) Plot of the
ﬁrst two coordinates. The labels of the diﬀerent Gaussian is
indicated by the diﬀerent colors. Note that in a realistic set-
ting, label information is of course not available, thus making
it very hard to distinguish the diﬀerent clusters. (b) Random
projection of the data onto a 2 dimensional space. (c) pro-
jection onto the ﬁrst 2 principal components. Only a small
fraction of the variance is explained by those components (the
ratio is indicated along the axis). (d) t-SNE embedding (per-
plexity = 60, #iteration = 1000) in a 2 dimensional latent
space. t-SNE captures correctly the local structure of the
data.
FIG.54 VisualizationoftheMNISThandwrittendigitstrain-
ing dataset (here N= 60000 ). (a) First two principal
components. (b) t-SNE applied with a perplexity of 30,
a Barnes-Hut angle of 0.5 and 1000 gradient descent iter-
ations. In order to reduce the noise and speed-up compu-
tation, PCA was ﬁrst applied to the dataset to project it
down to 40 dimensions. We used an open-source implemen-
tation to produce the results (Linderman et al., 2017), see
https://github.com/KlugerLab/FIt-SNE .
69
aim of clustering is to group unlabelled data into clusters
according to some similarity or distance measure. Infor-
mally, a cluster is thought of as a set of points sharing
some pattern or structure.
Clustering ﬁnds many applications throughout data
mining (Larsen and Aone, 1999), data compression and
signal processing (Gersho and Gray, 2012; MacKay,
2003). Clustering can be used to identify coarse features
or high level structures in an unlabelled dataset. The
technique also ﬁnds many applications in physical sci-
ences, ranging from detecting celestial emission sources
in astronomical surveys (Sander et al., 1998) to inferring
groups of genes and proteins with similar functions in
biology (Eisen et al., 1998), and building entanglement
classiﬁers (Lu et al., 2017). Clustering is perhaps the
simplest way to look for hidden structure in a dataset
and for this reason, is among the most widely used and
employed data analysis and machine learning techniques.
The ﬁeld of clustering is vast and there exists a
ﬂurry of clustering methods suited for diﬀerent purposes.
Some common considerations one has to take into ac-
count when choosing a particular method is the distribu-
tion of the clusters (overlapping/noisy clusters vs. well-
separated clusters), the geometry of the data (ﬂat vs.
non-ﬂat), the cluster size distribution (multiple sizes vs.
uniform sizes), the dimensionality of the data (low vs.
highdimensional)andthecomputationaleﬃciencyofthe
desired method (small vs. large dataset).
We begin section XIII.A with a focus on popular prac-
tical clustering methods such as K-means clustering, hi-
erarchical clustering and density clustering. Our goal is
to highlight the strength, weaknesses and diﬀerences be-
tweenthesetechniques, whilelayingoutsomeofthetheo-
retical framework required for clustering analysis. There
exist many more clustering methods beyond those dis-
cussed in this section16. The methods we discuss were
chosen for their pedagogical value and/or their applica-
bility to problems in physics.
In section XIII.B we discuss gaussian mixture models
and the formulation of clustering through latent variable
models. This section introduces many of the methods we
will encounter when discussing other unsupervised learn-
ingmethodslaterinthereview. Finally, insectionXIII.C
we discuss the problem of clustering in high-dimensional
data and possible ways to tackle this diﬃcult problem.
The reader is also urged to experiment with various clus-
tering methods using Notebook 15.
16Our complementary Python notebook introduces some of these
other methods.A. Practical clustering methods
Throughout this section we focus on the Euclidean dis-
tance as a similarity measure. Other measures may be
better suited for speciﬁc problems. We refer the enthusi-
ast reader to (Rokach and Maimon, 2005) for a more in-
depth discussion of the diﬀerent possible similarity mea-
sures.
1.K-means
We begin our discussion with K-means clustering since
this method is simple to implement and understand, and
covers the core concepts of clustering. Consider a set of
Nunlabelled observationsfxngN
n=1where xn2Rpand
wherepis the number of features. Also consider a set
ofKcluster centers called the cluster means:fkgK
k=1,
withk2Rp, which we’ll compute “emperically" in the
cluserting procedure. The cluster means can be thought
of as the representatives of each cluster, to which data
points are assigned (see FIG. 55). K-means clustering
canbeformulatedasfollows: givenaﬁxedinteger K, ﬁnd
the cluster means fgand the data point assignments in
order to minimize the following objective function:
C(fx;g) =KX
k=1NX
n=1rnk(xn k)2;(137)
wherernk2f0;1gis a binary variable called the assign-
ment. The assignment rnkis 1 ifxnis assigned to cluster
kand 0 otherwise. Notice thatP
krnk= 18nandP
nrnkNk, whereNkthe number of points assigned
to clusterk. The minimization of this objective func-
tion can be understood as trying to ﬁnd the best cluster
means such that the variance within each cluster is min-
imized. In physical terms, Cis equivalent to the sum of
the moments of inertia of every cluster. Indeed, as we
will see below, the cluster means kcorrespond to the
centers of mass of their respective cluster.
K-means algorithm. TheK-means algorithm alter-
nates between two steps:
1.Expectation : Given a set of assignments frnkg,
minimizeCwith respect to k. Taking a simple
derivative and setting it to zero yields the follow-
ing update rule:
k=1
NkX
nrnkxn: (138)
2.Maximization : Given a set of cluster means fkg,
ﬁnd the assignments frnkgwhich minimizes C.
70
Clearly, this is achieved by assigning each data
point to their nearest cluster-mean:
rnk=(
1ifk= arg mink0(xn k0)2
0otherwise(139)
K-means clustering consists in alternating between these
two steps until some convergence criterion is met. Practi-
cally, the algorithm should terminate when the change in
the objective function from one iteration to another be-
comes smaller than a pre-speciﬁed threshold. A simple
example of K-means is presented in FIG. 55.
C=10.5,t=1 a)
C=8.8,t=10 b)
C=8.0,t=20 c)
0 10 20
t8.08.59.09.510.010.5 d)
C
FIG. 55K-means with K= 3applied to an artiﬁcial two-
dimensional dataset. The cluster means at each iteration are
indicated by cyan star markers. tindicates the iteration num-
ber andCthe value of the objective function. (a) The algo-
rithm is initialized by randomly partitioning the space into 3
sectors to generate an initial assignment. (b)-(c) For well sep-
arated clusters, the algorithm converges rapidly to the true
clusters. (d) The objective function as a function of the it-
eration.Cconverges after t= 18iterations for this choice of
random seed (for center initialization).
A nice property of the K-means algorithm is that it
is guaranteed to converge. To see this, one can verify
explicitly (by taking second-order derivatives) that the
expectation step always decreases C. This is also true for
the assignment step. Thus, since Cis bounded from be-
low, the two-step iteration of K-meansalwaysconverges
to a local minimum of C. SinceCis generally a non-
convex function, in practice one usually needs to run the
algorithm with diﬀerent initial random cluster center ini-
tializations and post-select the best local minimum. A
simple implementation of K-means has an average com-
putational complexity which scales linearly in the size ofthe data set (more speciﬁcally the complexity is O(KN)
per iteration) and is thus scalable to very large datasets.
As we will see in section XIII.B, K-means is a hard-
assignment limit of the Gaussian mixture model where
all cluster variances are assumed to be the same. This
highlights a common drawback of K-means: if the true
clusters have very diﬀerent variances (spreads), K-means
can lead to spurious results since the underlying assump-
tion is that the latent model has uniform variances.
2. Hierarchical clustering: Agglomerative methods
Agglomerative clustering is a bottom up approach that
starts from small initial clusters which are then progres-
sively merged to form larger clusters. The merging pro-
cess generates a hierarchy of clusters that can be visu-
alized in the form of a dendrogram (see FIG. 56). This
hierarchy can be useful to analyze the relation between
clusters and the subcomponents of individual clusters.
Agglomerative methods are usually speciﬁed by deﬁn-
ing a distance measure between clusters17. We denote
the distance between clusters XandYbyd(X;Y )2R.
Diﬀerent choices of distance result in diﬀerent clustering
algorithms. At each step, the two clusters that are the
closest with respect to the distance measure are merged
until a single cluster is left.
Agglomerative clustering algorithm Agglomerative
clustering algorithms can thus be summarized as follows:
1. Initialize each point to its own cluster.
2. Given a set of KclustersX1;X2;;XK, merge
clusters until one cluster is left ( K= 1):
(a) Find the closest pair of clusters (Xi;Xj):
(i;j) = arg min(i0;j0)d(Xi0;Xj0)
(b) Merge the pair. Update: K K 1
Here we list a few of the most popular distances used
in agglomerative methods, often called linkage methods
in the clustering literature.
1. Single-linkage: the distance between clusters iand
jis deﬁned as the minimum distance between two
elements of the diﬀerent clusters
d(Xi;Xj) = min
xi2Xi;xj2Xjjjxi xjjj2:(140)
2. Complete linkage: the distance between clusters i
andjis deﬁned as the maximum distance between
two elements of the diﬀerent clusters.
d(Xi;Xj) = max
xi2Xi;xj2Xjjjxi xjjj2(141)
17Note that this measure need not be a metric.
71
3. Average linkage: average distance between points
of diﬀerent clusters
d(Xi;Xj) =1
jXijjXjjX
xi2Xi;xj2Xjjjxi xjjj2(142)
4. Ward’s linkage: This distance measure is analogous
to theK-means method as it seeks to minimize the
total inertia. The distance measure is the “error
squared” before and after merging which simpliﬁes
to:
d(Xi;Xj) =jXijjXjj
jXi[Xjj(i j)2;(143)
wherejis the center of cluster j.
A common drawback of hierarchical methods is that
they do not scale well: at every step, a distance ma-
trix between all clusters must be updated/computed.
Eﬃcient implementations achieve a typical computa-
tional complexity of O(N2)(Müllner, 2011), making the
method suitable for small to medium-size datasets. A
simple but major speed-up for the method is to initial-
ize the clusters with K-means using a large K(but still
a small fraction of N) and then proceed with hierarchi-
cal clustering. This has the advantage of preserving the
large-scale structure of the hierarchy while making use of
the linear scaling of K-means. In this way, hierarchical
clustering may be applied to very large datasets.
3. Density-based (DB) clustering
Density clustering makes the intuitive assumption that
clusters are deﬁned by regions of space with higher den-
sity of data points. Data points that constitute noise or
that are outliers are expected to form regions of low den-
sity. Densityclusteringhastheadvantageofbeingableto
considerclustersofmultipleshapesandsizeswhileidenti-
fying outliers. The method is also suitable for large-scale
applications.
The core assumption of DB clustering is that a rel-
ativelocal density estimation of the data is possible.
In other words, it is possible to order points according
to their densities. Density estimates are usually accu-
rate for low-dimensional data but become unreliable for
high-dimensional data due to large sampling noise. Here,
for brevity, we conﬁne our discussion to one of the most
widely used density clustering algorithms, DBSCAN. We
have also had great success with another recently in-
troduced variant of DB clustering (Rodriguez and Laio,
2014) that is similar in spirit which the reader is urged
to consult. One of the authors (A. D.) has also created
a Python package, https://pypi.org/project/fdc/ ,
which makes use of accurate density estimates via ker-
nel methods combined with agglomerative clustering to
produce fast and accurate density clustering (see also
GitHub repository).
0.40.60.80.40.50.60.70.80.9012345a)
014523Leaf label0.000.050.100.150.200.250.30d(X, Y)b)FIG. 56 Hierarchical clustering example with single linkage.
(a)Thedatapointsaresuccessivelygroupedasdenotedbythe
colored dotted lines. (b) Dendrogram representation of the
hierarchical decomposition. Each node of the tree represents
a cluster. One has to specify a scale cut-oﬀ for the distance
measured(X;Y )(corresponding to a horizontal cut in the
dendrogram) in order to obtain a set of clusters.
DBSCAN algorithm. Here we describe the most
prominent DB clustering algorithm: DBSCAN, or
density-basedspatialclusteringofapplicationswithnoise
(Esteret al., 1996). Consider once again a set of Ndata
pointsXfxngN
n=1.
We start by deﬁning the "-neighborhood of point xn
as follows:
N"(xn) =fx2Xjd(x;xn)<"g:(144)
N"(xn)are the data points that are at a distance smaller
than"from xn. As before, we consider d(;)to be the
Euclidean metric (which yields spherical neighborhoods,
see Figure 57) but other metrics may be better suited
depending on the speciﬁc data. N"(xn)can be seen as a
crude estimate of local density. xnis considered to be a
core-point if at least minPts are in its"-neighborhood.
minPts is a free parameter of the algorithm that sets
the scale of the size of the smallest cluster one should
expect. Finally, a point xiis said to be density-reachable
if it is in the "-neighborhood of a core-point . From these
72
deﬁnitions, the algorithm can be simply formulated (see
also Figure 57):
!Until all points in Xhave been visited; do
 Pick a point xithat has not been visited
 Mark xias a visited point
 Ifxiis a core point; then
FindthesetCofallpointsthatare density
reachable fromxi.
Cnow forms a cluster. Mark all points
within that cluster as being visited.
!Return the cluster assignments C1;;Ck, withk
the number of clusters. Points that have not been
assigned to a cluster are considered noise or out-
liers.
Note that DBSCAN does not require the user to specify
the number of clusters but only "andminPts. While, it
is common to heuristically ﬁx these parameters, methods
such as cross-validation can be used for their determi-
nation. Finally, we note that DBSCAN is very eﬃcient
sinceeﬃcientimplementationshaveacomputationalcost
ofO(NlogN).
B. Clustering and Latent Variables via the Gaussian Mixture
Models
In the previous section, we introduced several practical
methods for clustering. In this section, we will approach
clustering from a more abstract vantage point, and in
the process, introduce many of the core ideas underlying
unsupervised learning. A central concept in many un-
supervised learning techniques is the idea of a latent or
hidden variable. Even though latent variables are not di-
rectly observable, they still inﬂuence the visible structure
of the data. For example, in the context of clustering we
can think of the cluster identity of each datapoint (i.e.
which clusterdoes a datapoint belong to) as a latent vari-
able. And even though we cannot see the cluster label
explicitly, we know that points in the same cluster tend
to be closer together. The latent variables in our data
(cluster identity) are a way of representing and abstract-
ing the correlations between datapoints.
In this language, we can think of clustering as an algo-
rithmtolearnthemostprobablevalueofalatentvariable
(cluster identity) associated with each datapoint. Calcu-
latingthislatentvariablerequiresadditionalassumptions
about the structure of our dataset. Like all unsuper-
vised learning algorithms, in clustering we must make
an assumption about the underlying probability distri-
bution from which the data was generated. Our model
for how the data is generated is called the generative
model. In clustering, we assume that data points are as-
signed a cluster, with each cluster characterized by some
LowHighRelative densitya)
b)minPts=4"FIG. 57 (a) Illustration of DBSCAN algorithm with
minPts = 4. Two"-neighborhood are represented as dashed
circles of radius ". Red points are the core points and
blue points are density-reachable point that are not core
points. Outliers are gray colored. (b) Application of DB-
SCAN (minPts=40) to a noisy dataset with two non-convex
clusters. Density proﬁle is shown for clarity. Outliers are
indicated by black crosses.
cluster-speciﬁc probability distribution (e.g. a Gaussian
with some mean and variance that characterizes the clus-
ter). We then specify a procedure for ﬁnding the value
of the latent variable. This is often done by choosing
the values of the latent variable that minimize some cost
function.
One common choice for a class of cost functions for
many unsupervised learning problems is Maximum Like-
lihood Estimation (MLE), see Secs. V and VI. In MLE,
wechoosethevaluesofthelatentvariablesthatmaximize
the likelihood of the observed data under our generative
model (i.e. maximize the probability of getting the ob-
73
served dataset under our generative model). Such MLE
equationsoftengiverisetothekindofExpectationMaxi-
mization (EM) equations that we ﬁrst encountered in the
last section in the context of K-means clustering.
Gaussian Mixtures models (GMM) are a generative
model often used in the context of clustering. In GMM,
points are drawn from one of KGaussians, each with its
own meankand covariance matrix k,
N(xj;)exp
 1
2(x ) 1(x )T
:(145)
Let us denote the probability that a point is drawn from
mixturekbyk. Then, the probability of generating a
pointxin a GMM is given by
p(xjfk;k;kg) =KX
k=1N(xjk;k)k:(146)
Given a dataset X=fx1;;xNg, we can write the
likelihood of the dataset as
p(Xjfk;k;kg) =NY
i=1p(xijfk;k;kg)(147)
For future reference, let us denote the set of parameters
(ofKGaussians in the model) fk;k;kgby.
To see how we can use GMM and MLE to perform
clustering, we introduce discrete binary K-dimensional
latent variables zfor each data point xwhosek-th com-
ponent is 1if pointxwas generated from the k-th Gaus-
sian and zero otherwise (these are often called “one-hot
variables”). For instance if we were considering a Gaus-
sian mixture with K= 3, we would have three possible
values forz(z1;z2;z3):(1;0;0);(0;1;0)and(0;0;1).
We cannot directly observe the variable z. It is a latent
variable that encodes the cluster identity of point x. Let
us also denote all the Nlatent variables corresponding
to a datasetXbyZ.
Viewing the GMM as a generative model, we can write
the probability p(xjz)of observing a data point xgiven
zas
p(xjz;fk;kg) =KY
k=1N(xjk;k)zk(148)
as well as the probability of observing a given value of
latent variable
p(zjfkg) =KY
k=1zk
k: (149)
Using Bayes’ rule, we can write the joint probability of
a clustering assignment zand a data point xgiven theGMM parameters as
p(x;z;) =p(xjz;fk;kg)p(zjfkg):(150)
We can also use Bayes rule to rearrange this expression
to give the conditional probability of the data point x
being in the k-th cluster, (zk), given model parameters
as
(zk)p(zk= 1jx;) =kN(xjk;k)PK
j=1jN(xjj;j):(151)
The(zk)are often referred to as the “responsibility”
that mixture ktakes for explaining x. Just like in our
discussion of soft-max classiﬁers, this can be made into
a “hard-assignment” by assigning each point to the clus-
ter with the largest probability: arg maxk(zk)over the
responsibilities.
The complication is of course that we do not know
the parameters of the underlying GMM but instead
must also learn them from the dataset X. As discussed
above, ideally we could do this by choosing the param-
eters that maximize the likelihood (or equivalently the
log-likelihood) of the data
^= arg max
logp(Xj) (152)
where=fk;k;kg. Once we know the MLEs ^, we
could use Eq. (151) to calculate the optimal hard cluster
assignment arg maxk^(zk)where ^(zk) =p(zk= 1jx;^).
In practice, due to the complexity of Eq. (147), it is
almost impossible to ﬁnd the global maximum of the like-
lihood function. Instead, we must settle for a local max-
imum. One approach to ﬁnding a local maximum of the
likelihood is to use a method like stochastic gradient de-
scent on the negative log-likelihood, cf. Sec IV. Here, we
introduce an alternative, powerful approach for ﬁnding
local minima in latent variable models using an iterative
procedure called Expectation Maximization (EM). Given
aninitialguessfortheparameters (0), theEMalgorithm
iteratively generates new estimates for the parameters
(1);(2);:::. Importantly, thelikelihoodisguaranteedto
be non-decreasing under these iterations and hence EM
converges to a local maximum of the likelihood (Neal and
Hinton, 1998).
The central observation underlying EM is that it is
often much easier to calculate the conditional likelihoods
of the latent variables ~p(t)(Z) =p(ZjX;(t))given some
choice of parameters, and the maximum of the expected
log likelihood given an assignment of the latent variables:
(t+1)= arg maxEp(ZjX;(t))[logp(X;Z;)]. To get an
intuition for this later quantity notice that we can write
74
E~p(t)[logp(X;Z;)] =NX
i=1KX
k=1(t)
ik[logN(xijk;k) + logk]; (153)
where we have used the shorthand (t)
ik=p(zikjX;(t))
withzikthek-th component of zi. Taking the derivative
of this equation with respect to k,k, andk(subject
to the constraintP
kk= 1) and setting this to zero
yields the intuitive equations
(t+1)
k=PN
i(t)
ikxiP
i(t)
ik
(t+1)
k=PN
i(t)
ik(xi k)(xi k)T
P
i(t)
ik
(t+1)
k=1
NX
k(t)
ik(154)
These are just the usual estimates for the mean and vari-
ance, with each data point weighed according to our cur-
rent best guess for the probability that it belongs to clus-
terk. We can then use our new estimate (t+1)to calcu-
late responsibility (t+1)
ikand repeat the process. This is
essentially the K-Means algorithm discussed in the ﬁrst
section.
This discussion of the Gaussian mixture model intro-
duces several concepts that we will return to repeatedly
in the context of unsupervised learning. First, it is often
usefultothinkofthevisiblecorrelationsbetweenfeatures
in the data as resulting from hidden or latent variables.
Second, we will often posit a generative model that en-
codes the structure we think exists in the data and then
ﬁnd parameters that maximize the likelihood of the ob-
served data. Third, often we will not be able to directly
estimate the MLE, and will have to instead look for a
computationally eﬃcient way to ﬁnd a local minimum of
the likelihood.
C. Clustering in high dimensions
Clustering data in high-dimension can be very chal-
lenging. One major problem that is aggravated in high-
dimensions is the generic accumulation of noise due to
random measurement error for each feature. This in turn
leads to increased errors for pairwise similarity and dis-
tance measures and thus tends to “blur” distances be-
tween data points (Domingos, 2012; Kriegel et al., 2009;
Zimeket al., 2012). Many clustering algorithms rely on
the explicit use of a similarity measure or distance met-
rics that weigh all features equally. For this reason, one
must be careful when using an oﬀ-the-shelf method in
high dimensions.
In order to perform clustering on high-dimensional
data, it is often useful to denoise the data before pro-
FIG. 58 (a) Application of gaussian mixture modelling to
the Ising dataset. The normalized histogram corresponds to
the ﬁrst principal component distribution of the dataset (or
equivalently the magnetization in this case). The 1D data
is ﬁtted with a K= 3-component gaussian mixture. The
likehood of the ﬁtted gaussian mixture is represented in red
and is obtained via the expectation-maximization algorithm
(b) The gaussian mixture model can be used to compute
posterior probability (responsibilities), i.e. the probability
of being in one of the phases. Note that the point where
(1) =(2) =(3)can be interpreted as the critical point.
Indeed the crossing occurs at T2:26.
ceeding with using a standard clustering method such as
K-means (Kriegel et al., 2009). Figure 54 illustrates an
application of denoising to high-dimensional data. PCA
(section XII.B) was used to denoise the MNIST dataset
by projecting the 784 original dimensions onto the 40 di-
mensions with the largest principal components. The re-
sulting features were then used to construct a Euclidean
distance matrix which was used by t-SNE to compute
75
the two-dimensional embedding that is presented. Using
t-SNE directly on original data leads to a “blurring” of
the clusters (the reader is encouraged to test this them-
selves).
However, simple feature selection or feature denoising
(using PCA for instance) can sometimes be insuﬃcient
for learning clusters due to the presence of large vari-
ations in the signal and noise of the features that are
relevant for identifying the underlying clusters (Kriegel
et al., 2009). Recent promising work suggests that one
way to overcome these limitations is to learn the latent
spaceandthe cluster labels at the same time (Xieet al.,
2016).
Finally we end the clustering section with a short dis-
cussion on clustering validation, which can be particu-
larly diﬃcult for high-dimensional data. Often clustering
validation, i.e. verifying whether the obtained labels are
“valid” is done by direct visual inspection. That is, the
data is represented in a low-dimensional space and the
cluster labels obtained are visually inspected to make
sure that diﬀerent labels organize into distinct “blobs”.
For high-dimensional data, this is done by performing
dimensional reduction (section XII). However, this can
lead to the appearance of spurious clusters since dimen-
sional reduction inevitably loses information about the
original data. Thus, these methods should be used with
care when trying to validate clusters [see (Wattenberg
et al., 2016) for an interactive discussion on how t-SNE
can sometime be misleading and how to eﬀectively use
it].
Alotofworkhasbeendonetodevisewaysofvalidating
clusters based on various metrics and measures (Kriegel
et al., 2009). Perhaps one of the most intuitive way of
deﬁning a good clustering is by measuring how well clus-
ters generalize. Clustering methods based on leveraging
powerful classiﬁers to measure the generalization errors
of the clusters have been developed by some of the au-
thors (Day and Mehta, 2018), see https://pypi.org/
project/hal-x/ . We believe this represents an espe-
cially promising research direction in high-dimensional
clustering. Finally, we emphasize that this discussion is
far from exhaustive and we refer the reader to (Rokach
and Maimon, 2005), Chapter 15, for an in-depth survey
of the various validation techniques.
XIV. VARIATIONAL METHODS AND MEAN-FIELD
THEORY (MFT)
Acommonthreadinmanyunsupervisedlearningtasks
is accurately representing the underlying probability dis-
tribution from which a dataset is drawn. Unsuper-
vised learning of high-dimensional, complex distributions
presents a new set of technical and computational chal-
lenges that are diﬀerent from those we encountered in
a supervised learning setting. When dealing with com-plicated probability distributions, it is often much easier
to learn the relative weights of diﬀerent states or data
points (ratio of probabilities), than absolute probabili-
ties. In physics, this is the familiar statement that the
weights of a Boltzmann distribution are much easier to
calculate than the partition function. The relative prob-
ability of two conﬁgurations, x1andx2, are proportional
to the diﬀerence between their Boltzmann weights
p(x1)
p(x2)= e (E(x1) E(x2)); (155)
where as is usual in statistical mechanics is the inverse
temperature and E(x;)is the energy of state xgiven
someparameters(couplings) . However, calculatingthe
absolute weight of a conﬁguration requires knowledge of
the partition function
Zp= Tr xe E(x); (156)
(where the trace is taken over all possible conﬁgurations
x) since
p(x) =e E(x)
Zp: (157)
In general, calculating the partition function Zpis ana-
lytically and computationally intractable.
For example, for the Ising model with Nbinary spins,
the trace involves calculating a sum over 2Nterms, which
is a diﬃcult task for most energy functions. For this rea-
son, physicists (and machine learning scientists) have de-
veloped various numerical and computational methods
for evaluating such partition functions. One approach
is to use Monte-Carlo based methods to draw samples
from the underlying distribution (this can be done know-
ing only the relative probabilities) and then use these
samples to numerically estimate the partition function.
This is the philosophy behind powerful methods such as
Markov Chain Monte Carlo (MCMC) (Andrieu et al.,
2003) and annealed importance sampling (Neal and Hin-
ton, 1998) which are widely used in both the statistical
physics and machine learning communities. An alterna-
tive approach – which we focus on here – is to approxi-
mate the the probability distribution p(x)and partition
function using a “variational distribution” q(x;q)whose
partition function we can calculate exactly. The varia-
tional parameters qare chosen to make the variational
distribution as close to the true distribution as possible
(how this is done is the focus of much of this section).
One of the most-widely applied examples of a varia-
tional method in statistical physics is Mean-Field Theory
(MFT).MFTcanbenaturallyunderstoodasaprocedure
for approximating the true distribution of the system by
a factorized distribution. The deep connection between
MFT and variational methods is discussed below. These
variational MFT methods have been extended to under-
stand more complicated spin models (also called graph-
ical models in the ML literature) and form the basis of
76
powerful set of techniques that go under the name of Be-
liefPropagationandSurveyPropagation(MacKay,2003;
Wainwright et al., 2008; Yedidia et al., 2003).
Variational methods are also widely used in ML to ap-
proximate complex probabilistic models. For example,
below we show how the Expectation Maximization (EM)
procedure, which we discussed in the context of Gaus-
sian Mixture Models for clustering, is actually a general
method that can be derived for any latent (hidden) vari-
able model using a variational procedure (Neal and Hin-
ton, 1998). This section serves as an introduction to this
powerful class of variational techniques. For readers in-
terested in an in-depth discussion on variational infer-
ence for probabilistic graphical models, we recommend
the great treatise written by Michael I. Jordan and oth-
ers(Jordan et al., 1999), the more physics oriented dis-
cussion in (Yedidia, 2001; Yedidia et al., 2003), as well as
David MacKay’s outstanding book (MacKay, 2003).
A. Variational mean-ﬁeld theory for the Ising model
Ising models are a major paradigm in statistical
physics. Historically introduced to study magnetism, it
was quickly realized that their predictive power applies
to a variety of interacting many-particle systems. Ising
models are now understood to serve as minimal models
for complex phenomena such as certain classes of phase
transitions. In the Ising model, degrees of freedom called
spins assume discrete, binary values, e.g. si=1. Each
spin variable silives on a lattice (or, in general, a graph),
the sites of which are labeled by i= 1;2:::;N. De-
spite the extreme simplicity relative to real-world sys-
tems, Ising models exhibit a high level of intrinsic com-
plexity, andthedegreesoffreedomcanbecomecorrelated
in sophisticated ways. Often, spins interact spatially lo-
cally, and respond to externally applied magnetic ﬁelds.
A spin conﬁguration sspeciﬁes the values siof the
spins at every lattice site. We can assign an “energy” to
every such conﬁguration
E(s;J) = 1
2X
i;jJijsisj X
ihisi;(158)
wherehiis a local magnetic ﬁeld applied to the spin si,
andJijis the interaction strength between the spins si
andsj. In textbook examples, the coupling parameters
J= (J;h)are typically uniform or, in studies of disor-
dered systems, (Ji;hi)are drawn from some probability
distribution (i.e. quenched disorder).
The probability of ﬁnding the system in a given spin
conﬁguration at temperature  1is given by
p(sj;J) =1
Zp(J)e E(s;J);
Zp(;J) =X
fsi=1ge E(s;J); (159)withP
fsi=1gdenoting the sum over all possible con-
ﬁgurations of the spin variables. We write Zpto em-
phasize that this is the partition function corresponding
to the probability distribution p(sj;J), which will be-
come important later. For a ﬁxed number of lattice sites
N, there are 2Npossible conﬁgurations, a number that
grows exponentially with the system size. Therefore, it
is not in general feasible to evaluate the partition func-
tionZp(;J)in closed form. This represents a major
practical obstacle for extracting predictions from physi-
cal theories since the partition function is directly related
to the free-energy through the expression
Fp(J) = logZp(;J) =hE(s;J)ip Hp;(160)
with
Hp= X
fsi=1gp(sj;J) logp(sj;J)(161)
the entropy of the probability distribution p(sj;J).
Eventhoughthetrueprobabilitydistribution p(sj;J)
may be a very complicated object, we can still make
progress by approximating p(sj;J)by avariational dis-
tributionq(s;)which captures the essential features of
interest, with some parameters that deﬁne our varia-
tional ansatz. The name variational distribution comes
from the fact that we are going to vary the parame-
tersto makeq(s;)as close to p(sj;J)as possible.
The functional form of q(s;)is based on an “educated
guess”, which oftentimes comes from our intuition about
the problem. We can also deﬁne a variational free-energy
Fq(;J) =hE(s;J)iq Hq;(162)
wherehE(s;J)iqis the expectation value of the energy
E(s;J)with respect to the distribution q(s;), andHq
is the entropy of q(s;).
Before proceeding further, it is helpful to introduce
a new quantity: the Kullback-Leibler divergence (KL-
divergence or relative entropy) between two distributions
p(x)andq(x). The KL-divergence measures the dissim-
ilarity between the two distributions and is given by
DKL(qkp) = Tr xq(x) logq(x)
p(x);(163)
which is the expectation w.r.t. qof the logarithmic dif-
ference between the two distributions pandq. The trace
Trxdenotes a sum over all possible conﬁgurations x.
Two important properties of the KL-divergence are (i)
positivity: DKL(pkq)0with equality if and only if
p=q(in the sense of probability distributions), and (ii)
DKL(pkq)6=DKL(qkp), that is the KL-divergence is not
symmetric in its arguments.
Variational mean-ﬁeld theory is a systematic way for
constructing such an approximate distribution q(s;).
The main idea is to choose parameters that minimize the
77
diﬀerence between the variational free-energy Fq(J;)
and the true free-energy Fp(Jj). We will show in Sec-
tion XIV.B below that the diﬀerence between these two
free-energies is actually the KL-divergence:
Fq(J;) =Fp(J;) +DKL(qkp):(164)
This equality, when combined with the non-negativity of
the KL-divergence has important consequences. First,
it shows that the variational free-energy is always larger
than the true free-energy, Fq(J;)Fp(J), with equal-
ity if and only if q=p(the latter inequality is found
in many physics textbooks and is known as the Gibbs
inequality). Second, ﬁnding the best variational free-
energy is equivalent to minimizing the KL divergence
DKL(qkp).
Armed with these observations, let us now derive a
MFT of the Ising model using variational methods. In
the simplest MFT of the Ising model, the variational dis-
tribution is chosen so that all spins are independent:
q(s;) =1
Zqexp X
iisi!
=Y
ieisi
2 coshi:(165)
In other words, we have chosen a distribution qwhich
factorizes on every lattice site. An important property
of this functional form is that we can analytically ﬁnd a
closed-form expression for the variational partition func-
tionZq. This simplicity also comes at a cost: ignor-
ing correlations between spins. These correlations be-
come less and less important in higher dimensions and
the MFT ansatz becomes more accurate.
To evaluate the variational free-energy, we make use
of Eq. (162). First, we need the entropy Hqof the dis-
tributionq. Sinceqfactorizes over the lattice sites, the
entropy separates into a sum of one-body terms
Hq() = X
fsi=1gq(s;) logq(s;)
= X
iqilogqi+ (1 qi) log(1 qi);(166)
whereqi=ei
2 coshiis the probability that spin siis in the
+1state. Next, we need to evaluate the average of the
Ising energy E(s;J)with respect to the variational dis-
tributionq. Although the energy contains bilinear terms,
we can still evaluate this average easily, because the spins
areindependent(uncorrelated)inthe qdistribution. The
mean value of spin siin theqdistribution, also known
as the on-site magnetization, is given by
mi=hsiiq=X
si=1sieisi
2 coshi= tanh(i):(167)
Since the spins are independent, we have
hE(s;J)iq= 1
2X
i;jJijmimj X
ihimi:(168)The total variational free-energy is
Fq(J;) =hE(s;J)iq Hq;
and minimizing with respect to the variational parame-
ters, we obtain
@
@iFq(J;) = 2dqi
di0
@ 2
4X
jJijmj+hi3
5+i1
A:
(169)
Setting this equation to zero, we arrive at
i=X
jJijmj(j) +hi: (170)
For the special case of a uniform ﬁeld hi=hand uni-
form nearest neighbor couplings Jij=J, by symmetry
the variational parameters for all the spins are identical,
withi=for alli. Then, the mean-ﬁeld equations
reduce to their familiar textbook form (Sethna, 2006),
m= tanh()and=(zJm() +h), wherezis the
coordination number of the lattice (i.e. the number of
nearest neighbors).
Equations(167)and(170)formaclosedsystem,known
as the mean-ﬁeld equations for the Ising model. To ﬁnd
a solution to these equations, one method is to iterate
through and update each i, once at a time, in an asyn-
chronousfashion. Oncecanseetheemergingrelationship
of this approach to solving the MFT equations to Expec-
tation Maximization (EM) procedure ﬁrst introduced in
the context of the K-means algorithm in Sec. XIII.A. To
make this explicit, let us spell out the iterative procedure
to ﬁnd the solutions to Eq. (170). We start by initializing
our variational parameters to some (0)and repeat the
following two steps until convergence:
1.Expectation : Givenasetofassignmentsatiteration
t,(t), calculate the corresponding magnetizations
m(t)using Eq. (167)
2.Maximization : Given a set of magnetizations mt,
ﬁnd new assignments (t+1)which minimize the
variational free energy Fq. From, Eq. (170) this
is just
(t+1)
i =X
jJijm(t)
j+hi: (171)
From these equations, it is clear that we can think of the
MFT of the Ising model as an EM-like procedure similar
to the one we used for K-means clustering and Gaussian
Mixture Models in Sec. XIII.
As is well known in statistical physics, even though
MFT is not exact, it can often yield qualitatively and
even quantitatively precise predictions (especially in high
dimensions). The discrepancy between the true physics
and MFT predictions stems from the fact that the varia-
tional distribution qwe chose cannot capture correlations
78
between the spins. For instance, it predicts the wrong
value for the critical temperature for the two-dimensional
Ising model. It even erroneously predicts the existence of
a phase transition in one dimension at a non-zero tem-
perature. We refer the interested reader to standard
textbooks on statistical physics for a detailed analysis
of applicability of MFT to the Ising model. However,
we emphasize that the failure of any particular varia-
tional ansatz does not compromise the usefulness of the
approach. In some cases, one can consider changing the
variational ansatz to improve the predictive properties
of the corresponding variational MFT (Yedidia, 2001;
Yedidiaet al., 2003). The take-home message is that
variational MFT is a powerful tool but one that must be
applied and interpreted with care.
B. Expectation Maximization (EM)
Ideas along the lines of variational MFT have been
independently developed in statistics and imported into
machine learning to perform maximum likelihood (ML)
estimates. In this section, we explicitly derive the Expec-
tation Maximization (EM) algorithm and demonstrate
further its close relation to variational MFT (Neal and
Hinton, 1998). We will focus on latent variable mod-
els where some of the variables are hidden and cannot
be directly observed. This often makes maximum likeli-
hood estimation diﬃcult to implement. EM gets around
this diﬃculty by using an iterative two-step procedure,
closely related to variational free-energy based approxi-
mation schemes in statistical physics.
To set the stage for the following discussion, let xbe
the set of visible variables we can directly observe and z
be the set of latent or hidden variables that we cannot di-
rectly observe. Denote the underlying probability distri-
bution from which xandzare drawn by p(z;xj), with
representing all relevant parameters. Given a dataset
x, we wish to ﬁnd the maximum likelihood estimate of
the parameters that maximizes the probability of the
observed data.
As in variational MFT, we view as variational pa-
rameters chosen to maximize the log-likelihood L() =
hlogp(xj)iPx, where the expectation is taken with re-
spect to the marginal distributions of x. Algorithmically,
this can be done by iterating the variational parameters
(t)in a series of steps ( t= 1;2;:::) starting from some
arbitrary initial value (0):
1.Expectation step (E step): Given the known
values of observed variable xand the current esti-
mate of parameter t 1, ﬁnd the probability distri-
bution of the latent variable z:
qt 1(z) =p(zj(t 1);x) (172)
2.Maximization step (M step): Re-estimate theparameter(t)to be those with maximum likeli-
hood, assuming qt 1(z)found in the previous step
is the true distribution of hidden variable z:
t= arg max
hlogp(z;xj)iqt 1 (173)
It was shown (Dempster et al., 1977) that each EM iter-
ation increases the true log-likelihood L(), or at worst
leaves it unchanged. In most models, this iteration pro-
cedure converges to a local maximum ofL().
E-step M-step 
−Fq(θ(t))−Fq(θ(t+1) )−Fpθ(t+2) 
θ(t+1) 
θ(t)
FIG. 59 Convergence of EM algorithm. Starting from (t),
E-step (blue) establishes  Fq((t))which is always a lower
bound of Fp:=hlogp(xj)iPx(green). M-step (red) is then
applied to update the parameter, yielding (t+1). The up-
dated parameter (t+1)is then used to construct  Fq((t+1))
in the subsequent E-step. M-step is performed again to up-
date the parameter, etc.
To see how EM is actually performed and related to
variational MFT, we make use of KL-divergence between
two distributions introduced in the last section. Recall
that our goal is to maximize the log-likelihood L().
With datazmissing, we surely cannot just maximize
L()directly since parameter might couple both zand
x. EM circumvents this by optimizing another objective
function,Fq(), constructed based on estimates of the
hidden variable distribution q(zjx). Indeed, the function
optimized is none other than the variational free energy
we encountered in the previous section:
Fq() := hlogp(z;xj)iq;Px hHqiPx;(174)
whereHqis the Shannon entropy (deﬁned in Eq. (161))
ofq(zjx). One can deﬁne the true free-energy Fp()as
the negative log-likelihood of the observed data:
 Fp() =L() =hlogp(xj)iPx:(175)
In the language of statistical physics, Fp()is thetrue
free-energy while Fq()is the variational free-energy we
79
would like to minimize (see Table I). Note that we have
chosen to employ a physics sign convention here of deﬁn-
ing the free-energy as minus log of the partition function.
In the ML literature, this minus sign is often omitted
(Neal and Hinton, 1998) and this can lead to some con-
fusion. Our goal is to choose so that our variational
free-energy Fq()is as close to the true free-energy Fp()
as possible. The diﬀerence between these free-energies
can be written as
Fq() Fp() =hfq(x;) fp(x;)iPx;(176)
where
fq(x;) fp(x;)
= logp(xj) X
zq(zjx) logp(z;xj)
+X
zq(zjx) logq(zjx)
=X
zq(zjx) logp(xj) X
zq(zjx) logp(z;xj)
+X
zq(zjx) logq(zjx)
= X
zq(zjx) logp(z;xj)
p(xj)+X
zq(zjx) log ~p(z)
=X
zq(zjx) logq(zjx)
p(zjx;)
=DKL(q(zjx)kp(zjx;))0
where we have used Bayes’ theorem p(zjx;) =
p(z;xj)=p(xj). Since the KL-divergence is always pos-
itive, this shows that the variational free-energy Fqis
always an upper bound of the true free-energy Fp. In
physics, this result is known as Gibbs’ inequality.
From Eq. (174) and the fact that the the entropy term
in Eq. (174) does not depend on , we can immediately
see that the maximization step (M-step) in Eq. (173)
is equivalent to minimizing the variational free-energy
Fq(). Surprisingly, the expectation step (E-step) can
also viewed as the optimization of this variational free-
energy. Concretely, one can show that the distribution
of hidden variables zgiven the observed variable xand
the current estimate of parameter , Eq. (172), is the
uniqueprobability q(z)that minimizes Fq()(now seen
as a functional of q). This can be proved by taking the
functional derivative of Eq. (174), plus a Lagrange mul-
tiplier that encodesP
zq(z) = 1, with respect to q(z).
Summing things up, we can re-write EM in the following
form (Neal and Hinton, 1998):
1.Expectation step: Construct the approximating
probability distribution of unobserved zgiven the
values of observed variable xand parameter esti-
mate(t 1):
qt 1(z) = arg min
qFq((t 1)) (177)2.Maximization step: Fixq, update the variational
parameters:
(t)= arg max
 Fqt 1(): (178)
To recapitulate, EM implements ML estimation even
with missing or hidden variables through optimizing a
lower bound of the true log-likelihood. In statistical
physics, this is reminiscent of optimizing a variational
free-energy which is a lower bound of true free-energy
due to Gibbs inequality. In Fig. 59, we show pictorially
how EM works. The E-step can be seen as representing
the unobserved variable zby a probability distribution
q(z). This probability is used to construct an alterna-
tive objective function  Fq(), which is then maximized
with respect to in the M-step. By construction, maxi-
mizing the negative variational free-energy is equivalent
to doing ML estimation on the joint data (i.e. both ob-
served and unobserved). The name “M-step” is intuitive
since the parameters are found by maximizing  Fq().
The name “E-step” comes from the fact that one usually
doesn’tneedtoconstructtheprobabilityofmissingdatas
explicitly, but rather need only compute the “expected"
suﬃcient statistics over these data, cf. Fig. 59.
Onthepracticalside, EMhasbeendemonstratedtobe
extremely useful in parameter estimation, particularly in
hidden Markov models and Bayesian networks (see, for
example, (Barber, 2012; Wainwright et al., 2008)). Some
of the authors have used EM in biophysics, to design al-
gorithms which establish the equivalence of niche theory
and the Minimum Environmental Perturbation Princi-
ple (Marsland III et al., 2019). One of the striking ad-
vantages of EM is that it is conceptually simple and easy
to implement (see Notebook 16). In many cases, imple-
mentation of EM is guaranteed to increase the likelihood
monotonically, which could be a perk during debugging.
For readers interested in an overview on applications of
EM, we recommend (Do and Batzoglou, 2008).
Finally for advanced readers familiar with the physics
of disordered systems, we note that it is possible to
construct a one-to-one dictionary between EM for la-
tent variable models and the MFT of spin systems with
quenched disorder. In a disordered spin systems, the
Ising couplings Jare commonly taken to be quenched
random variables drawn from some underlying probabil-
ity distribution. In the EM procedure, the quenched dis-
order is provided by the observed data points xwhich
are drawn from some underlying probability distribution
that characterizes the data. The spins sare like the hid-
den or latent variables z. Similar analogues can be found
for all the variational MFT quantities (see Table I). This
striking correspondence oﬀers a glimpse into the deep
connection between statistical mechanics and unsuper-
vised latent variable models – a connection that we will
repeatedly exploit to gain more intuition for the energy-
based unsupervised models considered in the next few
80
statistical physics Variational EM
spins/d.o.f.:s hidden/latent variables z
couplings /quenched disorder:
Jdata observations: x
Boltzmann factor e E(s;J)Complete probability:
p(x;zj)
partition function: Z(J)marginal likelihood p(xj)
energy:E(s;J) negative log-complete data
likelihood: logp(x;zj;m)
free energy: Fp(Jj) negative log-marginal likeli-
hood: logp(xjm)
variational distribution: q(s)variational distribution:
q(zjx)
variational free-energy:
Fq(J;)variational free-energy: Fq()
TABLE I Analogy between quantities in statistical physics
and variational EM.
chapters.
XV. ENERGY BASED MODELS: MAXIMUM ENTROPY
(MAXENT) PRINCIPLE, GENERATIVE MODELS, AND
BOLTZMANN LEARNING
Most of the models discussed in the previous sections
(e.g. linear and logistic regression, ensemble models, and
supervised neural networks) are discriminative – they
are designed to perceive diﬀerences between groups or
categories of data. For example, recognizing diﬀerences
between images of cats and images of dogs allows a dis-
criminative model to label an image as “cat” or “dog”.
Discriminative models form the core techniques of most
supervised learning methods. However, discriminative
methods have several limitations. First, like all super-
vised learning methods, they require labeled data. Sec-
ond, there are tasks that discriminative approaches sim-
ply cannot accomplish, such as drawing new examples
from an unknown probability distribution. A model that
can learn to represent and sample from a probability dis-
tribution is called generative . For example, a genera-
tive model for images would learn to draw new examples
of cats and dogs given a dataset of images of cats and
dogs. Similarly, given samples generated from one phase
of an Ising model we may want to generate new sam-
ples from that phase. Such tasks are clearly beyond the
scope of discriminative models like the ensemble models
and DNNs discussed so far in the review. Instead, we
must turn to a new class of machine learning methods.
The goal of this section is to introduce the reader to
energy-based generative models. As we will see, energy-
based models are closely related to the kinds of models
commonly encountered in statistical physics. We will
draw upon many techniques that have their origin in
statistical mechanics (e.g. Monte-Carlo methods). Thesection starts with a brief overview of generative mod-
els, highlighting the similarities and diﬀerences with the
supervised learning methods encountered in earlier sec-
tions. Next, we introduce perhaps the simplest kind of
generative models – Maximum Entropy (MaxEnt) mod-
els. MaxEnt models have no latent (or hidden) vari-
ables, makingthemidealforintroducingthekeyconcepts
and tools that underlie energy-based generative models.
We then present an extended discussion of how to train
energy-based models. Much of this discussion will also
be applicable to more complicated energy-based models
such as Restricted Boltzmann Machines (RBMs) and the
deep models discussed in the next section.
A. An overview of energy-based generative models
Generative models are a machine learning technique
that allows to learn how to generate new examples sim-
ilar to those found in a training dataset. The core idea
of most generative models is to learn a parametric model
for the probability distribution from which the data was
drawn. Once we have learned a model, we can gener-
ate new examples by sampling from the learned gen-
erative model (see Fig. 60). As in statistical physics,
this sampling is often done using Markov Chain Monte
Carlo (MCMC) methods. A review of MCMC methods
is beyond the scope of this discussion: for a concise and
beautiful introduction to MCMC-inspired methods that
bridges both statistical physics and ML the reader is en-
couraged to consult Chapters 29-32 of David MacKay’s
book (MacKay, 2003) as well as the review by Michael
I. Jordan and collaborators (Andrieu et al., 2003).
The added complexity of learning models directly
from samples introduces many of the same fundamental
tensions we encountered when discussing discriminative
models. The ability to generate new examples requires
models to be able to “generalize” beyond the examples
they have been trained on, that is to generate new sam-
ples that are not samples of the training set. The models
must be expressive enough to capture the complex cor-
relations present in the underlying data distribution, but
the amount of data we have is ﬁnite which can give rise
to overﬁtting.
In practice, most generative models that are used in
machine learning are ﬂexible enough that, with a suﬃ-
cient number of parameters, they can approximate any
probability distribution. For this reason, there are three
axes on which we can diﬀerentiate classes of generative
models:
•The ﬁrst axis is how easy the model is to train –
both in terms of computational time and the com-
plexity of writing code for the algorithm.
•The second axis is how well the model generalizes
from the training set to the test set.
81
•The third axis is which characteristics of the data
distribution the model is capable of and focuses on
capturing.
All generative models must balance these competing re-
quirements and generative models diﬀer in the tradeoﬀs
they choose. Simpler models capture less structure about
the underlying distributions but are often easier to train.
More complicated models can capture this structure but
may overﬁt to the training data.
One of the fundamental reasons that energy-based
models have been less widely-employed than their dis-
criminative counterparts is that the training procedure
for these models diﬀers signiﬁcantly from those for su-
pervised neural networks models. Though both employ
gradient-descent based procedures for minimizing a cost
function (one common choice for generative models is
the negative log-likelihood function), energy-based mod-
els do not use backpropagation (see Sec. IX.C) and au-
tomatic diﬀerentiation for computing gradients. Rather,
one must turn to ideas inspired by MCMC based meth-
ods in physics and statistics that sometimes go under
the name “Boltzmann Learning” (discussed below). As a
result, training energy-based models requires additional
tools that are not immediately available in packages such
as PyTorch and TensorFlow.
The open-source package – Paysage – that is built on
top of PyTorch bridges this gap by providing the toolset
for training energy-based models (Paysage is maintained
by Unlearn.AI – a company aﬃliated with two of the au-
thors (CKF and PM)). Paysage makes it easy to quickly
code and deploy energy-based models such as Restricted
Boltzmann Machines (RBMs) and Stacked RBMs – a
“deep” unsupervised model. The package includes un-
published training methods that signiﬁcantly improve
the training performance, can be applied with various
datatypes, and can be employed on GPUs. We make
use of this package extensively in the next two sections
and the accompanying Python notebooks. For example,
Fig. 60 (and the accompanying Notebook 17) show how
the Paysage package can be used to quickly code and
train a variety of energy-based models on the MNIST
handwritten digit dataset.
Finally, we note that generative models at their most
basic level are complex parametrizations of the probabil-
ity distribution the data is drawn from. For this reason,
generative models can do much more than just generate
new examples. They can be used to perform a multi-
tude of other tasks that require sampling from a complex
probability distribution including “de-noising”, ﬁlling in
missing data, and even discrimination (Hinton, 2012).
The versatility of generative models is one of the major
appeals of these unsupervised learning methods.
FIG. 60 Examples of handwritten digits (“reconstructions”)
generated using various energy-based models using the pow-
erfulPaysage package for unsupervised learning. Examples
from top to bottom are: the original MNIST database, an
RBM with Gaussian units which is equivalent to a Hopﬁeld
Model, aRestrictedBoltzmannMachine(RBM),aRBMwith
anL1penalty for regularization, and a Deep Boltzmann Ma-
chine (DBM) with 3layers. All models have 200hidden units.
See Sec. XVI and corresponding notebook for details
B. Maximum entropy models: the simplest energy-based
generative models
Maximum Entropy (MaxEnt) models are one of the
simplest classes of energy-based generative models. Max-
Ent models have their origin in a series of beautiful pa-
pers by Jaynes that reformulated statistical mechanics in
information theoretic terms (Jaynes, 1957a,b). Recently,
the ﬂood of new, large scale datasets has resulted in a
resurgence of interest in MaxEnt models in many ﬁelds
including physics (especially biological physics), compu-
tational neuroscience, and ecology (Elith et al., 2011;
Schneidman et al., 2006; Weigt et al., 2009). MaxEnt
modelsareoftenpresentedastheclassofgenerativemod-
els that make the least assumptions about the underlying
data. However, aswehavetriedtoemphasizethroughout
the review, all ML and statistical models require assump-
tions, and MaxEnt models are no diﬀerent. Overlooking
this can sometimes lead to misleading conclusions, and
it is important to be cognizant of these implicit assump-
tions (Aitchison et al., 2016; Schwab et al., 2014).
1. MaxEnt models in statistical mechanics
MaxEnt models were introduced by E. T. Jaynes in a
two-part paper in 1957 entitled “Information theory and
statistical mechanics” (Jaynes, 1957a,b). In these incred-
ible papers, Jaynes showed that it was possible to re-
derive the Boltzmann distribution (and the idea of gen-
eralized ensembles) entirely from information theoretic
arguments. Quoting from the abstract, Jaynes consid-
ered “statistical mechanics as a form of statistical infer-
ence rather than as a physical theory” (portending the
82
close connection between statistical physics and machine
learning). Jaynes showed that the Boltzmann distribu-
tion could be viewed as resulting from a statistical in-
ference procedure for learning probability distributions
describing physical systems where one only has partial
information about the system (usually the average en-
ergy).
The key quantity in MaxEnt models is the informa-
tion theoretic, or Shannon, entropy, a concept introduced
by Shannon in his landmark treatise on information the-
ory (Shannon, 1949). The Shannon entropy quantiﬁes
the statistical uncertainty one has about the value of a
random variable xdrawn from a probability distribution
p(x). The Shannon entropy of the distribution is deﬁned
as
Sp= Trxp(x) logp(x) (179)
where the trace is a sum/integral over all possible val-
ues a variable can take. Jaynes showed that the Boltz-
mann distribution follows from the Principle of Maxi-
mum Entropy. A physical system should be described
by the probability distribution with the largest entropy
subject to certain constraints (often provided by measur-
ing the average value of conserved, extensive quantities
such as the energy, particle number, etc.) The princi-
ple uniquely speciﬁes a procedure for parametrizing the
functional form of the probability distribution. Once we
have speciﬁed and learned this form we can, of course,
generate new examples by sampling this distribution.
Let us illustrate how this works in more detail. Sup-
pose that we have chosen a set of functions ffi(x)gwhose
average value we want to ﬁx to some observed values
hfiiobs. The Principle of Maximum Entropy states that
we should choose the distribution p(x)with the largest
uncertainty (i.e. largest Shannon entropy Sp), subject to
the constraints that the model averages match the ob-
served averages:
hfiimodel =Z
dxfi(x)p(x) =hfiiobs:(180)
We can formulate the Principle of Maximum Entropy
asanoptimizationproblemusingthemethodofLagrange
multipliers by minimizing:
L[p] = Sp+X
ii
hfiiobs Z
dxfi(x)p(x)
+
1 Z
dxp(x)
;
where the ﬁrst set of constraints enforce the requirement
for the averages and the last constraint enforces the nor-
malization that the trace over the probability distribu-
tion equals one. We can solve for p(x)by taking the
functional derivative and setting it to zero
0 =L
p= (logp(x) + 1) X
iifi(x) :The general form of the maximum entropy distribution
is then given by
p(x) =1
ZeP
iifi(x)(181)
whereZ(i) =R
dxeP
iifi(x)is the partition function.
The maximum entropy distribution is clearly just
the usual Boltzmann distribution with energy E(x) =
 P
iifi(x). The values of the Lagrange multipliers are
chosen to match the observed averages for the set of func-
tionsffi(x)gwhose average value is being ﬁxed:
hfiimodel =Z
dxp(x)fi(x) =@logZ
@i=hfiiobs:(182)
In other words, the parameters of the distribution can be
chosen such that
@ilogZ=hfiidata: (183)
To gain more intuition for the MaxEnt distribution, it
is helpful to relate the Lagrange multipliers to the famil-
iar thermodynamic quantities we use to describe physical
systems (Jaynes, 1957a). Our xdenotes the microscopic
state of the system, i.e. the MaxEnt distribution is a
probability distribution over microscopic states. How-
ever, in thermodynamics we only have access to average
quantities. Ifweknowonlytheaverageenergy hE(x)iobs,
the MaxEnt procedure tells us to maximize the entropy
subject to the average energy constraint. This yields
p(x) =1
Ze E(x); (184)
where we have identiﬁed the Lagrange multiplier conju-
gate to the energy 1= = 1=kBTwith the (negative)
inverse temperature. Now, suppose we also constrain the
particle number hN(x)iobs. Then, an almost identical
calculationyieldsaMaxEntdistributionofthefunctional
form
p(x) =1
Ze (E(x) N(x)); (185)
where we have rewritten our Lagrange multipliers in
the familiar thermodynamic notation 1= and
2==. Since this is just the Boltzmann distribu-
tion, we can also relate the partition function in our
MaxEnt model to the thermodynamic free-energy via
F=  1logZ. The choice of which quantities to
constrain is equivalent to working in diﬀerent thermo-
dynamic ensembles.
2. From statistical mechanics to machine learning
The MaxEnt idea also provides a general procedure
for learning a generative model from data. The key dif-
ference between MaxEnt models in (theoretical) physics
83
and ML is that in ML we have no direct access to ob-
served valueshfiiobs. Instead, these averages must be
directly estimated from data (samples). To denote this
diﬀerence, we will call empirical averages calculated from
data ashfiidata. We can think of MaxEnt as a statisti-
cal inference procedure simply by replacing hfiiobsby
hfiidataabove.
This subtle change has important implications for
training MaxEnt models. First, since we do not know
these averages exactly, but must estimate them from the
data, ourtrainingproceduresmustbecarefulnottoover-
ﬁt to the observations (our samples might not be reﬂec-
tive of the true values of these statistics). Second, the av-
erages of certain functions fiare easier to estimate from
limited data than others. This is often an important con-
sideration when formulating which MaxEnt model to ﬁt
to the data. Finally, we note that unlike in physics where
conservation laws often suggest the functions fiwhose
averages we hold ﬁx, ML oﬀers no comparable guide for
how to choose the fiwe care about. For these reasons,
choosing theffigis often far from straightforward. As a
ﬁnalpoint,wenotethatherewehavepresentedaphysics-
based perspective for justifying the MaxEnt procedure.
We mention in passing that the MaxEnt in ML is also
closely related to ideas from Bayesian inference (Jaynes,
1968, 2003) and this latter point of view is more com-
mon in discussions of MaxEnt in the statistics and ML
literature.
3. Generalized Ising Models from MaxEnt
The form of a MaxEnt model is completely speciﬁed
once we choose the averages ffigwe wish to constrain.
One common choice often used in MaxEnt modeling is to
constrain the ﬁrst two moments of a distribution. When
ourrandomvariables xarecontinuous, thecorresponding
MaxEnt distribution is a multi-dimensional Gaussian. If
thexare binary (discrete), then the corresponding Max-
Ent distribution is a generalized Ising (Potts) model with
all-to-all couplings.
To see this, consider a random variable xwith ﬁrst
andsecondmoments hxiidataandhxixjidata, respectively.
According to the Principle of Maximum Entropy, we
should choose to model this variable using a Boltzmann
distribution with constraints on the ﬁrst and second mo-
ments. Let aibe the Lagrange multiplier associated with
hxiidataandJij=2be the Lagrange multiplier associated
withhxixjidata. Using Eq. (182), it is easy to verify that
the energy function
E(x) = X
iaixi 1
2X
ijJijxixj(186)
satisﬁes the above constraints.
Partition functions for maximum entropy models are
often intractable to compute. Therefore, it is helpful toconsider two special cases where xhas diﬀerent support
(diﬀerent kinds of data). First, consider the case that the
random variables x2Rnare real numbers. In this case
we can compute the partition function directly:
Z=Z
dxeaTx+1
2xTJx=p
(2)ndetJ 1e 1
2aTJ 1a:
(187)
The resulting probability density function is,
p(x) =Z 1e E(x)
=1p
(2)ndetJ 1e1
2aTJ 1a+aTx+1
2xTJx
=1p
(2)ndete 1
2(x )T 1(x );(188)
where= J 1aand = J 1. This, of course, is the
normalized, multi-dimensional Gaussian distribution.
Second, consider the case that the random variable x
is binary with xi2f  1;+1g. The energy function takes
the same form as Eq. (186), but the partition function
can no longer be computed in a closed form. This model
is known as the Ising model in the physics literature, and
is often called a Markov Random Field in the machine
learning literature. It is well known to physicists that
calculating the partition function for the Ising Model is
intractable. For this reason, the best we can do is esti-
mate it using numerical techniques such MCMC methods
or approximate methods like variational MFT methods,
see Sec. XIV. Finally, we note that in ML it is common to
use binary variables which take on values in xi2f0;1g
ratherthanf1g. Thiscansometimesbeasourceofcon-
fusion when translating between ML and physics litera-
tures and can lead to confusion when using ML packages
for physics problems.
C. Cost functions for training energy-based models
TheMaxEntproceduregivesusawayofparametrizing
an energy-based generative model. For any energy-based
generativemodel, theenergyfunction E(x;fig)depends
on some parameters i– couplings in the language of
statistical physics – that must be inferred directly from
the data. For example, for the MaxEnt models the fig
are just the Lagrange multipliers figintroduced in the
last section. The goal of the training procedure is to use
the available training data to ﬁt these parameters.
Like in many other ML techniques, we will ﬁt these
couplings by minimizing a cost function using stochastic
gradient descent (cf. Sec. IV). Such a procedure naturally
separates into two parts: choosing an appropriate cost
function, and calculating the gradient of the cost func-
tion with respect to the model parameters. Formulating
a cost function for generative models is a little bit trickier
84
than for supervised, discriminative models. The objec-
tive of discriminative models is straightforward – predict
the label from the features. However, what we mean by
a “good” generative model is much harder to deﬁne using
a cost function. We would like the model to generate
examples similar to those we ﬁnd in the training dataset.
However, we would also like the model to be able to gen-
eralize–wedonotwantthemodeltoreproduce“spurious
details” that are particular to the training dataset. Un-
like for discriminative models, there is no straightforward
idea like cross-validation on the data labels that neatly
addresses this issue. For this reason, formulating cost
functions for generative models is subtle and represents
an important and interesting open area of research.
Calculating the gradients of energy-based models also
turns out to be diﬀerent than for discriminative mod-
els, such as deep neural networks. Rather than relying
on automatic diﬀerentiation techniques and backpropa-
gation (see Sec. IX.C), calculating the gradient requires
drawing on intuitions from MCMC-based methods. Be-
low, we provide an in-depth discussion of Boltzmann
learning for energy-based generative models, focusing on
MaxEnt models. We put the emphasis on training pro-
cedures that generalize to more complicated generative
models with latent variables such as RBMs discussed in
the next section. Therefore, we largely ignore the in-
credibly rich physics-based literature on ﬁtting Ising-like
MaxEnt models (see the recent reviews (Baldassi et al.,
2018; Nguyen et al., 2017) and references therein).
1. Maximum likelihood
By far the most common approach used for training a
generative model is to maximize the log-likelihood of the
training data set. Recall, that the log-likelihood char-
acterizes the log-probability of generating the observed
data using our generative model. By choosing the nega-
tive log-likelihood as the cost function, the learning pro-
cedure tries to ﬁnd parameters that maximize the proba-
bility of the data. This cost function is intuitive and has
been the work-horse of most generative modeling. How-
ever, we note that the Maximum Likelihood estimation
(MLE) procedure has some important limitations that
we will return to in Sec. XVII.
In what follows, we employ a general notation that is
applicable to all energy-based models, not just the Max-
Ent models introduced above. The reason for this is that
much of this discussion does not rely on the speciﬁc form
of the energy function but only on the fact that our gen-
erative model takes a Boltzmann form. We denote the
generative model by the probability distribution p(x)
and its corresponding partition function by logZ(fig).
In MLE, the parameters of the model are ﬁt by maximiz-ing the log-likelihood:
L(fig) =hlog (p(x))idata
= hE(x;fig)idata logZ(fig);(189)
where we have set = 1. In writing this expression we
made use of two facts: (i) our generative distribution is
of the Boltzmann form, and (ii) the partition function
does not depend on the data:
hlogZ(fig)idata= logZ(fig):(190)
2. Regularization
Justasfordiscriminativemodelslikelinearandlogistic
regression, it is common to supplement the log-likelihood
with additional regularization terms (see Secs. VI and
VII). Instead of minimizing the negative log-likelihood,
one minimizes a cost function of the form
 L(fig) +Ereg(fig); (191)
whereEreg(fig)isanadditionalregularizationtermthat
prevents overﬁtting. From a Bayesian perspective, this
new term can be viewed as encoding a (negative) log-
prior on model parameters and performing a maximum-
a-posteriori (MAP) estimate instead of a MLE (see cor-
responding discussion in Sec. VI).
Aswesawbystudyinglinearregression, diﬀerentforms
of regularization give rise to diﬀerent kinds of properties.
A common choice for the regularization function are the
sums of the L1orL2norms of the parameters
Ereg(fig) = X
ijij; = 1;2(192)
with controllingtheregularizationstrength. For  = 0,
there is no regularization and we are simply performing
MLE. In contrast, a choice of large will force many
parameters to be close to or exactly zero. Just as in
regression, an L1 penalty enforces sparsity, with many of
theiset to zero, and L2 regularization shrinks the size
of the parameters towards zero.
One challenge of generative models is that it is often
diﬃcult to choose the regularization strength . Recall
that, for linear and logistic regression, is chosen to
maximize the out-of-sample performance on a validation
dataset (i.e. cross-validation). However, for generative
models our data are usually unlabeled. Therefore, choos-
ing a regularization strength is more subtle and there ex-
ists no universal procedure for choosing . One common
strategyistodividethedataintoatrainingsetandaval-
idation set and monitor a summary statistic such as the
log-likelihood, energy distance (Székely, 2003), or varia-
tional free-energy of the generative model on the training
and validation sets (the variational free-energy was dis-
cussed extensively in Sec. XIV ) (Hinton, 2012). If the
85
gap between the training and validation datasets starts
growing, one is probably overﬁtting the model even if
the log-likelihood of the training dataset is still increas-
ing. This also gives a procedure for “early stopping” –
a regularization procedure we introduced in the context
of discriminative models. In practice, when using such
regularizers it is important to try many diﬀerent values
ofand then try to use a proxy statistic for overﬁtting
to evaluate the optimal choice of .
D. Computing gradients
We still need to specify a procedure for minimizing the
cost function. One powerful and common choice that
is widely employed when training energy-based models
is stochastic gradient descent (SGD) (see Sec. IV). Per-
forming MLE using SGD requires calculating the gradi-
ent of the log-likelihood Eq. (189) with respect to the
parameters i. To simplify notation and gain intuition,
it is helpful to deﬁne “operators” Oi(x), conjugate to the
parameters i
Oi(x) =@E(x;i)
@i: (193)
Since the partition function is just the cumulant gener-
ating function for the Boltzmann distribution, we know
thattheusualstatisticalmechanicsrelationshipsbetween
expectation values and derivatives of the log-partition
function hold:
hOi(x)imodel = Tr xp(x)Oi(x) = @logZ(fig)
@i:(194)
In terms of the operators fOi(x)g, the gradient of
Eq. (189) takes the form (Ackley et al., 1987)
 @L(fig)
@i=D@E(x;i)
@iE
data+@logZ(fig)
@i
=hOi(x)idata hOi(x)imodel:(195)
These equations have a simple and beautiful interpre-
tation. The gradient of the log-likelihood with respect to
amodelparameterisadiﬀerenceofmoments–onecalcu-
lated directly from the data and one calculated from our
model using the current model parameters. The data-
dependent term is known as the positive phase of the
gradient and the model-dependent term is known as the
negative phase of the gradient. This derivation also gives
anintuitiveexplanationforlikelihood-basedtrainingpro-
cedures. The gradient acts on the model to lower the en-
ergy of conﬁgurations that are near observed data points
while raising the energy of conﬁgurations that are far
fromobserveddatapoints. Finally, wenotethatallinfor-
mation about the data only enters the training procedure
through the expectations hOi(x)idataand our generative
model is blind to information beyond what is contained
in these expectations.To use SGD, we must still calculate the expectation
valuesthatappearinEq.(195). Thepositivephaseofthe
gradient–theexpectationvalueswithrespecttothedata
–canbeeasilycalculatedusingsamplesfromthetraining
dataset. However, the negative phase – the expectation
valueswithrespecttothemodel–isgenerallymuchmore
diﬃcult to compute. We will see that in almost all cases,
we will have to resort to either numerical or approximate
methods. The fundamental reason for this is that it is
impossible to calculate the partition function exactly for
most interesting models in both physics and ML.
There are exceptional cases in which we can calcu-
late expectation values analytically. When this hap-
pens, the generative model is said to have a Tractable
Likelihood . One example of a generative model with a
Tractable Likelihood is the Gaussian MaxEnt model for
real valued data discussed in Eq. (188). The param-
eters/Lagrange multipliers for this model are the local
ﬁelds aand the pairwise coupling matrix J. In this case,
the usual manipulations involving Gaussian integrals al-
low us to exactly ﬁnd the parameters = J 1aand
 = J 1, yielding the familiar expressions =hxidata
and =h(x hxidata)(x hxidata)Tidata. These are
the standard estimates for the sample mean and covari-
ance matrix. Converting back to the Lagrange multipli-
ers yields
J= h(x hxidata)(x hxidata)Ti 1
data:(196)
Returning to the generic case where most energy-based
models have intractable likelihoods , we must estimate ex-
pectation values numerically. One way to do this is draw
samplesSmodel =fx0
igfrom the model p(x)and evalu-
ate arbitrary expectation values using these samples:
hf(x)imodel =Z
dxp(x)f(x)X
x0
i2Smodelf(x0
i):(197)
The samples from the model x0
i2S modelare often re-
ferred to as fantasy particles in the ML literature and
can be generated using simple MCMC algorithms such
as Metropolis-Hasting which are covered in most modern
statistical physics classes. However, if the reader is unfa-
miliar with MCMC methods or wants a quick refresher,
we recommend the concise and beautiful discussion of
MCMC methods from both the physics and ML point-
of-view in Chapters 29-32 of David MacKay’s masterful
book (MacKay, 2003).
Finally, wenotethatoncewehavethefantasyparticles
from the model, we can also easily calculate the gradient
of any expectation value hf(x)imodelusing what is com-
monly called the “log-derivative trick” in ML (Fu, 2006;
86
Kleijnen and Rubinstein, 1996):
@
@ihf(x)imodel =Z
dx@p(x)
@if(x)
=D@logp(x)
@if(x)E
model
=hOi(x)f(x)imodel
X
x0
j2SmodelOi(xj)f(x0
j):(198)
This expression allows us to take gradients of more com-
plex cost functions beyond the MLE procedure discussed
here.
E. Summary of the training procedure
We now summarize the discussion above and present a
general procedure for training an energy based model us-
ing SGD on the cost function (see Sec. IV). Our goal is to
ﬁt the parameters of a model p(fig) =Z 1e E(x;fig).
Training the model involves the following steps:
1. Read a minibatch of data, fxg.
2. Generate fantasy particles fx0g pusing an
MCMC algorithm (e.g., Metropolis-Hastings).
3. Compute the gradient of log-likelihood using these
samples and Eq. (195), where the averages are
taken over the minibatch of data and the fantasy
particles from the model, respectively.
4. Use the gradient as input to one of the gradient
based optimizers discussed in section Sec. IV.
In practice, it is helpful to supplement this basic proce-
dure with some tricks that help training. As with dis-
criminative neural networks, it is important to initial-
ize the parameters properly and print summary statistics
during the training procedure on the training and vali-
dation sets to prevent overﬁtting. These and many other
“cheap tricks” have been nicely summarized in a short
note from the Hinton group (Hinton, 2012).
A major computational and practical limitation of
these methods is that it is often hard to draw samples
fromgenerativemodels. MCMCmethodsoftenhavelong
mixing-times (the time one has to run the Markov chain
to get uncorrelated samples) and this can result in bi-
ased sampling. Luckily, we often do not need to know
the gradients exactly for training ML models (recall that
noisy gradient estimates often help the convergence of
gradient descent algorithms), and we can signiﬁcantly re-
duce the computational expense by running MCMC for
a reasonable time window. We will exploit this observa-
tion extensively in the next section when we discuss how
to train more complex energy-based models with hidden
variables.XVI. DEEP GENERATIVE MODELS: HIDDEN VARIABLES
AND RESTRICTED BOLTZMANN MACHINES (RBMS)
The last section introduced many of the core ideas be-
hind energy-based generative models. Here, we extend
this discussion to energy-based models that include la-
tent or hidden variables.
Including latent variables in generative models greatly
enhances their expressive power – allowing the model to
represent sophisticated correlations between visible fea-
tures without sacriﬁcing trainability. By having multiple
layers of latent variables, we can even construct powerful
deep generative models that possess many of the same
desirable properties as deep, discriminative neural net-
works.
We begin with a discussion that tries to provide a sim-
ple intuition for why latent variables are such a pow-
erful tool for generative models. Next, we introduce a
powerful class of latent variable models called Restricted
Boltzmann Machines (RBMs) and discuss techniques for
training these models. After that, we introduce Deep
BoltzmannMachines(DBMs),whichhavemultiplelayers
of latent variables. We then introduce the new Paysage
package for training energy-based models and demon-
strate how to use it on the MNIST dataset and sam-
ples from the Ising model. We conclude by discussing
recent physics literature related to energy-based genera-
tive models.
A. Why hidden (latent) variables?
Latent or hidden variables are a powerful yet elegant
way to encode sophisticated correlations between observ-
able features. The underlying reason for this is that
marginalizing over a subset of variables – “integrating
out” degrees of freedom in the language of physics – in-
duces complex interactions between the remaining vari-
ables. The idea that integrating out variables can lead
to complex correlations is a familiar component of many
physical theories. For example, when considering free
electronslivingonalattice, integratingoutphononsgives
risetohigher-orderelectron-electroninteractions(e.g.su-
perconducting or magnetic correlations). More generally,
in the Wilsonian renormalization group paradigm, all ef-
fective ﬁeld theories can be thought of as arising from
integrating out high-energy degrees of freedom (Wilson
and Kogut, 1974).
Generative models with latent variables run this logic
in reverse – encode complex interactions between visible
variablesbyintroducingadditional, hiddenvariablesthat
interact with visible degrees of freedom in a simple man-
ner, yet still reproduce the complex correlations between
visible degrees in the data once marginalized over (in-
tegrated out). This allows us to encode complex higher-
orderinteractionsbetweenthevisiblevariablesusingsim-
87
pler interactions at the cost of introducing new latent
variables/degrees of freedom. This trick is also widely
exploited in physics (e.g. in the Hubbard-Stratonovich
transformation (Hubbard, 1959; Stratonovich, 1957) or
the introduction of ghost ﬁelds in gauge theory (Faddeev
and Popov, 1967)).
To make these ideas more concrete, let us revisit the
pairwiseIsingmodelintroducedinthediscussionofMax-
Ent models, see Eq. (186). The model is described by a
Boltzmann distribution with energy
E(v) = X
iaivi 1
2X
ijviJijvj;(199)
whereJijis a symmetric coupling matrix that encodes
thepairwiseconstraintsand aienforcethesingle-variable
constraint.
Our goal is to replace the complicated interactions be-
tween the visible variables viencoded by Jij, by interac-
tions with a new set of latent variables h. In order to
do this, it is helpful to rewrite the coupling matrix in a
slightlydiﬀerentform. UsingSVD,wecanalwaysexpress
the coupling matrix in the form Jij=PN
=1WiWj,
wherefWigiare appropriately normalized singular vec-
tors. In terms of Wi, the energy takes the form
EHop(v) = X
iaivi 1
2X
ijviWiWjvj:(200)
We note that in the special case when both vi2
f 1;+1gandWi2f  1;+1gare binary variables, a
model with this form of the energy function is known as
theHopﬁeld model (Amitet al., 1985; Hopﬁeld, 1982).
The Hopﬁeld model has played an extremely important
role in statistical physics, computational neuroscience,
and machine learning, and a full discussion of its prop-
erties is well beyond the scope of this review [see (Amit,
1992) for a beautiful discussion that combines all these
perspectives]. Therefore, here we refer to all energy func-
tionsoftheformEq.(200)as(generalized)Hopﬁeldmod-
els, even for the case when the Wiare continuous vari-
ables.
We now “decouple” the visible variables viby intro-
ducing a set of normally, distributed continuous latent
variablesh(in condensed matter language we perform a
Hubbard-Stratonovich transformation). Using the usual
identity for Gaussian integrals, we can rewrite the Boltz-
mann distribution for the generalized Hopﬁeld model as
p(v) =eP
iaivi+1
2P
ijviWiWjvj
Z
=eP
iaiviQ
R
dhe 1
2P
h2
 P
iviWih
Z
=R
dhe E(v;h)
Z(201)
Hidden Layer 
Visible Layer ai(vi)bμ(hμ)
WiμvihμInteractions FIG. 61 A Restricted Boltzmann Machine (RBM) consists of
visible units viand hidden units hthat interact with each
other through interactions of the form Wivih. Importantly,
there are no interactions between visible units themselves or
hidden units themselves.
whereE(v;h)is a joint energy functional of both the
latent and visible variables of the form
E(v;h) = X
iaivi+1
2X
h2
 X
iviWih:(202)
We can also use the energy function E(v;h)to deﬁne a
new energy-based model p(v;h)on both the latent and
visible variables
p(v;h) =e E(v;h)
Z0: (203)
Marginalizingoverlatentvariablesofcoursegivesusback
the generalized Hopﬁeld model (Barra et al., 2012)
p(v) =Z
dhp(v;h) =e EHop(v)
Z:(204)
Notice that E(v;h)contains no direct interactions be-
tween visible degrees of freedom (or between hidden de-
gree of freedom). Instead, the complex correlations be-
tween theviare encoded in the interaction between the
visibleviand latent variables h. It turns out that the
model presented here is a special case of a more general
class of powerful energy-based models called Restricted
Boltzmann Machines (RBMs).
B. Restricted Boltzmann Machines (RBMs)
A Restricted Boltzmann Machine (RBM) is an energy-
basedmodelwithbothvisibleandhiddenunitswherethe
visible and hidden units interact with each other but do
not interact among themselves. The energy function of
an RBM takes the general functional form
E(v;h) = X
iai(vi) X
b(h) X
iWivih;(205)
whereai()andb()are functions that we are free to
choose. The most common choice is:
ai(vi) =(
aivi;ifvi2f0;1gis binary
v2
i
22
i;ifvi2Ris continuous ;
88
and
b(h) =(
bh;ifh2f0;1gis binary
h2

22;ifh2Ris continuous :
For this choice of ai()andb(), layers consisting of dis-
crete binary units are often called Bernoulli layers, and
layers consisting of continuous variables are often called
Gaussianlayers. ThebasicbipartitestructureofanRBM
– i.e., a visible and hidden layer that interact with each
other but not among themselves – is often depicted using
a graph of the form shown in Fig. 61.
An RBM can have diﬀerent properties depending on
whether the hidden and visible layers are taken to be
Bernoulli or Gaussian. The most common choice is to
have both the visible and hidden units be Bernoulli. This
is what is typically meant by an RBM. However, other
combinations are also possible and used in the ML lit-
erature. When all the units are continuous, the RBM
reduces to a multi-dimensional Gaussian with a very par-
ticular correlation structure. When the hidden units are
continuous and the visible units are discrete, the RBM is
equivalenttoageneralizedHopﬁeldmodel(seediscussion
above). When the the visible units are continuous and
the hidden units are discrete, the RBM is often called a
Gaussian Bernoulli Restricted Boltzmann Machine (Dahl
et al., 2010; Hinton and Salakhutdinov, 2006). It is even
possible to perform multi-modal learning with a mixture
of continuous and discrete variables. For all these archi-
tectures, the important point is that all interactions oc-
cur only between the visible and hidden units and there
are no interactions between units within the hidden or
visible layers, see Fig. 61. This is analogous to Quantum
Electrodynamics, where a free fermion and a free photon
interact with one another but not among themselves.
Specifying a generative model with this bipartite inter-
action structure has two major advantages: (i) it enables
capturing bothpairwise and higher-order correlations be-
tweenthevisibleunitsand(ii)itmakesiteasiertosample
from the model using an MCMC method known as block
Gibbs sampling, which in turn makes the model easier to
train.
Before discussing training, it is worth better under-
standing the kind of correlations that can be captured
usinganRBM.Todoso, wecanmarginalizeoverthehid-
den units and ask about the resulting distribution over
just the visible units
p(v) =Z
dhp(v;h) =Z
dhe E(v;h)
Z(206)
where the integral should be replaced by a trace in all
expressions for discrete units.
We can also deﬁne a marginal energy using the expres-
sion
p(v) =e E(v)
Z: (207)Combining these equations,
E(v) = logZ
dhe E(v;h)
= X
iai(vi) X
logZ
dheb(h)+P
iviWih
To understand what correlations are captured by p(v)it
is helpful to introduce the distribution
q(h) =eb(h)
Z(208)
of hidden units h, ignoring the interactions between v
andh, and the cumulant generating function
K(t) = logZ
dhq(h)eth=X
n(n)
tn
n!:(209)
K(t)is deﬁned such that the nthcumulant is (n)
=
@n
tKjt=0.
The cumulant generating function appears in the
marginal free-energy of the visible units, which can be
rewritten (up to a constant term) as:
E(v) = X
iai(vi) X
K X
iWivi!
= X
iai(vi) X
X
n(n)
(P
iWivi)n
n!
= X
iai(vi) X
i X
(1)
Wi!
vi
 1
2X
ij X
(2)
WiWj!
vivj+:::(210)
We see that the marginal energy includes all orders of in-
teractions between the visible units, with the n-th order
cumulants of q(h)weighting the n-th order interac-
tions between the visible units. In the case of the Hop-
ﬁeld model we discussed previously, q(h)is a standard
Gaussian distribution where the mean is (1)
= 0, the
variance is (2)
= 1, and all higher-order cumulants are
zero. Plugging these cumulants into Eq. (210) recovers
Eq. (202).
These calculations make clear the underlying reason
for the incredible representational power of RBMs with
aBernoullihiddenlayer. Eachhiddenunitcanencodein-
teractions of arbitrarily high order. By combining many
diﬀerent hidden units, we can encode very complex in-
teractions at all orders. Moreover, we can learn which
order of correlations/interactions are important directly
from the data instead of having to specify them ahead of
time as we did in the MaxEnt models. This highlights
the power of generative models with even the simplest in-
teractions between visible and latent variables to encode,
learn, and represent complex correlations present in the
data.
89
C. Training RBMs
RBMs are a special class of energy-based generative
models, which can be trained using the Maximum Like-
lihood Estimation (MLE) procedure described in detail
in Sec. XV. To brieﬂy recap, ﬁrst, we must choose a cost
function – for MLE this is just the negative log-likelihood
with or without an additional regularization term to pre-
vent overﬁtting. We then minimize this cost function us-
ing one of the Stochastic Gradient Descent (SGD) meth-
ods described in Sec. IV.
The gradient itself can be calculated using Eq. (195).
For example, for the Bernoulli-Bernoulli RBM in
Eq. (205) we have
@L(fWi;ai;bg)
@Wi=hvihidata hvihimodel
@L(fWi;ai;bg)
@ai=hviidata hviimodel
@L(fWi;ai;bg)
@b=hhidata hhimodel;(211)
where the positive expectation with respect to the data
is understood to mean sampling from the model while
clamping the visible units to their observed values in the
data. As before, calculating the negative phase of the
gradient (i.e. the expectation value with respect to the
model) requires that we draw samples from the model.
Luckily, the bipartite form of the interactions in RBMs
were speciﬁcally chosen with this in mind.
1. Gibbs sampling and contrastive divergence (CD)
ThebipartiteinteractionstructureofanRBMmakesit
possible to calculate expectation values using a Markov
Chain Monte Carlo (MCMC) method known as Gibbs
sampling. The key reason for this is that since there are
no interactions of visible units with themselves or hidden
units with themselves, the visible and hidden units of an
RBM are conditionally independent:
p(vjh) =Y
ip(vijh)
p(hjv) =Y
p(hjv); (212)
with
p(vi= 1jh) =(ai+X
Wih)(213)
p(h= 1jv) =(b+X
iWivi)
and where(z) = 1=(1 + e z)is the sigmoid function.
Using these expressions it is easy to compute expec-
tation values with respect to the data. The input to
t = 0 t = 1 t = 2 t = οο
data
t = 0 t = 1 t = 2 t = n
dataA
B
t = 0 t = 1 t = 2 t = n
fantasy particles
from last SGD stepCAlternating Gibbs Sampling
Contrastive Divergence (CD-n)
Persistent Contrastive Divergence (PCD-n)FIG. 62 (Top) To draw fantasy particles (samples from the
model) we can perform alternating (block) Gibbs sampling
between the visible and hidden layers starting with a sam-
ple from the data using the marginal distributions p(hjv)
andp(vjh). The “time” tcorresponds to the time in the
Markov chain for the Monte Carlo and measures the num-
ber of passes between the visible and hidden states. (Middle)
In Contrastive Divergence (CD), we approximately sample
the model by terminating the Gibbs sampling after nsteps
(CD-n) starting from the data. (C) In Persistent Contrastive
Divergence (PCD), instead of restarting the Gibbs sampler
from the data, we initialize the sampler with the fantasy par-
ticles calculated from the model at the last SGD step.
gradient descent is a minibatch of observed data. For
each sample in the minibatch, we simply clamp the visi-
bleunitstotheobservedvaluesandapplyEq.(213)using
the probability for the hidden variables. We then average
overallsamplesintheminibatchtocalculateexpectation
values with respect to the data. To calculate expectation
values with respect to the model, we use (block) Gibbs
sampling. The idea behind (block) Gibbs sampling is
to iteratively sample from the conditional distributions
ht+1p(hjvt)andvt+1p(vjht+1)(see Figure 62,
top). Since the units are conditionally independent, each
step of this iteration can be performed by simply draw-
ing random numbers. The samples are guaranteed to
converge to the equilibrium distribution of the model in
the limit that t!1. At the end of the Gibbs sampling
procedure, one ends up with a minibatch of samples (fan-
tasy particles).
One drawback of Gibbs sampling is that it may take
many back and forth iterations to draw an independent
sample. For this reason, the Hinton group introduced
an approximate Gibbs sampling technique called Con-
trastive Divergence (CD) (Hinton, 2002; Hinton et al.,
2006). In CD- n, we just perform niterations of (block)
90
Gibbs sampling, with noften taken to be as small as 1
(seeFigure62)! Thepriceforthistruncationis,ofcourse,
that we are not drawing samples from the true model dis-
tribution. But for our purpose – using the expectations
to estimate the gradient for SGD – CD- nhas proven to
work reasonably well. As long as the approximate gra-
dients are reasonably correlated with the true gradient,
SGD will move in a reasonable direction. CD- nof course
does come at a price. Truncating the Gibbs sampler pre-
vents sampling far away from the starting point, which
forCD-narethedatapointsintheminibatch. Therefore,
our generative model will be much more accurate around
regions of feature space close to our training data. Thus,
as is often the case in ML, CD- nsacriﬁces the ability
to generalize to some extent in order to make the model
easier to train.
Some of these undesirable features can be tempered
by using a slightly diﬀerent variant of CD called Persis-
tent Contrastive Divergence (PCD) (Tieleman and Hin-
ton, 2009). In PCD, rather than restarting the Gibbs
sampler from the data at each gradient descent step, we
start the Gibbs sampling at the fantasy particles in the
last gradient descent step (see Fig. 62). Since parameters
change slowly compared to the Gibbs sampling, samples
that are high probability at one step of the SGD are also
likely to be high probability at the next step. This en-
sures that PCD does not introduce large errors in the
estimation of the gradients. The advantage of using fan-
tasy particles to initialize the Gibbs sampler is to allow
PCD to explore parts of the feature space that are much
further from the training dataset than one could reach
with ordinary CD.
We note that, in applications using RBMs as a vari-
ational ansatz for quantum states, Gibbs sampling is
not necessarily the best option for training, and in prac-
tice parallel tempering or other Metropolis schemes can
outperform Gibbs sampling. In fact, Gibbs sampling is
not even feasible with complex-valued weights required
for quantum wavefucntions, whereas Metropolis schemes
might be feasible (Carleo, 2018).
2. Practical Considerations
The previous section gave an overview of how to train
RBMs. However, there are many “tricks of the trade”
that are missing from this discussion. Luckily, a succinct
summaryofthesehasbeencompiledbyGeoﬀHintonand
published as a note that readers interested in training
RBMs are urged to consult (Hinton, 2012).
For completeness, we brieﬂy list some of the important
points here:
•Initialization.— The model must be initialized.
Hinton suggests taking the weights Wifrom a
Gaussian with mean zero and standard deviation
Deep Boltzmann
Machine (DBM)Layerwise
PretrainingFine-tuning with
PCD on full DBMFIG. 63 Deep Boltzmann Machine contain multiple hidden
layers. To train deep networks, ﬁrst we perform layerwise
training where each two layers are treated as a RBM. This
can be followed by ﬁne-tuning using gradient descent and per-
sistent contrastive divergence (PCD).
= 0:01(Hinton, 2012). An alternative initial-
ization scheme proposed by Glorot and Bengio in-
stead chooses the standard deviation to scale with
the size of the layers: = 2=pNv+NhwhereNv
andNhare number of visible and hidden units re-
spectively (Glorot and Bengio, 2010). The bias of
the hidden units is initialized to zero while the bias
of the visible units is typically taken to be inversely
proportional to the mean activation, ai=hvii 1
data.
•Regularization. —One can of course use an L1 or
L2 penalty, typically only on the weight parame-
ters, not the biases. Alternatively, Dropout has
been shown to decrease overﬁtting when training
with CD and PCD, which results in more inter-
pretable learned features.
•Learning Rates. —Typically, it is helpful to re-
duce the learning rate in later stages of training.
•Updates for CD and PCD. —There are several
computational tricks one can use for speeding up
the alternating updates in CD and PCD, see Sec-
tion 3 in (Hinton, 2012).
D. Deep Boltzmann Machine
In this section, we introduce Deep Boltzmann Ma-
chines (DBMs). Unlike RBMs, DBMs possess multi-
ple hidden layers and were the ﬁrst models rebranded
as “deep learning” (Hinton et al., 2006; Hinton and
Salakhutdinov, 2006)18. Many of the advantages that
18Technically, these were Deep Belief Networks where only the top
layer was undirected
91
are thought to stem from having deep layers were al-
ready discussed in Sec. XI in the context of discrimina-
tive DNNs. Here, we revisit many of the same themes
with emphasis on energy-based models.
An RBM is composed of two layers of neurons that
are connected via an undirected graph, see Fig. 61. As
a result, it is possible to perform sampling vp(vjh)
and inference hp(hjv)with the same model. As with
the Hopﬁeld model, we can view each of the hidden units
as representative of a pattern, or feature, that could be
presentinthedata.19Theinferencestepinvolvesassign-
ing a probability to each of these features that expresses
the degree to which each feature is present in a given
data sample. In an RBM, hidden units do not inﬂuence
each other during the inference step, i.e. hidden units are
conditionally independent given the visible units. There
are a number of reasons why this is unsatisfactory. One
reasonisthedesireforsparsedistributedrepresentations,
where each observed visible vector will strongly activate
a few (i.e. more than one but only a very small frac-
tion) of the hidden units. In the brain, this is thought
to be achieved by inhibitory lateral connections between
neurons. However, adding lateral intra-layer connections
between the hidden units makes the distribution diﬃcult
to sample from, so we need to come up with another way
of creating connections between the hidden units.
With the Hopﬁeld model, we saw that pairwise linear
connections between neurons can be mediated through
another layer. Therefore, a simple way to allow for ef-
fective connections between the hidden units is to add
another layer of hidden units. Rather than just having
two layers, one visible and one hidden, we can add addi-
tional layers of latent variables to account for the corre-
lations between hidden units. Ideally, as one adds more
and more layers, one might hope that the correlations
between hidden variables become smaller and smaller
deeperintothenetwork. Thisbasiclogicisreminiscentof
renormalization procedures that seek to decorrelate lay-
ers at each step (Li and Wang, 2018; Mehta and Schwab,
2014; Vidal, 2007). The price of adding additional layers
is that the models become harder to train.
Training DBMs is more subtle than RBMs due to the
diﬃculty of propagating information from visible to hid-
den units. However, Hinton and collaborators realized
that some of these problems could be alleviated via a lay-
erwise procedure. Rather than attempting to the train
the whole DBM at once, we can think of the DBM as a
stack of RBMs (see Fig. 63). One ﬁrst trains the bottom
two layers of the DBM – treating it as if it is a stand-
alone RBM. Once this bottom RBM is trained, we can
generate “samples” from the hidden layer and use these
19Ingeneral, oneshouldinsteadthinkofactivitypatternsofhidden
units representing features in the data.
FIG. 64 Fantasy particles (samples) generated using the in-
dicated model trained on the MNIST dataset. Samples were
generated by running (alternating) layerwise Gibbs sampling
for100steps. This allows the ﬁnal sample to be very far away
from the starting point in our feature space. Notice that the
generated samples look much less like hand-written recon-
structions than in Fig. 60 which uses a single max-probability
iteration of the Gibbs sampler, indicating that training is
muchlesseﬀectivewhenexploringregionsofprobabilityspace
faraway from the training data. In the Sec. XVII, we will ar-
gue that this is likely a generic feature of Likelihood-based
training.
samples as an input to the next RBM (consisting of the
ﬁrstandsecondhiddenlayer–purplehexagonsandgreen
squares in Fig. 63). This procedure can then be repeated
to pretrain all layers of the DBM.
This pretraining initializes the weights so that SGD
can be used eﬀectively when the network is trained in a
supervised fashion. In particular, the pretraining helps
the gradients to stay well behaved rather than vanish
or blow up – a problem that we discussed extensively
in the earlier sections on DNNs. It is worth noting that
oncepretrained, wecanusetheusualBoltzmannlearning
rules in Eq. (195) to ﬁne-tune the weights and improve
the performance of the DBM (Hinton et al., 2006; Hinton
and Salakhutdinov, 2006). As we demonstrate in the
next section, the Paysage package presented here can be
used to both construct and train DBMs using such a
pretraining procedure.
E. Generative models in practice: examples
1. MNIST
First, we apply the open source package Paysage
(French for landscape ) for training unsupervised energy-
based models on the MNIST dataset.
In Notebook 17, we explicitly demonstrate how to
build and train four diﬀerent kinds of models: (i) a
“Hopﬁeld” type RBM with Gaussian hidden units and
Bernoulli (binary) visible units, (ii) a conventional RBM
where both the visible and hidden units are Bernoulli,
(iii) a conventional RBM with an additional L1-penalty
that enforces sparsity, and (iv) a Deep Boltzmann Ma-
92
chine (DBM) with three Bernoulli layers with L1 penalty
each. We refer the reader to the Notebook for the details
of the code. In the following, we show and brieﬂy discuss
the results.
After training the model, we compute reconstructions
and fantasy particles from the validation data set. Recall
that a reconstruction v0of a given data point xis com-
puted in two steps: (i) we ﬁx the visible layer v=xto
be the data, and use MCMC sampling to ﬁnd the state
of the hidden layer hwhich maximizes the probability
distribution p(hjv). (ii) ﬁxing the same obtained state
h, we ﬁnd the reconstruction v0of the original data point
which maximizes the probability p(v0jh). In the case of
a DBM, the forward pass continues until we reach the
last of the hidden layers, and the backward pass goes in
reverse. Figure 60 shows the result.
We also used MCMC to draw samples from the learned
probability distributions, the so-called fantasy particles.
To this end, we did layer-wise Gibbs sampling for a total
of a ﬁxed number of equilibration steps. The result is
shown in Figure 64.
Finally, one can use generative models to reduce the
noise in images (de-noising). We randomly ﬂipped a frac-
tion of the black&white bits in the validation data, and
use the models deﬁned above to reconstruct (de-noise)
the digit images. Figure 65 shows the result.
The full Paysage code used to generate Figs. 60, 64
and 65 is available in Notebook 17. The pack-
age was developed by one of the authors (CKF)
along with his colleagues at Unlearn.AI and makes
it easy to build, train, and deploy energy-based
generative models with diﬀerent architectures.
Paysage’s documentation is available on GitHub under
https://github.com/drckf/paysage/tree/master/docs.
2. Example: 2D Ising Model
We can also analyze the 2D Ising data set. In previous
sections, we used our knowledge of the critical point at
Tc=J2:26(see Onsager’s solution) to label the spin
conﬁgurations and study the problem of classifying the
states according to their phase of matter. However, in
more complicated models, where the precise position of
Tcis not known, one cannot label the states with such
an accuracy, if at all.
As we explained, generative models can be used to
learn a variational approximation for the probability dis-
tribution that generated the data points. By using only
the 2D spin conﬁgurations, we now attempt to train a
Bernoulli RBM, the fantasy particles of which are ther-
mal Ising conﬁgurations. Unlike in previous studies of
the Ising dataset, here we perform the analysis at a ﬁxed
temperature T. We can then apply our model at three
diﬀerent values T= 1:75;2:25;2:75in the ordered, near-
critical and disordered regions, respectively.
FIG. 65 Images from MNIST were randomly corrupted by
adding noise. These noisy images were used as inputs to the
visible layer of the generative model. The denoised images
are obtained by a single “deterministic” (max probability) it-
eration v!h!v0.
We deﬁne a Deep Boltzmann machine with two hidden
layers ofNhiddenandNhidden=10units, respectively, and
applyL1regularization to all weights. As in the MNIST
problem above, we use layer-wise pre-training, and de-
ploy Persistent Contrastive Divergence to train the DBM
using ADAM.
One of the lessons from this problem is that this task is
computationally intensive, see Notebook 17. The train-
ingtimeonpresent-daylaptopseasilyexceedsthatofpre-
vious studies from this review. Thus, we encourage the
interested reader to try GPU-based training and study
the resulting speed-up.
Figures 66, 67 and 68 show the results of the numerical
experiment at T=J = 1:75;2:25;2:75respectively, for a
DBMwithNhidden = 800. Lookingatthereconstructions
and the fantasy particles, we see that our DBM works
well in the disordered and critical regions. However, the
chosen layer architecture is not optimal for T= 1:75in
the ordered phase, presumably due to eﬀects related to
symmetry breaking.
F. Generative models in physics
Generative models have been studied and used ex-
tensively in the context of physics. For instance, in
Biophysics, dynamic Boltzmann distributions have been
used as eﬀective models in chemical kinetics (Ernst et al.,
2018). In Statistical Physics, they were used to identify
criticality in the Ising model (Morningstar and Melko,
2017). In parallel, tools from Statistical Physics have
beenappliedtoanalyzethelearningabilityofRBMs(De-
celleet al., 2018; Huang, 2017b), characterizing the spar-
sity of the weights, the eﬀective temperature, the non-
93
FIG. 66 MC samples, their reconstructions and fantasy particles generated by a Deep Boltzmann Machine in the ordered
phaseof the the 2D Ising data set at T=J = 1:75. We used two hidden layers of 1000and100layers, respectively.
FIG. 67 MC samples, their reconstructions and fantasy particles generated by a Deep Boltzmann Machine in the critical
regimeof the the 2D Ising data set at T=J = 2:25. We used two hidden layers of 1000and100layers, respectively.
linearities in the activation functions of hidden units,
and the adaptation of ﬁelds maintaining the activity in
the visible layer (Tubiana and Monasson, 2017). Spin
glass theory motivated a deterministic framework for
the training, evaluation, and use of RBMs (Tramel
et al., 2017); it was demonstrated that the training pro-
cess in RBMs itself exhibits phase transitions (Barra
et al., 2016, 2017); learning in RBMs was studied in the
context of equilibrium (Cossu et al., 2018; Funai and
Giataganas, 2018) and nonequilibrium (Salazar, 2017)
thermodynamics, and spectral dynamics (Decelle et al.,
2017); mean-ﬁeld theory found application in analyzing
DBMs (Huang, 2017a). Another interesting direction of
researchistheuseofgenerativemodelstoimproveMonte
Carlo algorithms (Cristoforetti et al., 2017; Nagai et al.,
2017; Tanaka and Tomiya, 2017b; Wang, 2017). Ideas
from quantum mechanics have been put forward to in-
troduce improved speed-up in certain parts of the learn-
ing algorithms for Helmholtz machines (Benedetti et al.,
2016, 2017).
At the same time, generative models have applica-tions in the study of quantum systems too. Most no-
tably, RBM-inspired variational ansatzes were used to
learn both complex-valued wavefunctions and the real-
valued probability distribution associated with the abso-
lute square of a quantum state (Carleo et al., 2018; Car-
leo and Troyer, 2017; Freitas et al., 2018; Nomura et al.,
2017; Torlai et al., 2018) and, in this context, RBMs are
sometimes called Born machines (Cheng et al., 2017), in-
cluding quantum state tomorgraphy (Carrasquilla et al.,
2018; Torlai et al., 2018; Torlai and Melko, 2017). Fur-
ther applications include the detection of order in low-
energy product states (Rao et al., 2017), and learning
Einstein-Podolsky-Rosen correlations on an RBM (Wein-
stein,2017). Inspiredbythesuccessoftensornetworksin
physics, the latter have been used as a basis for both gen-
erativeanddiscriminativelearning(Huggins et al.,2019):
RBMs (Chen et al., 2018) were used to extract the spa-
tial geometry from entanglement (You et al., 2017), and
generative models based on matrix product states have
been developed (Han et al., 2017). Last but not least,
Quantum entanglement was studied using RBM-encoded
94
FIG. 68 MC samples, their reconstructions and fantasy particles generated by a Deep Boltzmann Machine in the disordered
phaseof the the 2D Ising data set at T=J = 2:75. We used two hidden layers of 1000and100layers, respectively.
states (Deng et al., 2017) and tensor product based gen-
erativemodelshavebeenusedtounderstandMNISTand
other ML datasets (Stoudenmire and Schwab, 2016).
XVII. VARIATIONAL AUTOENCODERS (VAES) AND
GENERATIVE ADVERSARIAL NETWORKS (GANS)
In the previous two sections, we considered energy-
based generative models. Here, we extend our discus-
sion to two new generative model frameworks that have
gained wide appeal in the the last few years: generative
adversarial networks (GANs) (Goodfellow, 2016; Good-
fellowet al., 2014; Radford et al., 2015) and variational
autoencoders (VAEs) (Kingma and Welling, 2013). Un-
likeenergy-basedmodels, boththesegenerativemodeling
frameworks are based on diﬀerentiable neural networks
and consequently can be trained using backpropagation-
based methods. VAEs, in particular, can be easily im-
plemented and trained using high-level packages such as
Keras making them an easy-to-deploy generative frame-
work. These models also diﬀer from the energy-based
models in that they do not directly seek to maximize like-
lihood. GANs, for example, employ a novel cost function
based on adversarial learning (a concept we motivate and
explainbelow). FinallywenotethatVAEsandGANsare
already starting to make their way into physics (Heimel
et al., 2018; Liu et al., 2017; Rocchetto et al., 2018; Wet-
zel,2017)andastronomy(Ravanbakhsh et al.,2017), and
methods from physics may prove useful for furthering
our understanding of these methods (Alemi and Abbara,
2017). More generally, GANs have found important ap-
plications in many artistic and image manipulation tasks
(see references in (Goodfellow, 2016)).
The section is organized as follows. We start by moti-
vating adversarial learning by discussing the limitations
of maximum likelihood based approaches. We then give
a high-level introduction to the main idea behind gen-
erative adversarial networks and discuss how they over-come some of these limitations, simultaneously highlight-
ing both the power of GANs and some of the diﬃculties.
We then show how VAEs integrate the variational meth-
ods introduced in Sec. XIV with deep, diﬀerentiable neu-
ral networks to build more powerful generative models
that move beyond the Expectation Maximization (EM).
We then brieﬂy discuss VAEs from an information theo-
retic perspective, before discussing practical tips for im-
plementing and training VAEs. We conclude by using
VAEs on examples using the Ising and MNIST datasets
(see also Notebooks 19 and 20).
A. The limitations of maximizing Likelihood
The Kullback-Leibler (KL)-divergence plays a central
role in many generative models. Developing an intuition
about KL-divergences is one of the keys to understanding
whyadversariallearninghasprovedtobesuchapowerful
methodforgenerativemodeling. Here, werevisittheKL-
divergencewithaneyetowardsunderstandingGANsand
motivate adversarial learning. The KL-divergence mea-
sures the similarity between two probability distributions
p(x)andq(x). Strictly speaking, the KL divergence is
not a metric because it is not symmetric and does not
satisfy the triangle inequality.
Given two distributions, there are two distinct KL-
divergences we can construct:
DKL(pjjq) =Z
dxp(x) logp(x)
q(x)(214)
DKL(qjjp) =Z
dxq(x) logq(x)
p(x):(215)
ArelatedquantitycalledtheJensen-Shannondivergence,
DJS(p;q) =1
2
DKL
pp+q
2
+DKL
qp+q
2
does satisfy all of the properties of a squared metric (i.e.,
the square root of the Jensen-Shannon divergence is a
95
−15−10−5 0 5 10 15
x∆ = 2.0
Model
Data
0.0 0.5 1.0 1.5 2.0 2.5 3.0
∆05101520Data-Model
Model-Data
FIG. 69 KL-divergences between the data distribution pdata
and the model p. Data is drawn from a bimodal Gaus-
sian distribution with unit variances peaked at with
 = 2:0and the model p(x)is a Gaussian with mean zero
and same variance as p(x). (Top)pdataandpfor = 2.
(Bottom)DKL(pdatajjp)(Data-Model) and DKL(pjjpdata)
(Model-Data) as a function of . Notice that DKL(pdatajjp)
is insensitive to placing weight in the model distribution in
regions where pdata0whereasDKL(pjjpdata)punishes this
harshly.
metric). An important property of the KL-divergence
that we will make use of repeatedly is its positivity:
DKL(pjjq)0with equality if and only if p(x) =q(x)
almost everywhere.
In generative models in ML, the two distributions
we are usually concerned with are the model distribu-
tionp(x)and the data distribution pdata(x). We of
course would like these models to be as similar as possi-
ble. However, as we discuss below, there are many sub-
tleties about how we measure similarities that can have
large consequences for the behavior of training proce-
dures. Maximizing the log-likelihood of the data under
the model is the same as minimizing the KL divergence
between the data distribution and the model distribu-
tionDKL(pdatajjp). To see this, we can rewrite the KL
−15−10−50 5 10 15
x∆ = 5.0
Model
Data
−4−2 0 2 4
x∆ = 1.0
Model
Data
0 2 4 6 8 10
∆012345Data-Model
Model-DataFIG. 70 KL-divergences between the data distribution pdata
and the model p. Data is drawn from a Gaussian mixture
of the form pdata = 0:25N( ) + 0:25N() + 0:5N(0)
whereN(a)is a normal distribution with unit variance cen-
tered atx=a.p(x)is a Gaussian with 2= 2. (Top)
pdataandpfor = 5. (Middle) pdataandpfor = 1.
(Bottom)DKL(pdatajjp)[Data-Model] and DKL(pjjpdata)
[Model-Data] as a function of . Notice that DKL(pjjpdata)
is insensitive to placing weight in the model distribution in
regions where p0whereasDKL(pdatajjp)punishes this
harshly .
96
divergence as:
DKL(pdatajjp) =Z
dxpdata(x) logpdata(x)
 Z
dxpdata(x) logp(x)
= S[pdata] hlogp(x)idata(216)
Rearranging this equation, we have
hlogp(v)idata= S[pdata] DKL(pdatajjp)(217)
The equivalence follows from the positivity of KL-
divergence and the fact that the entropy of the data
distribution is constant. In contrast, the original for-
mulation of GANs minimizes an upper bound on the
Jensen-Shannon divergence between the model distribu-
tionp(x)andthedatadistribution pdata(x)(Goodfellow
et al., 2014).
This diﬀerence in objectives underlies the diﬀerence in
behavior between GANs and likelihood based generative
models. To see this, we can compare the behavior of the
two KL-divergences DKL(pdatajjp)andDKL(pjjpdata).
As is evident from Fig. 69 and Fig. 70, though both of
these KL-divergences measure similarities between the
two distributions, they are sensitive to very diﬀerent
things.DKL(pjjpdata)is insensitive to setting p0
even when pdata6= 0whereasDKL(pdatajjp)punishes
this harshly. In contrast, DKL(pdatajjp)is insensitive
to placing weight in the model distribution in regions
wherepdata0whereasDKL(pjjpdata)punishes this
harshly. In other words, DKL(pdatajjp)prefers models
that have a high probability in regions with lots of train-
ing data points whereas DKL(pjjpdata)punishes models
for putting high probability where there is no data.
In the context of the above discussion, this suggests
that the way likelihood-based methods are most likely to
fail, is by improperly “ﬁlling in” any low-probability den-
sity regions between peaks in the data distribution. In
contrast, at least in principle, the Jensen-Shannon distri-
bution which underlies GANs is sensitive both to placing
weight where there is data since it has information about
DKL(pdatajjp)and to not placing weight where no data
hasbeenobserved(i.e.inlow-probabilitydensityregions)
since it has information about DKL(pjjpdata).
In practice, DKL(pdatajjp)can be calculated easily
directly from the data using sampling. On the other
hand,DKL(pjjpdata)is impossible to compute since we
do not know pdata(x). In particular, this integral cannot
be calculated using sampling since we cannot evaluate
pdata(x)at the locations of the fantasy particles. The
idea of adversarial learning is to circumnavigate this dif-
ﬁculty by using an adversarial learning procedure. Re-
call, thatDKL(pjjpdata)is large when the model artiﬁ-
ciallyover-weighslow-densityregionsnearrealpeaks(see
Fig. 69). Adversarial learning accomplishes this same
task by teaching a discriminator network to distinguish
x sampled from
data “Discriminator”
network  D   D(x)  tries to
be near 1
latent space
input  z “Generator”
network  G  G tries to make
D(G(z))be near 1 D(x)  tries to make 
D(G(z))be near 0
x sampled from
dataDFIG. 71 A GAN consists of two diﬀerentiable functions (usu-
ally represented as deep neural networks): a generator func-
tionG(z;G)that takes as an input a zsampled from some
prioronthelatentspaceandoutputsapoint x. Thegenerator
function (neural network) has parameters G. The discrim-
inator function D(x;D)discriminates between xfrom the
dataandsamplesfromthemodel: x=G(z;G). Thetwonet-
worksaretrainedby“playingagame” wherethediscriminator
is trained to distinguish between synthetic and real examples
while the generator is trained to try to fool the discriminator.
Importantly, the cost function for the discriminator depends
on the generator parameters and vice versa.
between real data points and samples generated from the
model. By punishing the model for generating points
that can be easily discriminated from the data, adversar-
ial learning decreases the weight of regions in the model
space that are far away from data points – regions that
inevitably arise when maximizing likelihood. This core
intuition implicitly underlies many adversarial training
algorithms (though it has been recently suggested that
this may not be the entire story (Goodfellow, 2016)).
B. Generative models and adversarial learning
Here, we give a brief high-level overview of the ba-
sic idea behind GANs. The mathematics and theory
of GANs draws deeply from concepts in Game Theory
such as Nash Equilibrium that are foreign to most physi-
cists. For this reason, a comprehensive discussion of
97
GANs is beyond the scope of the review. Readers inter-
ested in learning more are directed to the comprehensive
tutorial by Goodfellow (Goodfellow, 2016). GANs are
also notorious for being hard to train. For this reason,
readers wishing to play with GANs should also consider
the very nice practical discussion entitled “How to train
a GAN” (aﬀectionately labeled “ganhacks”) available at
https://github.com/soumith/ganhacks .
The central idea of GANs is to construct two diﬀer-
entiable neural networks (see Fig. 71). The ﬁrst neural
network, usually a (de)convolutional network based on
the DCGAN architecture (Radford et al., 2015), approx-
imates a generator function G(z;G)that takes as input
azsampledfromsomeprioronthelatentspace, andout-
puts a xfrom the model. The second network approxi-
mates a discriminator function D(x;D)that is designed
to distinguish between xfrom the data and samples gen-
erated by the model: x=G(z;G). The scalar D(x)rep-
resents the probability that xcame from the data rather
than the model pG. We train Dto distinguish actual
data points from synthetic examples and the generative
network to fool the discriminative network.
To deﬁne the cost function for training, it is useful to
deﬁne the functional
V(D;G ) =Expdata(logD(x))
+Ezpprior(log [1 D(G(z))]):(218)
In the version of GANs most amenable to theoretical
analysis – though not the version usually implemented
in practice – we take the cost function for the discrimi-
nator and generators to be C(G)= C(D)=1
2V(D;G ).
Thischoiceofcostfunctionscorrespondstowhatiscalled
a zero-sum game. Since the discriminator is maximized,
we can write a cost function for the generator as
C(G) = max
DV(G;D ): (219)
It turns out that this cost function is related to the
Jensen-Shannon Divergence in a simple manner (Good-
fellow, 2016; Goodfellow et al., 2014):
C(G) = log 4 + 2DJS(pdata;pG):(220)
This brings us back full circle to the discussion in the last
section on KL-divergences.
C. Variational Autoencoders (VAEs)
We now turn our attention to another class of powerful
latent-variable, generative models called Variational Au-
toencoders (VAEs). VAEs exploit the variational/mean-
ﬁeld theory ideas presented in Sec. XIV to build complex
generative models using deep neural networks (DNNs).
The central idea behind VAEs is to represent the map
from latent variables to observable variables using a
Prior distribution: p (z)θ
p (x|z)θq (z|x)φDecoder: Encoder: 
Dataset: D x-spacez-spaceFIG. 72 VAEs learn a joint distribution p(x;z)between
latent variables zwith prior distribution p(z)and data x.
The conditional distribution p(xjz)can be thought of as a
stochastic “decoder” that maps latent variables to new ex-
amples. The stochastic “encoder” q(zjx)approximates the
true but intractable p(zjx)– much like mean-ﬁeld theories
in statistical physics approximate true distributions with ana-
lytically tractable approximations. Figure based on Kingma’s
Ph.D. dissertation Chapter 2. (Kingma et al., 2017).
DNN. The use of latent variables is a common theme
in many of the generative models we have encountered in
unsupervisedlearningtasksfromGaussianMixtureMod-
els (see Sec. XIII) to Restricted Boltzmann Machines.
However, in VAEs this mapping, p(xjz;)is much less
restrictive and much more complicated since it takes the
form of a DNN. This added complexity means we can-
not use techniques such as Expectation Maximization to
train the model and instead must rely of methods based
on backpropagation.
1. VAEs as variational models
We start by discussing VAEs from a variational per-
spective. We will make extensive use of the concepts
introduced in Sec. XIV and the reader is strongly-
encouraged to refresh their memory of this section before
proceeding. A VAE is a latent-variable model p(x;z)
with a latent variables zand observed variables x. The
latent variables are drawn from some pre-speciﬁed prior
distribution p(z). Inpractice, p(z)isalmostalwaystaken
98
to be a multivariate Gaussian. The conditional distribu-
tionp(xjz)maps points in the latent space to new ex-
amples (see Fig. 72). This is often called a “stochastic
decoder” and deﬁnes the generative model for the data.
The reverse mapping that gives the posterior over the
latent variables p(zjx)is often called the “stochastic en-
coder”.
A central challenge in latent variable modeling is to in-
fer the posterior distribution of the latent variables given
a sample from the data. This can in principle be done
via Bayes’ rule: p(zjx) =p(z)p(xjz)
p(x). For some models,
we can calculate this analytically. In this case, we can
use techniques like Expectation Maximization (EM) (see
Sec. XIV). However, in general this is intractable since
the denominator requires computing a sum over all con-
ﬁgurations of the latent variables, p(x) =R
p(x;z)dz=R
p(xjz)p(z)dz(i.e. a partition function in the language
of physics), which is often intractable for large models.
In VAEs, where the p(xjz)is modeled using a DNN, this
is impossible.
A ﬁrst attempt to address the issue of computing
p(x)could be through importance sampling (Neal, 2001).
That is, we choose a proposal distribution q(zjx)which
is easy to sample from, and rewrite the sum as an expec-
tation with respect to this distribution:
p(x) =Z
p(xjz)p(z)
q(zjx)q(zjx)dz:(221)
Thus, bysamplingfrom q(zjx)wecangetaMonteCarlo
estimate of p(x). However, this requires generating sam-
ples and thus our estimates will be noisy. If our proposal
distribution is poor, the variance in the estimate can be
very high.
An alternative approach that avoids these sampling
issues is to use the variational approach discussed in
Sec. XIV. We know from Eq. (162) that we can write
the log-likelihood as
logp(x) =DKL(q(zjx)kp(zjx;)) Fq(x);(222)
where the variational free energy is deﬁned as
 Fq(x)Eq(zjx)[logp(xjz)] DKL(q(zjx)jp(z)):
(223)
In writing this term, we have used Bayes rule and
Eq. (174). Since the KL-divergence is strictly positive,
the (negative) variational free energy is a lower-bound on
the log-likelihood. For this reason, in the VAE literature,
it is often called the Evidence Lower BOund or ELBO.
Equation (223) has a beautiful interpretation. The
ﬁrst term in this equation can be viewed as a “recon-
struction error”, where we start with data x, encode it
into the latent representation using our approximate pos-
teriorq(zjx), and then evaluate the log probability of
the original data given the inferred latents. For binary
variables, this is just the cross-entropy which we ﬁrst en-
countered when studying logistic regression, cf. Sec. VII.The second term acts as a regularizer and encourages the
posteriordistributionstobecloseto p(z). Bymaximizing
the ELBO, we minimize the KL-divergence between the
approximate and true posterior. By choosing a tractable
q(zjx), we make this feasible (see Fig. 72).
2. Training via the reparametrization trick
VAEs train models by minimizing the variational free
energy (maximizing the ELBO). Training a VAE is some-
what complicated because we must simultaneously learn
two sets of parameters: the parameters that deﬁne our
generative model p(x;z)as well as the variational pa-
rametersinq(zjx). The basic approach will be the
same as for all DNN models: we will use gradient de-
scent with the variational free energy as the objective
(cost) function. For a dataset L, we can write our cost
function as
C;(L) =X
x2L Fq(x): (224)
Taking the gradient with respect to is easy since only
the ﬁrst term in Eq. (223) depends on ,
C;(x) =Eq(zjx)[rlogp(xjz)]
rlogp(xjz) (225)
where in the second line we have replaced the expec-
tation value with a single Monte-Carlo sample zdrawn
fromq(zjx)(see Fig. XVII.C.2). When p(xjz)is ap-
proximated by a neural network, this can be calculated
using backpropagation with the reconstruction error as
the objective function.
On the other hand, calculating the gradient with re-
spect to the parameters is more complicated since 
also appears in the expectation value Eq(zjx). Ideally, we
would like to also use backpropagation to calculate this
as well. It turns out that this can be done by a simple
change of variables that often goes under the name the
“reparameterization trick” (Kingma and Welling, 2013;
Rezende et al., 2014). The basic idea is to change vari-
ables so that no longer appears in the distribution we
are taking an expectation value with respect to. To do
this, we express the random variable zq(zjx)as some
diﬀerentiable and invertible transformation of another
random variable :
z=g(;;x); (226)
where the distribution of is independent of xand.
Then, we can replace expectation values over q(zjx)by
expectation values over p
Eq(zjx)[f(z)] =Ep[f(z)]: (227)
Evaluatingthederivativethenbecomesquitestraightfor-
ward since
rEq(zjx)[f(z)]Ep[rf(z)]:(228)
99
q (z|x)φInference ModelDatapoint
zGenerative Model
p (x|z)θ
Negative 
Variational Free Energy:
(ELBO)E [ p (x|z)θlog - q (z|x)||p(z))φSample
KL( ]
q (z|x)φ
FIG. 73 Schematic explaining the computational ﬂow of VAEs. Figure based on Kingma’s Ph.D. dissertation Chapter 2.
(Kingma et al., 2017).
Of course, when we do this we still need to be able to
calculate the Jacobian of this change of variables
d(x;) = Det@z
@(229)
since
logq(zjx) = logp() logd(x;):(230)
Since we can calculate gradients, we can now use back-
propagation on the full the ELBO objective function (we
return to this below when we discuss concrete architec-
tures and implementations of VAE).
Oneoftheproblemsthatcommonlyoccurswhentrain-
ing VAEs by performing a stochastic optimization of the
ELBO (variational free energy) is that it often gets stuck
in undesirable local minima, especially at the beginning
of the training procedure (Bowman et al., 2015; Kingma
et al., 2017; Sønderby et al., 2016). The underlying rea-
son for this is that the ELBO objective function can be
improved in two qualitatively diﬀerent ways correspond-
ing to each of the two terms in Eq. (223): by minimizing
the reconstruction error or by making the posterior dis-
tributionq(zjx)to be close to p(z)(Of course, the goal
is to do both!). For complex datasets, at the beginning of
training when the reconstruction error is extremely poor,
the model often quickly learns to make q(zjx)p(z)and
getsstuckinthislocalminimum. Forthisreason, inprac-
tice it is found that it makes sense to modify the ELBO
objective to use an optimization schedule of the form
Eq(zjx)[logp(xjz)] DKL(q(zjx)jp(z))(231)
whereis slowly annealed from 0to1(Bowman et al.,
2015; Sønderby et al., 2016). An alternative regulariza-
tion is the “method of free bits”: modifying the objective
function of ELBO to ensure that on average q(zjx)has
at leastnatural units of information about p(z)(see
Kingma Ph.D thesis (Kingma et al., 2017) for details) .These observations hints at the more general connec-
tion between VAEs and information theory that we turn
to in the next section.
3. Connection to the information bottleneck
There is a fundamental connection between the vari-
ational autoencoder objective and the information bot-
tleneck (IB) for lossy compression (Tishby et al., 2000).
The information bottleneck imagines we have input data
xthat is correlated with another variable of interest, y,
and we are given access to the joint distribution, p(x;y).
Our task is to take xas input and compress it in such a
way as to retain as much information as possible about
the relevance variable, y. To do this, Tishby et al. pro-
pose to maximize the objective function
LIB=I(y;z) I(x;z) (232)
over a stochastic encoding distribution q(zjx), wherezis
our compression of the input, and is a tradeoﬀ param-
eter that sets the relative preference of compression and
accuracy, and I(y;z)isthemutualinformationbetween y
andz. Note that we choose a slightly diﬀerent but equiv-
alent form of the objective relative to Tishby et al.. This
objective is only known to have a closed-form solution
whenxandyare jointly Gaussian (Chechik et al., 2005).
Otherwise, the optimization can be performed through a
Blahut-Arimoto type iterative update scheme (Arimoto,
1972; Blahut, 1972). However, this is only guaranteed to
converge to a local optimum. A signiﬁcant diﬃculty in
implementing IB is that it requires knowledge of the joint
distribution p(x;y)and that we must be able to compute
the mutual information, a notoriously diﬃcult quantity
to estimate from samples. Hence, IB has in recent years
been utilized less than it might otherwise.
100
To address these problems, variational approximations
to the IB objective function have been developed (Alemi
et al., 2016; Chalk et al., 2016). These approximations,
when applied to a particular choice of p(x;y)give the
same objective as the variational autoencoder. Here
we follow the exposition from Alemi et al.(Alemi et al.,
2016). To see this, consider a dataset of Npoints,xi.
We setx=iandy=xiin the IB objective, similar
to (Slonim et al., 2005; Strouse and Schwab, 2017). We
choosep(i) = 1=Nandp(xji) =(x xi). That is, we
wouldliketoﬁndacompressionofthedatathatpreserves
information about data point location while reducing in-
formation about data point identity.
Imagine that we are unable to directly work with the
decoderp(xjz). The ﬁrst approximation replaces the ex-
act decoder inside the logarithm with an approximation,
q(xjz). Due to the positivity of KL-divergence, namely,
DKL(p(xjz)jjq(xjz))0
)Z
dxp(xjz) logp(xjz)Z
dxp(xjz) logq(xjz);
(233)
we have
I(x;z) =Z
dxdzp (x)p(zjx) logp(xjz)
p(x)
Z
dxdzp (x)p(zjx) logq(xjz) +Hp(x)
Z
dxdzp (x)p(zjx) logq(xjz); (234)
whereHp(x)0is the Shannon entropy of x. This
quantity can be estimated from data samples (i;xi)af-
ter drawing from p(zji) =p(zjxi). Similarly, we can
replace the prior distribution of the encoding, p(z) =R
dxp(x)q(zjx)which is typically intractable, with a
tractableq(z)to get
I(i;z)1
NX
iZ
dzp(zjxi) logp(zjxi)
q(z)(235)
Putting these two bounds Eqs. (234)and (235) together
and note that x=iandy=xi, we get an upper bound
for the IB objective that takes the same form as the VAE
objective Eq. (231) we saw earlier:
LIB=I(x;z) I(y;z)
Z
dxp(x)Ep(zjx)[logq(xjz)](236)
 1
NX
iDKL(p(zjxi)jq(z)):(237)
Note that in Eq. (236) we have a conditional distribution
ofxgivenzbut not their joint distribution inside the
expectation, which was the case in Eq. (231). This is
due to that we dropped the entropy term pertaining to
Hidden layers
Zmeanlog σzData
Latent layer parametersNeural network with
weights φ 
q (z|x)||p(z))φKL(Use analytic expression 
for Gaussians
ε Standard normal  variablex
Hidden layersLatent variable
Neural network with
weights   z
p θReconstruction  
E [ p (x|z)θlog
q (z|x)φ]Reconstruction Error
(i.e. cross-entropy)  FIG. 74 Computational graph for a VAE with Gaussian hid-
den units (i.e. p(z)are standard normal variables N(0;1)and
Gaussian variational encoder whose posterior takes the form
q(zjx) =N((x);2(x)).
x, which is irrelevant in the optimization procedure. In
fact, this objective has been explored and is called a -
VAE(Higgins et al.,2016). It’sinterestingtonotethatin
the case of IB, the variational approximations are with
respect to the decoder and prior, whereas in the VAE,
the variational approximations are with respect to the
encoder.
D. VAE with Gaussian latent variables and Gaussian encoder
Our discussion of VAEs thus far has been quite ab-
stract. In this section, we discuss one of the most widely
employed VAE architectures: a VAE with factorized
Gaussian posteriors, q(zjx) =N(z;(x);diag(2(x)))
and standard normal latent variables p(z) =N(0;I).
The training and implementation simpliﬁes greatly
here because we can analytically workout the term
DKL(q(zjx)jp(z)).
1. Implementing the Gaussian VAE
Wenowshowhow we can combine analyticexpressions
for the KL-divergence with backpropagation to eﬃciently
implementaGaussianVAE.Westartbyﬁrstderivingan-
alytic expressions for DKL(q(zjx)jp(z))in terms of the
means(x)andvariances 2(x). Thisisjustasimpleex-
ercise in Gaussian integrals. For notational convenience,
101
FIG. 75 Embedding of MNIST dataset into a two-
dimensional latent space using a VAE with two latent dimen-
sions(seeNotebook19andmaintextfordetails.) Datapoints
are colored by their identity [0-9].
we drop the x-dependence of the means (x), variances
2(x), andq(x). A straight-forward calculation gives
Z
dzq(z) logp(z) =Z
N(z;(x);diag(2(x))) logN(0;I)
= J
2log 2 1
2JX
j=1(2
j+ log2
j);(238)
whereJis the dimension of the latent space. An almost
identical calculation yields
Z
dzq(z) logq(z) = J
2log 2 1
2JX
j=1(1+2
j):(239)
Combining these equations gives
 DKL(q(zjx)jp(z)) =1
2JX
j=1 
1 + log2
j(x) 2
j(x) 2
j(x)
:
(240)
This analytic expression allows us to implement the
GaussianVAEinastraightforwardwayusingneuralnet-
works. The computational graph for this implementation
is shown in Fig. 74. Notice that since the parameters are
all compositions of diﬀerentiable functions, we can use
standard backpropagation algorithms to train VAEs.
2. VAEs for the MNIST dataset
In Notebook 19, we have implemented a VAE using
Keras and trained it using the MNIST dataset. The ba-
sic architecture is the one describe above. All ﬁgures
were generated with a VAE that has a latent space of
dimension 2. The architecture of both the encoder anddecoder is a Multi-layer Perceptron (MLPs) – neural net-
works with a single hidden layer. For this example, we
take the dimension of the hidden layer for both neural
networks to be 256. We trained the VAE using the RMS-
prop optimizer for 50 epochs.
We can visualize the embedding in the latent space
by plotting zof the test set and coloring the points by
digit identity [0-9] (see Figure XVII.D.2). Notice that
in general, digits that are similar end up being closer to
eachotherinthelatentspace. However,thisisnotalways
the case (see bright green points for example). This is a
general feature of these low-dimensional embeddings and
we saw a similar phenomenon when we examined t-SNE
in Section XII.
The real advantage that VAEs oﬀer over embeddings
such as t-SNE is that they are generative models. Given
asetofexamples, wecangeneratenewexamples–orfan-
tasy particles as they are commonly called in ML – by
samplingthelatentspace zandthenusingthedecoderto
map these latent variables to new examples. The results
of this procedure are shown in Figure XVII.D.2. In the
top ﬁgure, we sample the latent space uniformly in a 55
grid. Notice that this results in extremely similar exam-
ples through much of the latent space. The underlying
reason for this is that uniform sampling does not respect
the underlying Gausssian structure of the latent space z.
In the bottom ﬁgure, we perform a uniform sampling on
the probability p(z)and mapped this back to the latent
space using the inverse Cumulative Distribution Func-
tion (CDF) of the Gaussian. We see that the diversity of
the generated examples is much higher for this sampling
procedure.
This example is indicative of a more general problem:
once we have learned a generative model how should we
sample latent spaces (White, 2016). This is especially
important in high-dimensional spaces where direct visu-
alization is not possible. Often certain directions in the
latent space can have diﬀerent meanings. A particularly
striking visual illustration is the “smile vector” that in-
terpolates between smiling and frowning faces (White,
2016).
3. VAEs for the 2D Ising model
In Notebook 20, we used an almost identical architec-
ture (though coded in a slightly diﬀerent way) to train
a VAE on the Ising dataset discussed through out the
review. The only diﬀerences between the two VAEs are
that the visible layer of the Ising VAE now has 1600 units
(our samples are 4040instead of the 2828MNIST
images) and we have changed the standard deviation of
the Gaussian of the latent variables p(z)from= 1to
= 0:2.
We once again visualize the embedding learned by
the VAE by plotting zand coloring the points by the
102
FIG. 76 (Top) Fantasy particle generated by uniform sam-
pling of the latent space z. (Bottom) Fantasy particles gen-
erated by uniform sampling of probability p(z)mapped to
latent space using the inverse Cumulative Distribution Func-
tion (CDF) of the Gaussian.
temperature at which the sample was drawn (see Fig-
ure XVII.D.3 top). Notice that the latent space has
learned a lot of the physics of the Ising model. For ex-
ample, the ﬁrst VAE dimension is just the magnetization
(Fig. XVII.D.3 bottom). This is not surprising since we
FIG. 77 (Top) Embedding of the Ising dataset into a two-
dimensional latent space using a VAE with two latent dimen-
sions(seeNotebook20andmaintextfordetails.) Datapoints
are colored by the temperature each sample was drawn at.
(Bottom) Correlation between the latent dimensions and the
magnetization for each sample. Notice that the ﬁrst principle
component corresponds to the magnetization.
saw in Section XII that the ﬁrst principal component of
a PCA also corresponded to the magnetization.
We now ask how well the VAE can generate new exam-
ples (see Fig. 78). We see that the examples look quite
diﬀerent from real Ising conﬁgurations – they lack the
large scale patchiness seen in the critical region. They
mostly turn out to be unstructured speckles that reﬂect
only the average probability that a pixel is on in a region.
This is not surprising since our VAE has no spatial struc-
ture, has only two latent dimensions, and the cost func-
tion does not know about “correlations between spins”
: there is very little information about correlations in
the binary cross-entropy which we use to measure recon-
struction errors. The reader is encouraged to play with
the corresponding notebook and generate examples as we
change the latent dimension and/or choose modiﬁed ar-
chitectures such as decoders based on CNNs instead of
MLPs.
This example also shows how much easier it is to dis-
criminate between labeled data than it is to learn how to
generate new examples from an unlabeled dataset. This
is true in all spheres of machine learning. This is also
103
FIG. 78 Fantasy particles for the Ising model generated by
uniform sampling of probability p(z)mapped to latent space
using the inverse Cumulative Distribution Function (CDF) of
the Gaussian.
one of the reasons that generative models are one of the
cutting edge areas of modern Machine Learning research
and there are likely to be a barrage of new techniques for
generative modeling in the next few years.
XVIII. OUTLOOK
Inthisreview,wehaveattemptedtogivethereaderthe
intellectual and practical tools to engage with Machine
Learning (ML), data science, and parts of modern statis-
tics. We have tried to emphasize that ML diﬀers from
ordinary statistics in that the goal is to predict rather
than to ﬁt. For this reason, all the techniques discussed
here have to navigate important tensions that lie at the
heart of ML. The most prominent instantiation of these
inherent tradeoﬀs is the bias-variance tradeoﬀ, which is
perhaps the only universal principle in ML. Identifying
how these tradeoﬀs manifest in a particular algorithm is
the key to constructing and training powerful ML meth-
ods.
The immense progress in computing power and the
corresponding availability of large datasets ensure that
ML will be an important part of the physics toolkit. In
the future, we expect ML to be a core competency of
physicists much like linear algebra, group theory, anddiﬀerential equations. We hope that this review will play
some small part toward this aspirational goal.
We wrote this review to provide a relatively concise
introduction to ML using ideas and language familiar
to physicists (though the review ended up being almost
twice the planned length). In writing the review, we have
tried to accomplish two somewhat disparate tasks. First,
we have tried to highlight more abstract and theoretical
considerations to show the unity of ML and statistical
learning. Many ML techniques can be understood by
starting with some key concepts from statistical learning
(MLE, bias-variance tradeoﬀ, regularization) and com-
bining them with core concepts familiar from statisti-
cal physics (Monte-Carlo, gradient descent, variational
methods and MFT). Despite the high-level similarities
between all the methods presented here, the way that
these concepts manifest in any given technique is often
quite clever and understanding these “hacks” is the key to
understanding why some ML techniques turn out to be
so powerful and others not so much. ML, in this sense, is
as much an art as a science. Second, we have tried to give
thereader thepractical know-howto startusing thetools
and concepts from ML for immediately solving problems.
We believe the accompanying python notebooks and the
emphasis on coding in python have accomplished this
task.
A. Research at the intersection of physics and ML
We hope the review catalyzes more research at the
intersection of physics and machine learning. Here we
brieﬂy highlight a few promising research directions. We
note that this list is far from comprehensive.
•Applying ML to solve physics problems . One
theme that has reoccurred through out the review
is that ML is most eﬀective in settings with well de-
ﬁned objectives and lots of data. For this reason,
we expect ML to become a core competency of data
rich ﬁelds such as high-energy experiments and as-
tronomy. However, ML may also prove to be use-
ful for helping further our physical understanding
through data-driven approach to other branches of
physics that may not be immediately obvious, such
as quantum physics (Dunjko and Briegel, 2017).
For example, recent works have used ideas from
MLtoinvestigatedisparatetopicssuchasnon-local
correlations (Canabarro et al., 2018), disordered
materialsandglasses(Schoenholz,2017), electronic
structure calculations (Grisaﬁ et al., 2017) and
numerical analysis of ferromagnetic resonances in
thin ﬁlms (Tomczak and Puszkarski, 2018), de-
signing and analyzing quantum materials by inte-
grating ML with existing techniques such as Dy-
namical Mean Field Theory (DMFT) (Arsenault
et al., 2014), in the study of inﬂation (Rudelius,
104
2018), and even for experimental learning of quan-
tum states by using ML to aid in quantum tomog-
raphy (Rocchetto et al., 2017). For a comprehen-
sivereviewofMLmethodsinseismology, see(Kong
et al., 2018).
•Machine Learning on quantum computers .
Another interesting area of research that is likely
to grow is asking if and how quantum comput-
ers can help improve state-of-the art ML algo-
rithms (Arunachalam and de Wolf, 2017; Benedetti
et al., 2016, 2017; Bromley and Rebentrost, 2018;
Ciliberto et al.,2017;Daskin,2018;Innocenti et al.,
2018; Mitarai et al., 2018; Perdomo-Ortiz et al.,
2017; Rebentrost et al., 2017; Schuld et al., 2017;
Schuld and Killoran, 2018; Schuld et al., 2015).
Concrete examples that seek to extend some of
the basic ideas and methods we introduced in
this review to the quantum computing realm in-
clude: algorithms for quantum-assisted gradient
descent (Kerenidis and Prakash, 2017; Rebentrost
et al.,2016), classiﬁcation(SchuldandPetruccione,
2017), andRidgeregression(Yu et al.,2017). Inter-
est in this ﬁeld will undoubtedly grow once reliable
quantum computers become available (see also this
recent review (Dunjko and Briegel, 2017) ).
•Monte-Carlo Methods . An interesting area that
has seen a renewed interest with Bayesian modeling
isthedevelopmentofnewMonte-Carlomethodsfor
sampling complex probability distributions. Some
of the workhorses of modern Machine Learning –
Annealed Importance Sampling (AIS) (Neal, 2001)
and Hamiltonian or Hybrid Monte-Carlo (HMC)
(Nealet al., 2011) – are intimately related to
physics. As pointed out by Radford Neal, AIS is
just the Jarzynski inequality (Jarzynski, 1997) as
a Monte-Carlo method and HMC was developed
by physicists and exploits Hamiltonian dynamics
to improve proposal distributions.
•Statistical physics style theory of Deep
Learning . Many techniques in ML have origins
in statistical physics. Yet, a physics-style theory
of Deep Learning remains elusive. A key question
is to ask when and why these models manage to
generalize well. Physicists are only beginning to
ask these questions (Advani and Saxe, 2017; Mehta
and Schwab, 2014; Saxe et al., 2013; Shwartz-Ziv
and Tishby, 2017). But right now, it is fair to say
that the insights remain scattered and a cohesive
theoretical understanding is lacking.
•Biological physics and ML . Biological physics
is generating ever more datasets in ﬁelds ranging
from neuroscience to evolution and immunology. It
is likely that ML will be an important part of thebiophysics toolkit in the future. Many of the au-
thors of this review were inspired to engage with
ML for this reason.
•Using ideas from physics to develop new
ML algorithms . Many of the core ideas of ML
from Monte-Carlo techniques to variational meth-
ods have their origin in physics. There has been a
tremendousamountofrecentworkdevelopingtools
to understand physical systems that may be of po-
tential use to ML. For example, in quantum con-
densed matter techniques such as DMRG, MERA,
etc. have enriched both our practical and con-
ceptual understandings (Stoudenmire and White,
2012; Vidal, 2007; White, 1992). It will be inter-
esting to ﬁgure how and if these numerical methods
can be translated from a physics to a ML setting.
There are tantalizing hints that this is likely to be
a fruitful direction (Han et al., 2017; Stoudenmire,
2018; Stoudenmire and Schwab, 2016).
B. Topics not covered in review
Despite the considerable length of the review, we have
had to make many omissions for the sake of brevity. It
is our hope and belief that after reading this review the
reader will have the conceptual and practical knowledge
to quickly learn about these other topics. Among the
most prominent topics missing from this review are:
•Temporal/Sequential Data . We have not cov-
ered techniques for dealing with temporal or se-
quential data. Here, too there are many connec-
tions with statistical physics. A powerful class of
models for sequential data called Hidden Markov
Models (Rabiner, 1989) that utilize dynamical
programming techniques have natural statistical
physics interpretations in terms of transfer matri-
ces (see (Mehta et al., 2011) for explicit exam-
ple of this). Recently, Recurrent Neural Networks
(RNNs) have become an important and powerful
tool for dealing with sequence data (Goodfellow
et al., 2016). RNNs generalize many of the ideas
discussed in the DNN section to deal with temporal
data.
•Reinforcement Learning . Many of the most ex-
citing developments in the last ﬁve years have come
from combining ideas from reinforcement learning
with deep neural networks (Mnih et al., 2015; Sut-
ton and Barto, 1998). RL traces its origins to be-
haviourist psychology, when it was conceived as
a way to explain and study reward-based deci-
sion making. RL was put on solid mathematical
grounds in the 50’s by Richard Bellman and col-
laborators, and has by now become an inseparable
105
part of robotics and artiﬁcial intelligence. RL is a
ﬁeld of Machine Learning, in which an agent learns
how to master performing a speciﬁc task through
an interaction with its environment. Depending on
the reward it receives, the agent chooses to take an
action aﬀecting the environment, which in turn de-
termines the value of the next received reward, and
so on. The long-term goal of the agent is to max-
imise the cumulative expected return, thus improv-
ing its performance in the longer run. Shadowed by
more traditional optimal control algorithms, Re-
inforcement Learning has only recently taken oﬀ
in physics (Albarran-Arriagada et al., 2018; Au-
gust and Hernández-Lobato, 2018; Bukov, 2018;
Bukovet al., 2018; Cárdenas-López et al., 2017;
Chenet al., 2014; Chen and Xue, 2019; Dunjko
et al., 2017; Fösel et al., 2018; Lamata, 2017; Mel-
nikovet al., 2017; Neukart et al., 2017; Niu et al.,
2018; Ramezanpour, 2017; Reddy et al., 2016b; Sri-
arunothai et al., 2017; Sweke et al., 2018; Zhang
et al., 2018). Of particular interest are biophysics
inspired works that seek to use RL to understand
navigation and sensing in turbulent environments
(Colabrese et al., 2017; Masson et al., 2009; Reddy
et al., 2016a; Vergassola et al., 2007).
•Support Vector Machines (SVMs) and Ker-
nel Methods . SVMs and kernel methods are a
powerful set of techniques that work well when the
amount of training data is limited (Burges, 1998).
The mathematics and theory of SVM are very dif-
ferent from statistical physics and for this reason
we chose not to include them here. However, SVMs
and kernel methods have played an extremely im-
portant role in ML and are worth understanding.
C. Rebranding Machine Learning as “Artiﬁcial Intelligence”
The immense scientiﬁc progress in ML has also been
accompanied by a massive public relations eﬀort cen-
tered around Silicon Valley. Starting with the success
of ImageNet (the most prominent early use of GPUs
for training large models) and the widespread adoption
of Deep Learning based techniques by the Silicon Val-
ley companies, there has been a deliberate move to re-
brand modern ML as “artiﬁcial intelligence” or AI (see
graphs in (Katz, 2017)). Recently, computer scientist
Michael I. Jordan (who is famously known for his formal-
ization of variational inference, Bayesian network, and
expectation-maximization algorithm in machine learn-
ing research) cautioned that “ This conﬂuence of ideas
and technology trends has been rebranded as “AI” over
the past few years. This rebranding is worthy of some
scrutiny”(Jordan, 2018).
AI, by design, is an ambiguous term that mixes aspi-
rations with reality. It also conﬂates the statistical ideasthat form the basis of modern ML with the more com-
monplacenotionsaboutwhathumansandbehavioralsci-
entists mean by intelligence (see (Lake et al., 2017) for
an enlightening and important modern discussion of this
distinction from a quantitative cognitive science point of
view as well as (Dreyfus, 1965) for a surprisingly relevant
philosophy-based critique from 1965).
Almost all the techniques discussed here rely on op-
timizing a pre-speciﬁed objective function on a given
dataset. Yet, we know that for large, complex models
changing the data distribution or the goal can lead to an
immediate degradation of performance. Deep networks
have poor generalizations to even a slightly diﬀerent con-
text (the infamous Validation-Test set mismatch). This
inability to abstract and generalize is a common criticism
lobbied against branding modern ML techniques as AI
(Lakeet al., 2017). For all these reasons, we have chosen
to use the term Machine Learning rather than artiﬁcial
intelligence through out the review.
This is far from the ﬁrst time we have seen the use of
the term artiﬁcial intelligence and the grandiose promises
that it implies. In fact, the early 1950’s and 1960’s as
well as the early 1980’s saw similar AI bubbles (see this
interesting summary by Luke Muehlhauser for Open Phi-
lanthropy (Muehlhauser, 2016)). These AI bubbles have
been followed by what have been dubbed “AI Winters”
(McDermott et al., 1985).
The “Singularity” may not be coming but the advances
in computing and the availability of large data sets likely
ensure that the kind of statistical learning frameworks
discussed are here to stay. Rather than a general arti-
ﬁcial intelligence, the kind of techniques presented here
seem to be best suited for three important tasks: (a)
automating prediction from lots of labeled examples in
a narrowly-deﬁned setting (b) learning how to parame-
terize and capture the correlations of complex probabil-
ity distributions, and (c) ﬁnding policies for tasks with
well-deﬁned goals and clear rules. We hope that this
review has given the reader enough conceptual tools to
start forming their own opinions about reality and hype
when it comes to modern ML research. As Michael I.
Joran puts it, “ ...if the acronym “AI” continues to be
used as placeholder nomenclature going forward, letâĂŹs
be aware of the very real limitations of this placeholder.
LetâĂŹs broaden our scope, tone down the hype and rec-
ognize the serious challenges ahead "(Jordan, 2018).
D. Social Implications of Machine Learning
The last decade has also seen a systematic increase in
the use and deployment of Machine Learning techniques
into new areas of life and society. Some of the readers of
this review may currently be (or eventually be) employed
in industrial settings that seek to harness ML for practi-
cal purposes. However, caution is in order when applying
106
ML. Without foresight and accountability, the scale and
scope of modern ML algorithms can lead to large scale
unaccountable and undemocratic outcomes that can re-
inforce or even worsen existing inequality and inequities.
Mathematician and data scientist turned social commen-
tator Cathy O’Neil has dubbed the indiscriminate use of
these Big Data techniques “Weapons of Math Destruc-
tion” (O’Neil, 2017).
When ML is used in a social context, abstract statis-
tical relationships have real social consequences. False
positives can mean the diﬀerence between life and death
(for example in the context of “signature drone strikes”)
(Mehta, 2015). ML algorithms, like all techniques, have
important limitations and should be employed with great
caution. It is our hope that ML practitioners keep this
in mind when working in social settings.
All algorithms involve inherent tradeoﬀs in fairness, a
pointformalizedbycomputerscientistJonKleinbergand
collaborators in a very interesting recent paper (Klein-
berget al., 2016). It is far from clear how to make al-
gorithms fair for all people involved. This is even more
true with methods like Deep Learning that are hard to
interpret. All ML algorithms have implicit assumptions
and choices reﬂected in the datasets we use to the kind
of functions we choose to optimize. It is important to
remember that there is no “ view from nowhere” (Adam,
2006; Katz, 2017) – all ML algorithms reﬂect a point of
view and a set of assumptions about the world we live
in. For this reason, we hope that ML practitioners and
data scientists will take the time to consider the social
consequences of their actions. For example, developing a
Hippocratic Oath for data scientists is now being consid-
ered (Simonite, 2018). Doing no harm seems like a good
start for making sure that we harness ML for the beneﬁt
of all members of society.
XIX. ACKNOWLEDGMENTS
PM and DJS would like to thank Anirvan Sengupta,
Justin Kinney, and Ilya Nemenman for useful conver-
sations during the ACP working group. The authors
are also grateful to all readers who provided valuable
feedback on this manuscript while it was under peer re-
view. We encourage readers to help keep the Notebooks
which accompany the review up-to-date, by contribut-
ing to them on Github at https://github.com/drckf/
mlreview_notebooks . PM, CHW, and AD were sup-
portedbySimon’sFoundationintheformofaSimonsIn-
vestigator in the MMLS and NIH MIRA program grant:
1R35GM119461. MB acknowledges support from the
Emergent Phenomena in Quantum Systems initiative of
the Gordon and Betty Moore Foundation, the ERC syn-
ergy grant UQUAM, and the U.S. Department of Energy,
Oﬃce of Science, Oﬃce of Advanced Scientiﬁc Comput-
ing Research, Quantum Algorithm Teams Program. DJSwassupportedasaSimonsInvestigatorintheMMLSand
by NIH K25 grant GM098875-02. PM and DJS would
like to thank the NSF grant: PHYD1066293 for support-
ing the Aspen Center for Physics (ACP) for facilitating
discussions leading to this work. This research was sup-
ported in part by the National Science Foundation under
Grant No. NSF PHY-1748958. The authors are pleased
to acknowledge that the computational work reported on
in this paper was performed on the Shared Computing
Cluster which is administered by Boston University’s Re-
search Computing Services.
Appendix A: Overview of the Datasets used in the Review
1. Ising dataset
The Ising dataset we use throughout the review was
generated using the standard Metropolis algorithm to
generate a Markov Chain. The full dataset consist of
1610000samples of 4040spin conﬁgurations (i.e.
the design matrix has 160000 samples and 1600 features)
drawn at temperatures 0:25;0:5;4:0. The samples
are drawn for the Boltzmann distribution of the two-
dimensionalferromagneticIsingmodelona 4040square
lattice with periodic boundary conditions.
2. SUSY dataset
The SUSY dataset was generated by Baldi et al (Baldi
et al.,2014)toexploretheeﬃcacyofusingDeepLearning
for classifying collision events. The dataset is download-
able from the UCI Machine Learning Repository, a won-
derful resource for interesting datasets. Here we quote
directly from the paper:
The data has been produced using Monte
Carlo simulations and contains events with
two leptons (electrons or muons). In high
energy physics experiments, such as the AT-
LAS and CMS detectors at the CERN LHC,
one major hope is the discovery of new par-
ticles. To accomplish this task, physicists at-
tempt to sift through data events and classify
them as either a signal of some new physics
process or particle, or instead a background
event from understood Standard Model pro-
cesses. Unfortunately we will never know for
sure what underlying physical process hap-
pened (the only information to which we have
access are the ﬁnal state particles). How-
ever, we can attempt to deﬁne parts of phase
space that will have a high percentage of sig-
nal events. Typically this is done by using a
seriesofsimplerequirementsonthekinematic
107
quantities of the ﬁnal state particles, for ex-
ample having one or more leptons with large
amounts of momentum that is transverse to
the beam line ( pT ). Here instead we will
use logistic regression in order to attempt to
ﬁnd out the relative probability that an event
is from a signal or a background event and
rather than using the kinematic quantities of
ﬁnal state particles directly we will use the
output of our logistic regression to deﬁne a
part of phase space that is enriched in sig-
nal events. The dataset we are using has the
valueof18kinematicvariables("features")of
the event. The ﬁrst 8 features are direct mea-
surements of ﬁnal state particles, in this case
thepT,pseudo-rapidity, andazimuthalangle
of two leptons in the event and the amount
of missing transverse momentum (MET) to-
gether with its azimuthal angle. The last ten
features are functions of the ﬁrst 8 features;
these are high-level features derived by physi-
cists to help discriminate between the two
classes. You can think of them as physicists
attempttousenon-linearfunctionstoclassify
signal and background events and they have
been developed with a lot of deep thinking
on the part of physicist. There is however,
an interest in using deep learning methods to
obviate the need for physicists to manually
develop such features. Benchmark results us-
ing Bayesian Decision Trees from a standard
physics package and 5-layer neural networks
and the dropout algorithm are presented in
the original paper to compare the ability of
deep-learningtobypasstheneedofusingsuch
high level features. We will also explore this
topic in later notebooks. The dataset con-
sists of 5 million events, the ﬁrst 4,500,000 of
which we will use for training the model and
the last 500,000 examples will be used as a
test set.
3. MNIST Dataset
The MNIST dataset is one of the simplest and most
widely used Machine Learning Datasets. The MNIST
dataset consists of hand-written images of numerical
characters 0 9andconsistsofatrainingsetof60,000ex-
amples, and a test set of 10,000 examples (LeCun et al.,
1998a). Information about the MNIST database and its
historical importance can be found at Yann Lecun’s wed-
site: http://yann.lecun.com/exdb/mnist/ . A brief
description from the website:
The original black and white (bilevel) images
from NIST were size normalized to ﬁt in a20x20 pixel box while preserving their aspect
ratio. The resulting images contain grey lev-
els as a result of the anti-aliasing technique
used by the normalization algorithm. the im-
ages were centered in a 28x28 image by com-
puting the center of mass of the pixels, and
translating the image so as to position this
point at the center of the 28x28 ﬁeld.
The MNIST is often included by default in many modern
ML packages.
REFERENCES
Abu-Mostafa, Yaser S, Malik Magdon-Ismail, and Hsuan-
Tien Lin (2012), Learning from data , Vol. 4 (AMLBook
New York, NY, USA:).
Ackley, David H, Geoﬀrey E Hinton, and Terrence J Se-
jnowski (1987), “A learning algorithm for boltzmann ma-
chines,” in Readings in Computer Vision (Elsevier) pp.
522–533.
Adam, Alison (2006), Artiﬁcial knowing: Gender and the
thinking machine (Routledge).
Advani, Madhu, and Surya Ganguli (2016), “Statistical me-
chanics of optimal convex inference in high dimensions,”
Physical Review X 6(3), 031034.
Advani, Madhu, Subhaneil Lahiri, and Surya Ganguli (2013),
“Statistical mechanics of complex neural systems and high
dimensional data,” Journal of Statistical Mechanics: The-
ory and Experiment 2013(03), P03014.
Advani, Madhu S, and Andrew M Saxe (2017), “High-
dimensional dynamics of generalization error in neural net-
works,” arXiv preprint arXiv:1710.03667.
Aitchison, Laurence, Nicola Corradi, and Peter E Latham
(2016), “Zipfs law arises naturally when there are under-
lying, unobserved variables,” PLoS computational biology
12(12), e1005110.
Albarran-Arriagada, F, J. C. Retamal, E. Solano, and
L. Lamata (2018), “Measurement-based adapta-
tion protocol with quantum reinforcement learning,”
arXiv:1803.05340 .
Alemi, Alexander A, Ian Fischer, Joshua V Dillon, and Kevin
Murphy (2016), “Deep variational information bottleneck,”
arXiv preprint arXiv:1612.00410.
Alemi, Alireza, and Alia Abbara (2017), “Exponential capac-
ity in an autoencoder neural network with a hidden layer,”
arXiv preprint arXiv:1705.07441 .
Amit, Daniel J (1992), Modeling brain function: The world of
attractor neural networks (Cambridge university press).
Amit, Daniel J, Hanoch Gutfreund, and Haim Sompolinsky
(1985), “Spin-glass models of neural networks,” Physical
Review A 32(2), 1007.
Andrieu, Christophe, Nando De Freitas, Arnaud Doucet, and
Michael I Jordan (2003), “An introduction to mcmc for
machine learning,” Machine learning 50(1-2), 5–43.
Arai, Shunta, Masayuki Ohzeki, and Kazuyuki Tanaka
(2017), “Deep neural network detects quantum phase tran-
sition,” arXiv preprint arXiv:1712.00371 .
Arimoto, Suguru (1972), “An algorithm for computing the
capacity of arbitrary discrete memoryless channels,” IEEE
Transactions on Information Theory 18(1), 14–20.
108
Arsenault, Louis-François, Alejandro Lopez-Bezanilla,
O Anatole von Lilienfeld, and Andrew J Millis (2014),
“Machine learning for many-body physics: the case of the
anderson impurity model,” Physical Review B 90(15),
155136.
Arunachalam, Srinivasan, and Ronald de Wolf (2017),
“A survey of quantum learning theory,” arXiv preprint
arXiv:1701.06806 .
August, Moritz, and José Miguel Hernández-Lobato (2018),
“Taking gradients through experiments: Lstms and mem-
ory proximal policy optimization for black-box quantum
control,” arXiv:1802.04063.
Aurisano, A, A Radovic, D Rocco, A Himmel, MD Messier,
E Niner, G Pawloski, F Psihas, A Sousa, and P Vahle
(2016), “A convolutional neural network neutrino event
classiﬁer,” Journal of Instrumentation 11(09), P09001.
Baireuther, P, TE O’Brien, B Tarasinski, and CWJ
Beenakker (2017), “Machine-learning-assisted correction
of correlated qubit errors in a topological code,” arXiv
preprint arXiv:1705.07855 .
Baity-Jesi, M, L. Sagun, M. Geiger, S. Spigler, G. Ben Arous,
C.Cammarota, Y.LeCun, M.Wyart, andG.Biroli(2018),
“Comparing dynamics: Deep neural networks versus glassy
systems,” .
Baldassi, Carlo, Federica Gerace, Hilbert J Kappen, Carlo
Lucibello, Luca Saglietti, Enzo Tartaglione, and Riccardo
Zecchina (2017), “On the role of synaptic stochasticity
in training low-precision neural networks,” arXiv preprint
arXiv:1710.09825 .
Baldassi, Carlo, Federica Gerace, Luca Saglietti, and Ric-
cardo Zecchina (2018), “From inverse problems to learning:
a statistical mechanics approach,” in Journal of Physics:
Conference Series , Vol. 955 (IOP Publishing) p. 012001.
Baldi, Pierre, Peter Sadowski, and Daniel Whiteson (2014),
“Searching for exotic particles in high-energy physics with
deep learning,” Nature communications 5, 4308.
Barber, David (2012), Bayesian reasoning and machine learn-
ing(Cambridge University Press).
Barnes, Josh, and Piet Hut (1986), “A hierarchical o (n log
n) force-calculation algorithm,” nature 324(6096), 446.
Barra, Adriano, Alberto Bernacchia, Enrica Santucci, and
Pierluigi Contucci (2012), “On the equivalence of hopﬁeld
networks and boltzmann machines,” Neural Networks 34,
1–9.
Barra, Adriano, Giuseppe Genovese, Peter Sollich, and
Daniele Tantari (2016), “Phase transitions in restricted
boltzmann machines with generic priors,” arXiv preprint
arXiv:1612.03132 .
Barra,Adriano,GiuseppeGenovese,DanieleTantari, andPe-
ter Sollich (2017), “Phase diagram of restricted boltzmann
machines and generalised hopﬁeld networks with arbitrary
priors,” arXiv preprint arXiv:1702.05882 .
Battiti, Roberto (1992), “First-and second-order methods for
learning: between steepest descent and newton’s method,”
Neural computation 4(2), 141–166.
Benedetti, Marcello, John Realpe-Gómez, Rupak Biswas,
and Alejandro Perdomo-Ortiz (2016), “Quantum-assisted
learning of graphical models with arbitrary pairwise con-
nectivity,” arXiv preprint arXiv:1609.02542 .
Benedetti, Marcello, John Realpe-Gómez, and Alejandro
Perdomo-Ortiz (2017), “Quantum-assisted helmholtz ma-
chines: A quantum-classical deep learning framework for
industrial datasets in near-term devices,” arXiv preprint
arXiv:1708.09784 .Bengio, Yoshua (2012), “Practical recommendations for
gradient-based training of deep architectures,” in Neural
networks: Tricks of the trade (Springer) pp. 437–478.
Bennett, Robert (1969), “The intrinsic dimensionality of sig-
nal collections,” IEEE Transactions on Information Theory
15(5), 517–525.
Bény, Cédric (2018), “Inferring relevant features: from qft to
pca,” arXiv preprint arXiv:1802.05756 .
Berger,JamesO, andJoséMBernardo(1992),“Onthedevel-
opment of the reference prior method,” Bayesian statistics
4, 35–60.
Bickel, PeterJ, andDavidAFreedman(1981),“Someasymp-
totic theory for the bootstrap,” The Annals of Statistics ,
1196–1217.
Bickel, Peter J, Bo Li, Alexandre B Tsybakov, Sara A van de
Geer, Bin Yu, Teóﬁlo Valdés, Carlos Rivero, Jianqing Fan,
and Aad van der Vaart (2006), “Regularization in statis-
tics,” Test 15(2), 271–344.
Bishop,CM(2006), Pattern recognition and machine learning
(springer).
Bishop, Chris M (1995a), “Training with noise is equivalent to
tikhonov regularization,” Neural computation 7(1), 108–
116.
Bishop, Christopher M (1995b), Neural networks for pattern
recognition (Oxford university press).
Blahut, Richard (1972), “Computation of channel capacity
and rate-distortion functions,” IEEE transactions on Infor-
mation Theory 18(4), 460–473.
Bottou, Léon (2012), “Stochastic gradient descent tricks,” in
Neural networks: Tricks of the trade (Springer) pp. 421–
436.
Bowman, Samuel R, Luke Vilnis, Oriol Vinyals, Andrew M
Dai, Rafal Jozefowicz, and Samy Bengio (2015), “Gener-
ating sentences from a continuous space,” arXiv preprint
arXiv:1511.06349.
Boyd, Stephen, and Lieven Vandenberghe (2004), Convex
optimization (Cambridge university press).
Bradde, Serena, and William Bialek (2017), “Pca meets rg,”
Journal of Statistical Physics 167(3-4), 462–475.
Breiman, Leo (1996), “Bagging predictors,” Machine learning
24(2), 123–140.
Breiman, Leo (2001), “Random forests,” Machine learning
45(1), 5–32.
Breuckmann, Nikolas P, and Xiaotong Ni (2017), “Scalable
neural network decoders for higher dimensional quantum
codes,” arXiv preprint arXiv:1710.09489 .
Broecker, Peter, Fakher F Assaad, and Simon Trebst (2017),
“Quantum phase recognition via unsupervised machine
learning,” arXiv preprint arXiv:1707.00663 .
Bromley, Thomas R, and Patrick Rebentrost (2018),
“Batched quantum state exponentiation and quantum heb-
bian learning,” arXiv:1803.07039 .
Bukov, Marin (2018), “Reinforcement learning for au-
tonomous preparation of ﬂoquet-engineered states: Invert-
ing the quantum kapitza oscillator,” Phys. Rev. B 98,
224305.
Bukov, Marin, Alexandre G. R. Day, Dries Sels, Phillip Wein-
berg, Anatoli Polkovnikov, and Pankaj Mehta (2018), “Re-
inforcement learning in diﬀerent phases of quantum con-
trol,” Phys. Rev. X 8, 031086.
Burges, Christopher JC (1998), “A tutorial on support vector
machines for pattern recognition,” Data mining and knowl-
edge discovery 2(2), 121–167.
Caio, Marcello D, Marco Caccin, Paul Baireuther, Timo
109
Hyart, and Michel Fruchart (2019), “Machine learning as-
sisted measurement of local topological invariants,” arXiv
preprint arXiv:1901.03346 .
Caldeira, J, WLK Wu, B Nord, C Avestruz, S Trivedi, and
KT Story (2018), “Deepcmb: Lensing reconstruction of the
cosmic microwave background with deep neural networks,”
arXiv preprint arXiv:1810.01483 .
Canabarro,Askery,SamuraíBrito, andRafaelChaves(2018),
“Machine learning non-local correlations,” arXiv preprint
arXiv:1808.07069 .
Cárdenas-López, FA, L Lamata, JC Retamal, and E Solano
(2017), “Generalized quantum reinforcement learning with
quantum technologies,” arXiv preprint arXiv:1709.07848 .
Carleo, Giuseppe (2018), , Private Communication.
Carleo, Giuseppe, Yusuke Nomura, and Masatoshi Imada
(2018), “Constructing exact representations of quantum
many-body systems with deep neural networks,” arXiv
preprint arXiv:1802.09558 .
Carleo, Giuseppe, and Matthias Troyer (2017), “Solving the
quantum many-body problem with artiﬁcial neural net-
works,” Science 355(6325), 602–606.
Carrasquilla, Juan, and Roger G Melko (2017), “Machine
learning phases of matter,” Nature Physics 13(5), 431.
Carrasquilla, Juan, Giacomo Torlai, Roger G Melko, and Le-
andro Aolita (2018), “Reconstructing quantum states with
generative models,” arXiv preprint arXiv:1810.10584 .
Chalk, Matthew, Olivier Marre, and Gasper Tkacik (2016),
“Relevant sparse codes with variational information bottle-
neck,” in Advances in Neural Information Processing Sys-
tems, pp. 1957–1965.
Chamberland, Christopher, andPooyaRonagh(2018),“Deep
neural decoders for near term fault-tolerant experiments,”
arXiv preprint arXiv:1802.06441 .
Chechik, Gal, Amir Globerson, Naftali Tishby, and Yair
Weiss (2005), “Information bottleneck for gaussian vari-
ables,” Journal of machine learning research 6(Jan), 165–
188.
Chen, Chunlin, Daoyi Dong, Han-Xiong Li, Jian Chu, and
Tzyh-Jong Tarn (2014), “Fidelity-based probabilistic q-
learning for control of quantum systems,” IEEE transac-
tions on neural networks and learning systems 25(5), 920–
933.
Chen, Jing, SongCheng, HaidongXie, LeiWang, andTaoXi-
ang (2018), “Equivalence of restricted boltzmann machines
and tensor network states,” Phys. Rev. B 97, 085104.
Chen, Jun-Jie, and Ming Xue (2019), “Manipulation of spin
dynamics by deep reinforcement learning agent,” arXiv
preprint arXiv:1901.08748 .
Chen, Tianqi, and Carlos Guestrin (2016), “Xgboost: A scal-
able tree boosting system,” in Proceedings of the 22nd acm
sigkdd international conference on knowledge discovery and
data mining (ACM) pp. 785–794.
Cheng, Song, Jing Chen, and Lei Wang (2017), “Information
perspectivetoprobabilisticmodeling: Boltzmannmachines
versus born machines,” arXiv preprint arXiv:1712.04144 .
Ch’ng, Kelvin, Nick Vazquez, and Ehsan Khatami
(2017), “Unsupervised machine learning account of mag-
netic transitions in the hubbard model,” arXiv preprint
arXiv:1708.03350 .
Ciliberto, Carlo, Mark Herbster, Alessandro Davide Ialongo,
Massimiliano Pontil, Andrea Rocchetto, Simone Severini,
and Leonard Wossnig (2017), “Quantum machine learning:
a classical perspective,” .
Cohen, Nadav, Or Sharir, and Amnon Shashua (2016), “Onthe expressive power of deep learning: A tensor analysis,”
inConference on Learning Theory , pp. 698–728.
Colabrese, Simona, Kristian Gustavsson, Antonio Celani,
and Luca Biferale (2017), “Flow navigation by smart mi-
croswimmers via reinforcement learning,” Physical review
letters118(15), 158004.
Cossu, Guido, Luigi Del Debbio, Tommaso Giani, Ava Kham-
seh, and Michael Wilson (2018), “Machine learning deter-
mination of dynamical parameters: The ising model case,”
arXiv preprint arXiv:1810.11503 .
Cox, Trevor F, and Michael AA Cox (2000), Multidimen-
sional scaling (CRC press).
Cristoforetti, Marco, Giuseppe Jurman, Andrea I Nardelli,
and Cesare Furlanello (2017), “Towards meaningful physics
from generative models,” arXiv preprint arXiv:1705.09524
.
Dahl, George, Abdel-rahman Mohamed, Geoﬀrey E Hinton,
et al.(2010), “Phone recognition with the mean-covariance
restricted boltzmann machine,” in Advances in neural in-
formation processing systems , pp. 469–477.
Daskin, Ammar (2018), “A quantum implementation model
for artiﬁcial neural networks,” Quanta , 7–18.
Davaasuren, Amarsanaa, Yasunari Suzuki, Keisuke Fujii,
and Masato Koashi (2018), “General framework for con-
structing fast and near-optimal machine-learning-based de-
coder of the topological stabilizer codes,” arXiv preprint
arXiv:1801.04377 .
Day, Alexandre GR, Marin Bukov, Phillip Weinberg, Pankaj
Mehta, and Dries Sels (2019), “Glassy phase of opti-
mal quantum control,” Physical Review Letters 122(2),
020601.
Day, Alexandre GR, and Pankaj Mehta (2018), “Validated
agglomerative clustering,” in preparation.
Decelle, Aurélien, Giancarlo Fissore, and Cyril Furtlehner
(2017), “Spectral learning of restricted boltzmann ma-
chines,” arXiv preprint arXiv:1708.02917 .
Decelle, Aurélien, Giancarlo Fissore, and Cyril Furtlehner
(2018), “Thermodynamics of restricted boltzmann ma-
chines and related learning dynamics,” arXiv preprint
arXiv:1803.01960 .
Dempster, Arthur P, Nan M Laird, and Donald B Rubin
(1977), “Maximum likelihood from incomplete data via the
emalgorithm,” Journaloftheroyalstatisticalsociety.Series
B (methodological) , 1–38.
Deng, Dong-Ling, Xiaopeng Li, and S Das Sarma (2017),
“Quantum entanglement in neural network states,” Physi-
cal Review X 7(2), 021021.
Dietterich, Thomas G, et al.(2000), “Ensemble methods in
machine learning,” Multiple classiﬁer systems 1857, 1–15.
Do, Chuong B, and Seraﬁm Batzoglou (2008), “What is the
expectation maximization algorithm?” Nature biotechnol-
ogy26(8), 897–899.
Domingos, Pedro (2012), “A few useful things to know about
machine learning,” Communications of the ACM 55(10),
78–87.
Donoho, David L (2006), “Compressed sensing,” IEEE Trans-
actions on information theory 52(4), 1289–1306.
Dreyfus, Hubert L (1965), “Alchemy and artiﬁcial intelli-
gence,”.
Du, Simon S, Chi Jin, Jason D Lee, Michael I Jordan, Aarti
Singh, and Barnabas Poczos (2017), “Gradient descent can
take exponential time to escape saddle points,” in Advances
in Neural Information Processing Systems , pp. 1067–1077.
Duchi, John, Elad Hazan, and Yoram Singer (2011), “Adap-
110
tive subgradient methods for online learning and stochas-
tic optimization,” Journal of Machine Learning Research
12(Jul), 2121–2159.
Dunjko, Vedran, and Hans J Briegel (2017), “Machine learn-
ing and artiﬁcial intelligence in the quantum domain,”
arXiv preprint arXiv:1709.02779 .
Dunjko, Vedran, Yi-Kai Liu, Xingyao Wu, and Jacob M
Taylor (2017), “Super-polynomial and exponential im-
provementsforquantum-enhancedreinforcementlearning,”
arXiv preprint arXiv:1710.11160 .
Efron, B (1979), “Bootstrap methods: another look at the
jackknife annals of statistics 7: 1–26,” View Article Pub-
Med/NCBI Google Scholar.
Efron, Bradley, Trevor Hastie, Iain Johnstone, Robert Tib-
shirani,et al.(2004), “Least angle regression,” The Annals
of statistics 32(2), 407–499.
Eisen, Michael B, Paul T Spellman, Patrick O Brown, and
David Botstein (1998), “Cluster analysis and display of
genome-wide expression patterns,” Proceedings of the Na-
tional Academy of Sciences 95(25), 14863–14868.
Elith, Jane, Steven J Phillips, Trevor Hastie, Miroslav Dudík,
Yung En Chee, and Colin J Yates (2011), “A statistical
explanation of maxent for ecologists,” Diversity and distri-
butions17(1), 43–57.
Ernst, Oliver K, Thomas Bartol, Terrence Sejnowski, and
Eric Mjolsness (2018), “Learning dynamic boltzmann dis-
tributions as reduced models of spatial chemical kinetics,”
arXiv preprint arXiv:1803.01063 .
Ester, Martin, Hans-Peter Kriegel, Jörg Sander, Xiaowei Xu,
et al.(1996), “A density-based algorithm for discovering
clusters in large spatial databases with noise.” in Kdd,
Vol. 96, pp. 226–231.
Faddeev, Ludvig D, and Victor N Popov (1967), “Feynman
diagrams for the yang-mills ﬁeld,” Physics Letters B 25(1),
29–30.
Finol, David, Yan Lu, Vijay Mahadevan, and Ankit
Srivastava (2018), “Deep convolutional neural networks
for eigenvalue problems in mechanics,” arXiv preprint
arXiv:1801.05733 .
Fisher, Charles K, and Pankaj Mehta (2015a), “Bayesian fea-
ture selection for high-dimensional linear regression via the
ising approximation with applications to genomics,” Bioin-
formatics 31(11), 1754–1761.
Fisher, Charles K, and Pankaj Mehta (2015b), “Bayesian
feature selection with strongly regularizing priors maps to
the ising model,” Neural computation 27(11), 2411–2422.
Foreman, Sam, Joel Giedt, Yannick Meurice, and Judah
Unmuth-Yockey (2017), “Rg inspired machine learning for
lattice ﬁeld theory,” arXiv preprint arXiv:1710.02079 .
Fösel, Thomas, Petru Tighineanu, Talitha Weiss, and Flo-
rian Marquardt (2018), “Reinforcement learning with neu-
ral networks for quantum feedback,” arXiv:1802.05267 .
Freitas, Nahuel, Giovanna Morigi, and Vedran Dun-
jko (2018), “Neural network operations and susuki-
trotter evolution of neural network states,” arXiv preprint
arXiv:1803.02118 .
Freund, Yoav, Robert Schapire, and Naoki Abe (1999), “A
short introduction to boosting,” Journal-Japanese Society
For Artiﬁcial Intelligence 14(771-780), 1612.
Freund, Yoav, and Robert E Schapire (1995), “A desicion-
theoretic generalization of on-line learning and an applica-
tion to boosting,” in European conference on computational
learning theory (Springer) pp. 23–37.
Friedman, Jerome, Trevor Hastie, and Robert Tibshirani(2001),The elements of statistical learning ,Vol.1(Springer
series in statistics New York).
Friedman, JeromeH(2001),“Greedyfunctionapproximation:
a gradient boosting machine,” Annals of statistics , 1189–
1232.
Friedman, Jerome H (2002), “Stochastic gradient boosting,”
Computational Statistics & Data Analysis 38(4), 367–378.
Friedman, Jerome H, Bogdan E Popescu, et al.(2003), “Im-
portance sampled learning ensembles,” Journal of Machine
Learning Research 94305.
Fu, Michael C (2006), “Gradient estimation,” Handbooks in
operations research and management science 13, 575–616.
Funai, Shotaro Shiba, and Dimitrios Giataganas (2018),
“Thermodynamicsandfeatureextractionbymachinelearn-
ing,” arXiv preprint arXiv:1810.08179 .
Gao,Jun,Lu-FengQiao,Zhi-QiangJiao,Yue-ChiMa,Cheng-
Qiu Hu, Ruo-Jing Ren, Ai-Lin Yang, Hao Tang, Man-Hong
Yung, and Xian-Min Jin (2017), “Experimental machine
learning ofquantum stateswith partial information,” arXiv
preprint arXiv:1712.00456 .
Gao, Xun, and Lu-Ming Duan (2017), “Eﬃcient representa-
tion of quantum many-body states with deep neural net-
works,” arXiv preprint arXiv:1701.05039 .
Gelman, Andrew, John B Carlin, Hal S Stern, David B Dun-
son, Aki Vehtari, and Donald B Rubin (2014), Bayesian
data analysis , Vol. 2 (CRC press Boca Raton, FL).
Gersho, Allen, and Robert M Gray (2012), Vector quantiza-
tion and signal compression , Vol. 159 (Springer Science &
Business Media).
Geurts, Pierre, Damien Ernst, and Louis Wehenkel (2006),
“Extremely randomized trees,” Machine learning 63(1),
3–42.
Glorot, Xavier, and Yoshua Bengio (2010), “Understanding
thediﬃcultyoftrainingdeepfeedforwardneuralnetworks,”
inProceedings of the Thirteenth International Conference
on Artiﬁcial Intelligence and Statistics , pp. 249–256.
Goldt, Sebastian, and Udo Seifert (2017), “Thermodynamic
eﬃciency of learning a rule in neural networks,” arXiv
preprint arXiv:1706.09713 .
Goodfellow, Ian (2016), “Nips 2016 tutorial: Generative ad-
versarial networks,” arXiv preprint arXiv:1701.00160.
Goodfellow, Ian, Yoshua Bengio, and Aaron
Courville (2016), Deep Learning (MIT Press)
http://www.deeplearningbook.org .
Goodfellow, Ian, JeanPouget-Abadie, MehdiMirza, BingXu,
David Warde-Farley, Sherjil Ozair, Aaron Courville, and
YoshuaBengio(2014),“Generativeadversarialnets,” in Ad-
vances in neural information processing systems , pp. 2672–
2680.
Greplova, Eliska, Christian Kraglund Andersen, and Klaus
Mølmer (2017), “Quantum parameter estimation with a
neural network,” arXiv preprint arXiv:1711.05238 .
Grisaﬁ, Andrea, David M Wilkins, Gábor Csányi, and
Michele Ceriotti (2017), “Symmetry-adapted machine-
learning for tensorial properties of atomistic systems,”
arXiv preprint arXiv:1709.06757 .
Han, Zhao-Yu, Jun Wang, Heng Fan, Lei Wang, and Pan
Zhang (2017), “Unsupervised generative modeling using
matrix product states,” arXiv preprint arXiv:1709.01662 .
He, Kaiming, Xiangyu Zhang, Shaoqing Ren, and Jian Sun
(2015), “Delving deep into rectiﬁers: Surpassing human-
level performance on imagenet classiﬁcation,” in Proceed-
ings of the IEEE international conference on computer vi-
sion, pp. 1026–1034.
111
He, Kaiming, Xiangyu Zhang, Shaoqing Ren, and Jian Sun
(2016), “Deep residual learning for image recognition,” in
Proceedings of the IEEE conference on computer vision and
pattern recognition , pp. 770–778.
Heimel, Theo, Gregor Kasieczka, Tilman Plehn, and Jen-
nifer M Thompson (2018), “Qcd or what?” arXiv preprint
arXiv:1808.08979 .
Higgins, Irina, Loic Matthey, Arka Pal, Christopher Burgess,
Xavier Glorot, Matthew Botvinick, Shakir Mohamed, and
Alexander Lerchner (2016), “beta-vae: Learning basic vi-
sual concepts with a constrained variational framework,”
.
Hinton, Geoﬀrey E (2002), “Training products of experts by
minimizing contrastive divergence,” Neural computation
14(8), 1771–1800.
Hinton, Geoﬀrey E (2012), “A practical guide to training re-
stricted boltzmann machines,” in Neural networks: Tricks
of the trade (Springer) pp. 599–619.
Hinton, Geoﬀrey E, Simon Osindero, and Yee-Whye Teh
(2006), “A fast learning algorithm for deep belief nets,”
Neural computation 18(7), 1527–1554.
Hinton, GeoﬀreyE, andRuslanRSalakhutdinov(2006),“Re-
ducing the dimensionality of data with neural networks,”
science313(5786), 504–507.
Ho, Tin Kam (1998), “The random subspace method for con-
structing decision forests,” IEEE transactions on pattern
analysis and machine intelligence 20(8), 832–844.
Hopﬁeld, John J (1982), “Neural networks and physical sys-
tems with emergent collective computational abilities,”
Proceedings of the national academy of sciences 79(8),
2554–2558.
Huang, Haiping (2017a), “Mean-ﬁeld theory of input dimen-
sionality reduction in unsupervised deep neural networks,”
arXiv preprint arXiv:1710.01467 .
Huang, Haiping (2017b), “Statistical mechanics of unsuper-
vised feature learning in a restricted boltzmann machine
with binary synapses,” Journal of Statistical Mechanics:
Theory and Experiment 2017(5), 053302.
Huang, Hengfeng, Bowen Xiao, Huixin Xiong, Zeming Wu,
Yadong Mu, and Huichao Song (2018), “Applications
of deep learning to relativistic hydrodynamics,” arXiv
preprint arXiv:1801.03334 .
Hubbard, J(1959),“Calculationofpartitionfunctions,” Phys-
ical Review Letters 3(2), 77.
Huggins, William, Piyush Patil, Bradley Mitchell, K Birgitta
Whaley, and E Miles Stoudenmire (2019), “Towards quan-
tummachinelearningwithtensornetworks,” QuantumSci-
ence and Technology 4(2), 024001.
Iakovlev, I A, O. M. Sotnikov, and V. V. Mazurenko
(2018), “Supervised learning magnetic skyrmion phases,”
arXiv:1803.06682 .
Innocenti, Luca, Leonardo Banchi, Alessandro Ferraro,
Sougato Bose, and Mauro Paternostro (2018), “Supervised
learning of time-independent hamiltonians for gate design,”
arXiv:1803.07119 .
Ioﬀe, Sergey, and Christian Szegedy (2015), “Batch normal-
ization: Accelerating deep network training by reducing in-
ternal covariate shift,” in International Conference on Ma-
chine Learning , pp. 448–456.
Iso, Satoshi, Shotaro Shiba, and Sumito Yokoo (2018),
“Scale-invariant feature extraction of neural net-
work and renormalization group ﬂow,” arXiv preprint
arXiv:1801.07172 .
Jarzynski, Christopher (1997), “Nonequilibrium equality forfree energy diﬀerences,” Physical Review Letters 78(14),
2690.
Jaynes, Edwin T (1957a), “Information theory and statistical
mechanics,” Physical review 106(4), 620.
Jaynes, Edwin T (1957b), “Information theory and statistical
mechanics. ii,” Physical review 108(2), 171.
Jaynes, Edwin T (1968), “Prior probabilities,” IEEE Trans-
actions on systems science and cybernetics 4(3), 227–241.
Jaynes, Edwin T (1996), Probability theory: the logic of sci-
ence(Washington University St. Louis, MO).
Jaynes, Edwin T (2003), Probability theory: the logic of sci-
ence(Cambridge university press).
Jeﬀreys, Harold (1946), “An invariant form for the prior prob-
ability in estimation problems,” Proceedings of the Royal
Society of London. Series A, Mathematical and Physical
Sciences , 453–461.
Jin, Chi, Praneeth Netrapalli, and Michael I Jordan (2017),
“Accelerated gradient descent escapes saddle points faster
than gradient descent,” arXiv preprint arXiv:1711.10456.
Jordan, Michael (2018), “Artiﬁcial intelligence: The revolu-
tion hasnâĂŹt happened yet. medium,”.
Jordan, Michael I, Zoubin Ghahramani, Tommi S Jaakkola,
and Lawrence K Saul (1999), “An introduction to vari-
ational methods for graphical models,” Machine learning
37(2), 183–233.
Kalantre, Sandesh S, Justyna P Zwolak, Stephen Ragole,
Xingyao Wu, Neil M Zimmerman, MD Stewart, and Ja-
cob M Taylor (2017), “Machine learning techniques for
state recognition and auto-tuning in quantum dots,” arXiv
preprint arXiv:1712.04914 .
Katz, Yarden (2017), “Manufacturing an artiﬁcial intelligence
revolution,” SSRN Preprint .
Kerenidis, Iordanis, and Anupam Prakash (2017), “Quan-
tum gradient descent for linear systems and least squares,”
arXiv preprint arXiv:1704.04992 .
Keskar, Nitish Shirish, Dheevatsa Mudigere, Jorge Nocedal,
Mikhail Smelyanskiy, and Ping Tak Peter Tang (2016),
“On large-batch training for deep learning: Generalization
gap and sharp minima,” arXiv preprint arXiv:1609.04836.
Kingma, Diederik P, and Jimmy Ba (2014), “Adam:
A method for stochastic optimization,” arXiv preprint
arXiv:1412.6980.
Kingma, Diederik P, and Max Welling (2013),
“Auto-encoding variational bayes,” arXiv preprint
arXiv:1312.6114.
Kingma, DP, et al.(2017), “Variational inference & deep
learning,” PhD thesis 978-94-6299-745-5.
Kleijnen, Jack PC, and Reuven Y Rubinstein (1996), “Op-
timization and sensitivity analysis of computer simulation
models by the score function method,” European Journal
of Operational Research 88(3), 413–427.
Kleinberg, Jon, SendhilMullainathan, andManishRaghavan
(2016), “Inherent trade-oﬀs in the fair determination of risk
scores,” arXiv preprint arXiv:1609.05807.
Koch-Janusz, Maciej, and Zohar Ringel (2017), “Mutual in-
formation,neuralnetworksandtherenormalizationgroup,”
arXiv preprint arXiv:1704.06279 .
Kohonen, Teuvo (1998), “The self-organizing map,” Neuro-
computing 21(1-3), 1–6.
Kong, Qingkai, Daniel T. Trugman, Zachary E. Ross,
Michael J. Bianco, Brendan J. Meade, and Peter Ger-
stoft (2018), “Machine learning in seismology: Turn-
ing data into insights,” Seismological Research Letters
10.1785/0220180259.
112
Krastanov, Stefan, and Liang Jiang (2017), “Deep neural
network probabilistic decoder for stabilizer codes,” arXiv
preprint arXiv:1705.09334 .
Kriegel, Hans-Peter, Peer Kröger, and Arthur Zimek (2009),
“Clustering high-dimensional data: A survey on subspace
clustering, pattern-based clustering, and correlation clus-
tering,” ACM Transactions on Knowledge Discovery from
Data (TKDD) 3(1), 1.
Krizhevsky, Alex, Ilya Sutskever, and Geoﬀrey E Hinton
(2012), “Imagenet classiﬁcation with deep convolutional
neural networks,” in Advances in neural information pro-
cessing systems , pp. 1097–1105.
Krzakala, Florent, Andre Manoel, Eric W Tramel, and Lenka
Zdeborová(2014),“Variationalfreeenergiesforcompressed
sensing,” in Information Theory (ISIT), 2014 IEEE Inter-
national Symposium on (IEEE) pp. 1499–1503.
Krzakala, Florent, Marc Mézard, François Sausset, YF Sun,
and Lenka Zdeborová (2012a), “Statistical-physics-based
reconstruction in compressed sensing,” Physical Review X
2(2), 021005.
Krzakala, Florent, MarcMézard, FrancoisSausset, YifanSun,
and Lenka Zdeborová (2012b), “Probabilistic reconstruc-
tion in compressed sensing: algorithms, phase diagrams,
and threshold achieving matrices,” Journal of Statistical
Mechanics: Theory and Experiment 2012(08), P08009.
Lake, Brenden M, Tomer D Ullman, Joshua B Tenenbaum,
and Samuel J Gershman (2017), “Building machines that
learn and think like people,” Behavioral and Brain Sciences
40.
Lamata, Lucas (2017), “Basic protocols in quantum reinforce-
mentlearningwithsuperconductingcircuits,” ScientiﬁcRe-
ports7.
Larsen, Bjornar, and Chinatsu Aone (1999), “Fast and eﬀec-
tive text mining using linear-time document clustering,” in
Proceedings of the ﬁfth ACM SIGKDD international con-
ference on Knowledge discovery and data mining (ACM)
pp. 16–22.
Le, Quoc V (2013), “Building high-level features using large
scale unsupervised learning,” in Acoustics, Speech and Sig-
nal Processing (ICASSP), 2013 IEEE International Con-
ference on (IEEE) pp. 8595–8598.
LeCun, Yann, Yoshua Bengio, et al.(1995), “Convolutional
networks for images, speech, and time series,” The hand-
book of brain theory and neural networks 3361(10), 1995.
LeCun, Yann, Léon Bottou, Yoshua Bengio, and Patrick
Haﬀner (1998a), “Gradient-based learning applied to docu-
ment recognition,” Proceedings of the IEEE 86(11), 2278–
2324.
LeCun, Yann, Léon Bottou, Genevieve B Orr, and Klaus-
Robert Müller (1998b), “Eﬃcient backprop,” in Neural net-
works: Tricks of the trade (Springer) pp. 9–50.
Lee, JasonD,IoannisPanageas, GeorgiosPiliouras, MaxSim-
chowitz, Michael I Jordan, and Benjamin Recht (2017),
“First-order methods almost always avoid saddle points,”
arXiv preprint arXiv:1710.07406.
Lehmann, Erich L, and George Casella (2006), Theory of
point estimation (Springer Science & Business Media).
Lehmann, Erich L, and Joseph P Romano (2006), Testing
statistical hypotheses (Springer Science & Business Media).
Levine, Yoav, David Yakira, Nadav Cohen, and Amnon
Shashua (2017), “Deep learning and quantum entangle-
ment: Fundamental connections with implications to net-
work design.” arXiv preprint arXiv:1704.01552 .
Li, Bo, and David Saad (2017), “Exploring the func-tion space of deep-learning machines,” arXiv preprint
arXiv:1708.01422 .
Li, Chian-De, Deng-Ruei Tan, and Fu-Jiun Jiang (2017),
“Applications of neural networks to the studies of
phase transitions of two-dimensional potts models,” arXiv
preprint arXiv:1703.02369 .
Li, Richard Y, Rosa Di Felice, Remo Rohs, and Daniel A
Lidar (2018), “Quantum annealing versus classical ma-
chinelearningappliedtoasimpliﬁedcomputationalbiology
problem,” npj Quantum Information 4(1), 14.
Li, Shuo-Hui, and Lei Wang (2018), “Neural network renor-
malization group,” arXiv preprint arXiv:1802.02840 .
Lim, Tjen-Sien, Wei-Yin Loh, and Yu-Shan Shih (2000), “A
comparison of prediction accuracy, complexity, and train-
ing time of thirty-three old and new classiﬁcation algo-
rithms,” Machine learning 40(3), 203–228.
Lin, Henry W, Max Tegmark, and David Rolnick (2017),
“Why does deep and cheap learning work so well?” Journal
of Statistical Physics 168(6), 1223–1247.
Linderman, G C, M. Rachh, J. G. Hoskins, S. Steiner-
berger, and Y. Kluger (2017), “Eﬃcient Algorithms for
t-distributed Stochastic Neighborhood Embedding,” ArXiv
e-prints arXiv:1712.09005 [cs.LG].
Liu, Zhaocheng, Sean P Rodrigues, and Wenshan Cai
(2017), “Simulating the ising model with a deep convo-
lutional generative adversarial network,” arXiv preprint
arXiv:1710.04987 .
Loh, Wei-Yin (2011), “Classiﬁcation and regression trees,”
Wiley Interdisciplinary Reviews: Data Mining and Knowl-
edge Discovery 1(1), 14–23.
Louppe, Gilles (2014), “Understanding random forests: From
theory to practice,” arXiv preprint arXiv:1407.7502.
Lu, Sirui, Shilin Huang, Keren Li, Jun Li, Jianxin Chen,
Dawei Lu, Zhengfeng Ji, Yi Shen, Duanlu Zhou, and
Bei Zeng (2017), “A separability-entanglement classiﬁer via
machine learning,” arXiv preprint arXiv:1705.01523 .
Maaten, Laurens van der, and Geoﬀrey Hinton (2008), “Vi-
sualizing data using t-sne,” Journal of machine learning re-
search9(Nov), 2579–2605.
MacKay, David JC (2003), Information theory, inference and
learning algorithms (Cambridge university press).
Marsland III, Robert, Wenping Cui, and Pankaj Mehta
(2019), “The Minimum Environmental Perturbation Prin-
ciple: A New Perspective on Niche Theory,” arXiv preprint
arXiv:1901.09673 .
Maskara, Nishad, Aleksander Kubica, and Tomas
Jochym-O’Connor (2018), “Advantages of versatile neural-
network decoding for topological codes,” arXiv preprint
arXiv:1802.08680 .
Masson, JB, M Bailly Bechet, and Massimo Vergassola
(2009), “Chasing information to search in random environ-
ments,” Journal of Physics A: Mathematical and Theoret-
ical42(43), 434009.
Mattingly, Henry H, Mark K Transtrum, Michael C Abbott,
and Benjamin B Machta (2018), “Maximizing the infor-
mation learned from ﬁnite data selects a simple model,”
Proceedings of the National Academy of Sciences 115(8),
1760–1765.
McDermott, Drew, M Mitchell Waldrop, B Chandrasekaran,
John McDermott, and Roger Schank (1985), “The dark
ages of ai: a panel discussion at aaai-84,” AI Magazine
6(3), 122.
McInnes, Leland, John Healy, and James Melville
(2018), “UMAP: Uniform Manifold Approximation and
113
Projection for Dimension Reduction,” arXiv e-prints ,
arXiv:1802.03426arXiv:1802.03426 [stat.ML].
Mehta, Pankaj (2015), “Big data’s radical potential,
https://www.jacobinmag.com/2015/03/big-data-drones-
privacy-workers,” Jacobin .
Mehta, Pankaj, and David J Schwab (2014), “An exact map-
ping between the variational renormalization group and
deep learning,” arXiv preprint arXiv:1410.3831.
Mehta, Pankaj, David J Schwab, and Anirvan M Sengupta
(2011), “Statistical mechanics of transcription-factor bind-
ing site discovery using hidden markov models,” Journal of
statistical physics 142(6), 1187–1205.
Melnikov, Alexey A, Hendrik Poulsen Nautrup, Mario Krenn,
Vedran Dunjko, Markus Tiersch, Anton Zeilinger, and
Hans J Briegel (2017), “Active learning machine learns
to create new quantum experiments,” arXiv preprint
arXiv:1706.00868 .
Metz, Cade (2017), “Move over, coders-
physicists will soon rule silicon valley,”
Https://deepmind.com/blog/deepmind-ai-reduces-google-
data-centre-cooling-bill-40/.
Mezard, Marc, and Andrea Montanari (2009), Information,
physics, and computation (Oxford University Press).
Mhaskar, Hrushikesh, Qianli Liao, and Tomaso Poggio
(2016), “Learning functions: when is deep better than shal-
low,” arXiv preprint arXiv:1603.00988.
Mitarai, Kosuke, Makoto Negoro, Masahiro Kitagawa, and
Keisuke Fujii (2018), “Quantum circuit learning,” arXiv
preprint arXiv:1803.00745 .
Mnih, Volodymyr, Koray Kavukcuoglu, David Silver, An-
drei A Rusu, Joel Veness, Marc G Bellemare, Alex Graves,
Martin Riedmiller, Andreas K Fidjeland, Georg Ostrovski,
et al.(2015), “Human-level control through deep reinforce-
ment learning,” Nature 518(7540), 529.
Morningstar, Alan, and Roger G Melko (2017), “Deep
learning the ising model near criticality,” arXiv preprint
arXiv:1708.04622 .
Muehlhauser, Luke (2016), “What should we learn from past
ai forecasts?” Open Philanthropy Website .
Müllner, Daniel (2011), “Modern hierarchical, agglomerative
clustering algorithms,” arXiv preprint arXiv:1109.2378 .
Murphy, Kevin (2012), Machine Learning: A Probabilistic
Perspective (MIT press).
Nagai, Yuki, Huitao Shen, Yang Qi, Junwei Liu, and Liang
Fu (2017), “Self-learning monte carlo method: Continuous-
time algorithm,” arXiv preprint arXiv:1705.06724 .
Neal, Radford M (2001), “Annealed importance sampling,”
Statistics and computing 11(2), 125–139.
Neal, Radford M, and Geoﬀrey E Hinton (1998), “A view
of the em algorithm that justiﬁes incremental, sparse, and
other variants,” in Learning in graphical models (Springer)
pp. 355–368.
Neal, Radford M, et al.(2011), “Mcmc using hamiltonian dy-
namics,” Handbook of Markov Chain Monte Carlo 2(11).
Nesterov, Yurii (1983), “A method of solving a convex pro-
gramming problem with convergence rate o (1/k2),” in So-
viet Mathematics Doklady , Vol. 27, pp. 372–376.
Neukart, Florian, David Von Dollen, Christian Seidel, and
Gabriele Compostella (2017), “Quantum-enhanced rein-
forcement learning for ﬁnite-episode games with discrete
state spaces,” arXiv preprint arXiv:1708.09354 .
Nguyen, H Chau, Riccardo Zecchina, and Johannes Berg
(2017), “Inverse statistical problems: from the inverse ising
problem to data science,” Advances in Physics 66(3), 197–261.
Nielsen, Michael A (2015), Neural networks and deep learning
(Determination Press).
vanNieuwenburg, Evert, EyalBairey, andGilRefael(2017a),
“Learningphasetransitionsfromdynamics,” arXivpreprint
arXiv:1712.00450 .
van Nieuwenburg, Evert PL, Ye-Hua Liu, and Sebastian D
Huber (2017b), “Learning phase transitions by confusion,”
Nature Physics 13(5), 435.
Niu, Murphy Yuezhen, Sergio Boixo, Vadim Smelyanskiy,
and Hartmut Neven (2018), “Universal quantum con-
trol through deep reinforcement learning,” arXiv preprint
arXiv:1803.01857 .
Nomura, Yusuke, Andrew Darmawan, Youhei Yamaji, and
Masatoshi Imada (2017), “Restricted-boltzmann-machine
learning for solving strongly correlated quantum systems,”
arXiv preprint arXiv:1709.06475 .
Ohtsuki, Tomi, and Tomoki Ohtsuki (2017), “Deep learning
the quantum phase transitions in random electron systems:
Applications to three dimensions,” Journal of the Physical
Society of Japan 86(4), 044708.
O’Neil, Cathy (2017), Weapons of math destruction: How big
data increases inequality and threatens democracy (Broad-
way Books).
Papanikolaou, Stefanos, Michail Tzimas, Hengxu Song, An-
drew CE Reid, and Stephen A Langer (2017), “Learning
crystal plasticity using digital image correlation: Exam-
ples from discrete dislocation dynamics,” arXiv preprint
arXiv:1709.08225 .
Pedregosa, F, G. Varoquaux, A. Gramfort, V. Michel,
B. Thirion, O. Grisel, M. Blondel, P. Prettenhofer,
R. Weiss, V. Dubourg, J. Vanderplas, A. Passos, D. Cour-
napeau, M. Brucher, M. Perrot, and E. Duchesnay (2011),
“Scikit-learn: Machine learning in Python,” Journal of Ma-
chine Learning Research 12, 2825–2830.
Perdomo-Ortiz, Alejandro, Marcello Benedetti, John Realpe-
Gómez, and Rupak Biswas (2017), “Opportunities
and challenges for quantum-assisted machine learn-
ing in near-term quantum computers,” arXiv preprint
arXiv:1708.09757 .
Polyak, Boris T (1964), “Some methods of speeding up the
convergence of iteration methods,” USSR Computational
Mathematics and Mathematical Physics 4(5), 1–17.
Qian, Ning (1999), “On the momentum term in gradient de-
scent learning algorithms,” Neural networks 12(1), 145–
151.
Rabiner, Lawrence R (1989), “A tutorial on hidden markov
models and selected applications in speech recognition,”
Proceedings of the IEEE 77(2), 257–286.
Radford, Alec, Luke Metz, and Soumith Chintala (2015),
“Unsupervised representation learning with deep convo-
lutional generative adversarial networks,” arXiv preprint
arXiv:1511.06434.
Ramezanali, Mohammad, Partha P Mitra, and Anirvan M
Sengupta(2015),“Criticalbehavioranduniversalityclasses
for an algorithmic phase transition in sparse reconstruc-
tion,” arXiv preprint arXiv:1509.08995.
Ramezanpour, A (2017), “Optimization by a quantum rein-
forcement algorithm,” Phys. Rev. A 96, 052307.
Rao, Wen-Jia, Zhenyu Li, Qiong Zhu, Mingxing Luo, and
Xin Wan (2017), “Identifying product order with restricted
boltzmann machines,” arXiv preprint arXiv:1709.02597 .
Ravanbakhsh, Siamak, Francois Lanusse, Rachel Mandel-
baum, JeﬀGSchneider, andBarnabasPoczos(2017),“En-
114
abling dark energy science with deep generative models of
galaxy images.” in AAAI, pp. 1488–1494.
Rebentrost, Patrick, Thomas R. Bromley, Christian Weed-
brook, and Seth Lloyd (2017), “A quantum hopﬁeld neural
network,” arXiv:1710.03599 .
Rebentrost, Patrick, Maria Schuld, Francesco Petruccione,
and Seth Lloyd (2016), “Quantum gradient descent and
newton’smethodforconstrainedpolynomialoptimization,”
arXiv preprint arXiv:1612.01789 .
Reddy, Gautam, Antonio Celani, Terrence J Sejnowski, and
Massimo Vergassola (2016a), “Learning to soar in turbu-
lent environments,” Proceedings of the National Academy
of Sciences 113(33), E4877–E4884.
Reddy, Gautam, Antonio Celani, and Massimo Vergassola
(2016b), “Infomax strategies for an optimal balance be-
tween exploration and exploitation,” Journal of Statistical
Physics163(6), 1454–1476.
Rem, Benno S, Niklas Käming, Matthias Tarnowski, Luca
Asteria, Nick Fläschner, Christoph Becker, Klaus Seng-
stock, and Christof Weitenberg (2018), “Identifying quan-
tum phase transitions using artiﬁcial neural networks on
experimental data,” arXiv preprint arXiv:1809.05519 .
Rezende, Danilo Jimenez, Shakir Mohamed, and Daan
Wierstra (2014), “Stochastic backpropagation and approx-
imate inference in deep generative models,” arXiv preprint
arXiv:1401.4082.
Rocchetto, Andrea, Scott Aaronson, Simone Severini, Gon-
zalo Carvacho, Davide Poderini, Iris Agresti, Marco Ben-
tivegna, and Fabio Sciarrino (2017), “Experimental learn-
ing of quantum states,” arXiv preprint arXiv:1712.00127
.
Rocchetto, Andrea, Edward Grant, Sergii Strelchuk,
Giuseppe Carleo, and Simone Severini (2018), “Learn-
ing hard quantum distributions with variational autoen-
coders,” npj Quantum Information 4(1), 28.
Rockafellar, Ralph Tyrell (2015), Convex analysis (Princeton
university press).
Rodriguez, Alex, and Alessandro Laio (2014), “Clustering by
fast search and ﬁnd of density peaks,” Science 344(6191),
1492–1496.
Rokach, Lior, and Oded Maimon (2005), “Clustering meth-
ods,” in Data mining and knowledge discovery handbook
(Springer) pp. 321–352.
Roweis, Sam T, and Lawrence K Saul (2000), “Nonlinear
dimensionality reduction by locally linear embedding,” sci-
ence290(5500), 2323–2326.
Rudelius, Tom (2018), “Learning to inﬂate,” arXiv preprint
arXiv:1810.05159 .
Ruder, Sebastian (2016), “An overview of gradient descent
optimization algorithms,” arXiv preprint arXiv:1609.04747
.
Rumelhart, David E, and David Zipser (1985), “Feature dis-
covery by competitive learning,” Cognitive science 9(1),
75–112.
Ruscher, Céline, and Jörg Rottler (2018), “Correlations in
the shear ﬂow of athermal amorphous solids: A principal
component analysis,” arXiv preprint arXiv:1809.06487 .
Saito, Hiroki, and Masaya Kato (2017), “Machine learning
technique to ﬁnd quantum many-body ground states of
bosons on a lattice,” arXiv preprint arXiv:1709.05468 .
Salazar, Domingos SP (2017), “Nonequilibrium thermody-
namics of restricted boltzmann machines,” arXiv preprint
arXiv:1704.08724 .
Sander, Jörg, Martin Ester, Hans-Peter Kriegel, and XiaoweiXu (1998), “Density-based clustering in spatial databases:
The algorithm gdbscan and its applications,” Data mining
and knowledge discovery 2(2), 169–194.
Saxe, Andrew M, James L McClelland, and Surya Gan-
guli (2013), “Exact solutions to the nonlinear dynamics of
learning in deep linear neural networks,” arXiv preprint
arXiv:1312.6120.
Schapire, Robert E, and Yoav Freund (2012), Boosting:
Foundations and algorithms (MIT press).
Schindler, Frank, Nicolas Regnault, and Titus Neupert
(2017), “Probing many-body localization with neural net-
works,” Phys. Rev. B 95, 245134.
Schmidhuber, Jürgen (2015), “Deep learning in neural net-
works: An overview,” Neural networks 61, 85–117.
Schneidman, Elad, Michael J Berry II, Ronen Segev, and
William Bialek (2006), “Weak pairwise correlations imply
strongly correlated network states in a neural population,”
Nature440(7087), 1007.
Schoenholz, Samuel S (2017), “Combining machine learning
and physics to understand glassy systems,” arXiv preprint
arXiv:1709.08015 .
Schuld, Maria, Mark Fingerhuth, and Francesco Petruc-
cione (2017), “Implementing a distance-based classiﬁer
with a quantum interference circuit,” arXiv preprint
arXiv:1703.10793 .
Schuld, Maria, and Nathan Killoran (2018), “Quantum ma-
chine learning in feature hilbert spaces,” arXiv:1803.07128
.
Schuld, Maria, and Francesco Petruccione (2017), “Quan-
tum ensembles of quantum classiﬁers,” arXiv preprint
arXiv:1704.02146 .
Schuld, Maria, Ilya Sinayskiy, and Francesco Petruccione
(2015), “An introduction to quantum machine learning,”
Contemporary Physics 56(2), 172–185.
Schwab, David J, Ilya Nemenman, and Pankaj Mehta (2014),
Physical review letters 113(6), 068102.
Sethna, James (2006), Statistical mechanics: entropy, or-
der parameters, and complexity , Vol. 14 (Oxford University
Press).
Shanahan, Phiala E, Daniel Trewartha, and William
Detmold (2018), “Machine learning action parameters
in lattice quantum chromodynamics,” arXiv preprint
arXiv:1801.05784 .
Shannon, ClaudeE(1949),“Communicationtheoryofsecrecy
systems,” Bell Labs Technical Journal 28(4), 656–715.
Shen, Huitao, JunweiLiu, andLiangFu(2018),“Self-learning
monte carlo with deep neural networks,” arXiv preprint
arXiv:1801.01127 .
Shinjo, Kazuya, Shigetoshi Sota, Seiji Yunoki, and
Takami Tohyama (2019), “Characterization of photoex-
citedstatesinthehalf-ﬁlledone-dimensionalextendedhub-
bard model assisted by machine learning,” arXiv preprint
arXiv:1901.07900 .
Shlens, Jonathon (2014), “A tutorial on principal component
analysis,” arXiv preprint arXiv:1404.1100.
Shwartz-Ziv, Ravid, and Naftali Tishby (2017), “Opening the
black box of deep neural networks via information,” arXiv
preprint arXiv:1703.00810.
Sidky, Hythem, and Jonathan K Whitmer (2017), “Learn-
ing free energy landscapes using artiﬁcial neural networks,”
arXiv preprint arXiv:1712.02840 .
Simonite, Tom (2018), “Should data scientist adhere to a hip-
pocratic oath?” Wired .
Singh, Kesar (1981), “On the asymptotic accuracy of efron’s
115
bootstrap,” The Annals of Statistics , 1187–1195.
Slonim, Noam, Gurinder S Atwal, Gasper Tkacik, and
William Bialek (2005), “Estimating mutual information
and multi–information in large networks,” arXiv preprint
cs/0502017.
Sønderby, Casper Kaae, Tapani Raiko, Lars Maaløe,
Søren Kaae Sønderby, and Ole Winther (2016), “Ladder
variational autoencoders,” in Advances in neural informa-
tion processing systems , pp. 3738–3746.
Springenberg, Jost Tobias, Alexey Dosovitskiy, Thomas Brox,
and Martin Riedmiller (2014), “Striving for simplicity: The
all convolutional net,” arXiv preprint arXiv:1412.6806.
Sriarunothai, Theeraphot, Sabine Wölk, Gouri Shankar Giri,
Nicolai Fries, Vedran Dunjko, Hans J Briegel, and Christof
Wunderlich (2017), “Speeding-up the decision making of a
learning agent using an ion trap quantum processor,” arXiv
preprint arXiv:1709.01366 .
Srivastava, Nitish, Geoﬀrey E Hinton, Alex Krizhevsky, Ilya
Sutskever, and Ruslan Salakhutdinov (2014), “Dropout: a
simple way to prevent neural networks from overﬁtting.”
Journal of machine learning research 15(1), 1929–1958.
Stoudenmire, E Miles (2018), “Learning relevant features
of data with multi-scale tensor networks,” arXiv preprint
arXiv:1801.00315 .
Stoudenmire, E Miles, and David J Schwab (2016), “Super-
visedlearningwithtensornetworks,” in Advances in Neural
Information Processing Systems , pp. 4799–4807.
Stoudenmire, EM, and Steven R White (2012), “Studying
two-dimensionalsystemswiththedensitymatrixrenormal-
ization group,” Annu. Rev. Condens. Matter Phys. 3(1),
111–128.
Stratonovich, RL (1957), “On a method of calculating quan-
tum distribution functions,” in Soviet Physics Doklady ,
Vol. 2, p. 416.
Strouse, DJ, and David J Schwab (2017), “The deterministic
information bottleneck,” Neural computation 29(6), 1611–
1630.
Suchsland, Philippe, and Stefan Wessel (2018), “Parameter
diagnostics of phases and phase transition learning by neu-
ral networks,” arXiv preprint arXiv:1802.09876 .
Sutskever, Ilya, James Martens, George Dahl, and Geoﬀrey
Hinton (2013), “On the importance of initialization and
momentum in deep learning,” in International conference
on machine learning , pp. 1139–1147.
Sutton, Richard S, and Andrew G Barto (1998), Reinforce-
ment learning: An introduction , Vol. 1 (MIT press Cam-
bridge).
Swaddle, Michael, Lyle Noakes, Liam Salter, Harry Small-
bone, and Jingbo Wang (2017), “Generating 3 qubit
quantum circuits with neural networks,” arXiv preprint
arXiv:1703.10743 .
Sweke, Ryan, Markus S Kesselring, Evert PL van Nieuwen-
burg, and Jens Eisert (2018), “Reinforcement learning
decoders for fault-tolerant quantum computation,” arXiv
preprint arXiv:1810.07207 .
Székely, GJ (2003), “E-statistics: The energy of statistical
samples,” Bowling Green State University, Department of
Mathematics and Statistics Technical Report 3(05), 1–18.
Tanaka, Akinori, and Akio Tomiya (2017a), “Detection of
phase transition via convolutional neural networks,” Jour-
nal of the Physical Society of Japan 86(6), 063001.
Tanaka, Akinori, and Akio Tomiya (2017b), “Towards reduc-
tion of autocorrelation in hmc by machine learning,” arXiv
preprint arXiv:1712.03893 .Tenenbaum, Joshua B, Vin De Silva, and John C Langford
(2000),“Aglobalgeometricframeworkfornonlineardimen-
sionality reduction,” science 290(5500), 2319–2323.
Tibshirani, Ryan J, et al.(2013), “The lasso problem and
uniqueness,” Electronic Journal of Statistics 7, 1456–1490.
Tieleman, Tijmen, and Geoﬀrey Hinton (2009), “Using fast
weights to improve persistent contrastive divergence,” in
Proceedings of the 26th Annual International Conference
on Machine Learning (ACM) pp. 1033–1040.
Tieleman, Tijmen, and Geoﬀrey Hinton (2012), “Lecture 6.5-
rmsprop: Divide the gradient by a running average of its
recent magnitude,” COURSERA: Neural networks for ma-
chine learning 4(2), 26–31.
Tishby, Naftali, Fernando C Pereira, and William Bialek
(2000), “The information bottleneck method,” arXiv
preprint physics/0004057.
Tomczak, P, and H. Puszkarski (2018), “Ferromagnetic res-
onance in thin ﬁlms studied via cross-validation of numer-
ical solutions of the smit-beljers equation: Application to
(ga,mn)as,” Phys. Rev. B 98, 144415.
Torgerson, WarrenS(1958),“Theoryandmethodsofscaling.”
.
Torlai, Giacomo, Guglielmo Mazzola, Juan Carrasquilla,
Matthias Troyer, Roger Melko, and Giuseppe Carleo
(2018), “Neural-network quantum state tomography,” Na-
ture Physics 14(5), 447.
Torlai, Giacomo, and Roger G. Melko (2017), “Neural de-
coder for topological codes,” Phys. Rev. Lett. 119, 030501.
Tramel, Eric W, Marylou Gabrié, Andre Manoel, Francesco
Caltagirone, and Florent Krzakala (2017), “A determin-
istic and generalized framework for unsupervised learn-
ing with restricted boltzmann machines,” arXiv preprint
arXiv:1702.03260 .
Tubiana, Jérôme, and Rémi Monasson (2017), “Emergence
of compositional representations in restricted boltzmann
machines,” Physical Review Letters 118(13), 138301.
Van Der Maaten, Laurens (2014), “Accelerating t-sne using
tree-based algorithms,” The Journal of Machine Learning
Research15(1), 3221–3245.
Venderley, Jordan, Vedika Khemani, and Eun-Ah Kim
(2017), “Machine learning out-of-equilibrium phases of
matter,” arXiv preprint arXiv:1711.00020 .
Vergassola, Massimo, Emmanuel Villermaux, and Boris I
Shraiman (2007), Nature 445(7126), 406.
Vidal, Guifre (2007), “Entanglement renormalization,” Phys-
ical review letters 99(22), 220405.
Wainwright, Martin J, Michael I Jordan, et al.(2008),
“Graphicalmodels, exponentialfamilies, andvariationalin-
ference,” Foundations and Trends ®in Machine Learning
1(1–2), 1–305.
Wang, Ce, andHuiZhai(2017),“Unsupervisedlearningstud-
ies of frustrated classical spin models i: Principle compo-
nent analysis,” arXiv preprint arXiv:1706.07977 .
Wang, Ce, and Hui Zhai (2018), “Machine learning of frus-
trated classical spin models. ii. kernel principal component
analysis,” arXiv preprint arXiv:1803.01205 .
Wang, Lei (2017), “Can boltzmann machines discover cluster
updates?” arXiv preprint arXiv:1702.08586 .
Wang, Yi-Nan, and Zhibai Zhang (2018), “Learning non-
higgsable gauge groups in 4d f-theory,” arXiv preprint
arXiv:1804.07296 .
Wasserman, Larry(2013), All of statistics: a concise course in
statistical inference (Springer Science & Business Media).
Wattenberg, Martin, Fernanda Viégas, and Ian Johnson
116
(2016), “How to use t-sne eﬀectively,” Distill 1(10), e2.
Wei, Qianshi, Roger G Melko, and Jeﬀ ZY Chen (2017),
“Identifying polymer states by machine learning,” Physical
Review E 95(3), 032504.
Weigt, Martin, Robert A White, Hendrik Szurmant, James A
Hoch, and Terence Hwa (2009), “Identiﬁcation of direct
residue contacts in protein–protein interaction by message
passing,” Proceedings of the National Academy of Sciences
106(1), 67–72.
Weinstein, Steven (2017), “Learning the einstein-podolsky-
rosen correlations on a restricted boltzmann machine,”
arXiv preprint arXiv:1707.03114 .
Wetzel, Sebastian Johann (2017), “Unsupervised learning of
phase transitions: from principle component analysis to
variationalautoencoders,” arXivpreprintarXiv:1703.02435
.
Wetzel, Sebastian Johann, and Manuel Scherzer (2017),
“Machine learning of explicit order parameters: From the
ising model to SU(2)lattice gauge theory,” arXiv preprint
arXiv:1705.05582 .
White, Steven R (1992), “Density matrix formulation for
quantum renormalization groups,” Physical review letters
69(19), 2863.
White, Tom (2016), “Sampling generative networks:
Notes on a few eﬀective techniques,” arXiv preprint
arXiv:1609.04468.
Williams, DRGHR, and Geoﬀrey Hinton (1986), “Learn-
ing representations by back-propagating errors,” Nature
323(6088), 533–538.
Wilson, Ashia C, Rebecca Roelofs, Mitchell Stern, Nathan
Srebro, and Benjamin Recht (2017), “The marginal value
of adaptive gradient methods in machine learning,” arXiv
preprint arXiv:1705.08292.
Wilson, Kenneth G, and John Kogut (1974), “The renormal-
ization group and the epsilon expansion,” Physics Reports
12(2), 75–199.
Witte, RS, and J.S. Witte (2013), Statistics (Wiley).
Wu, Yadong, Pengfei Zhang, Huitao Shen, and Hui Zhai
(2018), “Visualizing neural network developing perturba-
tion theory,” arXiv preprint arXiv:1802.03930 .
Xie, Junyuan, Ross Girshick, and Ali Farhadi (2016), “Un-
supervised deep embedding for clustering analysis,” in In-
ternational conference on machine learning , pp. 478–487.
Yang, Tynia, Jinze Liu, Leonard McMillan, and Wei Wang
(2006),“Afastapproximationtomultidimensionalscaling,”
inIEEE workshop on Computation Intensive Methods for
Computer Vision .
Yang, Xu-Chen, Man-Hong Yung, and Xin Wang
(2017), “Neural network designed pulse sequences forrobust control of single-triplet qubits,” arXiv preprint
arXiv:1708.00238 .
Yedidia, Jonathan (2001), “An idiosyncratic journey beyond
mean ﬁeld theory,” Advanced mean ﬁeld methods: Theory
and practice , 21–36.
Yedidia, Jonathan S, William T Freeman, and Yair Weiss
(2003), “Understanding belief propagation and its general-
izations,” MorganKaufmannPublishersInc.SanFrancisco,
CA, USA .
Yoshioka, Nobuyuki, Yutaka Akagi, and Hosho Katsura
(2017), “Learning disordered topological phases by statisti-
calrecoveryofsymmetry,” arXivpreprintarXiv:1709.05790
.
You, Yi-Zhuang, Zhao Yang, and Xiao-Liang Qi (2017),
“Machine learning spatial geometry from entanglement fea-
tures,” arXiv preprint arXiv:1709.01223 .
Yu, Chao-Hua, Fei Gao, and Qiao-Yan Wen (2017),
“Quantum algorithms for ridge regression,” arXiv preprint
arXiv:1707.09524 .
Zdeborová, Lenka, and Florent Krzakala (2016), “Statistical
physicsofinference: Thresholdsandalgorithms,” Advances
in Physics 65(5), 453–552.
Zeiler, Matthew D (2012), “Adadelta: an adaptive learning
rate method,” arXiv preprint arXiv:1212.5701.
Zhang, Chengxian, and Xin Wang (2018), “Spin-qubit noise
spectroscopyfromrandomizedbenchmarkingbysupervised
learning,” arXiv preprint arXiv:1810.07914 .
Zhang, Chiyuan, Samy Bengio, Moritz Hardt, Benjamin
Recht, and Oriol Vinyals (2016), “Understanding deep
learning requires rethinking generalization,” arXiv preprint
arXiv:1611.03530.
Zhang, Pengfei, Huitao Shen, and Hui Zhai (2017a), “Ma-
chine learning topological invariants with neural networks,”
arXiv preprint arXiv:1708.09401 .
Zhang, Xiao-Ming, Zi-Wei Cui, Xin Wang, and Man-Hong
Yung (2018), “Automatic spin-chain learning to explore the
quantum speed limit,” arXiv preprint arXiv:1802.09248 .
Zhang, Yi, Roger G Melko, and Eun-Ah Kim (2017b), “Ma-
chine learning Z2quantum spin liquids with quasi-particle
statistics,” arXiv preprint arXiv:1705.01947 .
Zimek, Arthur, Erich Schubert, and Hans-Peter Kriegel
(2012),“Asurveyonunsupervisedoutlierdetectioninhigh-
dimensional numerical data,” Statistical Analysis and Data
Mining: The ASA Data Science Journal 5(5), 363–387.
Zou, Hui, andTrevorHastie(2005),“Regularizationandvari-
able selection via the elastic net,” Journal of the Royal Sta-
tistical Society: Series B (Statistical Methodology) 67(2),
301–320.
