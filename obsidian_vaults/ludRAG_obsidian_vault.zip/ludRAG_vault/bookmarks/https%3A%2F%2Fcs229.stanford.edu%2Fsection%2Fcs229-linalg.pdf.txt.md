Linear Algebra Review and Reference
Zico Kolter (updated by Chuong Do)
September 30, 2015
Contents
1 Basic Concepts and Notation 2
1.1 Basic Notation . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 2
2 Matrix Multiplication 3
2.1 Vector-Vector Products . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 4
2.2 Matrix-Vector Products . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 4
2.3 Matrix-Matrix Products . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 5
3 Operations and Properties 7
3.1 The Identity Matrix and Diagonal Matrices . . . . . . . . . . . . . . . . . . 8
3.2 The Transpose . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 8
3.3 Symmetric Matrices . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 8
3.4 The Trace . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 9
3.5 Norms . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 10
3.6 Linear Independence and Rank . . . . . . . . . . . . . . . . . . . . . . . . . 11
3.7 The Inverse . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 11
3.8 Orthogonal Matrices . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 1 2
3.9 Range and Nullspace of a Matrix . . . . . . . . . . . . . . . . . . . . . . . . 12
3.10 The Determinant . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 14
3.11 Quadratic Forms and Positive Semideﬁnite Matrices . . . . . . . . . . . . . . 17
3.12 Eigenvalues and Eigenvectors . . . . . . . . . . . . . . . . . . . . . . . . . . 18
3.13 Eigenvalues and Eigenvectors of Symmetric Matrices . . . . . . . . . . . . . 19
4 Matrix Calculus 20
4.1 The Gradient . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 20
4.2 The Hessian . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 22
4.3 Gradients and Hessians of Quadratic and Linear Functions . . . . . . . . . . 23
4.4 Least Squares . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 25
4.5 Gradients of the Determinant . . . . . . . . . . . . . . . . . . . . . . . . . . 25
4.6 Eigenvalues as Optimization . . . . . . . . . . . . . . . . . . . . . . . . . . . 26
1
1 Basic Concepts and Notation
Linear algebra provides a way of compactly representing and opera ting on sets of linear
equations. For example, consider the following system of equations :
4x1−5x2=−13
−2x1+ 3x2= 9.
This is two equations and two variables, so as you know from high scho ol algebra, you
can ﬁnd a unique solution for x1andx2(unless the equations are somehow degenerate, for
example if the second equation is simply a multiple of the ﬁrst, but in the case above there
is in fact a unique solution). In matrix notation, we can write the syst em more compactly
as
Ax=b
with
A=/bracketleftbigg4−5
−2 3/bracketrightbigg
, b=/bracketleftbigg−13
9/bracketrightbigg
.
As we will see shortly, there are many advantages (including the obv ious space savings)
to analyzing linear equations in this form.
1.1 Basic Notation
We use the following notation:
•ByA∈Rm×nwe denote a matrix with mrows and ncolumns, where the entries of A
are real numbers.
•Byx∈Rn, we denote a vector with nentries. By convention, an n-dimensional vector
is often thought of as a matrix with nrows and 1 column, known as a column vector .
If we want to explicitly represent a row vector — a matrix with 1 row and ncolumns
— we typically write xT(herexTdenotes the transpose of x, which we will deﬁne
shortly).
•Theith element of a vector xis denoted xi:
x=
x1
x2
...
xn
.
2
•We use the notation aij(orAij,Ai,j, etc) to denote the entry of Ain theith row and
jth column:
A=
a11a12···a1n
a21a22···a2n
............
am1am2···amn
.
•We denote the jth column of AbyajorA:,j:
A=
| | |
a1a2···an
| | |
.
•We denote the ith row of AbyaT
iorAi,::
A=
—aT
1—
—aT
2—
...
—aT
m—
.
•Note that these deﬁnitions are ambiguous (for example, the a1andaT
1in the previous
two deﬁnitions are notthe same vector). Usually the meaning of the notation should
be obvious from its use.
2 Matrix Multiplication
The product of two matrices A∈Rm×nandB∈Rn×pis the matrix
C=AB∈Rm×p,
where
Cij=n/summationdisplay
k=1AikBkj.
Note that in order for the matrix product to exist, the number of c olumns in Amust equal
the number of rows in B. There are many ways of looking at matrix multiplication, and
we’ll start by examining a few special cases.
3
2.1 Vector-Vector Products
Given two vectors x,y∈Rn, the quantity xTy, sometimes called the inner product ordot
product of the vectors, is a real number given by
xTy∈R=/bracketleftbig
x1x2···xn/bracketrightbig
y1
y2
...
yn
=n/summationdisplay
i=1xiyi.
Observe that inner products are really just special case of matrix multiplication. Note that
it is always the case that xTy=yTx.
Given vectors x∈Rm,y∈Rn(not necessarily of the same size), xyT∈Rm×nis called
theouter product of the vectors. It is a matrix whose entries are given by ( xyT)ij=xiyj,
i.e.,
xyT∈Rm×n=
x1
x2
...
xm
/bracketleftbig
y1y2···yn/bracketrightbig
=
x1y1x1y2···x1yn
x2y1x2y2···x2yn
............
xmy1xmy2···xmyn
.
As an example of how the outer product can be useful, let 1∈Rndenote an n-dimensional
vector whose entries are all equal to 1. Furthermore, consider t he matrix A∈Rm×nwhose
columns are all equal to some vector x∈Rm. Using outer products, we can represent A
compactly as,
A=
| | |
x x···x
| | |
=
x1x1···x1
x2x2···x2
............
xmxm···xm
=
x1
x2
...
xm
/bracketleftbig1 1···1/bracketrightbig
=x1T.
2.2 Matrix-Vector Products
Given a matrix A∈Rm×nand a vector x∈Rn, their product is a vector y=Ax∈Rm.
There are a couple ways of looking at matrix-vector multiplication, an d we will look at each
of them in turn.
If we write Aby rows, then we can express Axas,
y=Ax=
—aT
1—
—aT
2—
...
—aT
m—
x=
aT
1x
aT
2x
...
aT
mx
.
4
In other words, the ith entry of yis equal to the inner product of the ithrowofAandx,
yi=aT
ix.
Alternatively, let’s write Ain column form. In this case we see that,
y=Ax=
| | |
a1a2···an
| | |

x1
x2
...
xn
=
a1
x1+
a2
x2+...+
an
xn.
In other words, y is a linear combination of thecolumns ofA, where the coeﬃcients of
the linear combination are given by the entries of x.
So far we have been multiplying on the right by a column vector, but it is also possible
to multiply on the left by a row vector. This is written, yT=xTAforA∈Rm×n,x∈Rm,
andy∈Rn. As before, we can express yTin two obvious ways, depending on whether we
expressAin terms on its rows or columns. In the ﬁrst case we express Ain terms of its
columns, which gives
yT=xTA=xT
| | |
a1a2···an
| | |
=/bracketleftbig
xTa1xTa2···xTan/bracketrightbig
which demonstrates that the ith entry of yTis equal to the inner product of xand theith
columnofA.
Finally, expressing Ain terms of rows we get the ﬁnal representation of the vector-ma trix
product,
yT=xTA
=/bracketleftbig
x1x2···xn/bracketrightbig
—aT
1—
—aT
2—
...
—aT
m—

=x1/bracketleftbig
—aT
1—/bracketrightbig
+x2/bracketleftbig
—aT
2—/bracketrightbig
+...+xn/bracketleftbig
—aT
n—/bracketrightbig
so we see that yTis a linear combination of the rowsofA, where the coeﬃcients for the
linear combination are given by the entries of x.
2.3 Matrix-Matrix Products
Armed with this knowledge, we can now look at four diﬀerent (but, of course, equivalent)
ways of viewing the matrix-matrix multiplication C=ABas deﬁned at the beginning of
this section.
First, we can view matrix-matrix multiplication as a set of vector-vec tor products. The
most obvious viewpoint, which follows immediately from the deﬁnition, is that the ( i,j)th
5
entry of Cis equal to the inner product of the ith row of Aand the jth column of B.
Symbolically, this looks like the following,
C=AB=
—aT
1—
—aT
2—
...
—aT
m—

| | |
b1b2···bp
| | |
=
aT
1b1aT
1b2···aT
1bp
aT
2b1aT
2b2···aT
2bp
............
aT
mb1aT
mb2···aT
mbp
.
Remember that since A∈Rm×nandB∈Rn×p,ai∈Rnandbj∈Rn, so these inner
products all make sense. This is the most “natural” representatio n when we represent A
by rows and Bby columns. Alternatively, we can represent Aby columns, and Bby rows.
This representation leads to a much trickier interpretation of ABas a sum of outer products.
Symbolically,
C=AB=
| | |
a1a2···an
| | |

—bT
1—
—bT
2—
...
—bT
n—
=n/summationdisplay
i=1aibT
i.
Put another way, ABis equal to the sum, over all i, of the outer product of the ith column
ofAand theith row of B. Since, in this case, ai∈Rmandbi∈Rp, the dimension of the
outer product aibT
iism×p, which coincides with the dimension of C. Chances are, the last
equality above may appear confusing to you. If so, take the time to check it for yourself!
Second, we can also view matrix-matrix multiplication as a set of matrix -vector products.
Speciﬁcally, if we represent Bby columns, we can view the columns of Cas matrix-vector
products between Aand the columns of B. Symbolically,
C=AB=A
| | |
b1b2···bp
| | |
=
| | |
Ab1Ab2···Abp
| | |
.
Here the ith column of Cis given by the matrix-vector product with the vector on the right,
ci=Abi. These matrix-vector products can in turn be interpreted using b oth viewpoints
given in the previous subsection. Finally, we have the analogous viewp oint, where we repre-
sentAby rows, and view the rows of Cas the matrix-vector product between the rows of A
andC. Symbolically,
C=AB=
—aT
1—
—aT
2—
...
—aT
m—
B=
—aT
1B—
—aT
2B—
...
—aT
mB—
.
Here the ith row of Cis given by the matrix-vector product with the vector on the left,
cT
i=aT
iB.
6
It may seem like overkill to dissect matrix multiplication to such a larged egree, especially
when all these viewpoints follow immediately from the initial deﬁnition we gave (in about a
line of math) at the beginning of this section. However, virtually all of linear algebra deals
with matrix multiplications of some kind, and it is worthwhile to spend som e time trying to
develop an intuitive understanding of the viewpoints presented her e.
In addition to this, it is useful to know a few basic properties of matr ix multiplication at
a higher level:
•Matrix multiplication is associative: ( AB)C=A(BC).
•Matrix multiplication is distributive: A(B+C) =AB+AC.
•Matrix multiplication is, in general, notcommutative; that is, it can be the case that
AB/ne}ationslash=BA. (For example, if A∈Rm×nandB∈Rn×q, the matrix product BAdoes
not even exist if mandqare not equal!)
If you are not familiar with these properties, take the time to verify them for yourself.
For example, to check the associativity of matrix multiplication, supp ose that A∈Rm×n,
B∈Rn×p, andC∈Rp×q. Note that AB∈Rm×p, so (AB)C∈Rm×q. Similarly, BC∈Rn×q,
soA(BC)∈Rm×q. Thus, the dimensions of the resulting matrices agree. To show tha t
matrix multiplication is associative, it suﬃces to check that the ( i,j)th entry of ( AB)Cis
equal to the ( i,j)th entry of A(BC). We can verify this directly using the deﬁnition of
matrix multiplication:
((AB)C)ij=p/summationdisplay
k=1(AB)ikCkj=p/summationdisplay
k=1/parenleftBiggn/summationdisplay
l=1AilBlk/parenrightBigg
Ckj
=p/summationdisplay
k=1/parenleftBiggn/summationdisplay
l=1AilBlkCkj/parenrightBigg
=n/summationdisplay
l=1/parenleftBiggp/summationdisplay
k=1AilBlkCkj/parenrightBigg
=n/summationdisplay
l=1Ail/parenleftBiggp/summationdisplay
k=1BlkCkj/parenrightBigg
=n/summationdisplay
l=1Ail(BC)lj= (A(BC))ij.
Here, the ﬁrst and last two equalities simply use the deﬁnition of matr ix multiplication, the
third and ﬁfth equalities use the distributive property for scalar multiplication over addition ,
and the fourth equality uses the commutative and associativity of scalar addition . This
technique for proving matrix properties by reduction to simple scala r properties will come
up often, so make sure you’re familiar with it.
3 Operations and Properties
In this section we present several operations and properties of m atrices and vectors. Hope-
fully a great deal of this will be review for you, so the notes can just serve as a reference for
these topics.
7
3.1 The Identity Matrix and Diagonal Matrices
Theidentity matrix , denoted I∈Rn×n, is a square matrix with ones on the diagonal and
zeros everywhere else. That is,
Iij=/braceleftbigg
1i=j
0i/ne}ationslash=j
It has the property that for all A∈Rm×n,
AI=A=IA.
Note that in some sense, the notation for the identity matrix is ambig uous, since it does not
specify the dimension of I. Generally, the dimensions of Iare inferred from context so as to
make matrix multiplication possible. For example, in the equation above , theIinAI=A
is ann×nmatrix, whereas the IinA=IAis anm×mmatrix.
Adiagonal matrix is a matrix where all non-diagonal elements are 0. This is typically
denotedD= diag(d1,d2,...,d n), with
Dij=/braceleftbigg
dii=j
0i/ne}ationslash=j
Clearly,I= diag(1,1,...,1).
3.2 The Transpose
Thetranspose of a matrix results from “ﬂipping” the rows and columns. Given a matr ix
A∈Rm×n, its transpose, written AT∈Rn×m, is then×mmatrix whose entries are given
by
(AT)ij=Aji.
We have in fact already been using the transpose when describing ro w vectors, since the
transpose of a column vector is naturally a row vector.
The following properties of transposes are easily veriﬁed:
•(AT)T=A
•(AB)T=BTAT
•(A+B)T=AT+BT
3.3 Symmetric Matrices
A square matrix A∈Rn×nissymmetric ifA=AT. It isanti-symmetric ifA=−AT.
It is easy to show that for any matrix A∈Rn×n, the matrix A+ATis symmetric and the
8
matrixA−ATis anti-symmetric. From this it follows that any square matrix A∈Rn×ncan
be represented as a sum of a symmetric matrix and an anti-symmetr ic matrix, since
A=1
2(A+AT)+1
2(A−AT)
andtheﬁrstmatrixontherightissymmetric, whilethesecondisanti- symmetric. Itturnsout
that symmetric matrices occur a great deal in practice, and they h ave many nice properties
which we will look at shortly. It is common to denote the set of all symm etric matrices of
sizenasSn, so that A∈Snmeans that Ais a symmetric n×nmatrix;
3.4 The Trace
Thetraceof a square matrix A∈Rn×n, denoted tr( A) (or just tr Aif the parentheses are
obviously implied), is the sum of diagonal elements in the matrix:
trA=n/summationdisplay
i=1Aii.
As described in the CS229 lecture notes, the trace has the following properties (included
here for the sake of completeness):
•ForA∈Rn×n, trA= trAT.
•ForA,B∈Rn×n, tr(A+B) = trA+trB.
•ForA∈Rn×n,t∈R, tr(tA) =ttrA.
•ForA,Bsuch that ABis square, tr AB= trBA.
•ForA,B,Csuch that ABCis square, tr ABC= trBCA= trCAB, and so on for the
product of more matrices.
As an example of how these properties can be proven, we’ll consider the fourth property
given above. Suppose that A∈Rm×nandB∈Rn×m(so that AB∈Rm×mis a square
matrix). Observe that BA∈Rn×nis also a square matrix, so it makes sense to apply the
trace operator to it. To verify that tr AB= trBA, note that
trAB=m/summationdisplay
i=1(AB)ii=m/summationdisplay
i=1/parenleftBiggn/summationdisplay
j=1AijBji/parenrightBigg
=m/summationdisplay
i=1n/summationdisplay
j=1AijBji=n/summationdisplay
j=1m/summationdisplay
i=1BjiAij
=n/summationdisplay
j=1/parenleftBiggm/summationdisplay
i=1BjiAij/parenrightBigg
=n/summationdisplay
j=1(BA)jj= trBA.
9
Here, the ﬁrst and last two equalities use the deﬁnition of the trace operator and matrix
multiplication. The fourth equality, where the main work occurs, use s the commutativity
of scalar multiplication in order to reverse the order of the terms in e ach product, and the
commutativity and associativity of scalar addition in order to rearra nge the order of the
summation.
3.5 Norms
Anormof a vector /ba∇dblx/ba∇dblis informally a measure of the “length” of the vector. For example,
we have the commonly-used Euclidean or ℓ2norm,
/ba∇dblx/ba∇dbl2=/radicaltp/radicalvertex/radicalvertex/radicalbtn/summationdisplay
i=1x2
i.
Note that /ba∇dblx/ba∇dbl2
2=xTx.
More formally, a norm is any function f:Rn→Rthat satisﬁes 4 properties:
1. For all x∈Rn,f(x)≥0 (non-negativity).
2.f(x) = 0 if and only if x= 0 (deﬁniteness).
3. For all x∈Rn,t∈R,f(tx) =|t|f(x) (homogeneity).
4. For all x,y∈Rn,f(x+y)≤f(x)+f(y) (triangle inequality).
Other examples of norms are the ℓ1norm,
/ba∇dblx/ba∇dbl1=n/summationdisplay
i=1|xi|
and theℓ∞norm,
/ba∇dblx/ba∇dbl∞= max i|xi|.
In fact, all three norms presented so far are examples of the fam ily ofℓpnorms, which are
parameterized by a real number p≥1, and deﬁned as
/ba∇dblx/ba∇dblp=/parenleftBiggn/summationdisplay
i=1|xi|p/parenrightBigg1/p
.
Norms can also be deﬁned for matrices, such as the Frobenius norm ,
/ba∇dblA/ba∇dblF=/radicaltp/radicalvertex/radicalvertex/radicalbtm/summationdisplay
i=1n/summationdisplay
j=1A2
ij=/radicalbig
tr(ATA).
Many other norms exist, but they are beyond the scope of this rev iew.
10
3.6 Linear Independence and Rank
Aset ofvectors {x1,x2,...xn} ⊂Rmissaid to be (linearly) independent if no vector can
be represented as a linear combination of the remaining vectors. Co nversely, if one vector
belonging to the set canbe represented as a linear combination of the remaining vectors,
then the vectors are said to be (linearly) dependent . That is, if
xn=n−1/summationdisplay
i=1αixi
for some scalar values α1,...,α n−1∈R, then we say that the vectors x1,...,x nare linearly
dependent; otherwise, the vectors are linearly independent. For example, the vectors
x1=
1
2
3
x2=
4
1
5
x3=
2
−3
−1

are linearly dependent because x3=−2x1+x2.
Thecolumn rank of a matrix A∈Rm×nis the size of the largest subset of columns of
Athat constitute a linearly independent set. With some abuse of term inology, this is often
referred to simply as the number of linearly independent columns of A. In the same way,
therow rank is the largest number of rows of Athat constitute a linearly independent set.
For any matrix A∈Rm×n, it turns out that the column rank of Ais equal to the row
rank ofA(though we will not prove this), and so both quantities are referre d to collectively
as therankofA, denoted as rank( A). The following are some basic properties of the rank:
•ForA∈Rm×n, rank(A)≤min(m,n). If rank( A) = min( m,n), thenAis said to be
full rank .
•ForA∈Rm×n, rank(A) = rank( AT).
•ForA∈Rm×n,B∈Rn×p, rank(AB)≤min(rank( A),rank(B)).
•ForA,B∈Rm×n, rank(A+B)≤rank(A)+rank( B).
3.7 The Inverse
Theinverse of a square matrix A∈Rn×nis denoted A−1, and is the unique matrix such
that
A−1A=I=AA−1.
Note that not all matrices have inverses. Non-square matrices, f or example, do not have
inverses by deﬁnition. However, for some square matrices A, it may still be the case that
11
A−1may not exist. In particular, we say that Aisinvertible ornon-singular ifA−1
exists and non-invertible orsingular otherwise.1
In order for a square matrix Ato have an inverse A−1, thenAmust be full rank. We will
soon see that there are many alternative suﬃcient and necessary conditions, in addition to
full rank, for invertibility.
The following are properties of the inverse; all assume that A,B∈Rn×nare non-singular:
•(A−1)−1=A
•(AB)−1=B−1A−1
•(A−1)T= (AT)−1. For this reason this matrix is often denoted A−T.
As an example of how the inverse is used, consider the linear system o f equations, Ax=b
whereA∈Rn×n, andx,b∈Rn. IfAis nonsingular (i.e., invertible), then x=A−1b. (What
ifA∈Rm×nis not a square matrix? Does this work?)
3.8 Orthogonal Matrices
Two vectors x,y∈Rnareorthogonal ifxTy= 0. A vector x∈Rnisnormalized if
/ba∇dblx/ba∇dbl2= 1. A square matrix U∈Rn×nisorthogonal (note the diﬀerent meanings when
talking about vectors versus matrices) if all its columns are orthog onal to each other and are
normalized (the columns are then referred to as being orthonormal ).
It follows immediately from the deﬁnition of orthogonality and normalit y that
UTU=I=UUT.
In other words, the inverse of an orthogonal matrix is its transpo se. Note that if Uis not
square — i.e., U∈Rm×n, n < m — but its columns are still orthonormal, then UTU=I,
butUUT/ne}ationslash=I. We generally only use the term orthogonal to describe the previou s case,
whereUis square.
Another nice property of orthogonal matrices is that operating o n a vector with an
orthogonal matrix will not change its Euclidean norm, i.e.,
/ba∇dblUx/ba∇dbl2=/ba∇dblx/ba∇dbl2
for anyx∈Rn,U∈Rn×northogonal.
3.9 Range and Nullspace of a Matrix
Thespanof a set of vectors {x1,x2,...xn}is the set of all vectors that can be expressed as
a linear combination of {x1,...,x n}. That is,
span({x1,...xn}) =/braceleftBigg
v:v=n/summationdisplay
i=1αixi, αi∈R/bracerightBigg
.
1It’s easy to get confused and think that non-singular means non-in vertible. But in fact, it means the
opposite! Watch out!
12
It can be shown that if {x1,...,x n}is a set of nlinearly independent vectors, where each
xi∈Rn, then span( {x1,...xn}) =Rn. In other words, anyvectorv∈Rncan be written as
a linear combination of x1throughxn. Theprojection of a vector y∈Rmonto the span
of{x1,...,x n}(here we assume xi∈Rm) is the vector v∈span({x1,...xn}), such that v
is as close as possible to y, as measured by the Euclidean norm /ba∇dblv−y/ba∇dbl2. We denote the
projection as Proj( y;{x1,...,x n}) and can deﬁne it formally as,
Proj(y;{x1,...xn}) = argminv∈span({x1,...,xn})/ba∇dbly−v/ba∇dbl2.
Therange(sometimes also called the columnspace) of a matrix A∈Rm×n, denoted
R(A), is the the span of the columns of A. In other words,
R(A) ={v∈Rm:v=Ax,x∈Rn}.
Making a few technical assumptions (namely that Ais full rank and that n < m), the
projection of a vector y∈Rmonto the range of Ais given by,
Proj(y;A) = argminv∈R(A)/ba∇dblv−y/ba∇dbl2=A(ATA)−1ATy .
This last equation should look extremely familiar, since it is almost the sa me formula we
derived in class (and which we will soon derive again) for the least squa res estimation of
parameters. Looking at the deﬁnition for the projection, it should not be too hard to
convince yourself that this is in fact the same objective that we minim ized in our least
squares problem (except for a squaring of the norm, which doesn’t aﬀect the optimal point)
and so these problems are naturally very connected. When Acontains only a single column,
a∈Rm, this gives the special case for a projection of a vector on to a line:
Proj(y;a) =aaT
aTay .
Thenullspace of a matrix A∈Rm×n, denoted N(A) is the set of all vectors that equal
0 when multiplied by A, i.e.,
N(A) ={x∈Rn:Ax= 0}.
Note that vectors in R(A) are of size m, while vectors in the N(A) are of size n, so vectors
inR(AT) andN(A) are both in Rn. In fact, we can say much more. It turns out that
/braceleftbig
w:w=u+v,u∈ R(AT),v∈ N(A)/bracerightbig
=RnandR(AT)∩N(A) ={0}.
In other words, R(AT) andN(A) are disjoint subsets that together span the entire space of
Rn. Sets of this type are called orthogonal complements , and we denote this R(AT) =
N(A)⊥.
13
3.10 The Determinant
Thedeterminant of a square matrix A∈Rn×n, is a function det : Rn×n→R, and is
denoted|A|or detA(like the trace operator, we usually omit parentheses). Algebraica lly,
one could write down an explicit formula for the determinant of A, but this unfortunately
gives little intuition about its meaning. Instead, we’ll start out by pro viding a geometric
interpretation of the determinant and then visit some of its speciﬁc algebraic properties
afterwards.
Given a matrix 
—aT
1—
—aT
2—
...
—aT
n—
,
consider the set of points S⊂Rnformed by taking all possible linear combinations of the
row vectors a1,...,a n∈RnofA, where the coeﬃcients of the linear combination are all
between 0 and 1; that is, the set Sis the restriction of span( {a1,...,a n}) to only those
linear combinations whose coeﬃcients α1,...,α nsatisfy 0 ≤αi≤1,i= 1,...,n. Formally,
S={v∈Rn:v=n/summationdisplay
i=1αiaiwhere 0≤αi≤1,i= 1,...,n}.
The absolute value of the determinant of A, it turns out, is a measure of the “volume” of
the setS.2
For example, consider the 2 ×2 matrix,
A=/bracketleftbigg1 3
3 2/bracketrightbigg
. (1)
Here, the rows of the matrix are
a1=/bracketleftbigg
1
3/bracketrightbigg
a2=/bracketleftbigg
3
2/bracketrightbigg
.
The setScorresponding to these rows is shown in Figure 1. For two-dimension al matrices,
Sgenerally has the shape of a parallelogram . In our example, the value of the determinant
is|A|=−7 (as can be computed using the formulas shown later in this section) , so the area
of the parallelogram is 7. (Verify this for yourself!)
Inthreedimensions, theset Scorrespondstoanobject knownasa parallelepiped (athree-
dimensional box with skewed sides, such that every face has the sh ape of a parallelogram).
The absolute value of the determinant of the 3 ×3 matrix whose rows deﬁne Sgive the
three-dimensional volume of the parallelepiped. In even higher dimen sions, the set Sis an
object known as an n-dimensional parallelotope .
2Admittedly, we have not actually deﬁned what we mean by “volume” he re, but hopefully the intuition
should be clear enough. When n= 2, our notion of “volume” corresponds to the area of Sin the Cartesian
plane. When n= 3, “volume” corresponds with our usual notion of volume for a thr ee-dimensional object.
14
a1
a2(1,3)
(3,2)(4,5)
(0,0)
Figure 1: Illustration of the determinant for the 2 ×2 matrix Agiven in (1). Here, a1anda2
are vectors corresponding to the rows of A, and the set Scorresponds to the shaded region
(i.e., the parallelogram). The absolute value of the determinant, |detA|= 7, is the area of
the parallelogram.
Algebraically, the determinant satisﬁes the following three propert ies (from which all
other properties follow, including the general formula):
1. The determinant of the identity is 1, |I|= 1. (Geometrically, the volume of a unit
hypercube is 1).
2. Given a matrix A∈Rn×n, if we multiply a single row in Aby a scalar t∈R, then the
determinant of the new matrix is t|A|,
/vextendsingle/vextendsingle/vextendsingle/vextendsingle/vextendsingle/vextendsingle/vextendsingle/vextendsingle/vextendsingle
—t aT
1—
—aT
2—
...
—aT
m—
/vextendsingle/vextendsingle/vextendsingle/vextendsingle/vextendsingle/vextendsingle/vextendsingle/vextendsingle/vextendsingle=t|A|.
(Geometrically, multiplying one of the sides of the set Sby a factor tcauses the volume
to increase by a factor t.)
3. If we exchange any two rows aT
iandaT
jofA, then the determinant of the new matrix
is−|A|, for example/vextendsingle/vextendsingle/vextendsingle/vextendsingle/vextendsingle/vextendsingle/vextendsingle/vextendsingle/vextendsingle
—aT
2—
—aT
1—
...
—aT
m—
/vextendsingle/vextendsingle/vextendsingle/vextendsingle/vextendsingle/vextendsingle/vextendsingle/vextendsingle/vextendsingle=−|A|.
In case you are wondering, it is not immediately obvious that a functio n satisfying the above
three properties exists. In fact, though, such a function does e xist, and is unique (which we
will not prove here).
Several properties that follow from the three properties above in clude:
15
•ForA∈Rn×n,|A|=|AT|.
•ForA,B∈Rn×n,|AB|=|A||B|.
•ForA∈Rn×n,|A|= 0 if and only if Ais singular (i.e., non-invertible). (If Ais singular
then it does not have full rank, and hence its columns are linearly dep endent. In this
case, the set Scorresponds to a “ﬂat sheet” within the n-dimensional space and hence
has zero volume.)
•ForA∈Rn×nandAnon-singular, |A−1|= 1/|A|.
Before giving the general deﬁnition for the determinant, we deﬁne , forA∈Rn×n,A\i,\j∈
R(n−1)×(n−1)to be the matrixthat results from deleting the ith row and jth column from A.
The general (recursive) formula for the determinant is
|A|=n/summationdisplay
i=1(−1)i+jaij|A\i,\j|(for anyj∈1,...,n)
=n/summationdisplay
j=1(−1)i+jaij|A\i,\j|(for anyi∈1,...,n)
with the initial case that |A|=a11forA∈R1×1. If we were to expand this formula
completely for A∈Rn×n, there would be a total of n! (nfactorial) diﬀerent terms. For this
reason, we hardly ever explicitly write the complete equation of the d eterminant for matrices
bigger than 3 ×3. However, the equations for determinants of matrices up to size 3×3 are
fairly common, and it is good to know them:
|[a11]|=a11/vextendsingle/vextendsingle/vextendsingle/vextendsingle/bracketleftbigga11a12
a21a22/bracketrightbigg/vextendsingle/vextendsingle/vextendsingle/vextendsingle=a11a22−a12a21
/vextendsingle/vextendsingle/vextendsingle/vextendsingle/vextendsingle/vextendsingle
a11a12a13
a21a22a23
a31a32a33
/vextendsingle/vextendsingle/vextendsingle/vextendsingle/vextendsingle/vextendsingle=a11a22a33+a12a23a31+a13a21a32
−a11a23a32−a12a21a33−a13a22a31
Theclassical adjoint (often just called the adjoint) of a matrix A∈Rn×n, is denoted
adj(A), and deﬁned as
adj(A)∈Rn×n,(adj(A))ij= (−1)i+j|A\j,\i|
(note the switch in the indices A\j,\i). It can be shown that for any nonsingular A∈Rn×n,
A−1=1
|A|adj(A).
While this is a nice “explicit” formula for the inverse of matrix, we should note that, numer-
ically, there are in fact much more eﬃcient ways of computing the inve rse.
16
3.11 Quadratic Forms and Positive Semideﬁnite Matrices
Given a square matrix A∈Rn×nand a vector x∈Rn, the scalar value xTAxis called a
quadratic form . Written explicitly, we see that
xTAx=n/summationdisplay
i=1xi(Ax)i=n/summationdisplay
i=1xi/parenleftBiggn/summationdisplay
j=1Aijxj/parenrightBigg
=n/summationdisplay
i=1n/summationdisplay
j=1Aijxixj.
Note that,
xTAx= (xTAx)T=xTATx=xT/parenleftbigg1
2A+1
2AT/parenrightbigg
x,
where the ﬁrst equality follows from the fact that the transpose o f a scalar is equal to
itself, and the second equality follows from the fact that we are ave raging two quantities
which are themselves equal. From this, we can conclude that only the symmetric part of
Acontributes to the quadratic form. For this reason, we often implic itly assume that the
matrices appearing in a quadratic form are symmetric.
We give the following deﬁnitions:
•A symmetric matrix A∈Snispositive deﬁnite (PD) if for all non-zero vectors
x∈Rn,xTAx >0. This is usually denoted A≻0 (or just A >0), and often times the
set of all positive deﬁnite matrices is denoted Sn
++.
•A symmetric matrix A∈Snispositive semideﬁnite (PSD) if for all vectors xTAx≥
0. Thisiswritten A/{ollowsequal0(orjust A≥0), andthesetofallpositivesemideﬁnite matrices
is often denoted Sn
+.
•Likewise, a symmetric matrix A∈Snisnegative deﬁnite (ND), denoted A≺0 (or
justA <0) if for all non-zero x∈Rn,xTAx <0.
•Similarly, a symmetric matrix A∈Snisnegative semideﬁnite (NSD), denoted
A/p∇ecedesequal0 (or just A≤0) if for all x∈Rn,xTAx≤0.
•Finally, a symmetric matrix A∈Snisindeﬁnite , if it is neither positive semideﬁnite
nor negative semideﬁnite — i.e., if there exists x1,x2∈Rnsuch that xT
1Ax1>0 and
xT
2Ax2<0.
It should be obvious that if Ais positive deﬁnite, then −Ais negative deﬁnite and vice
versa. Likewise, if Ais positive semideﬁnite then −Ais negative semideﬁnite and vice versa.
IfAis indeﬁnite, then so is −A.
One important property of positive deﬁnite and negative deﬁnite ma trices is that they
are always full rank, and hence, invertible. To see why this is the cas e, suppose that some
matrixA∈Rn×nis not full rank. Then, suppose that the jth column of Ais expressible as
a linear combination of other n−1 columns:
aj=/summationdisplay
i/\e}atio\slash=jxiai,
17
for some x1,...,x j−1,xj+1,...,x n∈R. Setting xj=−1, we have
Ax=n/summationdisplay
i=1xiai= 0.
But this implies xTAx= 0 for some non-zero vector x, soAmust be neither positive deﬁnite
nor negative deﬁnite. Therefore, if Ais either positive deﬁnite or negative deﬁnite, it must
be full rank.
Finally, there is one type of positive deﬁnite matrix that comes up fre quently, and so
deserves some special mention. Given any matrix A∈Rm×n(not necessarily symmetric or
even square), the matrix G=ATA(sometimes called a Gram matrix ) is always positive
semideﬁnite. Further, if m≥n(and we assume for convenience that Ais full rank), then
G=ATAis positive deﬁnite.
3.12 Eigenvalues and Eigenvectors
Given a square matrix A∈Rn×n, we say that λ∈Cis aneigenvalue ofAandx∈Cnis
the corresponding eigenvector3if
Ax=λx, x/ne}ationslash= 0.
Intuitively, this deﬁnition means that multiplying Aby the vector xresults in a new vector
that points in the same direction as x, but scaled by a factor λ. Also note that for any
eigenvector x∈Cn, and scalar t∈C,A(cx) =cAx=cλx=λ(cx), socxis also an
eigenvector. For this reason when we talk about “the” eigenvecto r associated with λ, we
usually assume that the eigenvector is normalized to have length 1 (t his still creates some
ambiguity, since xand−xwill both be eigenvectors, but we will have to live with this).
We can rewrite the equation above to state that ( λ,x) is an eigenvalue-eigenvector pair
ofAif,
(λI−A)x= 0, x/ne}ationslash= 0.
But (λI−A)x= 0 has a non-zero solution to xif and only if ( λI−A) has a non-empty
nullspace, which is only the case if ( λI−A) is singular, i.e.,
|(λI−A)|= 0.
We can now use the previous deﬁnition of the determinant to expand this expression
into a (very large) polynomial in λ, whereλwill have maximum degree n. We then ﬁnd
then(possibly complex) roots of this polynomial to ﬁnd the neigenvalues λ1,...,λ n. To
ﬁnd the eigenvector corresponding to the eigenvalue λi, we simply solve the linear equation
(λiI−A)x= 0. It should be noted that this is not the method which is actually use d
3Note that λand the entries of xare actually in C, the set of complex numbers, not just the reals; we
will see shortly why this is necessary. Don’t worry about this technic ality for now, you can think of complex
vectors in the same way as real vectors.
18
in practice to numerically compute the eigenvalues and eigenvectors (remember that the
complete expansion of the determinant has n! terms); it is rather a mathematical argument.
Thefollowingarepropertiesofeigenvaluesandeigenvectors (inallc asesassume A∈Rn×n
has eigenvalues λi,...,λ nand associated eigenvectors x1,...xn):
•The trace of a Ais equal to the sum of its eigenvalues,
trA=n/summationdisplay
i=1λi.
•The determinant of Ais equal to the product of its eigenvalues,
|A|=n/productdisplay
i=1λi.
•The rank of Ais equal to the number of non-zero eigenvalues of A.
•IfAis non-singular then 1 /λiis an eigenvalue of A−1with associated eigenvector xi,
i.e.,A−1xi= (1/λi)xi. (To prove this, take the eigenvector equation, Axi=λixiand
left-multiply each side by A−1.)
•The eigenvalues of a diagonal matrix D= diag(d1,...dn) are just the diagonal entries
d1,...dn.
We can write all the eigenvector equations simultaneously as
AX=XΛ
where the columns of X∈Rn×nare the eigenvectors of Aand Λ is a diagonal matrix whose
entries are the eigenvalues of A, i.e.,
X∈Rn×n=
| | |
x1x2···xn
| | |
,Λ = diag( λ1,...,λ n).
If the eigenvectors of Aare linearly independent, then the matrix Xwill be invertible, so
A=XΛX−1. A matrix that can be written in this form is called diagonalizable .
3.13 Eigenvalues and Eigenvectors of Symmetric Matrices
Two remarkable properties come about when we look at the eigenvalu es and eigenvectors
of a symmetric matrix A∈Sn. First, it can be shown that all the eigenvalues of Aare
real. Secondly, the eigenvectors of Aare orthonormal, i.e., the matrix Xdeﬁned above is an
orthogonal matrix (for this reason, we denote the matrix of eigen vectors as Uin this case).
19
We can therefore represent AasA=UΛUT, remembering from above that the inverse of
an orthogonal matrix is just its transpose.
Using this, we can show that the deﬁniteness of a matrix depends en tirely on the sign of
its eigenvalues. Suppose A∈Sn=UΛUT. Then
xTAx=xTUΛUTx=yTΛy=n/summationdisplay
i=1λiy2
i
wherey=UTx(and since Uis full rank, any vector y∈Rncan be represented in this form).
Because y2
iis always positive, the sign of this expression depends entirely on the λi’s. If all
λi>0, then the matrix is positive deﬁnite; if all λi≥0, it is positive semideﬁnite. Likewise,
if allλi<0 orλi≤0, thenAis negative deﬁnite or negative semideﬁnite respectively.
Finally, if Ahas both positive and negative eigenvalues, it is indeﬁnite.
An application where eigenvalues and eigenvectors come up frequen tly is in maximizing
some function of a matrix. In particular, for a matrix A∈Sn, consider the following
maximization problem,
maxx∈RnxTAxsubject to /ba∇dblx/ba∇dbl2
2= 1
i.e., we want to ﬁnd the vector (of norm 1) which maximizes the quadra tic form. Assuming
the eigenvalues are ordered as λ1≥λ2≥...≥λn, the optimal xfor this optimization
problem is x1, the eigenvector corresponding to λ1. In this case the maximal value of the
quadratic form is λ1. Similarly, the optimal solution to the minimization problem,
minx∈RnxTAxsubject to /ba∇dblx/ba∇dbl2
2= 1
isxn, theeigenvector correspondingto λn, andtheminimalvalueis λn. Thiscanbeprovedby
appealing to the eigenvector-eigenvalue form of Aand the properties of orthogonal matrices.
However, in the next section we will see a way of showing it directly usin g matrix calculus.
4 Matrix Calculus
While the topics in the previous sections are typically covered in a stan dard course on linear
algebra, one topic that does not seem to be covered very often (a nd which we will use
extensively) is the extension of calculus to the vector setting. Des pite the fact that all the
actual calculus we use is relatively trivial, the notation can often mak e things look much
more diﬃcult than they are. In this section we present some basic de ﬁnitions of matrix
calculus and provide a few examples.
4.1 The Gradient
Suppose that f:Rm×n→Ris a function that takes as input a matrix Aof sizem×nand
returns a real value. Then the gradient off(with respect to A∈Rm×n) is the matrix of
20
partial derivatives, deﬁned as:
∇Af(A)∈Rm×n=
∂f(A)
∂A11∂f(A)
∂A12···∂f(A)
∂A1n∂f(A)
∂A21∂f(A)
∂A22···∂f(A)
∂A2n............
∂f(A)
∂Am1∂f(A)
∂Am2···∂f(A)
∂Amn

i.e., anm×nmatrix with
(∇Af(A))ij=∂f(A)
∂Aij.
Note that the size of ∇Af(A) is always the same as the size of A. So if, in particular, Ais
just a vector x∈Rn,
∇xf(x) =
∂f(x)
∂x1∂f(x)
∂x2...
∂f(x)
∂xn
.
Itisvery importanttoremember thatthegradientofafunctionis onlydeﬁnedifthefunction
is real-valued, that is, if it returns a scalar value. We can not, for ex ample, take the gradient
ofAx,A∈Rn×nwith respect to x, since this quantity is vector-valued.
It follows directly from the equivalent properties of partial derivat ives that:
• ∇x(f(x)+g(x)) =∇xf(x)+∇xg(x).
•Fort∈R,∇x(t f(x)) =t∇xf(x).
In principle, gradients are a natural extension of partial derivativ es to functions of mul-
tiple variables. In practice, however, working with gradients can so metimes be tricky for
notational reasons. For example, suppose that A∈Rm×nis a matrix of ﬁxed coeﬃcients
and suppose that b∈Rmis a vector of ﬁxed coeﬃcients. Let f:Rm→Rbe the function
deﬁned by f(z) =zTz, such that ∇zf(z) = 2z. But now, consider the expression,
∇f(Ax).
How should this expression be interpreted? There are at least two p ossibilities:
1. In the ﬁrst interpretation, recall that ∇zf(z) = 2z. Here, we interpret ∇f(Ax) as
evaluating the gradient at the point Ax, hence,
∇f(Ax) = 2(Ax) = 2Ax∈Rm.
2. In the second interpretation, we consider the quantity f(Ax) as a function of the input
variables x. More formally, let g(x) =f(Ax). Then in this interpretation,
∇f(Ax) =∇xg(x)∈Rn.
21
Here, wecanseethatthesetwo interpretationsareindeeddiﬀere nt. Oneinterpretationyields
anm-dimensional vector as a result, while the other interpretation yield s ann-dimensional
vector as a result! How can we resolve this?
Here, the key is to make explicit the variables which we are diﬀerentiat ing with respect
to. In the ﬁrst case, we are diﬀerentiating the function fwith respect to its arguments zand
then substituting the argument Ax. In the second case, we are diﬀerentiating the composite
function g(x) =f(Ax) with respect to xdirectly. We denote the ﬁrst case as ∇zf(Ax) and
the second case as ∇xf(Ax).4Keeping the notation clear is extremely important (as you’ll
ﬁnd out in your homework, in fact!).
4.2 The Hessian
Suppose that f:Rn→Ris a function that takes a vector in Rnand returns a real number.
Then the Hessian matrix with respect to x, written ∇2
xf(x) or simply as His then×n
matrix of partial derivatives,
∇2
xf(x)∈Rn×n=
∂2f(x)
∂x2
1∂2f(x)
∂x1∂x2···∂2f(x)
∂x1∂xn
∂2f(x)
∂x2∂x1∂2f(x)
∂x2
2···∂2f(x)
∂x2∂xn............
∂2f(x)
∂xn∂x1∂2f(x)
∂xn∂x2···∂2f(x)
∂x2n
.
In other words, ∇2
xf(x)∈Rn×n, with
(∇2
xf(x))ij=∂2f(x)
∂xi∂xj.
Note that the Hessian is always symmetric, since
∂2f(x)
∂xi∂xj=∂2f(x)
∂xj∂xi.
Similar to the gradient, the Hessian is deﬁned only when f(x) is real-valued.
It is natural to think of the gradient as the analogue of the ﬁrst de rivative for functions
of vectors, and the Hessian as the analogue of the second derivat ive (and the symbols we
use also suggest this relation). This intuition is generally correct, bu t there a few caveats to
keep in mind.
4A drawback to this notation that we will have to live with is the fact tha t in the ﬁrst case, ∇zf(Ax) it
appears that we are diﬀerentiating with respect to a variable that d oes not even appear in the expression
being diﬀerentiated! For this reason, the ﬁrst case is often writte n as∇f(Ax), and the fact that we are
diﬀerentiating with respect to the arguments of fis understood. However, the second case is alwayswritten
as∇xf(Ax).
22
First, for real-valued functions of one variable f:R→R, it is a basic deﬁnition that the
second derivative is the derivative of the ﬁrst derivative, i.e.,
∂2f(x)
∂x2=∂
∂x∂
∂xf(x).
However, for functions of a vector, the gradient of the function is a vector, and we cannot
take the gradient of a vector — i.e.,
∇x∇xf(x) =∇x
∂f(x)
∂x1∂f(x)
∂x2...
∂f(x)
∂xn

and this expression is not deﬁned. Therefore, it is notthe case that the Hessian is the
gradient of the gradient. However, this is almosttrue, in the following sense: If we look at
theith entry of the gradient ( ∇xf(x))i=∂f(x)/∂xi, and take the gradient with respect to
xwe get
∇x∂f(x)
∂xi=
∂2f(x)
∂xi∂x1
∂2f(x)
∂xi∂x2...
∂f(x)
∂xi∂xn

which is the ith column (or row) of the Hessian. Therefore,
∇2
xf(x) =/bracketleftbig∇x(∇xf(x))1∇x(∇xf(x))2··· ∇ x(∇xf(x))n/bracketrightbig
.
Ifwedon’tmindbeingalittlebitsloppywecansaythat(essentially) ∇2
xf(x) =∇x(∇xf(x))T,
solongasweunderstandthatthisreallymeanstakingthegradiento feachentryof( ∇xf(x))T,
not the gradient of the whole vector.
Finally, note that while we can take the gradient with respect to a mat rixA∈Rn, for
the purposes of this class we will only consider taking the Hessian with respect to a vector
x∈Rn. This is simply a matter of convenience (and the fact that none of th e calculations
we do require us to ﬁnd the Hessian with respect to a matrix), since t he Hessian with respect
to a matrix would have to represent all the partial derivatives ∂2f(A)/(∂Aij∂Akℓ), and it is
rather cumbersome to represent this as a matrix.
4.3 Gradients and Hessians of Quadratic and Linear Function s
Now let’s try to determine the gradient and Hessian matrices for a fe w simple functions. It
should be noted that all the gradients given here are special cases of the gradients given in
the CS229 lecture notes.
23
Forx∈Rn, letf(x) =bTxfor some known vector b∈Rn. Then
f(x) =n/summationdisplay
i=1bixi
so
∂f(x)
∂xk=∂
∂xkn/summationdisplay
i=1bixi=bk.
From this we can easily see that ∇xbTx=b. This should be compared to the analogous
situation in single variable calculus, where ∂/(∂x)ax=a.
Now consider the quadratic function f(x) =xTAxforA∈Sn. Remember that
f(x) =n/summationdisplay
i=1n/summationdisplay
j=1Aijxixj.
To take thepartial derivative, we’ll consider the terms including xkandx2
kfactorsseparately:
∂f(x)
∂xk=∂
∂xkn/summationdisplay
i=1n/summationdisplay
j=1Aijxixj
=∂
∂xk/bracketleftBigg/summationdisplay
i/\e}atio\slash=k/summationdisplay
j/\e}atio\slash=kAijxixj+/summationdisplay
i/\e}atio\slash=kAikxixk+/summationdisplay
j/\e}atio\slash=kAkjxkxj+Akkx2
k/bracketrightBigg
=/summationdisplay
i/\e}atio\slash=kAikxi+/summationdisplay
j/\e}atio\slash=kAkjxj+2Akkxk
=n/summationdisplay
i=1Aikxi+n/summationdisplay
j=1Akjxj= 2n/summationdisplay
i=1Akixi,
where the last equality follows since Ais symmetric (which we can safely assume, since it is
appearing in a quadratic form). Note that the kth entry of ∇xf(x) is just the inner product
of thekth row of Aandx. Therefore, ∇xxTAx= 2Ax. Again, this should remind you of
the analogous fact in single-variable calculus, that ∂/(∂x)ax2= 2ax.
Finally, let’s look at the Hessian of the quadratic function f(x) =xTAx(it should be
obvious that the Hessian of a linear function bTxis zero). In this case,
∂2f(x)
∂xk∂xℓ=∂
∂xk/bracketleftbigg∂f(x)
∂xℓ/bracketrightbigg
=∂
∂xk/bracketleftBigg
2n/summationdisplay
i=1Aℓixi/bracketrightBigg
= 2Aℓk= 2Akℓ.
Therefore, it should be clear that ∇2
xxTAx= 2A, which should be entirely expected (and
again analogous to the single-variable fact that ∂2/(∂x2)ax2= 2a).
To recap,
• ∇xbTx=b
• ∇xxTAx= 2Ax(ifAsymmetric)
• ∇2
xxTAx= 2A(ifAsymmetric)
24
4.4 Least Squares
Let’sapplytheequationsweobtainedinthelastsectiontoderivethe leastsquares equations.
Suppose we are given matrices A∈Rm×n(for simplicity we assume Ais full rank) and a
vectorb∈Rmsuch that b/ne}ationslash∈ R(A). In this situation we will not be able to ﬁnd a vector
x∈Rn, such that Ax=b, so instead we want to ﬁnd a vector xsuch that Axis as close as
possible to b, as measured by the square of the Euclidean norm /ba∇dblAx−b/ba∇dbl2
2.
Using the fact that /ba∇dblx/ba∇dbl2
2=xTx, we have
/ba∇dblAx−b/ba∇dbl2
2= (Ax−b)T(Ax−b)
=xTATAx−2bTAx+bTb
Taking the gradient with respect to xwe have, and using the properties we derived in the
previous section
∇x(xTATAx−2bTAx+bTb) =∇xxTATAx−∇x2bTAx+∇xbTb
= 2ATAx−2ATb
Setting this last expression equal to zero and solving for xgives the normal equations
x= (ATA)−1ATb
which is the same as what we derived in class.
4.5 Gradients of the Determinant
Now let’s consider a situation where we ﬁnd the gradient of a function with respect to
a matrix, namely for A∈Rn×n, we want to ﬁnd ∇A|A|. Recall from our discussion of
determinants that
|A|=n/summationdisplay
i=1(−1)i+jAij|A\i,\j|(for anyj∈1,...,n)
so
∂
∂Akℓ|A|=∂
∂Akℓn/summationdisplay
i=1(−1)i+jAij|A\i,\j|= (−1)k+ℓ|A\k,\ℓ|= (adj(A))ℓk.
From this it immediately follows from the properties of the adjoint tha t
∇A|A|= (adj(A))T=|A|A−T.
Now let’s consider the function f:Sn
++→R,f(A) = log|A|. Note that we have to
restrict the domain of fto be the positive deﬁnite matrices, since this ensures that |A|>0,
so that the log of |A|is a real number. In this case we can use the chain rule (nothing fanc y,
just the ordinary chain rule from single-variable calculus) to see tha t
∂log|A|
∂Aij=∂log|A|
∂|A|∂|A|
∂Aij=1
|A|∂|A|
∂Aij.
25
From this it should be obvious that
∇Alog|A|=1
|A|∇A|A|=A−1,
where we can drop the transpose in the last expression because Ais symmetric. Note the
similarity to the single-valued case, where ∂/(∂x) logx= 1/x.
4.6 Eigenvalues as Optimization
Finally, we use matrix calculus to solve an optimization problem in a way th at leads directly
toeigenvalue/eigenvector analysis. Consider thefollowing, equality constrained optimization
problem:
maxx∈RnxTAxsubject to /ba∇dblx/ba∇dbl2
2= 1
for a symmetric matrix A∈Sn. A standard way of solving optimization problems with
equality constraints is by forming the Lagrangian , an objective function that includes the
equality constraints.5The Lagrangian in this case can be given by
L(x,λ) =xTAx−λxTx
whereλis called the Lagrange multiplier associated with the equality constrain t. It can be
established that for x∗to be a optimal point to the problem, the gradient of the Lagrangian
has to be zero at x∗(this is not the only condition, but it is required). That is,
∇xL(x,λ) =∇x(xTAx−λxTx) = 2ATx−2λx= 0.
Notice that this is just the linear equation Ax=λx. This shows that the only points which
can possibly maximize (or minimize) xTAxassuming xTx= 1 are the eigenvectors of A.
5Don’t worry if you haven’t seen Lagrangians before, as we will cover them in greater detail later in
CS229.
26
