



























































































































GitHub - SkalskiP/courses: This repository is a curated collection of links to various courses and resources about Artificial Intelligence (AI)




























































































Skip to content


























Navigation Menu




Toggle navigation





















          Sign in
        






 



























        Product
        


























Actions

        Automate any workflow
      
















Packages

        Host and manage packages
      
















Security

        Find and fix vulnerabilities
      
















Codespaces

        Instant dev environments
      
















GitHub Copilot

        Write better code with AI
      
















Code review

        Manage code changes
      
















Issues

        Plan and track work
      
















Discussions

        Collaborate outside of code
      










Explore







      All features

    






      Documentation

    











      GitHub Skills

    











      Blog

    



















        Solutions
        












For







      Enterprise

    






      Teams

    






      Startups

    






      Education

    














By Solution







      CI/CD & Automation

    






      DevOps

    






      DevSecOps

    














Resources







      Learning Pathways

    











      White papers, Ebooks, Webinars

    











      Customer Stories

    






      Partners

    



















        Open Source
        




















GitHub Sponsors

        Fund open source developers
      


















The ReadME Project

        GitHub community articles
      










Repositories







      Topics

    






      Trending

    






      Collections

    














        Enterprise
        


























Enterprise platform

        AI-powered developer platform
      










Available add-ons
















Advanced Security

        Enterprise-grade security features
      
















GitHub Copilot

        Enterprise-grade AI features
      
















Premium Support

        Enterprise-grade 24/7 support
      














Pricing


























Search or jump to...
















Search code, repositories, users, issues, pull requests...




 









        Search
      




























Clear


 
































































































 









              Search syntax tips

 





























        Provide feedback
      




















 


We read every piece of feedback, and take your input very seriously.






Include my email address so I can be contacted






 
    Cancel



    Submit feedback




















        Saved searches
      


Use saved searches to filter your results more quickly




















 












Name














Query







            To see all available qualifiers, see our 
documentation
.
          


 












 
    Cancel



    Create saved search
















              Sign in
            





              Sign up
            




















You signed in with another tab or window. 
Reload
 to refresh your session.


You signed out in another tab or window. 
Reload
 to refresh your session.


You switched accounts on another tab or window. 
Reload
 to refresh your session.


 






Dismiss alert







































        SkalskiP

 


/




courses




Public












 




Notifications

 
You must be signed in to change notification settings






 




Fork
    
418










 





          Star

 
4.6k


 
 

























        This repository is a curated collection of links to various courses and resources about Artificial Intelligence (AI)
      












4.6k

          stars

 








418

          forks

 








Branches


 








Tags


 








Activity


 








 





          Star



 
 












 




Notifications

 
You must be signed in to change notification settings




























Code
















Issues


3














Pull requests


6














Discussions
















Actions
















Projects


0














Security
















Insights








 




 






Additional navigation options






 





















          Code




















          Issues




















          Pull requests




















          Discussions




















          Actions




















          Projects




















          Security




















          Insights











 












SkalskiP/courses
















This commit does not belong to any branch on this repository, and may belong to a fork outside of the repository.








 














































 
 
 
 
master
Branches
Tags
Go to file
Code
Folders and files
Name
Name
Last commit message
Last commit date
Latest commit
 
History
94 Commits
automation
automation
 
 
.gitignore
.gitignore
 
 
CONTRIBUTING.md
CONTRIBUTING.md
 
 
README.fr.md
README.fr.md
 
 
README.hi.md
README.hi.md
 
 
README.id.md
README.id.md
 
 
README.it.md
README.it.md
 
 
README.md
README.md
 
 
pull_request_template.md
pull_request_template.md
 
 
View all files
Repository files navigation
README


crème de la crème of AI courses




English
 | 
Hindi
 | 
Italiano
 | 
French
 | 
Indonesian




👋 hello


This repository is a curated collection of links to various courses and resources about Artificial Intelligence (AI). Whether you're a beginner or an experienced learner, there's something here for everyone!


👀 looking for ideas


I am looking for a good free course on statistics, linear algebra, integrals and derivatives that could be a good mathematical training for people who want to start a career in ML. I look forward to hearing 
your ideas
!


🧑‍🎓courses & resources








topic


format


difficulty


release year


price


course










Generative AI


GitHub repository


🟩⬜⬜


2023


free


 Generative AI for Beginners
 by  Microsoft






Deep Learning


YouTube playlist


🟩🟩⬜


2023


free


 6.5940 TinyML and Efficient Deep Learning Computing
 by  Massachusetts Institute of Technology






Natural Language Processing


YouTube playlist


🟩🟩⬜


2023


free


 Natural Language Processing
 by  The University of Texas at Austin






Deep Learning


website


🟩⬜⬜


2023


free


Deep Learning Fundamentals - Learning Deep Learning Using a Modern Open-Source Stack
 by  Sebastian Raschka






Large Language Models


YouTube playlist


🟩🟩⬜


2023


free


LLM Bootcamp - Spring 2023
 by  The Full Stack






Python


YouTube playlist


🟩⬜⬜


2023


free


CS50: Introduction to Programming with Python
 by  Harvard University x freeCodeCamp.org






Stable Diffusion and Deep Learning


website


🟩🟩⬜


2023


free


Practical Deep Learning for Coders part 2: Deep Learning Foundations to Stable Diffusion
 by fast.ai






Deep Learning


YouTube playlist


🟩⬜⬜


2023


free


6.S191: Introduction to Deep Learning
 by  Massachusetts Institute of Technology






Deep Learning


YouTube playlist


🟩⬜⬜


2023


free


 Neural Networks: Zero to Hero
 by  Andrej Karpathy






Large Language Models and Prompt Engineering


website


🟩⬜⬜


2023


free


 Prompt Engineering Guide
 by  DAIR.AI






Computer Vision


YouTube playlist


🟩⬜⬜


2023


free


 Computer Vision in Practice
 by  Piotr Skalski x Roboflow






Natural Language Processing


YouTube playlist


🟩🟩⬜


2023


free


 CS685: Advanced Natural Language Processing
 by  University of Massachusetts






Linear Algebra


YouTube playlist


🟩⬜⬜


2022


free


 Linear Algebra for Data Science
 by  Shaina Race






Machine Learning


YouTube playlist


🟩🟩⬜


2022


free


 CS229: Machine Learning
 by  Stanford University






MLOps


YouTube playlist


🟩🟩⬜


2022


free


 Machine Learning Engineering for Production
 by  Andrew Y. Ng






Multimodal Machine Learning


YouTube playlist


🟩🟩🟩


2022


free


11-777: Multimodal Machine Learning
 by  Carnegie Mellon University






Deep Multi-Task and Meta Learning


YouTube playlist


🟩🟩🟩


2022


free


CS330 Deep Multi-Task and Meta Learning
 by  Stanford University






Deep Learning


YouTube playlist


🟩⬜⬜


2022


free


 Practical Deep Learning for Coders
 by  fast.ai






Deep Learning


YouTube playlist


🟩⬜⬜


2021


free


 Neural Networks from Scratch in Python
 by  Sentdex






Natural Language Processing


YouTube playlist


🟩🟩⬜


2021


free


 CS224U: Natural Language Understanding
 by  Stanford University






Transformers


YouTube playlist


🟩🟩🟩


2021


free


CS25: Transformers United
 by  Stanford University






Deep Learning


YouTube playlist


🟩🟩⬜


2021


free


NYU-DLSP21: NYU Deep Learning Spring
 by  New York University






Natural Language Processing and Transformers


website


🟩⬜⬜


2021


free


 NLP Course
 by  Hugging Face






Deep Learning


book


🟩⬜⬜


2021


free


 Dive into Deep Learning
 by d2l.ai






Reinforcement Learning


YouTube playlist


🟩🟩🟩


2021


free


 Reinforcement Learning Course
 by  DeepMind x University College London






Natural Language Processing


YouTube playlist


🟩🟩⬜


2021


free


CS224N: Natural Language Processing with Deep Learning
 by  Stanford University






Deep Learning


YouTube playlist


🟩🟩⬜


2020


free


 Deep Learning Lecture Series
 by  DeepMind x University College London






Linear Algebra


website


🟩🟩🟩


2019


free


Advanced Linear Algebra - Foundations to Frontiers
 by Margaret E. Myers & Robert A. van de Geijn






Artificial Intelligence


Youtube playlist


🟩🟩⬜


2019


free


Stanford CS221: Artificial Intelligence: Principles and Techniques
 by  Stanford University






Computer Vision


Youtube playlist


🟩🟩⬜


2019


free


University of Michigan EECS 498.008 / 598.008: Deep Learning for Computer Vision
 by University of Michigan






Computer Vision


YouTube playlist


🟩🟩⬜


2018


free


CS231n: Deep Learning for Computer Vision
 by  Stanford University






Statistics and Probability


YouTube playlist


🟩⬜⬜


2013


free


 Statistics 110: Probability
 by  Harvard University








🦸 contribution


We would love your help in making this repository even better! If you know of an amazing AI course that isn't listed
here, or if you have any suggestions for improvement, feel free to open an

issue
 or submit a

pull request
. If you feel up to the task, please take a peek at our

contribution guide
.


Together, let's make this the best AI learning hub on GitHub! 🚀


 
 
 


















About



        This repository is a curated collection of links to various courses and resources about Artificial Intelligence (AI)
      


Topics







  nlp




  machine-learning




  natural-language-processing




  tutorial




  deep-neural-networks




  computer-vision




  deep-learning




  transformers




  generative-model




  multimodal




  mlops




  stable-diffusion







Resources











        Readme

 
















Activity


 


Stars












4.6k

      stars

 


Watchers












83

      watching

 


Forks












418

      forks

 





          Report repository

 



























    Contributors
      
14




























































































































































Languages






















Python


100.0%
































Footer

















        © 2024 GitHub, Inc.
      






Footer navigation






Terms






Privacy






Security






Status






Docs






Contact









      Manage cookies
    











      Do not share my personal information
    

































    You can’t perform that action at this time.
  

























