

















📥  Last added | Reader



















































              Readwise
            



              Reader
            






Sign up
















LA


Bundled by Ludwig ABAP


📥  Last added


Saved in the past week and not yet archived (default view)


Open in Reader ->








What's included












The borrow checker within












·


smallcultfollowing.com


·


12 mins




















How should I read type system notation?












·


Alexis King


·


9 mins














Writing a Simple Garbage Collector in C












·


Matthew Plant


·


16 mins














A decade of developing a programming language












·


yorickpeterse.com


·


11 mins














The Rust I Wanted Had No Future












·


dreamwidth.org


·


12 mins














The Garbage Collection Handbook












·


gchandbook.org


·


2 mins




















A high-bias, low-variance introduction to Machine Learning for
  physicists












·


Pankaj Mehta, Marin Bukov, Ching-Hao Wang, Alexandre G. R. Day, Clint Richardson, Charles K. Fisher, David J. Schwab


·


5 hrs 7 mins




















How diffusion models work: the math from scratch












·


Nikolas Adaloglou


·


15 mins




















essentials-of-compilation












·




·


2 hrs 12 mins














PRACTICAL COMPILER CONSTRUCTION












·


t3x.org


·


1 min




















DoctorWkt/acwj












·


DoctorWkt


·


3 mins














A Distributed Systems Reading List












·


dancres.github.io


·


4 mins














An Introduction to Assembly Programming with RISC-V












·


riscv-programming.org


·


20 mins




















Microsoft PowerPoint - SRAM Architecture












·


vishalsaxena


·


4 mins




















MLIR: A Compiler Infrastructure for the End of Moore's Law












·


Chris Lattner, Mehdi Amini, Uday Bondhugula, Albert Cohen, Andy Davis, Jacques Pienaar, River Riddle, Tatiana Shpeisman, Nicolas Vasilache, Oleksandr Zinenko


·


45 mins














MLIR — Getting Started












·


Math ∩ Programming


·


10 mins














Chapter 2 Basics of SIMD Programming












·


cvut.cz


·


35 mins




















Matrix multiplication in Mojo












·


modular.com


·


8 mins














Matrix Multiplication on CPU












·


Marek Kolodziej


·


25 mins




















How to Optimize a CUDA Matmul Kernel for cuBLAS-like Performance: a Worklog












·


Simon Boehm


·


24 mins














The Annotated Transformer












·


Harvard University Gazette


·


25 mins




















Anonymity and the internet












·


What's new


·


3 mins




















Auto-Regressive Next-Token Predictors are Universal Learners












·


Eran Malach


·


31 mins




















Where Vim Came From












·


twobithistory.org


·


11 mins




















Building and operating a pretty big storage system called S3












·


Dr Werner Vogels - https://www.allthingsdistributed.com/


·


24 mins














Unnamed Document












·


openreview.net




















How Good Are Low-bit Quantized LLaMA3 Models? An Empirical Study












·


Wei Huang, Xudong Ma, Haotong Qin, Xingyu Zheng, Chengtao Lv, Hong Chen, Jie Luo, Xiaojuan Qi, Xianglong Liu, Michele Magno


·


10 mins




















LADW_2017-09-04












·




·


5 hrs 59 mins




















New Scaling Laws for Large Language Models












·


lesswrong.com


·


6 mins




















Binary Magic: Building BitNet 1.58bit Using PyTorch from Scratch












·


Chidhambararajan R


·


4 mins




















king - man + woman is queen; but why?












·


Piotr Migdał


·


7 mins




















How Good Are Low-bit Quantized LLaMA3 Models? An Empirical Study












·


Wei Huang, Xudong Ma, Haotong Qin, Xingyu Zheng, Chengtao Lv, Hong Chen, Jie Luo, Xiaojuan Qi, Xianglong Liu, Michele Magno


·


10 mins




















1-bit Model












·


mobiusml.github.io


·


6 mins














Human Knowledge Compression Contest












·


Marcus Hutter


·


37 mins




















Heatmaps and CNNs Using Fast.ai












·


Fritz


·


7 mins




















Where do LLMs spend their FLOPS?












·


Finbarr Timbers


·


7 mins




















The Annotated Diffusion Model












·


huggingface.co


·


21 mins




















Defusing Diffusion Models












·


pawel


·


17 mins














The Illustrated Stable Diffusion












·


Jay Alammar


·


9 mins




















Mamba-UNet: UNet-Like Pure Visual Mamba for Medical Image Segmentation












·


Ziyang Wang, Jian-Qing Zheng, Yichi Zhang, Ge Cui, Lei Li


·


13 mins




















Sparse Autoencoders Find Highly Interpretable Features in Language Models












·


arXiv.org


·


1 min














KAN: Kolmogorov–Arnold Networks












·


James Halverson


·


1 hr 5 mins




















KAN: Kolmogorov-Arnold Networks












·


Ziming Liu, Yixuan Wang, Sachin Vaidya, Fabian Ruehle, James Halverson, Marin Soljačić, Thomas Y. Hou, Max Tegmark


·


1 hr 14 mins




















Structure and Interpretation of Computer Programs, 2nd ed.












·


Harold Abelson, Gerald Jay Sussman, Julie Sussman


·


11 hrs 51 mins




















OpenELM: An Efficient Language Model Family with Open-source Training
  and Inference Framework












·


Sachin Mehta, Mohammad Hossein Sekhavat, Qingqing Cao, Maxwell Horton, Yanzi Jin, Chenfan Sun, Iman Mirzadeh, Mahyar Najibi, Dmitry Belenko, Peter Zatloukal, Mohammad Rastegari


·


21 mins




















þÿAn Infinitely Large Napkin












·


þÿEvan Chen


·


20 hrs 16 mins














IEEE Xplore Full-Text PDF:












·






















Root Mean Square Layer Normalization












·


Biao Zhang, Rico Sennrich


·


25 mins




















Root Mean Square Layer Normalization












·


Biao Zhang, Rico Sennrich


·


25 mins




















Terry A. Davis












·


wikipedia.org


·


13 mins




















Pattern Recognition and Machine Learning












·


Christopher M. Bishop


·


17 hrs 5 mins




















Ludwig Wittgenstein: The Duty of Genius












·


Ray Monk


·


15 hrs 31 mins




















Generative Agents: Interactive Simulacra of Human Behavior












·


Joon Sung Park, Joseph C. O'Brien, Carrie J. Cai, Meredith Ringel Morris, Percy Liang, Michael S. Bernstein


·


1 hr 13 mins




















Three Decades of Activations: A Comprehensive Survey of 400 Activation
  Functions for Neural Networks












·


Vladimír Kunc, Jiří Kléma


·


3 hrs 52 mins




















Revisiting Deep Learning as a Non-Equilibrium Process












·


Carlos E. Perez


·


7 mins




















Dissipative Adaptation: The Origins of Life and Deep Learning












·


Carlos E. Perez


·


7 mins




















A Gentle Introduction to LLVM IR












·


mcyoung.xyz


·


24 mins














Re: [Fis] A PROPOSAL ABOUT THE DEFINITION OF INFORMATION












·


Sungchul Ji


·


11 mins




















The Art of Embeddings: Transforming Text for Vector Databases (Part 2)












·


David Gutsch


·


11 mins




























AI Art Explained: How AI Generates Images (Stable Diffusion, Midjourney, and DALLE)












·


Jay Alammar


·


28:46




















Parameter-Efficient Sparsity Crafting from Dense to Mixture-of-Experts
  for Instruction Tuning on General Tasks












·


Haoyuan Wu, Haisheng Zheng, Zhuolun He, Bei Yu


·


26 mins














(222) Intro to Deep Learning and Generative Models Course - YouTube












·






















þÿThe Little Book of Deep Learning












·


þÿFrançois Fleuret


·


1 hr 12 mins














Information












·


ucr.edu


·


12 mins




















Sequence to Sequence Learning with Neural Networks












·


Ilya Sutskever, Oriol Vinyals, Quoc V. Le


·


21 mins




















The Era of 1-bit LLMs: All Large Language Models are in 1.58 Bits












·


Shuming Ma, Hongyu Wang, Lingxiao Ma, Lei Wang, Wenhui Wang, Shaohan Huang, Li Dong, Ruiping Wang, Jilong Xue, Furu Wei


·


13 mins




















Latent Interfaces












·


Ian Johnson


·


5 mins














Hypercomputation












·


wikipedia.org


·


13 mins




















New paper on whether LLMs think in English (Wendler et...












·


Owain Evans


·


1 min




















The Era of 1-bit LLMs: All Large Language Models are in 1.58 Bits












·


huggingface.co


·


1 min




















How Netflix Really Uses Java












·


Paul Bakker


·


30 mins














Scheduling Internals












·


tontinton.com


·


20 mins




















Glossary of Deep Learning: Word Embedding












·


Jaron Collis


·


5 mins




















gemini_v1_5_report












·




·


1 hr 26 mins




















How to Use t-SNE Effectively












·


Martin Wattenberg


·


8 mins




















Temperature as Joules per Bit












·


Charles Alexandre Bédard, Sophie Berthelette, Xavier Coiteux-Roy, Stefan Wolf


·


17 mins




















Consciousness, Cognition and the Neuronal Cytoskeleton – A New Paradigm Needed in Neuroscience












·


Frontiers


·


45 mins




















OpenMEA: Open-Source Microelectrode Array Platform for Bioelectronic Interfacing












·


gerar


·


38 mins














Landauer's principle












·


wikipedia.org


·


6 mins














Bremermann's limit












·


wikipedia.org


·


3 mins




















Bekenstein bound












·


wikipedia.org


·


9 mins




















numerical_recipes












·




·


30 hrs 6 mins




















Temperature as Joules per Bit












·


Charles Alexandre Bédard, Sophie Berthelette, Xavier Coiteux-Roy, Stefan Wolf


·


17 mins














Deep Learning Course












·


fleuret.org


·


5 mins




















Memory in Plain Sight: A Survey of the Uncanny Resemblances between
  Diffusion Models and Associative Memories












·


Benjamin Hoover, Hendrik Strobelt, Dmitry Krotov, Judy Hoffman, Zsolt Kira, Duen Horng Chau


·


44 mins




















2309.10668












·




·


29 mins




















Memory in Plain Sight: A Survey of the Uncanny Resemblances between Diffusion Models and Associative Memories












·


arXiv.org


·


1 min




















tns












·




·


7 hrs 10 mins




















A New Physics Theory of Life












·


Natalie Wolchover


·


9 mins




















K-Level Reasoning with Large Language Models












·


arXiv.org


·


1 min




















Competitive Programmer's Handbook












·


cses.fi


·


4 hrs 29 mins














Writing an OS in Rust












·


phil-opp.com


·


4 mins














Ever wanted to make your own programming language or wondered how they are designed and built?












·


craftinginterpreters.com


·


2 mins




















sst/demo-ai-app












·


sst


·


2 mins




















ThermodynamicComputing












·




·


57 mins




















Measuring Faithfulness in Chain-of-Thought Reasoning












·


arXiv.org


·


1 min




















Links :












·


Dr Milan Milanović


·


1 min




















ageron/handson-ml3












·


GitHub


·


3 mins




















It took me 5 years to master all 24 of...












·


🔥 Matt Dancho (Business Science) 🔥


·


1 min




















Images are super redundant












·


François Fleuret


·


1 min




















Sentence-BERT: Sentence Embeddings using Siamese BERT-Networks












·


arXiv.org


·


1 min




















Turing-1951 Intelligent Machinery-a Heretical Theory












·


rauterberg.employee.id.tue.nl


·


9 mins




















Self-Rewarding Language Models












·


arXiv.org


·


1 min




















Software Development Trends 2023/2024 - Vol. 2.












·


Dr Milan Milanović


·


7 mins














Word2vec from Scratch












·


Jake Tae


·


15 mins




















MemGPT: Towards LLMs as Operating Systems












·


Charles Packer, Vivian Fang, Shishir G. Patil, Kevin Lin, Sarah Wooders, Joseph E. Gonzalez


·


31 mins




















Visual Guides to understand the basics of Large Language Models












·


Parul Pandey


·


2 mins




















Understanding and Coding Self-Attention, Multi-Head Attention, Cross-Attention, and Causal-Attention in LLMs












·


Sebastian Raschka


·


20 mins














Thinking in Systems: International Bestseller: Donella H. Meadows, Diana Wright: 9781603580557: Amazon.com: Books












·


amazon.com


·


4 mins




















Sleeper Agents: Training Deceptive LLMs that Persist Through Safety
  Training












·


Evan Hubinger, Carson Denison, Jesse Mu, Mike Lambert, Meg Tong, Monte MacDiarmid, Tamera Lanham, Daniel M. Ziegler, Tim Maxwell, Newton Cheng, Adam Jermyn, Amanda Askell, Ansh Radhakrishnan, Cem Anil, David Duvenaud, Deep Ganguli, Fazl Barez, Jac...


·


2 hrs 3 mins














This project is about how to systematically persuade LLMs to jailbreak them.












·


chats-lab.github.io


·


5 mins




















Pruning vs Quantization: Which is Better?












·


Andrey Kuzmin, Markus Nagel, Mart van Baalen, Arash Behboodi, Tijmen Blankevoort


·


29 mins




















mlx-examples












·


ml-explore


·


3 mins




















Mixtral of Experts












·


Timothée Lacroix


·


1 min




















Paper page - Self-Play Fine-Tuning Converts Weak Language Models to Strong Language
  Models












·


huggingface.co


·


1 min




















From LLM to Conversational Agent: A Memory Enhanced Architecture with Fine-Tuning of Large Language Models












·


Na Liu, Liangyu Chen, Xiaoyu Tian, Wei Zou, Kaijiang Chen, Ming Cui


·


35 mins




















WikiChat: Stopping the Hallucination of Large Language Model Chatbots by Few-Shot Grounding on Wikipedia












·


Sina J. Semnani, Violet Z. Yao, Heidi C. Zhang, Monica S. Lam


·


57 mins




















Discovering Language Model Behaviors with Model-Written Evaluations












·




·


1 hr 48 mins




















Getting Started with Elastic Stack 8.0












·




·


4 hrs 49 mins




















Understanding The Exploding and Vanishing Gradients Problem












·


Seb


·


5 mins




















Practical Deep Learning for Coders 2022












·


fast.ai


·


7 mins




















The fastai book, published as Jupyter Notebooks












·


GitHub


·


2 mins




















Elasticsearch 8.x Cookbook: Over 180 recipes to perform fast, scalable, and reliable searches for your enterprise, 5th Edition












·


Xin Rong


·


24 mins














Attention? Attention!












·


lilianweng.github.io


·


13 mins




















An Intuition for Attention












·


Jay Mody


·


8 mins




















Pen and Paper Exercises in Machine Learning












·


Michael U. Gutmann


·


1 min














Transformers From Scratch












·


Mat Miller


·


1 min




















Mathematics for Machine Learning












·


þÿMarc Peter Deisenroth, A. Aldo Faisal, Cheng Soon Ong


·


8 hrs 42 mins




















Linear Algebra Review and Reference












·




·


33 mins














 Probability and InformationTheory












·


deeplearningbook.org


·


28 mins














Linear Algebra












·


deeplearningbook.org


·


21 mins




















Mathematics for Machine Learning












·


þÿMarc Peter Deisenroth, A. Aldo Faisal, Cheng Soon Ong


·


8 hrs 42 mins




















An overview of gradient descent optimization algorithms












·


Sebastian Ruder


·


22 mins




















An overview of gradient descent optimization algorithms∗












·


Sebastian Ruder


·


22 mins














How GPT3 Works - Visualizations and Animations












·


Jay Alammar


·


3 mins




















GPT in 60 Lines of NumPy












·


Jay Mody


·


34 mins




















Tensor2Tensor Intro












·


Google Brain team


·


1 min














The Annotated Transformer












·


Harvard University Gazette


·


13 mins














The Illustrated Transformer












·


Jay Alammar


·


15 mins




















Neural Machine Translation (seq2seq) Tutorial












·


tensorflow


·


25 mins




















What Are Word Embeddings for Text?












·


Jason Brownlee


·


8 mins




















Deep Learning for Natural Language Processing












·


Ian Clark


·


8 mins














Visualizing A Neural Machine Translation Model (Mechanics of Seq2seq Models With Attention)












·


Jay Alammar


·


6 mins




















The Random Transformer












·


osanseviero.github.io


·


2 mins




















SkalskiP/courses












·


SkalskiP


·


3 mins














Stanford CS25 - Transformers United - YouTube












·


m.youtube.com




















CS25: Transformers United V3












·


Stanford CS25


·


5 mins




























(A Brief Video Overview of) Neural Circuit Diagrams












·


vtabbott


·


07:41




















Spaces using openai/whisper-large-v2 232












·


huggingface.co


·


6 mins




















Text Summarization: How to Calculate BertScore












·


Hatice Özbolat


·


4 mins




















Some Core Principles of Large Language Model (LLM) Tuning












·


Subrata Goswami


·


23 mins




















MotionGPT: Human Motion as a Foreign Language












·


Biao Jiang, Xin Chen, Wen Liu, Jingyi Yu, Gang Yu, Tao Chen


·


37 mins




















VideoPoet












·


VideoPoet – Google Research


·


3 mins




















LangChain












·


langchain.com


·


1 min




















An intuitive introduction to text embeddings












·


Kevin Henner


·


12 mins




























Watching Neural Networks Learn












·


Emergent Garden


·


25:27




















Mathematics for Machine Learning












·


Garrett Thomas


·


58 mins




























What is backpropagation really doing? | Chapter 3, Deep learning












·


3Blue1Brown


·


12:47




















Generative Agents: Interactive Simulacra of Human Behavior












·


Joon Sung Park, Joseph C. O'Brien, Carrie J. Cai, Meredith Ringel Morris, Percy Liang, Michael S. Bernstein


·


1 hr 13 mins




















VOYAGER: An Open-Ended Embodied Agent with Large Language Models












·


Guanzhi Wang, Yuqi Xie, Yunfan Jiang, Ajay Mandlekar, Chaowei Xiao, Yuke Zhu, Linxi Fan, Anima Anandkumar


·


1 hr 6 mins




















Can we align LLMs to honesty via instruction finetuning?












·


Shizhe Diao


·


1 min




















Getting Started with Reader












·


Daniel Doyon


·


7 mins


















Experience the future of reading


Get started for free (beta)



          For web, desktop, iOS, and Android.
        
























Sign up


Create an account to continue








Sign up with Email










First Name:
















Email:
















Password:




























Sign up with Email












or





















              Sign up with Amazon




Already have a Readwise account? Sign in






Click "Sign up" above to accept 


Readwise's Terms of Service
 & 
Privacy
              Policy
.


Readwise is free for the first 30 days, 

            after which it costs a small monthly fee.




×
















Welcome back!


Sign in to use your account













            Sign in with Amazon
          








Email:
















Password:














Sign in with Email


Forgot password?








Don't have an account? Sign up




×















