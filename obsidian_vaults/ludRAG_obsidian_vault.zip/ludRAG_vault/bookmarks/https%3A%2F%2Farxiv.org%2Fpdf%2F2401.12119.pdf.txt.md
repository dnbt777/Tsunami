arXiv:2401.12119v1  [quant-ph]  22 Jan 2024Temperature as Joules per Bit
Charles Alexandre B´ edard1, Sophie Berthelette2,
Xavier Coiteux-Roy3, 4, and Stefan Wolf1, 5
1Faculty of Informatics, Universit` a della Svizzera italia na, Lugano, Switzerland
2D´ epartement de physique, Universit´ e de Montr´ eal, Montr´ e al, Canada
3School of Computation, Information and Technology, Techni sche Universit¨ at M ¨ unchen
4Munich Center for Quantum Science and Technology (MCQST), Muni ch, Germany
5Facolt` a indipendente di Gandria, Gandria, Switzerland
January 2024
Abstract
Boltzmann’s constant reﬂects a historical misunderstandi ng of the concept of
entropy, whose informational nature is obfuscated when exp ressed in J/K. We
suggest that the development of temperature and energy, his torically prior to
that of entropy, does not amount to their logical priority: T emperature should
be deﬁned in terms of entropy, not vice versa. Following the pr ecepts of in-
formation theory, entropy is measured in bits, and coincide s with information
capacity at thermodynamic equilibrium. Consequently, not only is the tem-
perature of an equilibrated system expressed in J/bit, but it acquires an opera-
tional meaning: It is the cost in energy to increase its infor mation capacity by
1 bit. Our proposal also supports the notion of available capacity , analogous to
free energy. Finally, it simpliﬁes Landauer’s cost and clari ﬁes that it is a cost
ofdisplacement , not of erasure.
1 A Historical Artifact
“Careful, that’s hot!” Temperature is one of the most intuitive physical concepts,
as we can vividly feel it through our skin. Arguably, temperature is more in-
tuitive than energy ; and deﬁnitely more than entropy . Perhaps unsurprisingly,
the historical development of the three concepts has also fo llowed that order.
The ﬁrst thermometers were built in the 17thcentury, by the end of which
some precursor of kinetic energy, the so-called vis viva , was introduced by
Leibniz [1]. As Young [2] coined the term energy at the beginn ing of the 19th
century, its existence in various forms is quickly realized . Notably, in 1824,
Carnot [3] studied engines that could use energy of the caloric type to produce
energy of the work type. Clausius [4] then characterized the form of energy
that is inevitably lost during a thermodynamical cycle in su ch engines. Only
then did he introduce entropy as ∆S=Q/T , whereQis the amount of heat
entering or escaping the system and Tis the absolute temperature of the sys-
tem. This tortuous path to entropy explains why it carries th e units of joules
per kelvin, which, still today, prevail as the units of entro py; they are the ones
advocated by the International System of Units.
Boltzmann’s approach [5] to entropy, measured as the logari thm of the
number of microstates in a given macroscopic description of a system, can
be thought of as the ﬁrst proposal to identify entropy with an i nformation-
theoretic measure of capacity. If all the microstates compa tible with the macro-
scopic description are assumed to be possible, and if the log arithm is taken in
base 2, Boltzmann’s entropy is a measure of capacity which is operationally
identiﬁed with the maximum number of bits that can be stored in the system.
Similar to the memory capacity of computing devices, it can b e measured in
bits. Boltzmann’s entropy is a priori very remote from joule s per kelvin, yet,
in order to make it consistent with Clausius’ deﬁnition, Plan ck rescaled it by
a constant kBthat carries the units of J/K. We suggest that the introduction
of this constant is unnecessary and prevents a clear and cris p understanding
of entropy, namely, one that is compatible not only with stea m engines but
with any manipulation of thermodynamic systems, including those that are
information-theoretic in nature.
To think of entropy as joules per kelvin is thus merely a histo rical artifact,
which introduces into our view of entropy all the parochial d ependencies en-
compassed in the development of the Kelvin scale. For instanc e, this includes
the aggregate behaviour of water and the number 100 — and with it, our
physiology: the number of our ﬁngers. Furthermore, expressi ng entropy as
such misleadingly signals that entropy must be deﬁned in term s of tempera-
ture. But this is true only for the historically ﬁrst notion of entropy, which,
as groundbreaking as it was, cannot be expected to arise in it s ﬁnal form —
the existence of atoms was still unknown, let alone quantum t heory and in-
formation theory. The chronological discovery of ideas doe s not amount to
their logical priority: We suggest seeing entropy as a more f undamental con-
cept than temperature and, following the modern informatio n-theoretic view,
measuring entropy in bits, i.e., inbasic information uni t.
The signiﬁcant role of information in thermodynamics is emph asized in
the following section, which motivates the information-th eoretic account of
entropy. As explained in Section 3, at thermodynamic equili brium, entropy
amounts to information capacity. In Section 4, we show how te mperature
arises as a bridge between energy and information capacity, and how it ac-
quires an operational meaning. Not only does it yield a notio n of unused
capacity completely analogous to free energy, but it also sh eds light on Lan-
dauer’s erasure.
2
2 Information in Thermodynamics
Crucial insights and results were borne by bringing informa tion-processing
considerations into the picture of thermodynamics. For mod ern reviews, see
Refs [6, 7]. A serious challenge to the second law was propose d by Maxwell [8,
9, 10] with his famous demon who sorts a system via measuremen ts and ma-
nipulations, thereby reducing its entropy. Szilard’s engi ne [11] has become the
canonical system on which a demon is imagined to perform its p uzzling ma-
nipulations. It consists of a one-molecule gas container th at can be bisected
by a partition, which thereupon acts as a bidirectional pist on. After insert-
ing the partition, the demon observes on which side the molec ule is trapped,
and then expands adiabatically the piston in the opposite di rection. This ex-
tractskBTln2 J of free energy from the molecule. After thermalization with
the environment, the process can be repeated, ifthe demon has kept his abil-
ity to measure and act on the system. Szilard suggested that t he second law
should be saved by the act of measurement of the demon, which, he thought,
should unavoidably create kBTln2 J of heat, namely, just enough to compen-
sate. The idea to tie a thermodynamic cost to the act of measur ement per se has
been followed by many [12, 13, 14], and was likely stimulated by the confusion
that arose with measurement in quantum theory.
In 1961, Landauer [15] correctly identiﬁed information eras ure — and not
measurement — as the precise thermodynamically irreversib le step which needs
to be compensated by heat dissipation. The erasure of one bit of information
must be accompanied by kBTln2 J of free energy lost to the environment, or
to the non-information-bearing degrees of freedom of a comp uter. The rea-
son for heat dissipation is purely physical: Information ca nnot be processed
independently of real devices, or as Landauer would have it, “information is
physical .”
The fact that erasure has a thermodynamic cost does not a priori preclude
measurement from also having such a cost. This concern was pa rt of the
larger misconception which held that computing devices sho uld unavoidably
involve logical irreversibility, and, with it, heat dissip ation. Upon demonstrat-
ing that universal computation can be done via logically rev ersible steps, Ben-
nett [16] paved the way for developing thermodynamically re versible mod-
els of computation; the most spectacular of which is perhaps Fredkin and
Toffoli’s ballistic computer [17]. In this light, the statu s of measurement has
been clariﬁed [18]: An apparatus initialized in a ready state can measure non-
dissipatively. This yields a detailed and satisfactory res olution of Maxwell’s
problem: With an initialized memory, the demon canmeasure the system and
act on it to reduce its entropy. But this is no paradox, as it me rely displaces
the entropy of the system onto the demon’s memory. To operate in a cycle, the
demon needs to get rid of the information stored — an erasure w hich, by Lan-
dauer’s bound, dissipates a quantity of heat greater or equa l to the entropy
reduction of the system times the environmental temperatur e.
The logical reversibility of dynamical laws applies to all p hysical systems,
3
including those with the ability to store information and ac t based on it. Information-
processing agents cannot avoid the second law. Yet, the poin t of view of infor-
mation processing has offered information-theoretic limi ts to what can or can-
not be done, thermodynamically. In particular, Landauer’s erasure cost can
be considered one of the many expressions of the second law, w hich, as elo-
quently stated by Schumacher [19], mandates that “No physic al process has
as its sole result the erasure of information.”
The resolution of Maxwell’s demon has been highly inﬂuential in promot-
ing the role of information theory in thermodynamics. The sc ientiﬁc literature
on the topic has been booming and ramifying in many ways. The a dvent of
Shannon’s mathematical theory of communication [20] gener ated insights [21,
22, 23] (and debates [24, 25]). Algorithmic information the ory [26, 27, 28] per-
mits a quantiﬁcation of information based on individual obje cts, yielding more
sophisticated notions of entropy [29, 30] and macrostates [ 31]. The signiﬁcance
of quantum information was realized [32, 33, 34, 35] and inco rporated into var-
ious thermodynamical analyses [36, 37, 38, 39, 40, 41]. And a xiomatic recon-
structions of thermodynamics have been suggested [42, 43, 4 4].
This work is part of the program of modernizing thermodynami cs — of
cleaning the soot out of its steam pipe origins. We consider p hysics and in-
formation theory to be both embodied in thermodynamics, rep resented by
energy and entropy, respectively. Temperature arises as th e bridge between
them. Our suggestion is simple: Entropy, not temperature, d eserves a unit of
its own. Yet, it is potentially transformative, for it genui nely suggests a modi-
ﬁcation to the International System of Units and a dissolutio n of Boltzmann’s
constant, which reduces to unity the countless “ kBln2”s found in thermody-
namics. That simpliﬁcation arises not by mathematical conve nience, but rather
by integrating information into physics.
3 Thermodynamic Equilibrium: Entropy as In-
formation Capacity
Energy is a fundamental physical quantity whose conservati on principle has
both permitted signiﬁcant theoretical advancements and res isted to severe ex-
perimental tests. In a conversation about thermodynamics, we shall be satis-
ﬁed with its SI unit, the joule ( J), itself expressed in terms of the second, the
meter, and the kilogram. However, in Section 1, we express ou r dissatisfaction
with the SI unit of entropy as measured in J/Kand advocate instead for the
information-theoretic view of entropy, measured in bits. Ma ny such entropy
measures have been proposed, most of which are operationall y tied to bits.
For instance, Shannon entropy H(X)is the expected number of bits required
to communicate the outcome of a random variable Xin an optimal preﬁx code.
More convoluted measures were proposed, yet, for our purpose s, we step back
on what is perhaps the simplest: information capacity.
4
The information capacity S(E)of a system at a given energy Eis quantiﬁed
by
S(E) = log2Ω(E)bits,
whereΩ(E)is the number of possible conﬁgurations a system at energy Ecan
adopt, and a bit is the capacity of a 2-level system. The logar ithm of a mi-
crostate count that corresponds to a given constraint is the gist of Boltzmann’s
entropy. By using the base 2instead of the natural logarithm1, and prefactor-
ing it by1bit instead of kB, we obtain a measure of capacity in bits, correspond-
ing to a given energy E. Information capacity is a counterfactual property of
the system, namely, an assessment of all the conﬁgurations in which the sys-
tem could be , and it does not depend on the system’s actual conﬁguration. N or
does it depend on any probabilistic assessment, thereby avo iding the question
of subjectivity and agent dependency.
Like a distance in space measured by the number of meters that can ﬁt in
that space, the capacity of a system is measured by the number of bits that can
ﬁt in that system. Operationally, S(E)is the number of bits required to label
all distinguishable states at energy E, or equivalently, the number of bits that
can be encoded in the system if it is seen as a storage resource .
In modern days, it has become second nature to quantify the st orage ca-
pacity of devices in bits. In a similar way, any physical syst em can be viewed
as an information-storage system. Compared to the memory of a computing
device that has been engineered to be stable in some relevant set of environ-
ments, a generic physical system has microstates which, for all practical pur-
poses, cannot be prepared nor maintained in any chosen conﬁgu ration. De-
spite this technological (but not fundamental) impractica lity for user interplay,
it remains that information can be encoded in physical syste ms, a quantity
which is bounded by its information capacity. The assumptio n of thermody-
namic equilibrium amounts to viewing a system’s entropy as m aximal and,
therefore, reaching its full capacity2.
4 Temperature as Joules per Bit
In this Section, we develop the logical implication that tem perature is better
understood as J/bit. The information capacity Sis a function of its internal
energyE, which can be inverted into a function E(S). As with the usual statis-
tical mechanical deﬁnition of temperature, Tis obtained as the slope ∂E/∂S
between energy and information capacity. Therefore, with e ntropy measured
1A valid defence of the natural logarithm is its convenience w hen the machinery of differen-
tial calculus is used to elaborate the theory. While true, th is is easily resolved by the conver-
sionlog2Ω(E)bits= lnΩ(E)nat, where the nat is the natural unit of information.
2The fact that a system at maximal entropy saturates its capac ity can be easily recognized when
quantifying entropy in the probabilistic setting: In this c ase, the Gibbs–Shannon entropy S(ρ) =
−/summationtextΩ(E)
i=1pilog2piof a distribution ρover a conﬁguration space of Ω(E)possible values is maximal
for the uniform distribution, and is then equal to the capaci ty.
5
in bits, temperature is in J/bit. Note that the insistence on having entropy in
terms of temperature ( e.g.inJ/K) yields a blatant circularity for those relying
on a statistical mechanical temperature. For instance, whe ndeﬁning tempera-
ture, Schroeder [45] justiﬁes the survival of the kelvin by: “ Thanks to the factor
of Boltzmann’s constant in the deﬁnition of entropy, the slop e∂S/∂E of a sys-
tem’s entropy vs. energy graph has the units of (J/K)/J = 1/K. If we take the
reciprocal of this slope, we get something with units of kelv ins, just what we
want for temperature.”
Non-exotic systems are of positive temperature and positiv e heat capacity,
yielding both positive ﬁrst and positive second derivatives ofEwith respect
toS, as displayed in Figure 1.1. In thermodynamic contexts, whe re large sys-
tems are concerned, 1bit is small compared to the relevant scale of the energy
vs capacity graphs, and the operational meaning of the tempe rature of a sys-
tem can be made clear.
Energy (E)
Information capacity ( S)∆S∆E
(1)Systems usually have a concave up
shape.
Energy (E)
Information capacity ( S)
(2)A heat bath is a linear idealization.
Figure 1: Graphs of energy vs capacity.
Operational deﬁnition of temperature: it is the increase in internal energy (in J)
required to increase the information capacity by 1bit.
Temperature as such is independent of an a priori notion of heat baths , which
instead can be understood in terms of systems whose E(S)function is of con-
stant slope, namely, of constant temperature, as displayed in Figure 1.2. Such
systems can be thought of as idealizations of very large syst ems or, in fact,
close-ups of some E(S)function, which then appears to be linear. The en-
ergy cost to increase the information capacity of a heat bath at temperature T
byxbits isxTJ. However, for systems that are not well approximated by
a heat bath, the energy cost for an additional xbits need not be linear: The
energy cost must be integrated over the interval of increase d information ca-
pacity.
6
4.1 Available Energy and Capacity
In 1873, Gibbs [46] found out that systems whose entropy is no t maximal have
available energy — now known as free energy — as the system can be used to
produce work. This energy is extracted from the system by tra nsforming it
into a state of lower energy, while conserving its entropy, u ntil the capacity
curve is reached. It is thus the amount of energy that can be ex tracted from
the system with no need to store an excess of entropy. See Figu re 2.Energy (E)
Information capacity ( S)Available
energyAvailable
capacity
Figure 2: The point’s coordinates are given by the system’s entropy an d
energy, respectively on the xandyaxes. The red dashed line represents
the available energy while the blue dashed line, the availab le capacity.
In the same breath, Gibbs presents what he calls the capacity for entropy , or
as we like to view it, available capacity3. It is the number of bits that can be
encoded in the system at no extra energy cost. Available capa city quantiﬁes
the amount of structure in the system, like blanks on a tape, o r the empty
registers in the memory of Maxwell’s demon. The view advocate d here, in
which energy and entropy are more fundamental than temperat ure, highlights
well the duality captured by Gibbs between available energy and available
capacity.
Moreover, that duality is also captured by idealized systems that are efﬁ-
cient to store either energy or entropy. A battery is a system designed to keep
the energy available, namely, the internal energy of the sys tem can be changed
with no signiﬁcant changes in entropy. As an example, conside r a weight in a
gravitational ﬁeld. The (potential) energy of the weight can be easily changed
without affecting the information that is encoded in it. Whe n changing the
position of the weight, except for the energy, all the intrin sic properties of the
system are unchanged. Given the interpretation of temperat ure as joules per
3Available capacity is also known by the names negative entropy (Schr¨ odinger [47]) and negen-
tropy (Brillouin [48]).
7
bit, a battery is hot: Its energy can be changed with minimal i nformation pro-
cessing. On the other hand, some systems are efﬁcient for stor ing information
(or entropy) with no energy change — we call them tapes . Degenerate ground
states, or hard disk drives, are instances of those tapes. An empty tape is cold,
since information can be encoded in it at no energy cost.
4.2 Landauer’s “Displacement”
Be it classical or quantum, information processing follows the logical reversibil-
ity of the physical laws of motion. As a consequence, the info rmation (i.e.
entropy) of an isolated system does not decrease spontaneou sly. When consid-
ering the entire universe as one isolated system, the conclu sion is straightfor-
ward: “No information is ever lost.” This statement has been recognized as a
formulation of the second law of thermodynamics [49, 50].
The term “information erasure” is, therefore, a misnomer: I nformation is
never erased as if free energy had the power of fundamental erasure. Rathe r,
information is displaced . If information leaves a system, it moves to its environ-
ment.
The environment, therefore, should be seen as a memory which is itself
described by an energy vs information capacity curve of the s ort shown in
Figure 1. Landauer’s principle then reﬂects a clear operati onal application of
Temperature as Joules per Bit: To accommodate one additiona l bit of informa-
tion, the environment’s capacity must be expanded via a prec ise quantity of
free energy (in joules). By deﬁnition, this quantity is the te mperature Tof the
environment times one bit. No unnecessary kB. No unnecessary ln2.
5 Conclusion
Upon arguing the primality of bits over kelvins, we offer an i nterpretation
of thermodynamics centred on the duality between energy and information.
Temperature arises as the nexus between them, linking joule s to bits.
When a system’s entropy is maximal, its capacity is a useful p roxy for its en-
tropy, as they coincide. The system’s temperature is then op erationally given
by the energy cost to increase the capacity by one bit. When th e system’s en-
tropy is not maximal, it has available energy, or available c apacity, like batter-
ies and tapes do. And viewing the environment as a storage of i nformation is
what explains Landauer’s “displacement”; namely, since a b it is never erased,
the environment’s capacity needs to be increased by one bit t o accommodate
it, which is achieved at the expense of TJ, whereTis the temperature’s value
in joules per bit.
Like energy, which takes very different forms across the man y domains of
physics, information might also be characterized in differ ent ways. Investigat-
ing them and interlinking information-theoretic notions w ith many of the tra-
ditional concepts of thermodynamics is part of the large res earch programme
8
brieﬂy summarized in Section 2.
While the authors are now adept of “temperature as joules/bi t,” they un-
surprisingly do not use these units to discuss the water temp erature when they
go swimming. In fact, most of them still use the Fahrenheit. N evertheless, as
1Kis about 9.57×10−24J/bit, their preferred water temperature would be
around2.87×10−21J/bit.
Acknowledgements
The authors are grateful to Charles H. Bennett, David Deutsc h, Paul Erker,
and Maria Violaris for fruitful discussions and thought-pro voking comments
about earlier versions of this work. The authors also thank J ude the Obscure
for its enlightening atmosphere.
CAB’s work is supported by the Fonds de recherche du Qu´ ebec – Nature
et technologie, the Hasler Foundation, and the Swiss Nation al Science Foun-
dation. XCR and SW acknowledge support from the Swiss Nation al Science
Foundation (SNSF).
References
[1] Gottfried W Leibniz. Specimen dynamicum pro admirandis Naturae
legibus circa corporum vires et mutuas actiones detegendis , et ad suas
causas revocandis. Acta Eruditorum , 4:145–157, 1695.
[2] Thomas Young. A course of lectures on natural philosophy and the mechanical
arts: in two volumes , volume 2. Johnson, 1807.
[3] Sadi Carnot. R´ eﬂexions sur la puissance motrice du feu e t sur les ma-
chines propres ` a d´ evelopper cette puissance. Paris: Bachelier , 1824.
[4] Rudolf Clausius. ¨Uber die bewegende Kraft der W¨ arme und die Gesetze,
welche sich daraus f ¨ ur die W¨ armelehre selbst ableiten las sen. Annalen der
Physik , 155(3):368–397, 1850.
[5] Ludwig Boltzmann. ¨Uber die Beziehung dem zweiten Haubtsatze der
mechanischen W¨ armetheorie und der Wahrscheinlichkeitsr echnung re-
spektive den S¨ atzen ¨ uber das W¨ armegleichgewicht. Wiener Berichte ,
76:373–435, 1877.
[6] Koji Maruyama, Franco Nori, and Vlatko Vedral. Colloquium : The
physics of Maxwell’s demon and information. Reviews of Modern Physics ,
81(1):1–23, 2009.
[7] Juan MR Parrondo, Jordan M Horowitz, and Takahiro Sagawa. Thermo-
dynamics of information. Nature physics , 11(2):131–139, 2015.
[8] James C Maxwell. Theory of heat . Cambridge University Press, 1871.
[9] Harvey S Leff and Andrew F Rex. Maxwell’s demon: entropy, information,
computing . Princeton University Press, 1990.
9
[10] Harvey Leff and Andrew F Rex. Maxwell’s Demon 2 Entropy, Classical and
Quantum Information, Computing . CRC Press, 2002.
[11] Leo Szilard. ¨Uber die Entropieverminderung in einem thermodynamis-
chen System bei Eingriffen intelligenter Wesen. Zeitschrift f¨ ur Physik ,
53(11-12):840–856, 1929.
[12] John Von Neumann. Mathematical foundations of quantum mechanics .
Princeton University Press, 1955.
[13] Denis Gabor. IV light and information. In Progress in optics , volume 1,
pages 109–153. Elsevier, 1961.
[14] Leon Brillouin. Science and information theory . Academic Press, 2ndedition,
1962.
[15] Rolf Landauer. Irreversibility and heat generation in the computing pro-
cess. IBM journal of Research and Development , 5(3):183–191, 1961.
[16] Charles H Bennett. Logical reversibility of computati on. IBM journal of
Research and Development , 17(6):525–532, 1973.
[17] Edward Fredkin and Tommaso Toffoli. Conservative logi c.International
Journal of Theoretical Physics , 21(3-4):219–253, 1982.
[18] Charles H Bennett. The thermodynamics of computation— a review. In-
ternational Journal of Theoretical Physics , 21(12):905–940, 1982.
[19] Benjamin Schumacher. in quantum information and foun-
dations of thermodynamics, ETH Z¨ urich, 9-12 August, 2011,
https://www.video.ethz.ch/conferences/2011/ qiftw11/f9b b6f3d-7461-4971-
8213-2e3ceb48c0ba.html (accessed November 11, 2023) .
[20] Claude E Shannon. A mathematical theory of communicati on. The Bell
System Technical Journal , 27:379–423, 1948.
[21] Edwin T Jaynes. Information theory and statistical mec hanics. Physical
Review , 106(4):620–630, 1957.
[22] Edwin T Jaynes. Information theory and statistical mec hanics. II. Physical
Review , 108(2):171–190, 1957.
[23] Rudolf Hanel, Stefan Thurner, and Murray Gell-Mann. How m ultiplicity
determines entropy and the derivation of the maximum entrop y princi-
ple for complex systems. Proceedings of the National Academy of Sciences ,
111(19):6905–6910, 2014.
[24] Abner Shimony. The status of the principle of maximum en tropy. Syn-
these , 63(1):35–53, 1985.
[25] Tommaso Toffoli. Entropy? Honest! Entropy , 18(7):247, 2016.
[26] Ray J Solomonoff. A formal theory of inductive inferenc e. Part I. Informa-
tion and control , 7(1):1–22, 1964.
[27] Andre¨ ı N Kolmogorov. Three approaches to the quantitat ive deﬁnition
of information. Problemy Peredachi Informatsii , 1(1):3–11, 1965.
10
[28] Gregory J Chaitin. On the length of programs for computi ng ﬁnite binary
sequences. Journal of the ACM , 13(4):547–569, 1966.
[29] Wojciech H Zurek. Algorithmic randomness and physical entropy. Phys-
ical Review A , 40(8):4731, 1989.
[30] Murray Gell-Mann and Seth Lloyd. Effective complexity. I nMurray Gell-
Mann: Selected Papers , pages 391–402. World Scientiﬁc, 2010.
[31] ¨Amin Baumeler and Stefan Wolf. Causality–Complexity–Cons istency:
Can space-time be based on logic and computation? In Time in Physics ,
pages 69–101. Springer, 2017.
[32] Alexander S Holevo. Some estimates for the amount of inf ormation trans-
mittable by a quantum communication channel (in russian). Problemy
Predachi Informacii , 9:3–11, 1973.
[33] Charles H Bennett and Gilles Brassard. Quantum cryptog raphy: Public
key distribution and coin tossing. In International conference on computers,
systems and signal processing , pages 175–179, 1984.
[34] David Deutsch. Quantum theory, the Church–Turing prin ciple and the
universal quantum computer. Proceedings of the Royal Society A. Mathemat-
ical, Physical and Engineering Sciences , 400(1818):97–117, 1985.
[35] Vlatko Vedral. Introduction to quantum information science . Oxford Univer-
sity Press, USA, 2006.
[36] Elihu Lubkin. Keeping the entropy of measurement: Szila rd revisited.
International Journal of Theoretical Physics , 26:523–535, 1987.
[37] Martin B Plenio and Vincenzo Vitelli. The physics of forg etting: Lan-
dauer’s erasure principle and information theory. Contemporary Physics ,
42(1):25–60, 2001.
[38] Wojciech H Zurek. Quantum discord and Maxwell’s demons. Physical
Review A , 67(1):012320, 2003.
[39] L´ ıdia del Rio, Johan ˚Aberg, Renato Renner, Oscar Dahlsten, and Vlatko
Vedral. The thermodynamic meaning of negative entropy. Nature ,
474(7349):61–63, 2011.
[40] Philippe Faist, Fr´ ed´ eric Dupuis, Jonathan Oppenhei m, and Renato Ren-
ner. The minimal work cost of information processing. Nature communi-
cations , 6(1):7669, 2015.
[41] John Goold, Marcus Huber, Arnau Riera, L´ ıdia Del Rio, an d Paul
Skrzypczyk. The role of quantum information in thermodynam -
ics—a topical review. Journal of Physics A: Mathematical and Theoretical ,
49(14):143001, 2016.
[42] Elliott H Lieb and Jakob Yngvason. The physics and mathe matics of the
second law of thermodynamics. Physics Reports , 310(1):1–96, 1999.
[43] Chiara Marletto. Constructor theory of thermodynamics .arXiv preprint
arXiv:1608.02625 , 2016.
11
[44] Austin Hulse, Benjamin Schumacher, and Michael D Westmo reland. Ax-
iomatic information thermodynamics. Entropy , 20(4):237, 2018.
[45] Daniel V Schroeder. An Introduction to Thermal Physics . Addison Wesley,
2000.
[46] Josiah Willard Gibbs. A method of geometrical represen tation of the
thermodynamic properties by means of surfaces. The Collected Works of
J. Willard Gibbs, Ph. D., LL. D , pages 33–54, 1957.
[47] Erwin Schr¨ odinger. What is life?: The physical aspect of the living cell . Cam-
bridge University Press, 1944.
[48] Leon Brillouin. The negentropy principle of informati on. Journal of Ap-
plied Physics , 24(9):1152–1163, 1953.
[49] Stefan Wolf. Second thoughts on the second law. In Adventures Between
Lower Bounds and Higher Altitudes , pages 463–476. Springer, 2018.
[50] ¨Amin Baumeler and Stefan Wolf. Free energy of a general compu tation.
Physical Review E , 100(5):052115, 2019.
12
