







Hypercomputation - Wikipedia
























































































Home












Random












Nearby
















Log in
















Settings
















Donate














About Wikipedia










Disclaimers








































Search


























Hypercomputation










Article






Talk
















Language












Watch












Edit




















Hypercomputation
 or 
super-Turing computation
 is a set of hypothetical 
models of computation
 that can provide outputs that are not 
Turing-computable
. For example, a machine that could solve the 
halting problem
 would be a hypercomputer; so too would one that could 
correctly evaluate every statement
 in 
Peano arithmetic
.

The 
Church–Turing thesis
 states that any "computable" function that can be computed by a mathematician with a pen and paper using a finite set of simple algorithms, can be computed by a Turing machine. Hypercomputers compute functions that a 
Turing machine
 cannot and which are, hence, not computable in the Church–Turing sense.

Technically, the output of a 
random Turing machine
 is uncomputable; however, most hypercomputing literature focuses instead on the 
computation
 of deterministic, rather than random, uncomputable functions.



Contents




1
 
History


2
 
State space


3
 
Models




3.1
 
Uncomputable inputs or black-box components


3.2
 
"Infinite computational steps" models


3.3
 
Quantum models


3.4
 
"Eventually correct" systems






4
 
Analysis of capabilities


5
 
Criticism


6
 
See also


7
 
References


8
 
Further reading






History






edit








A computational model going beyond Turing machines was introduced by 
Alan Turing
 in his 1938 PhD dissertation 
Systems of Logic Based on Ordinals
.
[1]
 This paper investigated mathematical systems in which an 
oracle
 was available, which could compute a single arbitrary (non-recursive) function from 
naturals
 to naturals. He used this device to prove that even in those more powerful systems, 
undecidability
 is still present. Turing's oracle machines are mathematical abstractions, and are not physically realizable.
[2]




State space






edit








In a sense, most functions are uncomputable: there are 










ℵ




0










{\displaystyle \aleph _{0}}




 
 computable functions, but there are an 
uncountable
 number (










2






ℵ




0














{\displaystyle 2^{\aleph _{0}}}




 
) of possible super-Turing functions.
[3]




Models






edit








Hypercomputer models range from useful but probably unrealizable (such as Turing's original oracle machines), to less-useful random-function generators that are more plausibly "realizable" (such as a 
random Turing machine
).



Uncomputable inputs or black-box components






edit








This section 
is in 
list
 format but may read better as 
prose
.
 You can help by 
converting this section
, if appropriate. 
Editing help
 is available.
 
(
July 2023
)


A system granted knowledge of the uncomputable, oracular 
Chaitin's constant
 (a number with an infinite sequence of digits that encode the solution to the halting problem) as an input can solve a large number of useful undecidable problems; a system granted an uncomputable random-number generator as an input can create random uncomputable functions, but is generally not believed to be able to meaningfully solve "useful" uncomputable functions such as the halting problem. There are an unlimited number of different types of conceivable hypercomputers, including:



Turing's original oracle machines, defined by Turing in 1939.


A 
real computer
 (a sort of idealized 
analog computer
) can perform hypercomputation
[4]
 if physics admits general 
real
 variables (not just 
computable reals
), and these are in some way "harnessable" for useful (rather than random) computation.  This might require quite bizarre laws of physics (for example, a measurable 
physical constant
 with an oracular value, such as 
Chaitin's constant
), and would require the ability to measure the real-valued physical value to arbitrary precision, though standard physics makes such arbitrary-precision measurements theoretically infeasible.
[5]


Similarly, a neural net that somehow had Chaitin's constant exactly embedded in its weight function would be able to solve the halting problem,
[6]
 but is subject to the same physical difficulties as other models of hypercomputation based on real computation.


Certain 
fuzzy logic
-based "fuzzy Turing machines" can, by definition, accidentally solve the halting problem, but only because their ability to solve the halting problem is indirectly assumed in the specification of the machine; this tends to be viewed as a "bug" in the original specification of the machines.
[7]
[8]


Similarly, a proposed model known as 
fair nondeterminism
 can accidentally allow the oracular computation of noncomputable functions, because some such systems, by definition, have the oracular ability to identify reject inputs that would "unfairly" cause a subsystem to run forever.
[9]
[10]


Dmytro Taranovsky has proposed a 
finitistic
 model of traditionally non-finitistic branches of analysis, built around a Turing machine equipped with a rapidly increasing function as its oracle. By this and more complicated models he was able to give an interpretation of second-order arithmetic. These models require an uncomputable input, such as a physical event-generating process where the interval between events grows at an uncomputably large rate.
[11]


Similarly, one unorthodox interpretation of a model of 
unbounded nondeterminism
 posits, by definition, that the length of time required for an "Actor" to settle is fundamentally unknowable, and therefore it cannot be proven, within the model, that it does not take an uncomputably long period of time.
[12]


"Infinite computational steps" models






edit








In order to work correctly, certain computations by the machines below literally require infinite, rather than merely unlimited but finite, physical space and resources; in contrast, with a Turing machine, any given computation that halts will require only finite physical space and resources.

A Turing machine that can 
complete
 infinitely many steps in finite time, a feat known as a 
supertask
. Simply being able to run for an unbounded number of steps does not suffice. One mathematical model is the 
Zeno machine
 (inspired by 
Zeno's paradox
). The Zeno machine performs its first computation step in (say) 1 minute, the second step in ½ minute, the third step in ¼ minute, etc.  By summing 
1 + ½ + ¼ + ...
 (a 
geometric series
) we see that the machine performs infinitely many steps in a total of 2 minutes. According to 
Oron Shagrir
, Zeno machines introduce physical paradoxes and its state is logically undefined outside of one-side open period of [0, 2), thus undefined exactly at 2 minutes after beginning of the computation.
[13]


It seems natural that the possibility of time travel (existence of 
closed timelike curves
 (CTCs)) makes hypercomputation possible by itself. However, this is not so since a CTC does not provide (by itself) the unbounded amount of storage that an infinite computation would require. Nevertheless, there are spacetimes in which the CTC region can be used for relativistic hypercomputation.
[14]
 According to a 1992 paper,
[15]
 a computer operating in a 
Malament–Hogarth spacetime
 or in orbit around a rotating 
black hole
[16]
 could theoretically perform non-Turing computations for an observer inside the black hole.
[17]
[18]
 Access to a CTC may allow the rapid solution to 
PSPACE-complete
 problems, a complexity class which, while Turing-decidable, is generally considered computationally intractable.
[19]
[20]




Quantum models






edit








Some scholars conjecture that a 
quantum mechanical
 system which somehow uses an infinite superposition of states could compute a non-
computable function
.
[21]
 This is not possible using the standard 
qubit
-model 
quantum computer
, because it is proven that a regular quantum computer is 
PSPACE-reducible
 (a quantum computer running in 
polynomial time
 can be simulated by a classical computer running in 
polynomial space
).
[22]




"Eventually correct" systems






edit








Some physically realizable systems will always eventually converge to the correct answer, but have the defect that they will often output an incorrect answer and stick with the incorrect answer for an uncomputably large period of time before eventually going back and correcting the mistake.

In mid 1960s, 
E Mark Gold
 and 
Hilary Putnam
 independently proposed models of 
inductive inference
 (the "limiting recursive functionals"
[23]
 and "trial-and-error predicates",
[24]
 respectively). These models enable some nonrecursive sets of numbers or languages (including all 
recursively enumerable
 sets of languages) to be "learned in the limit"; whereas, by definition, only recursive sets of numbers or languages could be identified by a Turing machine. While the machine will stabilize to the correct answer on any learnable set in some finite time, it can only identify it as correct if it is recursive; otherwise, the correctness is established only by running the machine forever and noting that it never revises its answer. Putnam identified this new interpretation as the class of "empirical" predicates, stating: "if we always 'posit' that the most recently generated answer is correct, we will make a finite number of mistakes, but we will eventually get the correct answer. (Note, however, that even if we have gotten to the correct answer (the end of the finite sequence) we are never 
sure
 that we have the correct answer.)"
[24]
 
L. K. Schubert
's 1974 paper "Iterated Limiting Recursion and the Program Minimization Problem"
[25]
 studied the effects of iterating the limiting procedure; this allows any 
arithmetic
 predicate to be computed. Schubert wrote, "Intuitively, iterated limiting identification might be regarded as higher-order inductive inference performed collectively by an ever-growing community of lower order inductive inference machines."

A symbol sequence is 
computable in the limit
 if there is a finite, possibly non-halting program on a 
universal Turing machine
 that incrementally outputs every symbol of the sequence. This includes the dyadic expansion of π and of every other 
computable real
, but still excludes all noncomputable reals. The 'Monotone Turing machines' traditionally used in 
description size
 theory cannot edit their previous outputs; generalized Turing machines, as defined by 
Jürgen Schmidhuber
, can. He defines the constructively describable symbol sequences as those that have a finite, non-halting program running on a generalized Turing machine, such that any output symbol eventually converges; that is, it does not change any more after some finite initial time interval. Due to limitations first exhibited by 
Kurt Gödel
 (1931), it may be impossible to predict the convergence time itself by a halting program, otherwise the 
halting problem
 could be solved. Schmidhuber (
[26]
[27]
) uses this approach to define the set of formally describable or constructively computable universes or constructive 
theories of everything
. Generalized Turing machines can eventually converge to a correct solution of the halting problem by evaluating a 
Specker sequence
.



Analysis of capabilities






edit








Many hypercomputation proposals amount to alternative ways to read an 
oracle
 or 
advice function
 embedded into an otherwise classical machine. Others allow access to some higher level of the 
arithmetic hierarchy
. For example, supertasking Turing machines, under the usual assumptions, would be able to compute any predicate in the 
truth-table degree
 containing 










Σ




1






0










{\displaystyle \Sigma _{1}^{0}}




 
 or 










Π




1






0










{\displaystyle \Pi _{1}^{0}}




 
. Limiting-recursion, by contrast, can compute any predicate or function in the corresponding 
Turing degree
, which is known to be 










Δ




2






0










{\displaystyle \Delta _{2}^{0}}




 
. Gold further showed that limiting partial recursion would allow the computation of precisely the 










Σ




2






0










{\displaystyle \Sigma _{2}^{0}}




 
 predicates.







Model



Computable predicates



Notes



Refs





supertasking











tt


⁡




(






Σ




1






0






,




Π




1






0








)








{\displaystyle \operatorname {tt} \left(\Sigma _{1}^{0},\Pi _{1}^{0}\right)}




 




dependent on outside observer



[28]






limiting/trial-and-error













Δ




2






0










{\displaystyle \Delta _{2}^{0}}




 








[23]






iterated limiting (
k
 times)













Δ




k


+


1






0










{\displaystyle \Delta _{k+1}^{0}}




 








[25]






Blum–Shub–Smale machine








incomparable with traditional 
computable real
 functions



[29]






Malament–Hogarth spacetime




HYP




dependent on spacetime structure



[30]






analog recurrent neural network













Δ




1






0






[


f


]






{\displaystyle \Delta _{1}^{0}[f]}




 




f
 is an advice function giving connection weights; size is bounded by runtime



[31]
[32]






infinite time Turing machine











A


Q


I






{\displaystyle AQI}




 




Arithmetical Quasi-Inductive sets



[33]






classical fuzzy Turing machine













Σ




1






0






∪




Π




1






0










{\displaystyle \Sigma _{1}^{0}\cup \Pi _{1}^{0}}




 




for any computable 
t-norm




[8]






increasing function oracle













Δ




1






1










{\displaystyle \Delta _{1}^{1}}




 




for the one-sequence model; 










Π




1






1










{\displaystyle \Pi _{1}^{1}}




 
 are r.e.



[11]




Criticism






edit








Martin Davis
, in his writings on hypercomputation,
[34]
[35]

refers to this subject as "a myth" and offers counter-arguments to the
physical realizability of hypercomputation. As for its theory, he argues against
the claims that this is a new field founded in the 1990s. This point of view relies
on the history of 
computability theory
 (degrees of unsolvability, computability over
functions, real numbers and ordinals), as also mentioned above.
In his argument, he makes a remark that all of hypercomputation is little more than: "
if non-computable inputs are permitted, then non-computable outputs are attainable.
"
[36]




See also






edit








Digital physics


Limits of computation


References






edit












^
 
Turing, A. M. (1939). "Systems of Logic Based on Ordinals†". 
Proceedings of the London Mathematical Society
. 
45
: 161–228. 
doi
:
10.1112/plms/s2-45.1.161
. 
hdl
:
21.11116/0000-0001-91CE-3
.




^
 
"Let us suppose that we are supplied with some unspecified means of solving number-theoretic problems; a kind of oracle as it were. We shall not go any further into the nature of this oracle apart from saying that it cannot be a machine" (Undecidable p. 167, a reprint of Turing's paper 
Systems of Logic Based On Ordinals
)




^
 
J. Cabessa; H.T. Siegelmann (Apr 2012). 
"The Computational Power of Interactive Recurrent Neural Networks"
 
(PDF)
. 
Neural Computation
. 
24
 (4): 996–1019. 
CiteSeerX
 
10.1.1.411.7540
. 
doi
:
10.1162/neco_a_00263
. 
PMID
 
22295978
. 
S2CID
 
5826757
.




^
 
Arnold Schönhage
, "On the power of random access machines", in 
Proc. Intl. Colloquium on Automata, Languages, and Programming (ICALP)
, pages 520–529, 1979.  Source of citation: 
Scott Aaronson
, "NP-complete Problems and Physical Reality"
[1]
 p. 12




^
 
Andrew Hodges. 
"The Professors and the Brainstorms"
. 
The Alan Turing Home Page
. Retrieved 
23 September
 2011
.




^
 
H.T. Siegelmann; E.D. Sontag (1994). 
"Analog Computation via Neural Networks"
. 
Theoretical Computer Science
. 
131
 (2): 331–360. 
doi
:
10.1016/0304-3975(94)90178-3
.




^
 
Biacino, L.; Gerla, G. (2002). "Fuzzy logic, continuity and effectiveness". 
Archive for Mathematical Logic
. 
41
 (7): 643–667. 
CiteSeerX
 
10.1.1.2.8029
. 
doi
:
10.1007/s001530100128
. 
ISSN
 
0933-5846
. 
S2CID
 
12513452
.




^ 
a
 
b
 
Wiedermann, Jiří (2004). 
"Characterizing the super-Turing computing power and efficiency of classical fuzzy Turing machines"
. 
Theoretical Computer Science
. 
317
 (1–3): 61–69. 
doi
:
10.1016/j.tcs.2003.12.004
. 
Their (ability to solve the halting problem) is due to their acceptance criterion in which the ability to solve the halting problem is indirectly assumed.




^
 
Edith Spaan; Leen Torenvliet; Peter van Emde Boas (1989). "Nondeterminism, Fairness and a Fundamental Analogy". 
EATCS Bulletin
. 
37
: 186–193.




^
 
Ord, Toby (2006). "The many forms of hypercomputation". 
Applied Mathematics and Computation
. 
178
: 143–153. 
doi
:
10.1016/j.amc.2005.09.076
.




^ 
a
 
b
 
Dmytro Taranovsky (July 17, 2005). 
"Finitism and Hypercomputation"
. Retrieved 
Apr 26,
 2011
.




^
 
Hewitt, Carl. "What Is Commitment." Physical, Organizational, and Social (Revised), Coordination, Organizations, Institutions, and Norms in Agent Systems II: AAMAS (2006).




^
 
These models have been independently developed by many different authors, including 
Hermann Weyl
 (1927). 
Philosophie der Mathematik und Naturwissenschaft
.
; the model is discussed in 
Shagrir, O.
 (June 2004). 
"Super-tasks, accelerating Turing machines and uncomputability"
. 
Theoretical Computer Science
. 
317
 (1–3): 105–114. 
doi
:
10.1016/j.tcs.2003.12.007
.
, 
Petrus H. Potgieter (July 2006). "Zeno machines and hypercomputation". 
Theoretical Computer Science
. 
358
 (1): 23–33. 
arXiv
:
cs/0412022
. 
doi
:
10.1016/j.tcs.2005.11.040
. 
S2CID
 
6749770
.
 and 
Vincent C. Müller (2011). 
"On the possibilities of hypercomputing supertasks"
. 
Minds and Machines
. 
21
 (1): 83–96. 
CiteSeerX
 
10.1.1.225.3696
. 
doi
:
10.1007/s11023-011-9222-6
. 
S2CID
 
253434
.




^
 
Andréka, Hajnal; Németi, István; Székely, Gergely (2012). "Closed Timelike Curves in Relativistic Computation". 
Parallel Processing Letters
. 
22
 (3). 
arXiv
:
1105.0047
. 
doi
:
10.1142/S0129626412400105
. 
S2CID
 
16816151
.




^
 
Hogarth, Mark L. (1992). "Does general relativity allow an observer to view an eternity in a finite time?". 
Foundations of Physics Letters
. 
5
 (2): 173–181. 
Bibcode
:
1992FoPhL...5..173H
. 
doi
:
10.1007/BF00682813
. 
S2CID
 
120917288
.




^
 
István Neméti; 
Hajnal Andréka
 (2006). "Can General Relativistic Computers Break the Turing Barrier?". 
Logical Approaches to Computational Barriers, Second Conference on Computability in Europe, CiE 2006, Swansea, UK, June 30-July 5, 2006. Proceedings
. Lecture Notes in Computer Science. Vol. 3988. Springer. 
doi
:
10.1007/11780342
. 
ISBN
 
978-3-540-35466-6
.




^
 
Etesi, Gabor; Nemeti, Istvan (2002). "Non-Turing computations via Malament-Hogarth space-times". 
International Journal of Theoretical Physics
. 
41
 (2): 341–370. 
arXiv
:
gr-qc/0104023
. 
doi
:
10.1023/A:1014019225365
. 
S2CID
 
17081866
.




^
 
Earman, John; Norton, John D. (1993). "Forever is a Day: Supertasks in Pitowsky and Malament-Hogarth Spacetimes". 
Philosophy of Science
. 
60
: 22–42. 
doi
:
10.1086/289716
. 
S2CID
 
122764068
.




^
 
Brun, Todd A. (2003). "Computers with closed timelike curves can solve hard problems". 
Found. Phys. Lett
. 
16
 (3): 245–253. 
arXiv
:
gr-qc/0209061
. 
doi
:
10.1023/A:1025967225931
. 
S2CID
 
16136314
.




^
 
S. Aaronson
 and J. Watrous. Closed Timelike Curves Make Quantum and Classical Computing Equivalent 
[2]




^
 
There have been some claims to this effect; see 
Tien Kieu (2003). 
"Quantum Algorithm for the Hilbert's Tenth Problem"
. 
Int. J. Theor. Phys
. 
42
 (7): 1461–1478. 
arXiv
:
quant-ph/0110136
. 
doi
:
10.1023/A:1025780028846
. 
S2CID
 
6634980
.
 or 
M. Ziegler (2005). "Computational Power of Infinite Quantum Parallelism". 
International Journal of Theoretical Physics
. 
44
 (11): 2059–2071. 
arXiv
:
quant-ph/0410141
. 
Bibcode
:
2005IJTP...44.2059Z
. 
doi
:
10.1007/s10773-005-8984-0
. 
S2CID
 
9879859
.
 and the ensuing literature. For a retort see  
Warren D. Smith (2006). "Three counterexamples refuting Kieu's plan for "quantum adiabatic hypercomputation"; and some uncomputable quantum mechanical tasks". 
Applied Mathematics and Computation
. 
178
 (1): 184–193. 
doi
:
10.1016/j.amc.2005.09.078
.
.




^
 
Bernstein, Ethan; Vazirani, Umesh (1997). 
"Quantum Complexity Theory"
. 
SIAM Journal on Computing
. 
26
 (5): 1411–1473. 
doi
:
10.1137/S0097539796300921
.




^ 
a
 
b
 
E. M. Gold (1965). "Limiting Recursion". 
Journal of Symbolic Logic
. 
30
 (1): 28–48. 
doi
:
10.2307/2270580
. 
JSTOR
 
2270580
. 
S2CID
 
33811657
.
, 
E. Mark Gold (1967). 
"Language identification in the limit"
. 
Information and Control
. 
10
 (5): 447–474. 
doi
:
10.1016/S0019-9958(67)91165-5
.




^ 
a
 
b
 
Hilary Putnam (1965). "Trial and Error Predicates and the Solution to a Problem of Mostowksi". 
Journal of Symbolic Logic
. 
30
 (1): 49–57. 
doi
:
10.2307/2270581
. 
JSTOR
 
2270581
. 
S2CID
 
44655062
.




^ 
a
 
b
 
L. K. Schubert (July 1974). 
"Iterated Limiting Recursion and the Program Minimization Problem"
. 
Journal of the ACM
. 
21
 (3): 436–445. 
doi
:
10.1145/321832.321841
. 
S2CID
 
2071951
.




^
 
Schmidhuber, Juergen (2000). "Algorithmic Theories of Everything". 
arXiv
:
quant-ph/0011122
.




^
 
J. Schmidhuber (2002). 
"Hierarchies of generalized Kolmogorov complexities and nonenumerable universal measures computable in the limit"
. 
International Journal of Foundations of Computer Science
. 
13
 (4): 587–612. 
arXiv
:
quant-ph/0011122
. 
Bibcode
:
2000quant.ph.11122S
. 
doi
:
10.1142/S0129054102001291
.




^
 
Petrus H. Potgieter (July 2006). "Zeno machines and hypercomputation". 
Theoretical Computer Science
. 
358
 (1): 23–33. 
arXiv
:
cs/0412022
. 
doi
:
10.1016/j.tcs.2005.11.040
. 
S2CID
 
6749770
.




^
 
Lenore Blum
, Felipe Cucker, Michael Shub, and 
Stephen Smale
 (1998). 
Complexity and Real Computation
. Springer. 
ISBN
 
978-0-387-98281-6
.
{{
cite book
}}
:  CS1 maint: multiple names: authors list (
link
)




^
 
P.D. Welch
 (2008). "The extent of computation in Malament-Hogarth spacetimes". 
British Journal for the Philosophy of Science
. 
59
 (4): 659–674. 
arXiv
:
gr-qc/0609035
. 
doi
:
10.1093/bjps/axn031
.




^
 
H.T. Siegelmann (Apr 1995). 
"Computation Beyond the Turing Limit"
 
(PDF)
. 
Science
. 
268
 (5210): 545–548. 
Bibcode
:
1995Sci...268..545S
. 
doi
:
10.1126/science.268.5210.545
. 
PMID
 
17756722
. 
S2CID
 
17495161
.




^
 
Hava Siegelmann
; 
Eduardo Sontag
 (1994). 
"Analog Computation via Neural Networks"
. 
Theoretical Computer Science
. 
131
 (2): 331–360. 
doi
:
10.1016/0304-3975(94)90178-3
.




^
 
P.D. Welch
 (2009). 
"Characteristics of discrete transfinite time Turing machine models: Halting times, stabilization times, and Normal Form theorems"
. 
Theoretical Computer Science
. 
410
 (4–5): 426–442. 
doi
:
10.1016/j.tcs.2008.09.050
.




^
 
Davis, Martin (2006). "Why there is no such discipline as hypercomputation". 
Applied Mathematics and Computation
. 
178
 (1): 4–7. 
doi
:
10.1016/j.amc.2005.09.066
.




^
 
Davis, Martin (2004). "The Myth of Hypercomputation". 
Alan Turing: Life and Legacy of a Great Thinker
. Springer.




^
 
Martin Davis (Jan 2003). "The Myth of Hypercomputation". In Alexandra Shlapentokh (ed.). 
Miniworkshop: Hilbert's Tenth Problem, Mazur's Conjecture and Divisibility Sequences
 
(PDF)
. MFO Report. Vol. 3. Mathematisches Forschungsinstitut Oberwolfach. p. 2.






Further reading






edit








Aoun, Mario Antoine (2016). 
"Advances in Three Hypercomputation Models"
 
(PDF)
. 
Electronic Journal of Theoretical Physics
. 
13
 (36): 169–182.


Burgin, M. S. (1983). "Inductive Turing Machines". 
Notices of the Academy of Sciences of the USSR
. 
270
 (6): 1289–1293.


Burgin, Mark (2005). 
Super-recursive algorithms
. Monographs in computer science. Springer. 
ISBN
 
0-387-95569-0
.


Cockshott, P.; Michaelson, G. (2007). "Are there new Models of Computation? Reply to Wegner and Eberbach". 
The Computer Journal
. 
doi
:
10.1093/comjnl/bxl062
.


Cooper, S. B.; Odifreddi, P. (2003). 
"Incomputability in Nature"
 
(PDF)
. In Cooper, S. B.; Goncharov, S. S. (eds.). 
Computability and Models: Perspectives East and West
. New York, Boston, Dordrecht, London, Moscow: Plenum Publishers. pp. 137–160. Archived from 
the original
 
(PDF)
 on 2011-07-24
. Retrieved 
2011-06-16
.


Cooper, S. B. (2006). "Definability as hypercomputational effect". 
Applied Mathematics and Computation
. 
178
: 72–82. 
CiteSeerX
 
10.1.1.65.4088
. 
doi
:
10.1016/j.amc.2005.09.072
. 
S2CID
 
1487739
.


Copeland, J. (2002). 
"Hypercomputation"
 
(PDF)
. 
Minds and Machines
. 
12
 (4): 461–502. 
doi
:
10.1023/A:1021105915386
. 
S2CID
 
218585685
. Archived from 
the original
 
(PDF)
 on 2016-03-14.


Hagar, A.; Korolev, A. (2007). 
"Quantum Hypercomputation—Hype or Computation?*"
 
(PDF)
. 
Philosophy of Science
. 
74
 (3): 347–363. 
doi
:
10.1086/521969
. 
S2CID
 
9857468
.


Ord, Toby (2002). "Hypercomputation: Computing more than the Turing machine can compute: A survey article on various forms of hypercomputation". 
arXiv
:
math/0209332
.


Piccinini, Gualtiero
 (June 16, 2021). 
"Computation in Physical Systems"
. 
Stanford Encyclopedia of Philosophy
. Retrieved 
2023-07-31
.


Sharma, Ashish (2022). "Nature Inspired Algorithms with Randomized Hypercomputational Perspective". 
Information Sciences
. 
608
: 670–695. 
doi
:
10.1016/j.ins.2022.05.020
. 
S2CID
 
248881264
.


Stannett, Mike (1990). 
"X-machines and the halting problem: Building a super-Turing machine"
. 
Formal Aspects of Computing
. 
2
 (1): 331–341. 
doi
:
10.1007/BF01888233
. 
S2CID
 
7406983
.


Stannett, Mike (2006). 
"The case for hypercomputation"
 
(PDF)
. 
Applied Mathematics and Computation
. 
178
 (1): 8–24. 
doi
:
10.1016/j.amc.2005.09.067
. Archived from 
the original
 
(PDF)
 on 2016-03-04.


Syropoulos, Apostolos (2008). 
Hypercomputation: Computing Beyond the Church–Turing Barrier
. Springer. 
ISBN
 
978-0-387-30886-9
.














Retrieved from "
https://en.wikipedia.org/w/index.php?title=Hypercomputation&oldid=1227156198
"




















Last edited on 4 June 2024, at 01:43




















Languages






Español
Français
한국어
Lombard
日本語
Polski
Português
Русский
Српски / srpski
Українська
中文




 






 This page was last edited on 4 June 2024, at 01:43
 (UTC)
.


Content is available under 
CC BY-SA 4.0
 unless otherwise noted.






Privacy policy


About Wikipedia


Disclaimers


Contact Wikipedia


Code of Conduct


Developers


Statistics


Cookie statement


Terms of Use


Desktop





















