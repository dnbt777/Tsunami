









































Chapter
 
2
Linear
 
Algebra
Linear
 
algebra
 
is
 
a
 
branc
h
 
of
 
mathematics
 
that
 
is
 
widely
 
used
 
throughout
 
science
and
 
engineering.
 
Y
et
 
because
 
linear
 
algebra
 
is
 
a
 
form
 
of
 
con
tin
uous
 
rather
 
than
discrete
 
mathematics,
 
man
y
 
computer
 
scien
tists
 
ha
v
e
 
little
 
exp
erience
 
with
 
it.
 
A
go
o
d
 
understanding
 
of
 
linear
 
algebra
 
is
 
essen
tial
 
for
 
understanding
 
and
 
w
orking
with
 
many
 
machine
 
learning
 
algorithms,
 
esp
ecially
 
deep
 
learning
 
algorithms.
 
W
e
therefore
 
precede
 
our
 
in
tro
duction
 
to
 
deep
 
learning
 
with
 
a
 
fo
cused
 
presen
tation
 
of
the
 
key
 
linear
 
algebra
 
prerequisites.
If
 
y
ou
 
are
 
already
 
familiar
 
with
 
linear
 
algebra,
 
feel
 
free
 
to
 
skip
 
this
 
chapter.
 
If
y
ou
 
hav
e
 
previous
 
exp
erience
 
with
 
these
 
concepts
 
but
 
need
 
a
 
detailed
 
reference
sheet
 
to
 
review
 
key
 
formulas,
 
w
e
 
recommend
 
The
 
Matrix
 
Co
okb
o
ok
 
(
Petersen
 
and
P
edersen
,
 
2006
).
 
If
 
you
 
hav
e
 
had
 
no
 
exp
osure
 
at
 
all
 
to
 
linear
 
algebra,
 
this
 
c
hapter
will
 
teach
 
you
 
enough
 
to
 
read
 
this
 
b
o
ok,
 
but
 
we
 
highly
 
recommend
 
that
 
y
ou
 
also
consult
 
another
 
resource
 
fo
cused
 
exclusiv
ely
 
on
 
teaching
 
linear
 
algebra,
 
such
 
as
Shilo
v
 
(
1977
).
 
This
 
c
hapter
 
completely
 
omits
 
many
 
imp
ortan
t
 
linear
 
algebra
 
topics
that
 
are
 
not
 
essential
 
for
 
understanding
 
deep
 
learning.
2.1
 
Scalars,
 
V
ectors,
 
Matrices
 
and
 
T
ensors
The
 
study
 
of
 
linear
 
algebra
 
inv
olv
es
 
several
 
types
 
of
 
mathematical
 
ob
jects:
•
 
Scalars
:
 
A
 
scalar
 
is
 
just
 
a
 
single
 
num
ber,
 
in
 
contrast
 
to
 
most
 
of
 
the
 
other
ob
jects
 
studied
 
in
 
linear
 
algebra,
 
which
 
are
 
usually
 
arra
ys
 
of
 
m
ultiple
 
num
bers.
W
e
 
write
 
scalars
 
in
 
italics.
 
W
e
 
usually
 
giv
e
 
scalars
 
low
ercase
 
v
ariable
 
names.
When
 
we
 
in
tro
duce
 
them,
 
w
e
 
sp
ecify
 
what
 
kind
 
of
 
n
um
ber
 
they
 
are.
 
F
or
29


CHAPTER
 
2.
 
LINEAR
 
ALGEBRA
example,
 
we
 
might
 
say
 
“Let
s
 
∈
 
R
b
e
 
the
 
slop
e
 
of
 
the
 
line,”
 
while
 
deﬁning
 
a
real-v
alued
 
scalar,
 
or
 
“Let
n
 
∈
 
N
b
e
 
the
 
num
b
er
 
of
 
units,”
 
while
 
deﬁning
 
a
natural
 
num
b
er
 
scalar.
•
 
V
ectors
: A
 
vector
 
is
 
an
 
array
 
of
 
num
b
ers.
 
The
 
n
um
b
ers
 
are
 
arranged
 
in
order.
 
W
e
 
can
 
identify
 
eac
h
 
individual
 
num
b
er
 
by
 
its
 
index
 
in
 
that
 
ordering.
T
ypically
 
we
 
give
 
vectors
 
lo
w
ercase
 
names
 
in
 
b
old
 
typeface,
 
such
 
as
x
.
 
The
elemen
ts
 
of
 
the
 
vector
 
are
 
iden
tiﬁed
 
by
 
writing
 
its
 
name
 
in
 
italic
 
typeface,
with
 
a
 
subscript.
 
The
 
ﬁrst
 
element
 
of
x
is
x
1
,
 
the
 
second
 
elemen
t
 
is
x
2
,
 
and
so
 
on.
 
W
e
 
also
 
need
 
to
 
sa
y
 
what
 
kind
 
of
 
n
um
b
ers
 
are
 
stored
 
in
 
the
 
v
ector.
 
If
eac
h
 
element
 
is
 
in
R
,
 
and
 
the
 
vector
 
has
n
elemen
ts,
 
then
 
the
 
vector
 
lies
 
in
the
 
set
 
formed
 
by
 
taking
 
the
 
Cartesian
 
pro
duct
 
of
R
 
n
times,
 
denoted
 
as
R
n
.
When
 
w
e
 
need
 
to
 
explicitly
 
identify
 
the
 
elemen
ts
 
of
 
a
 
vector,
 
w
e
 
write
 
them
as
 
a
 
column
 
enclosed
 
in
 
square
 
brack
ets:
x
 
=





x
1
x
2
.
.
.
x
n





.
 
(2.1)
W
e
 
can
 
think
 
of
 
vectors
 
as
 
iden
tifying
 
p
oints
 
in
 
space,
 
with
 
eac
h
 
element
giving
 
the
 
co
ordinate
 
along
 
a
 
diﬀerent
 
axis.
Sometimes
 
we
 
need
 
to
 
index
 
a
 
set
 
of
 
elements
 
of
 
a
 
v
ector.
 
In
 
this
 
case,
 
we
deﬁne
 
a
 
set
 
con
taining
 
the
 
indices
 
and
 
write
 
the
 
set
 
as
 
a
 
subscript.
 
F
or
example,
 
to
 
access
x
1
,
x
3
and
x
6
,
 
we
 
deﬁne
 
the
 
set
S
=
{
1
,
3
,
6
}
and
 
write
x
S
.
 
W
e
 
use
 
the
−
sign
 
to
 
index
 
the
 
complement
 
of
 
a
 
set.
 
F
or
 
example
x
−
1
is
the
 
vector
 
containing
 
all
 
elements
 
of
x
except
 
for
x
1
,
 
and
x
−
S
is
 
the
 
vector
con
taining
 
all
 
elements
 
of
 
x
 
except
 
for
 
x
1
,
 
x
3
and
 
x
6
.
•
 
Matrices
:
 
A
 
matrix
 
is
 
a
 
2-D
 
array
 
of
 
num
b
ers,
 
so
 
each
 
elemen
t
 
is
 
iden
tiﬁed
b
y
 
t
w
o
 
indices
 
instead
 
of
 
just
 
one.
 
W
e
 
usually
 
giv
e
 
matrices
 
upp
ercase
v
ariable
 
names
 
with
 
b
old
 
typeface,
 
such
 
as
A
.
 
If
 
a
 
real-v
alued
 
matrix
A
has
a
 
height
 
of
m
and
 
a
 
width
 
of
n
,
 
then
 
we
 
sa
y
 
that
A
 
∈
 
R
m
×
n
. W
e
 
usually
iden
tify
 
the
 
elements
 
of
 
a
 
matrix
 
using
 
its
 
name
 
in
 
italic
 
but
 
not
 
b
old
 
font,
and
 
the
 
indices
 
are
 
listed
 
with
 
separating
 
commas.
 
F
or
 
example,
A
1
,
1
is
 
the
upp
er
 
left
 
en
try
 
of
A
and
A
m,n
is
 
the
 
b
ottom
 
right
 
en
try
.
 
W
e
 
can
 
iden
tify
all
 
the
 
n
um
b
ers
 
with
 
vertical
 
co
ordinate
i
b
y
 
writing
 
a
 
“
:
”
 
for
 
the
 
horizon
tal
co
ordinate.
 
F
or
 
example,
A
i,
:
denotes
 
the
 
horizon
tal
 
cross
 
section
 
of
A
with
v
ertical
 
co
ordinate
i
.
 
This
 
is
 
known
 
as
 
the
i
-th
ro
w
of
A
.
 
Lik
ewise,
A
:
,i
is
30


CHAPTER
 
2.
 
LINEAR
 
ALGEBRA
the
 
i
-th
 
column
 
of
 
A
.
 
When
 
we
 
need
 
to
 
explicitly
 
iden
tify
 
the
 
elements
 
of
a
 
matrix,
 
we
 
write
 
them
 
as
 
an
 
arra
y
 
enclosed
 
in
 
square
 
brack
ets:

A
1
,
1
A
1
,
2
A
2
,
1
A
2
,
2

.
 
(2.2)
Sometimes
 
we
 
may
 
need
 
to
 
index
 
matrix-v
alued
 
expressions
 
that
 
are
 
not
 
just
a
 
single
 
letter.
 
In
 
this
 
case,
 
w
e
 
use
 
subscripts
 
after
 
the
 
expression
 
but
 
do
 
not
con
v
ert
 
anything
 
to
 
low
ercase.
 
F
or
 
example,
f
(
A
)
i,j
giv
es
 
element
 
(
i,
 
j
)
 
of
the
 
matrix
 
computed
 
by
 
applying
 
the
 
function
 
f
 
to
 
A
.
•
 
T
ensors
:
 
In
 
some
 
cases
 
we
 
will
 
need
 
an
 
array
 
with
 
more
 
than
 
tw
o
 
axes.
In
 
the
 
general
 
case,
 
an
 
array
 
of
 
num
b
ers
 
arranged
 
on
 
a
 
regular
 
grid
 
with
 
a
v
ariable
 
num
b
er
 
of
 
axes
 
is
 
known
 
as
 
a
 
tensor.
 
W
e
 
denote
 
a
 
tensor
 
named
 
“A”
with
 
this
 
typeface:
A
.
 
W
e
 
identify
 
the
 
element
 
of
A
at
 
co
ordinates
 
(
i,
 
j,
 
k
)
b
y
 
writing
 
A
i,j,k
.
One
 
imp
ortant
 
op
eration
 
on
 
matrices
 
is
 
the
transp
ose
.
 
The
 
transp
ose
 
of
 
a
matrix
 
is
 
the
 
mirror
 
image
 
of
 
the
 
matrix
 
across
 
a
 
diagonal
 
line,
 
called
 
the
main
diagonal
,
 
running
 
do
wn
 
and
 
to
 
the
 
righ
t,
 
starting
 
from
 
its
 
upp
er
 
left
 
corner.
 
See
ﬁgure
 
2.1
 
for
 
a
 
graphical
 
depiction
 
of
 
this
 
op
eration.
 
W
e
 
denote
 
the
 
transp
ose
 
of
 
a
matrix
 
A
 
as
 
A

,
 
and
 
it
 
is
 
deﬁned
 
such
 
that
(
A

)
i,j
= 
A
j,i
.
 
(2.3)
V
ectors
 
can
 
b
e
 
thought
 
of
 
as
 
matrices
 
that
 
contain
 
only
 
one
 
column.
 
The
transp
ose
 
of
 
a
 
vector
 
is
 
therefore
 
a
 
matrix
 
with
 
only
 
one
 
ro
w.
 
Sometimes
 
we
A
 
=


A
1
,
1
A
1
,
2
A
2
,
1
A
2
,
2
A
3
,
1
A
3
,
2


⇒
 
A

=

A
1
,
1
A
2
,
1
A
3
,
1
A
1
,
2
A
2
,
2
A
3
,
2

Figure
 
2.1:
 
The
 
transp
ose
 
of
 
the
 
matrix
 
can
 
b
e
 
thought
 
of
 
as
 
a
 
mirror
 
image
 
across
 
the
main
 
diagonal.
31


CHAPTER
 
2.
 
LINEAR
 
ALGEBRA
deﬁne
 
a
 
vector
 
b
y
 
writing
 
out
 
its
 
elements
 
in
 
the
 
text
 
inline
 
as
 
a
 
row
 
matrix,
 
then
using
 
the
 
transp
ose
 
op
erator
 
to
 
turn
 
it
 
into
 
a
 
standard
 
column
 
vector,
 
for
 
example
x
 
= [
x
1
,
 
x
2
,
 
x
3
]

.
A
 
scalar
 
can
 
b
e
 
thought
 
of
 
as
 
a
 
matrix
 
with
 
only
 
a
 
single
 
en
try
.
 
F
rom
 
this,
 
we
can
 
see
 
that
 
a
 
scalar
 
is
 
its
 
o
wn
 
transp
ose:
 
a
 
= 
a

.
W
e
 
can
 
add
 
matrices
 
to
 
each
 
other,
 
as
 
long
 
as
 
they
 
hav
e
 
the
 
same
 
shap
e,
 
just
b
y
 
adding
 
their
 
corresp
onding
 
elements:
 
C
 
= 
A
 
+
 
B
 
where
 
C
i,j
= 
A
i,j
+
 
B
i,j
.
W
e
 
can
 
also
 
add
 
a
 
scalar
 
to
 
a
 
matrix
 
or
 
m
ultiply
 
a
 
matrix
 
b
y
 
a
 
scalar,
 
just
b
y
 
p
erforming
 
that
 
op
eration
 
on
 
each
 
element
 
of
 
a
 
matrix:
D
=
a
 
·
 
B
+
c
where
D
i,j
= 
a
 
·
 
B
i,j
+
 
c
.
In
 
the
 
con
text
 
of
 
deep
 
learning,
 
we
 
also
 
use
 
some
 
less
 
conv
entional
 
notation.
 
W
e
allo
w
 
the
 
addition
 
of
 
a
 
matrix
 
and
 
a
 
vector,
 
yielding
 
another
 
matrix:
C
=
A
+
b
,
where
C
i,j
=
A
i,j
+
b
j
.
 
In
 
other
 
words,
 
the
 
v
ector
b
is
 
added
 
to
 
each
 
row
 
of
 
the
matrix.
 
This
 
shorthand
 
eliminates
 
the
 
need
 
to
 
deﬁne
 
a
 
matrix
 
with
b
copied
 
into
eac
h
 
row
 
b
efore
 
doing
 
the
 
addition.
 
This
 
implicit
 
cop
ying
 
of
b
to
 
many
 
lo
cations
is
 
called
 
broadcasting
.
2.2
 
Multiplying
 
Matrices
 
and
 
V
ectors
One
 
of
 
the
 
most
 
imp
ortant
 
op
erations
 
inv
olving
 
matrices
 
is
 
multiplication
 
of
 
tw
o
matrices.
 
The
matrix
 
pro
duct
of
 
matrices
A
and
B
is
 
a
 
third
 
matrix
C
.
 
In
order
 
for
 
this
 
pro
duct
 
to
 
b
e
 
deﬁned,
A
m
ust
 
ha
v
e
 
the
 
same
 
num
b
er
 
of
 
columns
 
as
B
has
 
rows.
 
If
A
is
 
of
 
shap
e
m
 
×
 
n
and
B
is
 
of
 
shap
e
n
 
×
 
p
,
 
then
C
is
 
of
 
shap
e
m
 
×
 
p
.
 
W
e
 
can
 
write
 
the
 
matrix
 
product
 
just
 
by
 
placing
 
tw
o
 
or
 
more
 
matrices
together,
 
for
 
example,
C
 
= 
AB
.
 
(2.4)
The
 
pro
duct
 
op
eration
 
is
 
deﬁned
 
by
C
i,j
=

k
A
i,k
B
k,j
.
 
(2.5)
Note
 
that
 
the
 
standard
 
pro
duct
 
of
 
tw
o
 
matrices
 
is
 
not
 
just
 
a
 
matrix
 
containing
the
 
pro
duct
 
of
 
the
 
individual
 
elemen
ts.
 
Such
 
an
 
op
eration
 
exists
 
and
 
is
 
called
 
the
elemen
t-wise
 
pro
duct
,
 
or
 
Hadamard
 
product
,
 
and
 
is
 
denoted
 
as
 
A
 

B
.
The
dot
 
pro
duct
b
et
w
een
 
tw
o
 
vectors
x
and
y
of
 
the
 
same
 
dimensionalit
y
is
 
the
 
matrix
 
pro
duct
x

y
.
 
W
e
 
can
 
think
 
of
 
the
 
matrix
 
pro
duct
C
=
AB
as
computing
 
C
i,j
as
 
the
 
dot
 
pro
duct
 
b
etw
een
 
row
 
i
 
of
 
A
 
and
 
column
 
j
 
of
 
B
.
32


CHAPTER
 
2.
 
LINEAR
 
ALGEBRA
Matrix
 
pro
duct
 
op
erations
 
hav
e
 
man
y
 
useful
 
prop
erties
 
that
 
make
 
mathematical
analysis of
 
matrices more con
venien
t.
 
F
or example, matrix m
ultiplication is
distributiv
e:
A
(
B
 
+
 
C
) = 
AB
 
+
 
AC
.
 
(2.6)
It
 
is
 
also
 
asso
ciative:
A
(
B
C
) = (
AB
)
C
.
 
(2.7)
Matrix
 
multiplication
 
is
 
not
 
comm
utativ
e
 
(the
 
condition
AB
=
B
A
do
es
 
not
alw
a
ys
 
hold),
 
unlik
e
 
scalar
 
multiplication.
 
Ho
wev
er,
 
the
 
dot
 
pro
duct
 
b
etw
een
 
tw
o
v
ectors
 
is
 
commutativ
e:
x

y
 
= 
y

x
.
 
(2.8)
The
 
transp
ose
 
of
 
a
 
matrix
 
pro
duct
 
has
 
a
 
simple
 
form:
(
AB
)

= 
B

A

.
 
(2.9)
This
 
enables
 
us
 
to
 
demonstrate
 
equation
 
2.8
 
by
 
exploiting
 
the
 
fact
 
that
 
the
 
v
alue
of
 
such
 
a
 
pro
duct
 
is
 
a
 
scalar
 
and
 
therefore
 
equal
 
to
 
its
 
own
 
transp
ose:
x

y
 
=

x

y


= 
y

x
.
 
(2.10)
Since
 
the
 
fo
cus
 
of
 
this
 
textb
o
ok
 
is
 
not
 
linear
 
algebra,
 
we
 
do
 
not
 
attempt
 
to
dev
elop
 
a
 
comprehensive
 
list
 
of
 
useful
 
prop
erties
 
of
 
the
 
matrix
 
pro
duct
 
here,
 
but
the
 
reader
 
should
 
b
e
 
aw
are
 
that
 
many
 
more
 
exist.
W
e
 
no
w
 
kno
w
 
enough
 
linear
 
algebra
 
notation
 
to
 
write
 
down
 
a
 
system
 
of
 
linear
equations:
Ax
 
= 
b
 
(2.11)
where
A
 
∈
 
R
m
×
n
is
 
a
 
known
 
matrix,
b
 
∈
 
R
m
is
 
a
 
known
 
vector,
 
and
x
 
∈
 
R
n
is
 
a
v
ector
 
of
 
unknown
 
v
ariables
 
we
 
would
 
lik
e
 
to
 
solve
 
for.
 
Each
 
element
x
i
of
x
is
 
one
of
 
these
 
unknown
 
v
ariables.
 
Each
 
row
 
of
A
and
 
eac
h
 
element
 
of
b
pro
vide
 
another
constrain
t.
 
W
e
 
can
 
rewrite
 
equation
 
2.11
 
as
A
1
,
:
x
 
= 
b
1
(2.12)
A
2
,
:
x
 
= 
b
2
(2.13)
.
 
.
 
.
 
(2.14)
A
m,
:
x
 
= 
b
m
(2.15)
or
 
even
 
more
 
explicitly
 
as
A
1
,
1
x
1
+
 
A
1
,
2
x
2
+
 
·
·
·
 
+
 
A
1
,n
x
n
= 
b
1
(2.16)
33


CHAPTER
 
2.
 
LINEAR
 
ALGEBRA
A
2
,
1
x
1
+
 
A
2
,
2
x
2
+
 
·
·
·
 
+
 
A
2
,n
x
n
= 
b
2
(2.17)
.
 
.
 
.
 
(2.18)
A
m,
1
x
1
+
 
A
m,
2
x
2
+
 
·
·
·
 
+
 
A
m,n
x
n
= 
b
m
.
 
(2.19)
Matrix-v
ector
 
pro
duct
 
notation
 
provides
 
a
 
more
 
compact
 
represen
tation
 
for
equations
 
of
 
this
 
form.
2.3
 
Iden
tit
y
 
and
 
In
v
erse
 
Matrices
Linear
 
algebra
 
oﬀers
 
a
 
p
ow
erful
 
to
ol
 
called
matrix
 
inv
ersion
that
 
enables
 
us
 
to
analytically
 
solve
 
equation
 
2.11
 
for
 
man
y
 
v
alues
 
of
 
A
.
T
o
 
describ
e
 
matrix
 
inv
ersion,
 
we
 
ﬁrst
 
need
 
to
 
deﬁne
 
the
 
concept
 
of
 
an
iden
tity
matrix
.
 
An
 
identit
y
 
matrix
 
is
 
a
 
matrix
 
that
 
do
es
 
not
 
c
hange
 
an
y
 
v
ector
 
when
 
we
m
ultiply
 
that
 
vector
 
b
y
 
that
 
matrix.
 
W
e
 
denote
 
the
 
iden
tit
y
 
matrix
 
that
 
preserves
n
-dimensional
 
vectors
 
as
 
I
n
.
 
F
ormally
,
 
I
n
∈
 
R
n
×
n
,
 
and
∀
x
 
∈
 
R
n
,
 
I
n
x
 
= 
x
.
 
(2.20)
The
 
structure
 
of
 
the
 
identit
y
 
matrix
 
is
 
simple:
 
all
 
the
 
en
tries
 
along
 
the
 
main
diagonal
 
are
 
1,
 
while
 
all
 
the
 
other
 
en
tries
 
are
 
zero.
 
See
 
ﬁgure
 
2.2
 
for
 
an
 
example.
The
matrix
 
inv
erse
of
A
is
 
denoted
 
as
A
−
1
,
 
and
 
it
 
is
 
deﬁned
 
as
 
the
 
matrix
suc
h
 
that
A
−
1
A
 
= 
I
n
.
 
(2.21)
W
e
 
can
 
now
 
solve
 
equation
 
2.11
 
using
 
the
 
following
 
steps:
Ax
 
= 
b
 
(2.22)
A
−
1
Ax
 
= 
A
−
1
b
 
(2.23)
I
n
x
 
= 
A
−
1
b
 
(2.24)


1
 
0
 
0
0
 
1
 
0
0
 
0
 
1


Figure
 
2.2:
 
Example
 
identit
y
 
matrix:
 
This
 
is
 
I
3
.
34


CHAPTER
 
2.
 
LINEAR
 
ALGEBRA
x
 
= 
A
−
1
b
.
 
(2.25)
Of
 
course,
 
this
 
pro
cess
 
dep
ends
 
on
 
it
 
b
eing
 
p
ossible
 
to
 
ﬁnd
A
−
1
.
 
W
e
 
discuss
the
 
conditions
 
for
 
the
 
existence
 
of
 
A
−
1
in
 
the
 
following
 
section.
When
A
−
1
exists,
 
several
 
diﬀerent
 
algorithms
 
can
 
ﬁnd
 
it
 
in
 
closed
 
form.
 
In
theory
,
 
the
 
same
 
inv
erse
 
matrix
 
can
 
then
 
b
e
 
used
 
to
 
solv
e
 
the
 
equation
 
many
 
times
for
 
diﬀeren
t
 
v
alues
 
of
b
.
A
−
1
is
 
primarily
 
useful
 
as
 
a
 
theoretical
 
to
ol,
 
how
ever,
 
and
should
 
not
 
actually
 
b
e
 
used
 
in
 
practice
 
for
 
most
 
softw
are
 
applications.
 
Because
A
−
1
can
 
b
e
 
represented
 
with
 
only
 
limited
 
precision
 
on
 
a
 
digital
 
computer,
 
algorithms
that
 
make
 
use
 
of
 
the
 
v
alue
 
of
 
b
 
can
 
usually
 
obtain
 
more
 
accurate
 
estimates
 
of
 
x
.
2.4
 
Linear
 
Dep
endence
 
and
 
Span
F
or
A
−
1
to
 
exist,
 
equation
 
2.11
 
must
 
hav
e
 
exactly
 
one
 
solution
 
for
 
every
 
v
alue
 
of
b
.
 
It
 
is
 
also
 
p
ossible
 
for
 
the
 
system
 
of
 
equations
 
to
 
hav
e
 
no
 
solutions
 
or
 
inﬁnitely
man
y
 
solutions
 
for
 
some
 
v
alues
 
of
b
.
 
It
 
is
 
not
 
p
ossible,
 
how
ever,
 
to
 
hav
e
 
more
 
than
one
 
but
 
less
 
than
 
inﬁnitely
 
many
 
solutions
 
for
 
a
 
particular
b
;
 
if
 
b
oth
x
and
y
are
solutions,
 
then
z
 
= 
α
x
 
+
 
(1
 
−
α
)
y
 
(2.26)
is
 
also
 
a
 
solution
 
for
 
any
 
real
 
α
.
T
o
 
analyze
 
how
 
many
 
solutions
 
the
 
equation
 
has,
 
think
 
of
 
the
 
columns
 
of
A
as
sp
ecifying
 
diﬀerent
 
directions
 
we
 
can
 
trav
el
 
in
 
from
 
the
origin
(the
 
p
oint
 
sp
eciﬁed
b
y
 
the
 
vector
 
of
 
all
 
zeros),
 
then
 
determine
 
ho
w
 
man
y
 
w
a
ys
 
there
 
are
 
of
 
reaching
b
.
In
 
this
 
view,
 
each
 
element
 
of
x
sp
eciﬁes
 
how
 
far
 
we
 
should
 
trav
el
 
in
 
each
 
of
 
these
directions,
 
with
 
x
i
sp
ecifying
 
how
 
far
 
to
 
mov
e
 
in
 
the
 
direction
 
of
 
column
 
i
:
Ax
 
=

i
x
i
A
:
,i
.
 
(2.27)
In
 
general,
 
this
 
kind
 
of
 
operation
 
is
 
called
 
a
linear
 
com
bination
.
 
F
ormally
,
 
a
linear
 
combination
 
of
 
some
 
set
 
of
 
vectors
{
v
(1)
,
 
.
 
.
 
.
 
,
 
v
(
n
)
}
is
 
given
 
b
y
 
multiplying
eac
h
 
vector
 
v
(
i
)
b
y
 
a
 
corresp
onding
 
scalar
 
co
eﬃcient
 
and
 
adding
 
the
 
results:

i
c
i
v
(
i
)
.
 
(2.28)
The
span
of
 
a
 
set
 
of
 
vectors
 
is
 
the
 
set
 
of
 
all
 
p
oin
ts
 
obtainable
 
by
 
linear
 
combination
of
 
the
 
original
 
vectors.
35


CHAPTER
 
2.
 
LINEAR
 
ALGEBRA
Determining
 
whether
Ax
=
b
has
 
a
 
solution
 
thus
 
amounts
 
to
 
testing
 
whether
b
is
 
in
 
the
 
span
 
of
 
the
 
columns
 
of
A
.
 
This
 
particular
 
span
 
is
 
known
 
as
 
the
column
space
,
 
or
 
the
 
range
,
 
of
 
A
.
In
 
order
 
for
 
the
 
system
Ax
=
b
to
 
ha
v
e
 
a
 
solution
 
for
 
all
 
v
alues
 
of
b
 
∈
 
R
m
,
w
e
 
therefore
 
require
 
that
 
the
 
column
 
space
 
of
A
b
e
 
all
 
of
R
m
.
 
If
 
an
y
 
p
oin
t
 
in
R
m
is
 
excluded
 
from
 
the
 
column
 
space,
 
that
 
p
oint
 
is
 
a
 
p
otential
 
v
alue
 
of
b
that
 
has
no
 
solution.
 
The
 
requirement
 
that
 
the
 
column
 
space
 
of
A
b
e
 
all
 
of
R
m
implies
immediately
 
that
A
m
ust
 
hav
e
 
at
 
least
m
columns,
 
that
 
is,
n
 
≥
 
m
.
 
Otherwise,
 
the
dimensionalit
y
 
of
 
the
 
column
 
space
 
would
 
b
e
 
less
 
than
m
.
 
F
or
 
example,
 
consider
 
a
3
×
2
 
matrix.
 
The
 
target
b
is
 
3-D,
 
but
x
is
 
only
 
2-D,
 
so
 
mo
difying
 
the
 
v
alue
 
of
x
at
 
b
est
 
enables
 
us
 
to
 
trace
 
out
 
a
 
2-D
 
plane
 
within
R
3
.
 
The
 
equation
 
has
 
a
 
solution
if
 
and
 
only
 
if
 
b
 
lies
 
on
 
that
 
plane.
Ha
ving
n
 
≥
 
m
is
 
only
 
a
 
necessary
 
condition
 
for
 
every
 
p
oint
 
to
 
hav
e
 
a
 
solution.
It
 
is
 
not
 
a
 
suﬃcient
 
condition,
 
b
ecause
 
it
 
is
 
p
ossible
 
for
 
some
 
of
 
the
 
columns
 
to
b
e
 
redundant.
 
Consider
 
a
 
2
×
2
 
matrix
 
where
 
b
oth
 
of
 
the
 
columns
 
are
 
identical.
This
 
has
 
the
 
same
 
column
 
space
 
as
 
a
 
2
×
1
 
matrix
 
containing
 
only
 
one
 
copy
 
of
 
the
replicated
 
column.
 
In
 
other
 
words,
 
the
 
column
 
space
 
is
 
still
 
just
 
a
 
line
 
and
 
fails
 
to
encompass
 
all
 
of
 
R
2
,
 
even
 
though
 
there
 
are
 
tw
o
 
columns.
F
ormally
,
 
this
 
kind
 
of
 
redundancy
 
is
 
known
 
as
linear
 
dep
endence
.
 
A
 
set
 
of
v
ectors
 
is
linearly
 
indep
endent
if
 
no
 
v
ector
 
in
 
the
 
set
 
is
 
a
 
linear
 
com
bination
of
 
the
 
other
 
vectors. If
 
we
 
add
 
a
 
v
ector
 
to
 
a
 
set
 
that
 
is
 
a
 
linear
 
combination
 
of
the
 
other
 
vectors
 
in
 
the
 
set,
 
the
 
new
 
vector
 
do
es
 
not
 
add
 
any
 
p
oints
 
to
 
the
 
set’s
span.
 
This
 
means
 
that
 
for
 
the
 
column
 
space
 
of
 
the
 
matrix
 
to
 
encompass
 
all
 
of
R
m
,
the
 
matrix
 
m
ust
 
con
tain
 
at
 
least
 
one
 
set
 
of
m
linearly
 
indep
enden
t
 
columns.
 
This
condition
 
is
 
b
oth
 
necessary
 
and
 
suﬃcient
 
for
 
equation
 
2.11
 
to
 
hav
e
 
a
 
solution
 
for
ev
ery
 
v
alue
 
of
b
.
 
Note
 
that
 
the
 
requirement
 
is
 
for
 
a
 
set
 
to
 
hav
e
 
exactly
m
linearly
indep
enden
t
 
columns,
 
not
 
at
 
least
m
.
 
No
 
set
 
of
m
-dimensional
 
vectors
 
can
 
hav
e
more
 
than
m
m
utually
 
linearly
 
indep
enden
t
 
columns,
 
but
 
a
 
matrix
 
with
 
more
 
than
m
 
columns
 
may
 
hav
e
 
more
 
than
 
one
 
such
 
set.
F
or
 
the
 
matrix
 
to
 
hav
e
 
an
 
inv
erse,
 
w
e
 
additionally
 
need
 
to
 
ensure
 
that
 
equa-
tion
 
2.11
 
has
 
at
 
most
 
one
 
solution
 
for
 
each
 
v
alue
 
of
b
.
 
T
o
 
do
 
so,
 
w
e
 
need
 
to
 
mak
e
certain
 
that
 
the
 
matrix
 
has
 
at
 
most
m
columns.
 
Otherwise
 
there
 
is
 
more
 
than
 
one
w
a
y
 
of
 
parametrizing
 
each
 
solution.
T
ogether,
 
this
 
means
 
that
 
the
 
matrix
 
m
ust
 
b
e
square
,
 
that
 
is,
 
we
 
require
 
that
m
=
n
and
 
that
 
all
 
the
 
columns
 
b
e
 
linearly
 
indep
enden
t.
 
A
 
square
 
matrix
 
with
linearly
 
dep
endent
 
columns
 
is
 
known
 
as
 
singular
.
If
A
is
 
not
 
square
 
or
 
is
 
square
 
but
 
singular,
 
solving
 
the
 
equation
 
is
 
still
 
p
ossible,
but
 
we
 
cannot
 
use
 
the
 
metho
d
 
of
 
matrix
 
inv
ersion
 
to
 
ﬁnd
 
the
 
solution.
36


CHAPTER
 
2.
 
LINEAR
 
ALGEBRA
So
 
far
 
we
 
ha
v
e
 
discussed
 
matrix
 
inv
erses
 
as
 
b
eing
 
multiplied
 
on
 
the
 
left.
 
It
 
is
also
 
p
ossible
 
to
 
deﬁne
 
an
 
inv
erse
 
that
 
is
 
m
ultiplied
 
on
 
the
 
right:
AA
−
1
= 
I
.
 
(2.29)
F
or
 
square
 
matrices,
 
the
 
left
 
inv
erse
 
and
 
righ
t
 
in
v
erse
 
are
 
equal.
2.5
 
Norms
Sometimes
 
w
e
 
need
 
to
 
measure
 
the
 
size
 
of
 
a
 
vector.
 
In
 
machine
 
learning,
 
we
 
usually
measure
 
the
 
size
 
of
 
vectors
 
using
 
a
 
function
 
called
 
a
norm
.
 
F
ormally
,
 
the
L
p
norm
is
 
given
 
by
||
x
||
p
=


i
|
x
i
|
p

1
p
(2.30)
for
 
p
 
∈
 
R
,
 
p
 
≥
 
1
.
Norms,
 
including
 
the
L
p
norm,
 
are
 
functions
 
mapping
 
v
ectors
 
to
 
non-negative
v
alues.
 
On
 
an
 
intuitiv
e
 
level,
 
the
 
norm
 
of
 
a
 
v
ector
x
measures
 
the
 
distance
 
from
the
 
origin
 
to
 
the
 
p
oint
x
.
 
More
 
rigorously
,
 
a
 
norm
 
is
 
any
 
function
f
that
 
satisﬁes
the
 
following
 
prop
erties:
•
 
f
 
(
x
) = 0 
⇒
 
x
 
= 
0
•
 
f
 
(
x
 
+
 
y
) 
≤
 
f
 
(
x
)
 
+
 
f
(
y
)
 
(the
 
triangle
 
inequalit
y
)
•
 
∀
α
 
∈
 
R
,
 
f
(
α
x
) = 
|
α
|
f
(
x
)
The
L
2
norm,
 
with
p
= 2
,
 
is
 
kno
wn
 
as
 
the
Euclidean
 
norm
,
 
whic
h
 
is
 
simply
the
 
Euclidean
 
distance
 
from
 
the
 
origin
 
to
 
the
 
p
oin
t
 
iden
tiﬁed
 
b
y
x
.
 
The
L
2
norm
is
 
used
 
so
 
frequently
 
in
 
mac
hine
 
learning
 
that
 
it
 
is
 
often
 
denoted
 
simply
 
as
||
x
||
,
with
 
the
 
subscript
 
2
 
omitted. It
 
is
 
also
 
common
 
to
 
measure
 
the
 
size
 
of
 
a
 
v
ector
using
 
the
 
squared
 
L
2
norm,
 
which
 
can
 
b
e
 
calculated
 
simply
 
as
 
x

x
.
The
 
squared
L
2
norm
 
is
 
more
 
con
v
enient
 
to
 
work
 
with
 
mathematically
 
and
computationally
 
than
 
the
L
2
norm
 
itself.
 
F
or
 
example,
 
eac
h
 
deriv
ative
 
of
 
the
squared
L
2
norm
 
with
 
resp
ect
 
to
 
eac
h
 
elemen
t
 
of
x
dep
ends
 
only
 
on
 
the
 
corre-
sp
onding
 
element
 
of
x
,
 
while
 
all
 
the
 
deriv
atives
 
of
 
the
L
2
norm
 
dep
end
 
on
 
the
en
tire
 
v
ector.
 
In
 
many
 
contexts,
 
the
 
squared
L
2
norm
 
ma
y
 
b
e
 
undesirable
 
b
ecause
it
 
increases
 
very
 
slowly
 
near
 
the
 
origin.
 
In
 
several
 
machine
 
learning
 
applications,
 
it
is
 
imp
ortan
t
 
to
 
discriminate
 
b
et
w
een
 
elemen
ts
 
that
 
are
 
exactly
 
zero
 
and
 
elemen
ts
that
 
are
 
small
 
but
 
nonzero.
 
In
 
these
 
cases,
 
we
 
turn
 
to
 
a
 
function
 
that
 
gro
ws
 
at
 
the
37


CHAPTER
 
2.
 
LINEAR
 
ALGEBRA
same
 
rate
 
in
 
all
 
lo
cations,
 
but
 
that
 
retains
 
mathematical
 
simplicit
y:
 
the
L
1
norm.
The
 
L
1
norm
 
may
 
b
e
 
simpliﬁed
 
to
||
x
||
1
=

i
|
x
i
|
.
 
(2.31)
The
 
L
1
norm
 
is
 
commonly
 
used
 
in
 
machine
 
learning
 
when
 
the
 
diﬀerence
 
b
et
w
een
zero
 
and
 
nonzero
 
elements
 
is
 
very
 
imp
ortant.
 
Every
 
time
 
an
 
elemen
t
 
of
x
mo
v
es
a
w
a
y
 
from
 
0
 
by
 

,
 
the
 
L
1
norm
 
increases
 
by
 

.
W
e
 
sometimes
 
measure
 
the
 
size
 
of
 
the
 
vector
 
b
y
 
counting
 
its
 
num
b
er
 
of
 
nonzero
elemen
ts.
 
Some
 
authors
 
refer
 
to
 
this
 
function
 
as
 
the
 
“
L
0
norm,”
 
but
 
this
 
is
 
incorrect
terminology
. The
 
n
um
b
er
 
of
 
nonzero
 
entries
 
in
 
a
 
vector
 
is
 
not
 
a
 
norm,
 
b
ecause
scaling
 
the
 
vector
 
by
α
do
es
 
not
 
change
 
the
 
num
b
er
 
of
 
nonzero
 
entries.
 
The
L
1
norm
 
is
 
often
 
used
 
as
 
a
 
substitute
 
for
 
the
 
n
um
b
er
 
of
 
nonzero
 
entries.
One
 
other
 
norm
 
that
 
commonly
 
arises
 
in
 
mac
hine
 
learning
 
is
 
the
L
∞
norm,
also
 
known
 
as
 
the
max
 
norm
.
 
This
 
norm
 
simpliﬁes
 
to
 
the
 
absolute
 
v
alue
 
of
 
the
elemen
t
 
with
 
the
 
largest
 
magnitude
 
in
 
the
 
vector,
||
x
||
∞
= max
i
|
x
i
|
.
 
(2.32)
Sometimes
 
we
 
ma
y
 
also
 
wish
 
to
 
measure
 
the
 
size
 
of
 
a
 
matrix.
 
In
 
the
 
context
of
 
deep
 
learning,
 
the
 
most
 
common
 
w
a
y
 
to
 
do
 
this
 
is
 
with
 
the
 
otherwise
 
obscure
F
robenius
 
norm
:
||
A
||
F
=


i,j
A
2
i,j
,
 
(2.33)
whic
h
 
is
 
analogous
 
to
 
the
 
L
2
norm
 
of
 
a
 
vector.
The
 
dot
 
pro
duct
 
of
 
t
w
o
 
vectors
 
can
 
b
e
 
rewritten
 
in
 
terms
 
of
 
norms.
 
Sp
eciﬁcally
,
x

y
 
= 
||
x
||
2
||
y
||
2
cos
 
θ
,
 
(2.34)
where
 
θ
 
is
 
the
 
angle
 
b
etw
een
 
x
 
and
 
y
.
2.6
 
Sp
ecial
 
Kinds
 
of
 
Matrices
 
and
 
V
ectors
Some
 
sp
ecial
 
kinds
 
of
 
matrices
 
and
 
vectors
 
are
 
particularly
 
useful.
Diagonal
matrices
 
consist
 
mostly
 
of
 
zeros
 
and
 
hav
e
 
nonzero
 
entries
 
only
 
along
the
 
main
 
diagonal. F
ormally
,
 
a
 
matrix
D
is
 
diagonal
 
if
 
and
 
only
 
if
D
i,j
=
 
0
 
for
all
i
 

=
j
. W
e
 
hav
e
 
already
 
seen
 
one
 
example
 
of
 
a
 
diagonal
 
matrix: the
 
identit
y
38


CHAPTER
 
2.
 
LINEAR
 
ALGEBRA
matrix,
 
where
 
all
 
the
 
diagonal
 
entries
 
are
 
1.
 
W
e
 
write
diag
(
v
)
 
to
 
denote
 
a
 
square
diagonal
 
matrix
 
whose
 
diagonal
 
en
tries
 
are
 
giv
en
 
by
 
the
 
entries
 
of
 
the
 
vector
v
.
Diagonal
 
matrices
 
are
 
of
 
interest
 
in
 
part
 
b
ecause
 
m
ultiplying
 
b
y
 
a
 
diagonal
 
matrix
is
 
computationally
 
eﬃcient.
 
T
o
 
compute
diag
(
v
)
x
,
 
w
e
 
only
 
need
 
to
 
scale
 
eac
h
elemen
t
x
i
b
y
v
i
.
 
In
 
other
 
words,
diag
(
v
)
x
=
v
 

 
x
.
 
In
v
erting
 
a
 
square
 
diagonal
matrix
 
is
 
also
 
eﬃcient.
 
The
 
inv
erse
 
exists
 
only
 
if
 
every
 
diagonal
 
entry
 
is
 
nonzero,
and
 
in
 
that
 
case,
diag
(
v
)
−
1
=
diag
([1
/v
1
,
 
.
 
.
 
.
 
,
1
/v
n
]

)
.
 
In
 
man
y
 
cases,
 
w
e
 
may
deriv
e
 
some
 
general
 
mac
hine
 
learning
 
algorithm
 
in
 
terms
 
of
 
arbitrary
 
matrices
but
 
obtain
 
a
 
less
 
exp
ensive
 
(and
 
less
 
descriptive)
 
algorithm
 
by
 
restricting
 
some
matrices
 
to
 
b
e
 
diagonal.
Not
 
all
 
diagonal
 
matrices
 
need
 
b
e
 
square.
 
It
 
is
 
p
ossible
 
to
 
construct
 
a
 
rectangular
diagonal
 
matrix.
 
Nonsquare
 
diagonal
 
matrices
 
do
 
not
 
ha
ve
 
inv
erses,
 
but
 
we
 
can
still
 
multiply
 
by
 
them
 
cheaply
.
 
F
or
 
a
 
nonsquare
 
diagonal
 
matrix
D
,
 
the
 
pro
duct
D
x
will
 
inv
olve
 
scaling
 
each
 
element
 
of
x
and
 
either
 
concatenating
 
some
 
zeros
 
to
the
 
result,
 
if
D
is
 
taller
 
than
 
it
 
is
 
wide,
 
or
 
discarding
 
some
 
of
 
the
 
last
 
elemen
ts
 
of
the
 
vector,
 
if
 
D
 
is
 
wider
 
than
 
it
 
is
 
tall.
A
 
symmetric
 
matrix
 
is
 
any
 
matrix
 
that
 
is
 
equal
 
to
 
its
 
own
 
transp
ose:
A
 
= 
A

.
 
(2.35)
Symmetric
 
matrices
 
often
 
arise
 
when
 
the
 
entries
 
are
 
generated
 
b
y
 
some
 
function
 
of
t
w
o
 
argumen
ts
 
that
 
do
es
 
not
 
dep
end
 
on
 
the
 
order
 
of
 
the
 
arguments.
 
F
or
 
example,
if
A
is
 
a
 
matrix
 
of
 
distance
 
measuremen
ts,
 
with
A
i,j
giving
 
the
 
distance
 
from
 
p
oint
i
 
to
 
p
oint
 
j
,
 
then
 
A
i,j
= 
A
j,i
b
ecause
 
distance
 
functions
 
are
 
symmetric.
A
 
unit
 
v
ector
 
is
 
a
 
vector
 
with
 
unit
 
norm
:
||
x
||
2
= 1
.
 
(2.36)
A
 
vector
x
and
 
a
 
vector
y
are
orthogonal
to
 
each
 
other
 
if
x

y
= 0
.
 
If
 
b
oth
v
ectors
 
ha
v
e
 
nonzero
 
norm,
 
this
 
means
 
that
 
they
 
are
 
at
 
a
 
90
 
degree
 
angle
 
to
 
each
other.
 
In
R
n
,
 
at
 
most
n
v
ectors
 
may
 
b
e
 
m
utually
 
orthogonal
 
with
 
nonzero
 
norm.
If
 
the
 
vectors
 
not
 
only
 
are
 
orthogonal
 
but
 
also
 
ha
ve
 
unit
 
norm,
 
we
 
call
 
them
orthonormal
.
An
orthogonal
 
matrix
is
 
a
 
square
 
matrix
 
whose
 
ro
ws
 
are
 
mutually
 
orthonor-
mal
 
and
 
whose
 
columns
 
are
 
mutually
 
orthonormal:
A

A
 
= 
AA

= 
I
.
 
(2.37)
This
 
implies
 
that
A
−
1
= 
A

,
 
(2.38)
39


CHAPTER
 
2.
 
LINEAR
 
ALGEBRA
so
 
orthogonal
 
matrices
 
are
 
of
 
interest
 
b
ecause
 
their
 
in
v
erse
 
is
 
v
ery
 
cheap
 
to
 
compute.
P
a
y
 
careful
 
atten
tion
 
to
 
the
 
deﬁnition
 
of
 
orthogonal
 
matrices.
 
Coun
terintuitiv
ely
,
their
 
rows
 
are
 
not
 
merely
 
orthogonal
 
but
 
fully
 
orthonormal.
 
There
 
is
 
no
 
sp
ecial
term
 
for
 
a
 
matrix
 
whose
 
rows
 
or
 
columns
 
are
 
orthogonal
 
but
 
not
 
orthonormal.
2.7
 
Eigendecomp
osition
Man
y
 
mathematical
 
ob
jects
 
can
 
b
e
 
understo
o
d
 
b
etter
 
by
 
breaking
 
them
 
in
to
constituen
t
 
parts,
 
or
 
ﬁnding
 
some
 
prop
erties
 
of
 
them
 
that
 
are
 
universal,
 
not
 
caused
b
y
 
the
 
wa
y
 
we
 
choose
 
to
 
represen
t
 
them.
F
or
 
example,
 
in
tegers
 
can
 
b
e
 
decomposed
 
into
 
prime
 
factors.
 
The
 
w
ay
 
w
e
represen
t
 
the
 
num
b
er
 
12
 
will
 
change
 
dep
ending
 
on
 
whether
 
we
 
write
 
it
 
in
 
base
 
ten
or
 
in
 
binary
,
 
but
 
it
 
will
 
alwa
ys
 
b
e
 
true
 
that
 
12
 
=
 
2
×
2
×
3
.
 
F
rom
 
this
 
representation
w
e
 
can
 
conclude
 
useful
 
prop
erties,
 
for
 
example,
 
that
 
12
 
is
 
not
 
divisible
 
by
 
5
,
 
and
that
 
any
 
integer
 
multiple
 
of
 
12
 
will
 
b
e
 
divisible
 
by
 
3
.
Muc
h
 
as
 
w
e
 
can
 
disco
v
er
 
something
 
ab
out
 
the
 
true
 
nature
 
of
 
an
 
in
teger
 
b
y
decomp
osing
 
it
 
into
 
prime
 
factors,
 
we
 
can
 
also
 
decomp
ose
 
matrices
 
in
 
wa
ys
 
that
sho
w
 
us
 
information
 
ab
out
 
their
 
functional
 
prop
erties
 
that
 
is
 
not
 
obvious
 
from
 
the
represen
tation
 
of
 
the
 
matrix
 
as
 
an
 
array
 
of
 
elements.
One
 
of
 
the
 
most
 
widely
 
used
 
kinds
 
of
 
matrix
 
decomp
osition
 
is
 
called
eigen-
decomp
osition
,
 
in
 
which
 
w
e
 
decomp
ose
 
a
 
matrix
 
into
 
a
 
set
 
of
 
eigen
vectors
 
and
eigen
v
alues.
An
eigen
vector
of
 
a
 
square
 
matrix
A
is
 
a
 
nonzero
 
v
ector
v
suc
h
 
that
 
multi-
plication
 
by
 
A
 
alters
 
only
 
the
 
scale
 
of
 
v
:
Av
 
= 
λ
v
.
 
(2.39)
The
 
scalar
λ
is
 
kno
wn
 
as
 
the
eigen
v
alue
corresp
onding
 
to
 
this
 
eigen
vector.
 
(One
can
 
also
 
ﬁnd
 
a
left
 
eigen
v
ector
suc
h
 
that
v

A
=
λ
v

, but
 
w
e
 
are
 
usually
concerned
 
with
 
right
 
eigenv
ectors.)
If
v
is
 
an
 
eigenv
ector
 
of
A
,
 
then
 
so
 
is
 
any
 
rescaled
 
vector
s
v
for
s
 
∈
 
R
,
 
s
 

= 0
.
Moreo
v
er,
s
v
still
 
has
 
the
 
same
 
eigen
v
alue.
 
F
or
 
this
 
reason,
 
we
 
usually
 
lo
ok
 
only
for
 
unit
 
eigenv
ectors.
Supp
ose
 
that
 
a
 
matrix
A
has
n
linearly
 
indep
endent
 
eigenv
ectors
{
v
(1)
,
 
.
 
.
 
.
 
,
v
(
n
)
}
with
 
corresp
onding
 
eigen
v
alues
{
λ
1
,
 
.
 
.
 
.
 
,
 
λ
n
}
. W
e
 
may
 
concatenate
 
all
 
the
eigen
v
ectors
 
to
 
form
 
a
 
matrix
V
with
 
one
 
eigen
v
ector
 
p
er
 
column:
V
= [
v
(1)
,
 
.
 
.
 
.
 
,
v
(
n
)
]
.
 
Lik
ewise,
 
we
 
can
 
concatenate
 
the
 
eigenv
alues
 
to
 
form
 
a
 
vector
λ
= [
λ
1
,
 
.
 
.
 
.
 
,
40


CHAPTER
 
2.
 
LINEAR
 
ALGEBRA
λ
n
]

.
 
The
 
eigendecomp
osition
 
of
 
A
 
is
 
then
 
given
 
b
y
A
 
= 
V
 
diag
(
λ
)
V
−
1
.
 
(2.40)
W
e
 
hav
e
 
seen
 
that
 
c
onstructing
 
matrices
 
with
 
sp
eciﬁc
 
eigenv
alues
 
and
 
eigen-
v
ectors
 
enables
 
us
 
to
 
stretc
h
 
space
 
in
 
desired
 
directions.
 
Y
et
 
w
e
 
often
 
w
an
t
 
to
decomp
ose
matrices
 
into
 
their
 
eigenv
alues
 
and
 
eigen
v
ectors.
 
Doing
 
so
 
can
 
help
us
 
analyze
 
certain
 
prop
erties
 
of
 
the
 
matrix,
 
muc
h
 
as
 
decomp
osing
 
an
 
integer
 
in
to
its
 
prime
 
factors
 
can
 
help
 
us
 
understand
 
the
 
b
eha
vior
 
of
 
that
 
integer.
Not
 
every
 
matrix
 
can
 
b
e
 
decomp
osed
 
into
 
eigenv
alues
 
and
 
eigen
v
ectors.
 
In
 
some
cases,
 
the
 
decomp
osition
 
exists
 
but
 
inv
olves
 
complex
 
rather
 
than
 
real
 
num
b
ers.
F
ortunately
,
 
in
 
this
 
b
o
ok,
 
w
e
 
usually
 
need
 
to
 
decomp
ose
 
only
 
a
 
sp
eciﬁc
 
class
 
of
󰤓
 
󰤓
 
󰤓
 

 

 

 



󰤓
󰤓
󰤓











󰤓
 
󰤓
 
󰤓
 

 

 

 




󰤓
󰤓
󰤓





















Figure
 
2.3:
 
An
 
example
 
of
 
the
 
eﬀect
 
of
 
eigen
vectors
 
and
 
eigenv
alues.
 
Here,
 
we
 
ha
ve
a
 
matrix
A
with
 
tw
o
 
orthonormal
 
eigenv
ectors,
v
(1)
with
 
eigenv
alue
λ
1
and
v
(2)
with
eigen
v
alue
λ
2
.
 
(L
eft)
W
e
 
plot
 
the
 
set
 
of
 
all
 
unit
 
vectors
u
 
∈
 
R
2
as
 
a
 
unit
 
circle.
 
(R
ight)
W
e
plot
 
the
 
set
 
of
 
all
 
p
oints
Au
.
 
By
 
observing
 
the
 
wa
y
 
that
A
distorts
 
the
 
unit
 
circle,
 
we
can
 
see
 
that
 
it
 
scales
 
space
 
in
 
direction
 
v
(
i
)
b
y
 
λ
i
.
41


CHAPTER
 
2.
 
LINEAR
 
ALGEBRA
matrices
 
that
 
hav
e
 
a
 
simple
 
decomp
osition.
 
Sp
eciﬁcally
,
 
ev
ery
 
real
 
symmetric
matrix
 
can
 
b
e
 
decomp
osed
 
into
 
an
 
expression
 
using
 
only
 
real-v
alued
 
eigen
v
ectors
and
 
eigenv
alues:
A
 
= 
Q
Λ
Q

,
 
(2.41)
where
Q
is
 
an
 
orthogonal
 
matrix
 
comp
osed
 
of
 
eigen
v
ectors
 
of
A
,
 
and
Λ
is
 
a
diagonal
 
matrix.
 
The
 
eigenv
alue
 
Λ
i,i
is
 
asso
ciated
 
with
 
the
 
eigenv
ector
 
in
 
column
i
of
Q
,
 
denoted
 
as
Q
:
,i
.
 
Because
Q
is
 
an
 
orthogonal
 
matrix,
 
we
 
can
 
think
 
of
A
as
scaling
 
space
 
by
 
λ
i
in
 
direction
 
v
(
i
)
.
 
See
 
ﬁgure
 
2.3
 
for
 
an
 
example.
While
 
any
 
real
 
symmetric
 
matrix
A
is
 
guaran
teed
 
to
 
hav
e
 
an
 
eigendecomp
osi-
tion,
 
the
 
eigendecomp
osition
 
may
 
not
 
b
e
 
unique.
 
If
 
any
 
tw
o
 
or
 
more
 
eigen
v
ectors
share
 
the
 
same
 
eigenv
alue,
 
then
 
any
 
set
 
of
 
orthogonal
 
vectors
 
lying
 
in
 
their
 
span
are
 
also
 
eigenv
ectors
 
with
 
that
 
eigen
v
alue,
 
and
 
we
 
could
 
equiv
alently
 
choose
 
a
Q
using
 
those
 
eigenv
ectors
 
instead.
 
By
 
conv
ention,
 
we
 
usually
 
sort
 
the
 
entries
 
of
Λ
in
 
descending
 
order.
 
Under
 
this
 
con
v
en
tion,
 
the
 
eigendecomp
osition
 
is
 
unique
 
only
if
 
all
 
the
 
eigenv
alues
 
are
 
unique.
The
 
eigendecomposition of
 
a matrix
 
tells us
 
many
 
useful facts
 
ab
out the
matrix.
 
The
 
matrix
 
is
 
singular
 
if
 
and
 
only
 
if
 
an
y
 
of
 
the
 
eigenv
alues
 
are
 
zero.
The
 
eigendecomp
osition
 
of
 
a
 
real
 
symmetric
 
matrix
 
can
 
also
 
b
e
 
used
 
to
 
optimize
quadratic
 
expressions
 
of
 
the
 
form
f
(
x
) =
x

Ax
sub
ject
 
to
||
x
||
2
= 1
.
 
Whenev
er
x
is
 
equal
 
to
 
an
 
eigenv
ector
 
of
A
,
f
tak
es
 
on
 
the
 
v
alue
 
of
 
the
 
corresp
onding
 
eigen
v
alue.
The
 
maxim
um
 
v
alue
 
of
f
within
 
the
 
constrain
t
 
region
 
is
 
the
 
maximum
 
eigen
v
alue
and
 
its
 
minimum
 
v
alue
 
within
 
the
 
constrain
t
 
region
 
is
 
the
 
minimum
 
eigenv
alue.
A
 
matrix
 
whose
 
eigen
v
alues
 
are
 
all
 
p
ositiv
e
 
is
 
called
p
ositiv
e
 
deﬁnite
.
 
A
matrix
 
whose
 
eigen
v
alues
 
are
 
all
 
p
ositive
 
or
 
zero
 
v
alued
 
is
 
called
p
ositiv
e
 
semideﬁ-
nite
.
 
Lik
ewise,
 
if
 
all
 
eigenv
alues
 
are
 
negative,
 
the
 
matrix
 
is
negativ
e
 
deﬁnite
,
 
and
if
 
all
 
eigenv
alues
 
are
 
negative
 
or
 
zero
 
v
alued,
 
it
 
is
negativ
e
 
semideﬁnite
.
 
P
ositive
semideﬁnite
 
matrices
 
are
 
interesting
 
b
ecause
 
they
 
guaran
tee
 
that
∀
x
,
 
x

Ax
 
≥
0
.
P
ositiv
e
 
deﬁnite
 
matrices
 
additionally
 
guarantee
 
that
 
x

Ax
 
= 0 
⇒
 
x
 
= 
0
.
2.8
 
Singular
 
V
alue
 
Decomp
osition
In
 
section
 
2.7
,
 
we
 
saw
 
ho
w
 
to
 
decomp
ose
 
a
 
matrix
 
into
 
eigen
v
ectors
 
and
 
eigenv
alues.
The
singular
 
v
alue
 
decomp
osition
(SVD)
 
provides
 
another
 
wa
y
 
to
 
factorize
a
 
matrix,
 
in
to
singular
 
v
ectors
and
singular
 
v
alues
. The
 
SVD
 
enables
 
us
 
to
disco
v
er
 
some
 
of
 
the
 
same
 
kind
 
of
 
information
 
as
 
the
 
eigendecomp
osition
 
reveals;
ho
w
ev
er,
 
the
 
SVD
 
is
 
more
 
generally
 
applicable.
 
Every
 
real
 
matrix
 
has
 
a
 
singular
v
alue
 
decomp
osition,
 
but
 
the
 
same
 
is
 
not
 
true
 
of
 
the
 
eigen
v
alue
 
decomp
osition.
42


CHAPTER
 
2.
 
LINEAR
 
ALGEBRA
F
or
 
example,
 
if
 
a
 
matrix
 
is
 
not
 
square,
 
the
 
eigendecomp
osition
 
is
 
not
 
deﬁned,
 
and
w
e
 
must
 
use
 
a
 
singular
 
v
alue
 
decomp
osition
 
instead.
Recall
 
that
 
the
 
eigendecomp
osition
 
inv
olves
 
analyzing
 
a
 
matrix
A
to
 
discov
er
a
 
matrix
V
of
 
eigen
v
ectors
 
and
 
a
 
vector
 
of
 
eigenv
alues
λ
suc
h
 
that
 
we
 
can
 
rewrite
A
 
as
A
 
= 
V
 
diag
(
λ
)
V
−
1
.
 
(2.42)
The
 
singular
 
v
alue
 
decomp
osition
 
is
 
similar,
 
except
 
this
 
time
 
w
e
 
will
 
write
A
as
 
a
 
pro
duct
 
of
 
three
 
matrices:
A
 
= 
U
 
D
V

.
 
(2.43)
Supp
ose
 
that
A
is
 
an
m
 
×
n
matrix.
 
Then
U
is
 
deﬁned
 
to
 
b
e
 
an
m
 
×
m
matrix,
D
 
to
 
b
e
 
an
 
m
 
×
 
n
 
matrix,
 
and
 
V
 
to
 
b
e
 
an
 
n
 
×
 
n
 
matrix.
Eac
h
 
of
 
these
 
matrices
 
is
 
deﬁned
 
to
 
hav
e
 
a
 
sp
ecial
 
structure.
 
The
 
matrices
U
and
V
are
 
b
oth
 
deﬁned
 
to
 
b
e
 
orthogonal
 
matrices.
 
The
 
matrix
D
is
 
deﬁned
 
to
 
b
e
a
 
diagonal
 
matrix.
 
Note
 
that
 
D
 
is
 
not
 
necessarily
 
square.
The
 
elemen
ts
 
along
 
the
 
diagonal
 
of
D
are
 
kno
wn
 
as
 
the
singular
 
v
alues
of
the
 
matrix
A
.
 
The
 
columns
 
of
U
are
 
known
 
as
 
the
left-singular
 
vectors
.
 
The
columns
 
of
 
V
 
are
 
known
 
as
 
as
 
the
 
righ
t-singular
 
v
ectors
.
W
e
 
can
 
actually
 
in
terpret
 
the
 
singular
 
v
alue
 
decomp
osition
 
of
A
in
 
terms
 
of
the
 
eigendecomp
osition
 
of
 
functions
 
of
A
.
 
The
 
left-singular
 
vectors
 
of
A
are
 
the
eigen
v
ectors
 
of
AA

.
 
The
 
righ
t-singular
 
vectors
 
of
A
are
 
the
 
eigenv
ectors
 
of
A

A
.
The
 
nonzero
 
singular
 
v
alues
 
of
A
are
 
the
 
square
 
ro
ots
 
of
 
the
 
eigenv
alues
 
of
A

A
.
The
 
same
 
is
 
true
 
for
 
AA

.
P
erhaps
 
the
 
most
 
useful
 
feature
 
of
 
the
 
SVD
 
is
 
that
 
w
e
 
can
 
use
 
it
 
to
 
partially
generalize
 
matrix
 
inv
ersion
 
to
 
nonsquare
 
matrices,
 
as
 
we
 
will
 
see
 
in
 
the
 
next
 
section.
2.9
 
The
 
Mo
ore-P
enrose
 
Pseudoin
v
erse
Matrix
 
in
v
ersion
 
is
 
not
 
deﬁned
 
for
 
matrices
 
that
 
are
 
not
 
square.
 
Supp
ose
 
we
 
w
ant
to
 
make
 
a
 
left-inv
erse
 
B
 
of
 
a
 
matrix
 
A
 
so
 
that
 
we
 
can
 
solve
 
a
 
linear
 
equation
Ax
 
= 
y
 
(2.44)
b
y
 
left-multiplying
 
each
 
side
 
to
 
obtain
x
 
= 
B
y
.
 
(2.45)
43


CHAPTER
 
2.
 
LINEAR
 
ALGEBRA
Dep
ending
 
on
 
the
 
structure
 
of
 
the
 
problem,
 
it
 
ma
y
 
not
 
b
e
 
p
ossible
 
to
 
design
 
a
unique
 
mapping
 
from
 
A
 
to
 
B
.
If
A
is
 
taller
 
than
 
it
 
is
 
wide,
 
then
 
it
 
is
 
p
ossible
 
for
 
this
 
equation
 
to
 
hav
e
no
 
solution.
 
If
A
is
 
wider
 
than
 
it
 
is
 
tall,
 
then
 
there
 
could
 
b
e
 
m
ultiple
 
possible
solutions.
The
Mo
ore-P
enrose
 
pseudoinv
erse
enables
 
us
 
to
 
make
 
some
 
headwa
y
 
in
these
 
cases.
 
The
 
pseudoinv
erse
 
of
 
A
 
is
 
deﬁned
 
as
 
a
 
matrix
A
+
=
 
lim
α

0
(
A

A
 
+
 
α
I
)
−
1
A

.
 
(2.46)
Practical
 
algorithms
 
for
 
computing
 
the
 
pseudoinv
erse
 
are
 
based
 
not
 
on
 
this
 
deﬁni-
tion,
 
but
 
rather
 
on
 
the
 
formula
A
+
= 
V
 
D
+
U

,
 
(2.47)
where
U
,
D
and
V
are
 
the
 
singular
 
v
alue
 
decomp
osition
 
of
A
,
 
and
 
the
 
pseudoinv
erse
D
+
of
 
a
 
diagonal
 
matrix
D
is
 
obtained
 
by
 
taking
 
the
 
reciprocal
 
of
 
its
 
nonzero
elemen
ts
 
then
 
taking
 
the
 
transp
ose
 
of
 
the
 
resulting
 
matrix.
When
A
has
 
more
 
columns
 
than
 
rows,
 
then
 
solving
 
a
 
linear
 
equation
 
using
 
the
pseudoin
v
erse
 
provides
 
one
 
of
 
the
 
many
 
p
ossible
 
solutions.
 
Sp
eciﬁcally
,
 
it
 
pro
vides
the
 
solution
x
=
A
+
y
with
 
minimal
 
Euclidean
 
norm
||
x
||
2
among
 
all
 
possible
solutions.
When
A
has
 
more
 
rows
 
than
 
columns,
 
it
 
is
 
p
ossible
 
for
 
there
 
to
 
b
e
 
no
 
solution.
In
 
this
 
case,
 
using
 
the
 
pseudoinv
erse
 
gives
 
us
 
the
x
for
 
which
Ax
is
 
as
 
close
 
as
p
ossible
 
to
 
y
 
in
 
terms
 
of
 
Euclidean
 
norm
 
||
Ax
 
−
 
y
||
2
.
2.10
 
The
 
T
race
 
Op
erator
The
 
trace
 
op
erator
 
gives
 
the
 
sum
 
of
 
all
 
the
 
diagonal
 
entries
 
of
 
a
 
matrix:
T
r(
A
) =

i
A
i,i
.
 
(2.48)
The
 
trace
 
op
erator
 
is
 
useful
 
for
 
a
 
v
ariety
 
of
 
reasons.
 
Some
 
op
erations
 
that
 
are
diﬃcult
 
to
 
sp
ecify
 
without
 
resorting
 
to
 
summation
 
notation
 
can
 
b
e
 
sp
eciﬁed
 
using
matrix
 
pro
ducts
 
and
 
the
 
trace
 
op
erator.
 
F
or
 
example,
 
the
 
trace
 
op
erator
 
provides
an
 
alternative
 
wa
y
 
of
 
writing
 
the
 
F
rob
enius
 
norm
 
of
 
a
 
matrix:
||
A
||
F
=

T
r(
AA

)
.
 
(2.49)
44


CHAPTER
 
2.
 
LINEAR
 
ALGEBRA
W
riting
 
an
 
expression
 
in
 
terms
 
of
 
the
 
trace
 
op
erator
 
op
ens
 
up
 
opp
ortunities
 
to
manipulate
 
the
 
expression
 
using
 
man
y
 
useful
 
iden
tities. F
or
 
example,
 
the
 
trace
op
erator
 
is
 
inv
ariant
 
to
 
the
 
transp
ose
 
op
erator:
T
r(
A
) = T
r(
A

)
.
 
(2.50)
The
 
trace
 
of
 
a
 
square
 
matrix
 
comp
osed
 
of
 
many
 
factors
 
is
 
also
 
in
v
ariant
 
to
mo
ving
 
the
 
last
 
factor
 
into
 
the
 
ﬁrst
 
p
osition,
 
if
 
the
 
shap
es
 
of
 
the
 
corresp
onding
matrices
 
allow
 
the
 
resulting
 
pro
duct
 
to
 
b
e
 
deﬁned:
T
r(
AB
C
) = T
r(
C
AB
) = T
r(
B
C
A
)
 
(2.51)
or
 
more
 
generally
,
T
r(
n

i
=1
F
(
i
)
) = T
r(
F
(
n
)
n
−
1

i
=1
F
(
i
)
)
.
 
(2.52)
This
 
in
v
ariance
 
to
 
cyclic
 
p
ermutation
 
holds
 
ev
en
 
if
 
the
 
resulting
 
pro
duct
 
has
 
a
diﬀeren
t
 
shap
e.
 
F
or
 
example,
 
for
 
A
 
∈
 
R
m
×
n
and
 
B
 
∈
 
R
n
×
m
,
 
we
 
hav
e
T
r(
AB
) = T
r(
B
A
)
 
(2.53)
ev
en
 
though
 
AB
 
∈
 
R
m
×
m
and
 
B
A
 
∈
 
R
n
×
n
.
Another
 
useful
 
fact
 
to
 
keep
 
in
 
mind
 
is
 
that
 
a
 
scalar
 
is
 
its
 
own
 
trace:
a
=
T
r
(
a
)
.
2.11
 
The
 
Determinan
t
The
 
determinan
t
 
of
 
a
 
square
 
matrix,
 
denoted
det
(
A
)
,
 
is
 
a
 
function
 
that
 
maps
matrices
 
to
 
real
 
scalars.
 
The
 
determinan
t
 
is
 
equal to
 
the
 
product of
 
all
 
the
eigen
v
alues
 
of
 
the
 
matrix.
 
The
 
absolute
 
v
alue
 
of
 
the
 
determinant
 
can
 
b
e
 
though
t
of
 
as
 
a
 
measure
 
of
 
ho
w
 
muc
h
 
multiplication
 
by
 
the
 
matrix
 
expands
 
or
 
contracts
space.
 
If
 
the
 
determinant
 
is
 
0,
 
then
 
space
 
is
 
contracted
 
completely
 
along
 
at
 
least
one
 
dimension,
 
causing
 
it
 
to
 
lose
 
all
 
its
 
v
olume.
 
If
 
the
 
determinan
t
 
is
 
1,
 
then
 
the
transformation
 
preserves
 
volume.
2.12
 
Example:
 
Principal
 
Comp
onents
 
Analysis
One
 
simple
 
machine
 
learning
 
algorithm,
principal
 
comp
onents
 
analysis
(PCA),
can
 
b
e
 
derived
 
using
 
only
 
kno
wledge
 
of
 
basic
 
linear
 
algebra.
45


CHAPTER
 
2.
 
LINEAR
 
ALGEBRA
Supp
ose
 
we
 
hav
e
 
a
 
collection
 
of
 
m
 
p
oin
ts
 
{
x
(1)
,
 
.
 
.
 
.
 
,
 
x
(
m
)
}
 
in
 
R
n
and
 
we
 
wan
t
to
 
apply
 
lossy
 
compression
 
to
 
these
 
p
oints.
 
Lossy
 
compression
 
means
 
storing
 
the
p
oin
ts
 
in
 
a
 
wa
y
 
that
 
requires
 
less
 
memory
 
but
 
may
 
lose
 
some
 
precision.
 
W
e
 
w
an
t
to
 
lose
 
as
 
little
 
precision
 
as
 
p
ossible.
One
 
wa
y
 
we
 
can
 
enco
de
 
these
 
p
oints
 
is
 
to
 
represent
 
a
 
low
er-dimensional
 
v
ersion
of
 
them.
 
F
or
 
each
 
p
oint
x
(
i
)
∈
 
R
n
w
e
 
will
 
ﬁnd
 
a
 
corresp
onding
 
co
de
 
vector
c
(
i
)
∈
 
R
l
.
If
l
is
 
smaller
 
than
n
,
 
storing
 
the
 
co
de
 
p
oin
ts
 
will
 
tak
e
 
less
 
memory
 
than
 
storing
 
the
original
 
data.
 
W
e
 
will
 
w
an
t
 
to
 
ﬁnd
 
some
 
enco
ding
 
function
 
that
 
pro
duces
 
the
 
co
de
for
 
an
 
input,
f
(
x
) =
c
,
 
and
 
a
 
deco
ding
 
function
 
that
 
pro
duces
 
the
 
reconstructed
input
 
given
 
its
 
co
de,
 
x
 
≈
 
g
(
f
 
(
x
))
.
PCA
 
is
 
deﬁned
 
b
y
 
our
 
choice
 
of
 
the
 
deco
ding
 
function.
 
Sp
eciﬁcally
,
 
to
 
make
 
the
deco
der
 
v
ery
 
simple,
 
we
 
c
ho
ose
 
to
 
use
 
matrix
 
multiplication
 
to
 
map
 
the
 
co
de
 
back
in
to
 
R
n
.
 
Let
 
g
(
c
) = 
Dc
,
 
where
 
D
 
∈
 
R
n
×
l
is
 
the
 
matrix
 
deﬁning
 
the
 
deco
ding.
Computing
 
the
 
optimal
 
co
de
 
for
 
this
 
deco
der
 
could
 
b
e
 
a
 
diﬃcult
 
problem.
 
T
o
k
eep
 
the
 
enco
ding
 
problem
 
easy
,
 
PCA
 
constrains
 
the
 
columns
 
of
D
to
 
b
e
 
orthogonal
to
 
each
 
other.
 
(Note
 
that
D
is
 
still
 
not
 
technically
 
“an
 
orthogonal
 
matrix”
 
unless
l
 
= 
n
.)
With
 
the
 
problem
 
as
 
describ
ed
 
so
 
far,
 
man
y
 
solutions
 
are
 
p
ossible,
 
b
ecause
 
we
can
 
increase
 
the
 
scale
 
of
D
:
,i
if
 
w
e
 
decrease
c
i
prop
ortionally
 
for
 
all
 
p
oin
ts.
 
T
o
 
give
the
 
problem
 
a
 
unique
 
solution,
 
w
e
 
constrain
 
all
 
the
 
columns
 
of
D
to
 
ha
ve
 
unit
norm.
In
 
order
 
to
 
turn
 
this
 
basic
 
idea
 
into
 
an
 
algorithm
 
we
 
can
 
implement,
 
the
 
ﬁrst
thing
 
w
e
 
need
 
to
 
do
 
is
 
ﬁgure
 
out
 
how
 
to
 
generate
 
the
 
optimal
 
co
de
 
p
oint
c
∗
for
eac
h
 
input
 
p
oint
x
.
 
One
 
wa
y
 
to
 
do
 
this
 
is
 
to
 
minimize
 
the
 
distance
 
b
etw
een
 
the
input
 
p
oin
t
x
and
 
its
 
reconstruction,
g
(
c
∗
)
.
 
W
e
 
can
 
measure
 
this
 
distance
 
using
 
a
norm.
 
In
 
the
 
principal
 
comp
onents
 
algorithm,
 
we
 
use
 
the
 
L
2
norm:
c
∗
= arg
 
min
c
||
x
 
−
 
g
(
c
)
||
2
.
 
(2.54)
W
e
 
can
 
switc
h
 
to
 
the
 
squared
L
2
norm
 
instead
 
of
 
using
 
the
L
2
norm
 
itself
b
ecause
 
b
oth
 
are
 
minimized
 
by
 
the
 
same
 
v
alue
 
of
c
.
 
Both
 
are
 
minimized
 
by
 
the
same
 
v
alue
 
of
c
b
ecause
 
the
L
2
norm
 
is
 
non-negative
 
and
 
the
 
squaring
 
op
eration
 
is
monotonically
 
increasing
 
for
 
non-negative
 
arguments.
c
∗
= arg
 
min
c
||
x
 
−
 
g
(
c
)
||
2
2
.
 
(2.55)
The
 
function
 
b
eing
 
minimized
 
simpliﬁes
 
to
(
x
 
−
 
g
(
c
))

(
x
 
−
 
g
(
c
))
 
(2.56)
46


CHAPTER
 
2.
 
LINEAR
 
ALGEBRA
(b
y
 
the
 
deﬁnition
 
of
 
the
 
L
2
norm,
 
equation
 
2.30
)
= 
x

x
 
−
 
x

g
(
c
)
 
−
g
(
c
)

x
 
+
 
g
(
c
)

g
(
c
)
 
(2.57)
(b
y
 
the
 
distributive
 
prop
erty)
= 
x

x
 
−
 
2
x

g
(
c
)
 
+
 
g
(
c
)

g
(
c
)
 
(2.58)
(b
ecause
 
the
 
scalar
 
g
(
c
)

x
 
is
 
equal
 
to
 
the
 
transp
ose
 
of
 
itself
).
W
e
 
can
 
now
 
c
hange
 
the
 
function
 
b
eing
 
minimized
 
again,
 
to
 
omit
 
the
 
ﬁrst
 
term,
since
 
this
 
term
 
do
es
 
not
 
dep
end
 
on
 
c
:
c
∗
= arg
 
min
c
−
2
x

g
(
c
)
 
+
 
g
(
c
)

g
(
c
)
.
 
(2.59)
T
o
 
make
 
further
 
progress,
 
we
 
m
ust
 
substitute
 
in
 
the
 
deﬁnition
 
of
 
g
(
c
)
:
c
∗
= arg
 
min
c
−
2
x

D
c
 
+
 
c

D

D
c
 
(2.60)
= arg
 
min
c
−
2
x

D
c
 
+
 
c

I
l
c
 
(2.61)
(b
y
 
the
 
orthogonality
 
and
 
unit
 
norm
 
constrain
ts
 
on
 
D
)
= arg
 
min
c
−
2
x

D
c
 
+
 
c

c
.
 
(2.62)
W
e
 
can
 
solve
 
this
 
optimization
 
problem
 
using
 
vector
 
calculus
 
(see
 
section
 
4.3
 
if
y
ou
 
do
 
not
 
know
 
how
 
to
 
do
 
this):
∇
c
(
−
2
x

D
c
 
+
 
c

c
) = 
0
 
(2.63)
−
 
2
D

x
 
+
 
2
c
 
= 
0
 
(2.64)
c
 
= 
D

x
.
 
(2.65)
This
 
mak
es
 
the
 
algorithm
 
eﬃcient: w
e
 
can
 
optimally
 
encode
x
using
 
just
 
a
matrix-v
ector
 
op
eration.
 
T
o
 
enco
de
 
a
 
vector,
 
w
e
 
apply
 
the
 
enco
der
 
function
f
(
x
) = 
D

x
.
 
(2.66)
Using
 
a
 
further
 
matrix
 
m
ultiplication,
 
w
e
 
can
 
also
 
deﬁne
 
the
 
PCA
 
reconstruction
op
eration:
r
(
x
) = 
g
 
(
f
 
(
x
)) = 
D
D

x
.
 
(2.67)
47


CHAPTER
 
2.
 
LINEAR
 
ALGEBRA
Next,
 
w
e
 
need
 
to
 
c
ho
ose
 
the
 
enco
ding
 
matrix
D
.
 
T
o
 
do
 
so,
 
we
 
revisit
 
the
 
idea
of
 
minimizing
 
the
L
2
distance
 
b
etw
een
 
inputs
 
and
 
reconstructions.
 
Since
 
we
 
will
use
 
the
 
same
 
matrix
D
to
 
deco
de
 
all
 
the
 
p
oin
ts,
 
w
e
 
can
 
no
 
longer
 
consider
 
the
p
oin
ts
 
in
 
isolation.
 
Instead,
 
we
 
must
 
minimize
 
the
 
F
rob
enius
 
norm
 
of
 
the
 
matrix
of
 
errors
 
computed
 
ov
er
 
all
 
dimensions
 
and
 
all
 
p
oin
ts:
D
∗
= arg
 
min
D


i,j

x
(
i
)
j
−
 
r
(
x
(
i
)
)
j

2
sub
ject
 
to
 
D

D
 
= 
I
l
.
 
(2.68)
T
o
 
deriv
e
 
the
 
algorithm
 
for
 
ﬁnding
D
∗
,
 
w
e
 
start
 
by
 
considering
 
the
 
case
 
where
l
= 1
. In
 
this
 
case,
D
is
 
just
 
a
 
single
 
vector,
d
.
 
Substituting
 
equation
 
2.67
 
into
equation
 
2.68
 
and
 
simplifying
 
D
 
into
 
d
,
 
the
 
problem
 
reduces
 
to
d
∗
= arg
 
min
d

i
||
x
(
i
)
−
 
dd

x
(
i
)
||
2
2
sub
ject
 
to
 
||
d
||
2
= 1
.
 
(2.69)
The
 
ab
o
v
e
 
formulation
 
is
 
the
 
most
 
direct
 
wa
y
 
of
 
p
erforming
 
the
 
substitution
 
but
is
 
not
 
the
 
most
 
stylistically
 
pleasing
 
wa
y
 
to
 
write
 
the
 
equation.
 
It
 
places
 
the
 
scalar
v
alue
d

x
(
i
)
on
 
the
 
righ
t
 
of
 
the
 
v
ector
d
.
 
Scalar
 
co
eﬃcients
 
are
 
conv
entionally
written
 
on
 
the
 
left
 
of
 
vector
 
they
 
op
erate
 
on.
 
W
e
 
therefore
 
usually
 
write
 
such
 
a
form
ula
 
as
d
∗
= arg
 
min
d

i
||
x
(
i
)
−
 
d

x
(
i
)
d
||
2
2
sub
ject
 
to
 
||
d
||
2
= 1
,
 
(2.70)
or,
 
exploiting
 
the
 
fact
 
that
 
a
 
scalar
 
is
 
its
 
o
wn
 
transp
ose,
 
as
d
∗
= arg
 
min
d

i
||
x
(
i
)
−
 
x
(
i
)

dd
||
2
2
sub
ject
 
to
 
||
d
||
2
= 1
.
 
(2.71)
The
 
reader
 
should
 
aim
 
to
 
b
ecome
 
familiar
 
with
 
suc
h
 
cosmetic
 
rearrangements.
A
t
 
this
 
p
oint,
 
it
 
can
 
b
e
 
helpful
 
to
 
rewrite
 
the
 
problem
 
in
 
terms
 
of
 
a
 
single
design
 
matrix
 
of
 
examples,
 
rather
 
than
 
as
 
a
 
sum
 
ov
er
 
separate
 
example
 
vectors.
This
 
will
 
enable
 
us
 
to
 
use
 
more
 
compact
 
notation.
 
Let
X
 
∈
 
R
m
×
n
b
e
 
the
 
matrix
deﬁned
 
by
 
stacking
 
all
 
the
 
vectors
 
describing
 
the
 
p
oin
ts,
 
suc
h
 
that
X
i,
:
=
x
(
i
)

.
W
e
 
can
 
now
 
rewrite
 
the
 
problem
 
as
d
∗
= arg
 
min
d
||
X
 
−
 
X
dd

||
2
F
sub
ject
 
to
 
d

d
 
= 1
.
 
(2.72)
Disregarding
 
the
 
constraint
 
for
 
the
 
moment,
 
we
 
can
 
simplify
 
the
 
F
rob
enius
 
norm
p
ortion
 
as
 
follows:
arg
 
min
d
||
X
 
−
 
X
dd

||
2
F
(2.73)
48


CHAPTER
 
2.
 
LINEAR
 
ALGEBRA
= arg
 
min
d
T
r


X
 
−
 
X
dd




X
 
−
 
X
dd



(2.74)
(b
y
 
equation
 
2.49
)
= arg
 
min
d
T
r(
X

X
 
−
 
X

X
dd

−
 
dd

X

X
 
+
 
dd

X

X
dd

)
 
(2.75)
= arg
 
min
d
T
r(
X

X
)
 
−
T
r(
X

X
dd

)
 
−
 
T
r(
dd

X

X
)
 
+
 
T
r(
dd

X

X
dd

)
(2.76)
= arg
 
min
d
−
T
r(
X

X
dd

)
 
−
 
T
r(
dd

X

X
)
 
+
 
T
r(
dd

X

X
dd

)
 
(2.77)
(b
ecause
 
terms
 
not
 
inv
olving
 
d
 
do
 
not
 
aﬀect
 
the
 
arg
 
min
)
= arg
 
min
d
−
2
 
T
r(
X

X
dd

)
 
+
 
T
r(
dd

X

X
dd

)
 
(2.78)
(b
ecause
 
we
 
can
 
cycle
 
the
 
order
 
of
 
the
 
matrices
 
inside
 
a
 
trace,
 
equation
 
2.52
)
= arg
 
min
d
−
2
 
T
r(
X

X
dd

)
 
+
 
T
r(
X

X
dd

dd

)
 
(2.79)
(using
 
the
 
same
 
prop
erty
 
again).
A
t
 
this
 
p
oint,
 
we
 
rein
tro
duce
 
the
 
constrain
t:
arg
 
min
d
−
2
 
T
r(
X

X
dd

)
 
+
 
T
r(
X

X
dd

dd

)
 
sub
ject
 
to
 
d

d
 
= 1
 
(2.80)
= arg
 
min
d
−
2
 
T
r(
X

X
dd

)
 
+
 
T
r(
X

X
dd

)
 
sub
ject
 
to
 
d

d
 
= 1
 
(2.81)
(due
 
to
 
the
 
constraint)
= arg
 
min
d
−
T
r(
X

X
dd

)
 
sub
ject
 
to
 
d

d
 
= 1
 
(2.82)
= arg
 
max
d
T
r(
X

X
dd

)
 
sub
ject
 
to
 
d

d
 
= 1
 
(2.83)
= arg
 
max
d
T
r(
d

X

X
d
)
 
sub
ject
 
to
 
d

d
 
= 1
.
 
(2.84)
This
 
optimization
 
problem
 
may
 
b
e
 
solv
ed
 
using
 
eigendecomp
osition.
 
Sp
eciﬁcally
,
the
 
optimal
d
is
 
given
 
by
 
the
 
eigenv
ector
 
of
X

X
corresp
onding
 
to
 
the
 
largest
eigen
v
alue.
This
 
deriv
ation
 
is
 
sp
eciﬁc
 
to
 
the
 
case
 
of
l
=
 
1
 
and
 
reco
v
ers
 
only
 
the
 
ﬁrst
principal
 
comp
onen
t.
 
More
 
generally
,
 
when
 
we
 
wish
 
to
 
recov
er
 
a
 
basis
 
of
 
principal
49


CHAPTER
 
2.
 
LINEAR
 
ALGEBRA
comp
onen
ts,
 
the
 
matrix
D
is
 
giv
en
 
by
 
the
l
eigen
v
ectors
 
corresponding
 
to
 
the
largest
 
eigen
v
alues.
 
This
 
ma
y
 
b
e
 
shown
 
using
 
pro
of
 
b
y
 
induction.
 
W
e
 
recommend
writing
 
this
 
pro
of
 
as
 
an
 
exercise.
Linear
 
algebra
 
is
 
one
 
of
 
the
 
fundamental
 
mathematical
 
disciplines
 
necessary
 
to
understanding
 
deep
 
learning.
 
Another
 
key
 
area
 
of
 
mathematics
 
that
 
is
 
ubiquitous
in
 
machine
 
learning
 
is
 
probability
 
theory
,
 
presented
 
next.
50













