An overview of gradient descent optimization
algorithms
Sebastian Ruder
Insight Centre for Data Analytics, NUI Galway
Aylien Ltd., Dublin
ruder.sebastian@gmail.com
Abstract
Gradient descent optimization algorithms, while increasingly popular, are often
used as black-box optimizers, as practical explanations of their strengths and
weaknesses are hard to come by. This article aims to provide the reader with
intuitions with regard to the behaviour of different algorithms that will allow her
to put them to use. In the course of this overview, we look at different variants of
gradient descent, summarize challenges, introduce the most common optimization
algorithms, review architectures in a parallel and distributed setting, and investigate
additional strategies for optimizing gradient descent.
1 Introduction
Gradient descent is one of the most popular algorithms to perform optimization and by far the
most common way to optimize neural networks. At the same time, every state-of-the-art Deep
Learning library contains implementations of various algorithms to optimize gradient descent (e.g.
lasagne’s2, caffe’s3, and keras’4documentation). These algorithms, however, are often used as
black-box optimizers, as practical explanations of their strengths and weaknesses are hard to come
by.
This article aims at providing the reader with intuitions with regard to the behaviour of different
algorithms for optimizing gradient descent that will help her put them to use. In Section 2, we
are ﬁrst going to look at the different variants of gradient descent. We will then brieﬂy summarize
challenges during training in Section 3. Subsequently, in Section 4, we will introduce the most
common optimization algorithms by showing their motivation to resolve these challenges and how
this leads to the derivation of their update rules. Afterwards, in Section 5, we will take a short look at
algorithms and architectures to optimize gradient descent in a parallel and distributed setting. Finally,
we will consider additional strategies that are helpful for optimizing gradient descent in Section 6.
Gradient descent is a way to minimize an objective function J()parameterized by a model’s
parameters2Rdby updating the parameters in the opposite direction of the gradient of the
objective function rJ()w.r.t. to the parameters. The learning rate determines the size of the
steps we take to reach a (local) minimum. In other words, we follow the direction of the slope of the
surface created by the objective function downhill until we reach a valley.5
This paper originally appeared as a blog post at http://sebastianruder.com/
optimizing-gradient-descent/index.html on 19 January 2016.
2http://lasagne.readthedocs.org/en/latest/modules/updates.html
3http://caffe.berkeleyvision.org/tutorial/solver.html
4http://keras.io/optimizers/
5If you are unfamiliar with gradient descent, you can ﬁnd a good introduction on optimizing neural networks
athttp://cs231n.github.io/optimization-1/ .arXiv:1609.04747v2  [cs.LG]  15 Jun 2017
2 Gradient descent variants
There are three variants of gradient descent, which differ in how much data we use to compute the
gradient of the objective function. Depending on the amount of data, we make a trade-off between
the accuracy of the parameter update and the time it takes to perform an update.
2.1 Batch gradient descent
Vanilla gradient descent, aka batch gradient descent, computes the gradient of the cost function w.r.t.
to the parameters for the entire training dataset:
= rJ() (1)
As we need to calculate the gradients for the whole dataset to perform just oneupdate, batch gradient
descent can be very slow and is intractable for datasets that do not ﬁt in memory. Batch gradient
descent also does not allow us to update our model online , i.e. with new examples on-the-ﬂy.
In code, batch gradient descent looks something like this:
for i in range ( nb_epochs ):
params_grad = evaluate_gradient ( loss_function , data , params )
params = params - learning_rate * params_grad
For a pre-deﬁned number of epochs, we ﬁrst compute the gradient vector params_grad of the loss
function for the whole dataset w.r.t. our parameter vector params . Note that state-of-the-art deep
learning libraries provide automatic differentiation that efﬁciently computes the gradient w.r.t. some
parameters. If you derive the gradients yourself, then gradient checking is a good idea.6
We then update our parameters in the direction of the gradients with the learning rate determining
how big of an update we perform. Batch gradient descent is guaranteed to converge to the global
minimum for convex error surfaces and to a local minimum for non-convex surfaces.
2.2 Stochastic gradient descent
Stochastic gradient descent (SGD) in contrast performs a parameter update for each training example
x(i)and labely(i):
= rJ(;x(i);y(i)) (2)
Batch gradient descent performs redundant computations for large datasets, as it recomputes gradients
for similar examples before each parameter update. SGD does away with this redundancy by
performing one update at a time. It is therefore usually much faster and can also be used to learn
online. SGD performs frequent updates with a high variance that cause the objective function to
ﬂuctuate heavily as in Figure 1.
While batch gradient descent converges to the minimum of the basin the parameters are placed in,
SGD’s ﬂuctuation, on the one hand, enables it to jump to new and potentially better local minima.
On the other hand, this ultimately complicates convergence to the exact minimum, as SGD will keep
overshooting. However, it has been shown that when we slowly decrease the learning rate, SGD
shows the same convergence behaviour as batch gradient descent, almost certainly converging to a
local or the global minimum for non-convex and convex optimization respectively. Its code fragment
simply adds a loop over the training examples and evaluates the gradient w.r.t. each example. Note
that we shufﬂe the training data at every epoch as explained in Section 6.1.
for i in range ( nb_epochs ):
np. random . shuffle ( data )
for example in data :
params_grad = evaluate_gradient ( loss_function , example , params )
params = params - learning_rate * params_grad
6Refer to http://cs231n.github.io/neural-networks-3/ for some great tips on how to check gradi-
ents properly.
2
Figure 1: SGD ﬂuctuation (Source: Wikipedia)
2.3 Mini-batch gradient descent
Mini-batch gradient descent ﬁnally takes the best of both worlds and performs an update for every
mini-batch of ntraining examples:
= rJ(;x(i:i+n);y(i:i+n)) (3)
This way, it a) reduces the variance of the parameter updates, which can lead to more stable conver-
gence; and b) can make use of highly optimized matrix optimizations common to state-of-the-art
deep learning libraries that make computing the gradient w.r.t. a mini-batch very efﬁcient. Common
mini-batch sizes range between 50and256, but can vary for different applications. Mini-batch
gradient descent is typically the algorithm of choice when training a neural network and the term
SGD usually is employed also when mini-batches are used. Note: In modiﬁcations of SGD in the
rest of this post, we leave out the parameters x(i:i+n);y(i:i+n)for simplicity.
In code, instead of iterating over examples, we now iterate over mini-batches of size 50:
for i in range ( nb_epochs ):
np. random . shuffle ( data )
for batch in get_batches (data , batch_size =50):
params_grad = evaluate_gradient ( loss_function , batch , params )
params = params - learning_rate * params_grad
3 Challenges
Vanilla mini-batch gradient descent, however, does not guarantee good convergence, but offers a few
challenges that need to be addressed:
Choosing a proper learning rate can be difﬁcult. A learning rate that is too small leads to
painfully slow convergence, while a learning rate that is too large can hinder convergence
and cause the loss function to ﬂuctuate around the minimum or even to diverge.
Learning rate schedules [ 18] try to adjust the learning rate during training by e.g. annealing,
i.e. reducing the learning rate according to a pre-deﬁned schedule or when the change in
objective between epochs falls below a threshold. These schedules and thresholds, however,
have to be deﬁned in advance and are thus unable to adapt to a dataset’s characteristics [4].
Additionally, the same learning rate applies to all parameter updates. If our data is sparse
and our features have very different frequencies, we might not want to update all of them to
the same extent, but perform a larger update for rarely occurring features.
Another key challenge of minimizing highly non-convex error functions common for neural
networks is avoiding getting trapped in their numerous suboptimal local minima. Dauphin
et al. [ 5] argue that the difﬁculty arises in fact not from local minima but from saddle points,
i.e. points where one dimension slopes up and another slopes down. These saddle points are
usually surrounded by a plateau of the same error, which makes it notoriously hard for SGD
to escape, as the gradient is close to zero in all dimensions.
3
4 Gradient descent optimization algorithms
In the following, we will outline some algorithms that are widely used by the Deep Learning
community to deal with the aforementioned challenges. We will not discuss algorithms that are
infeasible to compute in practice for high-dimensional data sets, e.g. second-order methods such as
Newton’s method7.
4.1 Momentum
SGD has trouble navigating ravines, i.e. areas where the surface curves much more steeply in one
dimension than in another [ 20], which are common around local optima. In these scenarios, SGD
oscillates across the slopes of the ravine while only making hesitant progress along the bottom
towards the local optimum as in Figure 2a.
(a) SGD without momentum
 (b) SGD with momentum
Figure 2: Source: Genevieve B. Orr
Momentum [ 17] is a method that helps accelerate SGD in the relevant direction and dampens
oscillations as can be seen in Figure 2b. It does this by adding a fraction of the update vector of the
past time step to the current update vector8
vt=vt 1+rJ()
= vt(4)
The momentum term is usually set to 0:9or a similar value.
Essentially, when using momentum, we push a ball down a hill. The ball accumulates momentum
as it rolls downhill, becoming faster and faster on the way (until it reaches its terminal velocity, if
there is air resistance, i.e.  <1). The same thing happens to our parameter updates: The momentum
term increases for dimensions whose gradients point in the same directions and reduces updates for
dimensions whose gradients change directions. As a result, we gain faster convergence and reduced
oscillation.
4.2 Nesterov accelerated gradient
However, a ball that rolls down a hill, blindly following the slope, is highly unsatisfactory. We would
like to have a smarter ball, a ball that has a notion of where it is going so that it knows to slow down
before the hill slopes up again.
Nesterov accelerated gradient (NAG) [ 14] is a way to give our momentum term this kind of prescience.
We know that we will use our momentum term vt 1to move the parameters . Computing  vt 1
thus gives us an approximation of the next position of the parameters (the gradient is missing for the
full update), a rough idea where our parameters are going to be. We can now effectively look ahead
by calculating the gradient not w.r.t. to our current parameters but w.r.t. the approximate future
position of our parameters:
vt=vt 1+rJ( vt 1)
= vt(5)
7https://en.wikipedia.org/wiki/Newton%27s_method_in_optimization
8Some implementations exchange the signs in the equations.
4
Figure 3: Nesterov update (Source: G. Hinton’s lecture 6c)
Again, we set the momentum term to a value of around 0:9. While Momentum ﬁrst computes the
current gradient (small blue vector in Figure 3) and then takes a big jump in the direction of the
updated accumulated gradient (big blue vector), NAG ﬁrst makes a big jump in the direction of the
previous accumulated gradient (brown vector), measures the gradient and then makes a correction
(green vector). This anticipatory update prevents us from going too fast and results in increased
responsiveness, which has signiﬁcantly increased the performance of RNNs on a number of tasks
[2].9
Now that we are able to adapt our updates to the slope of our error function and speed up SGD in turn,
we would also like to adapt our updates to each individual parameter to perform larger or smaller
updates depending on their importance.
4.3 Adagrad
Adagrad [ 8] is an algorithm for gradient-based optimization that does just this: It adapts the learning
rate to the parameters, performing larger updates for infrequent and smaller updates for frequent
parameters. For this reason, it is well-suited for dealing with sparse data. Dean et al. [ 6] have found
that Adagrad greatly improved the robustness of SGD and used it for training large-scale neural nets
at Google, which – among other things – learned to recognize cats in Youtube videos10. Moreover,
Pennington et al. [ 16] used Adagrad to train GloVe word embeddings, as infrequent words require
much larger updates than frequent ones.
Previously, we performed an update for all parameters at once as every parameter iused the same
learning rate . As Adagrad uses a different learning rate for every parameter iat every time step t,
we ﬁrst show Adagrad’s per-parameter update, which we then vectorize. For brevity, we set gt;ito be
the gradient of the objective function w.r.t. to the parameter iat time stept:
gt;i=rtJ(t;i) (6)
The SGD update for every parameter iat each time step tthen becomes:
t+1;i=t;i gt;i (7)
In its update rule, Adagrad modiﬁes the general learning rate at each time step tfor every parameter
ibased on the past gradients that have been computed for i:
t+1;i=t;i p
Gt;ii+gt;i (8)
Gt2Rddhere is a diagonal matrix where each diagonal element i;iis the sum of the squares of the
gradients w.r.t. iup to time step t11, whileis a smoothing term that avoids division by zero (usually
on the order of 1e 8). Interestingly, without the square root operation, the algorithm performs much
worse.
9Refer to http://cs231n.github.io/neural-networks-3/ for another explanation of the intuitions
behind NAG, while Ilya Sutskever gives a more detailed overview in his PhD thesis [19].
10http://www.wired.com/2012/06/google-x-neural-network/
11Duchi et al. [ 8] give this matrix as an alternative to the fullmatrix containing the outer products of all
previous gradients, as the computation of the matrix square root is infeasible even for a moderate number of
parameters d.
5
AsGtcontains the sum of the squares of the past gradients w.r.t. to all parameters along its
diagonal, we can now vectorize our implementation by performing an element-wise matrix-vector
multiplicationbetweenGtandgt:
t+1=t pGt+gt: (9)
One of Adagrad’s main beneﬁts is that it eliminates the need to manually tune the learning rate. Most
implementations use a default value of 0:01and leave it at that.
Adagrad’s main weakness is its accumulation of the squared gradients in the denominator: Since
every added term is positive, the accumulated sum keeps growing during training. This in turn causes
the learning rate to shrink and eventually become inﬁnitesimally small, at which point the algorithm
is no longer able to acquire additional knowledge. The following algorithms aim to resolve this ﬂaw.
4.4 Adadelta
Adadelta [ 22] is an extension of Adagrad that seeks to reduce its aggressive, monotonically decreasing
learning rate. Instead of accumulating all past squared gradients, Adadelta restricts the window of
accumulated past gradients to some ﬁxed size w.
Instead of inefﬁciently storing wprevious squared gradients, the sum of gradients is recursively
deﬁned as a decaying average of all past squared gradients. The running average E[g2]tat time stept
then depends (as a fraction similarly to the Momentum term) only on the previous average and the
current gradient:
E[g2]t=E[g2]t 1+ (1 )g2
t (10)
We setto a similar value as the momentum term, around 0:9. For clarity, we now rewrite our vanilla
SGD update in terms of the parameter update vector t:
t= gt;i
t+1=t+ t(11)
The parameter update vector of Adagrad that we derived previously thus takes the form:
t= pGt+gt (12)
We now simply replace the diagonal matrix Gtwith the decaying average over past squared gradients
E[g2]t:
t= p
E[g2]t+gt (13)
As the denominator is just the root mean squared (RMS) error criterion of the gradient, we can replace
it with the criterion short-hand:
t= 
RMS [g]tgt (14)
The authors note that the units in this update (as well as in SGD, Momentum, or Adagrad) do not
match, i.e. the update should have the same hypothetical units as the parameter. To realize this, they
ﬁrst deﬁne another exponentially decaying average, this time not of squared gradients but of squared
parameter updates:
E[2]t=E[2]t 1+ (1 )2
t (15)
6
The root mean squared error of parameter updates is thus:
RMS []t=p
E[2]t+ (16)
SinceRMS []tis unknown, we approximate it with the RMS of parameter updates until the
previous time step. Replacing the learning rate in the previous update rule with RMS []t 1
ﬁnally yields the Adadelta update rule:
t= RMS []t 1
RMS [g]tgt
t+1=t+ t(17)
With Adadelta, we do not even need to set a default learning rate, as it has been eliminated from the
update rule.
4.5 RMSprop
RMSprop is an unpublished, adaptive learning rate method proposed by Geoff Hinton in Lecture 6e
of his Coursera Class12.
RMSprop and Adadelta have both been developed independently around the same time stemming
from the need to resolve Adagrad’s radically diminishing learning rates. RMSprop in fact is identical
to the ﬁrst update vector of Adadelta that we derived above:
E[g2]t= 0:9E[g2]t 1+ 0:1g2
t
t+1=t p
E[g2]t+gt(18)
RMSprop as well divides the learning rate by an exponentially decaying average of squared gradients.
Hinton suggests to be set to 0:9, while a good default value for the learning rate is0:001.
4.6 Adam
Adaptive Moment Estimation (Adam) [ 10] is another method that computes adaptive learning rates
for each parameter. In addition to storing an exponentially decaying average of past squared gradients
vtlike Adadelta and RMSprop, Adam also keeps an exponentially decaying average of past gradients
mt, similar to momentum:
mt=1mt 1+ (1 1)gt
vt=2vt 1+ (1 2)g2
t(19)
mtandvtare estimates of the ﬁrst moment (the mean) and the second moment (the uncentered
variance) of the gradients respectively, hence the name of the method. As mtandvtare initialized as
vectors of 0’s, the authors of Adam observe that they are biased towards zero, especially during the
initial time steps, and especially when the decay rates are small (i.e. 1and2are close to 1).
They counteract these biases by computing bias-corrected ﬁrst and second moment estimates:
^mt=mt
1 t
1
^vt=vt
1 t
2(20)
12http://www.cs.toronto.edu/~tijmen/csc321/slides/lecture_slides_lec6.pdf
7
They then use these to update the parameters just as we have seen in Adadelta and RMSprop, which
yields the Adam update rule:
t+1=t p^vt+^mt (21)
The authors propose default values of 0:9for1,0:999for2, and 10 8for. They show empiri-
cally that Adam works well in practice and compares favorably to other adaptive learning-method
algorithms.
4.7 AdaMax
Thevtfactor in the Adam update rule scales the gradient inversely proportionally to the `2norm of
the past gradients (via the vt 1term) and current gradient jgtj2:
vt=2vt 1+ (1 2)jgtj2(22)
We can generalize this update to the `pnorm. Note that Kingma and Ba also parameterize 2asp
2:
vt=p
2vt 1+ (1 p
2)jgtjp(23)
Norms for large pvalues generally become numerically unstable, which is why `1and`2norms are
most common in practice. However, `1also generally exhibits stable behavior. For this reason, the
authors propose AdaMax [ 10] and show that vtwith`1converges to the following more stable value.
To avoid confusion with Adam, we use utto denote the inﬁnity norm-constrained vt:
ut=1
2vt 1+ (1 1
2)jgtj1
= max(2vt 1;jgtj)(24)
We can now plug this into the Adam update equation by replacingp^vt+withutto obtain the
AdaMax update rule:
t+1=t 
ut^mt (25)
Note that as utrelies on the max operation, it is not as suggestible to bias towards zero as mtandvt
in Adam, which is why we do not need to compute a bias correction for ut. Good default values are
again= 0:002,1= 0:9, and2= 0:999.
4.8 Nadam
As we have seen before, Adam can be viewed as a combination of RMSprop and momentum: RM-
Sprop contributes the exponentially decaying average of past squared gradients vt, while momentum
accounts for the exponentially decaying average of past gradients mt. We have also seen that Nesterov
accelerated gradient (NAG) is superior to vanilla momentum.
Nadam (Nesterov-accelerated Adaptive Moment Estimation) [ 7] thus combines Adam and NAG. In
order to incorporate NAG into Adam, we need to modify its momentum term mt.
First, let us recall the momentum update rule using our current notation :
gt=rtJ(t)
mt=mt 1+gt
t+1=t mt(26)
8
whereJis our objective function, is the momentum decay term, and is our step size. Expanding
the third equation above yields:
t+1=t (mt 1+gt) (27)
This demonstrates again that momentum involves taking a step in the direction of the previous
momentum vector and a step in the direction of the current gradient.
NAG then allows us to perform a more accurate step in the gradient direction by updating the
parameters with the momentum step before computing the gradient. We thus only need to modify the
gradientgtto arrive at NAG:
gt=rtJ(t mt 1)
mt=mt 1+gt
t+1=t mt(28)
Dozat proposes to modify NAG the following way: Rather than applying the momentum step twice –
one time for updating the gradient gtand a second time for updating the parameters t+1– we now
apply the look-ahead momentum vector directly to update the current parameters:
gt=rtJ(t)
mt=mt 1+gt
t+1=t (mt+gt)(29)
Notice that rather than utilizing the previous momentum vector mt 1as in Equation 27, we now use
the current momentum vector mtto look ahead. In order to add Nesterov momentum to Adam, we
can thus similarly replace the previous momentum vector with the current momentum vector. First,
recall that the Adam update rule is the following (note that we do not need to modify ^vt):
mt=1mt 1+ (1 1)gt
^mt=mt
1 t
1
t+1=t p^vt+^mt(30)
Expanding the second equation with the deﬁnitions of ^mtandmtin turn gives us:
t+1=t p^vt+(1mt 1
1 t
1+(1 1)gt
1 t
1) (31)
Note that1mt 1
1 t
1is just the bias-corrected estimate of the momentum vector of the previous time
step. We can thus replace it with ^mt 1:
t+1=t p^vt+(1^mt 1+(1 1)gt
1 t
1) (32)
This equation looks very similar to our expanded momentum term in Equation 27. We can now add
Nesterov momentum just as we did in Equation 29 by simply replacing this bias-corrected estimate of
the momentum vector of the previous time step ^mt 1with the bias-corrected estimate of the current
momentum vector ^mt, which gives us the Nadam update rule:
t+1=t p^vt+(1^mt+(1 1)gt
1 t
1) (33)
9
4.9 Visualization of algorithms
The following two ﬁgures provide some intuitions towards the optimization behaviour of the presented
optimization algorithms.13
In Figure 4a, we see the path they took on the contours of a loss surface (the Beale function). All
started at the same point and took different paths to reach the minimum. Note that Adagrad, Adadelta,
and RMSprop headed off immediately in the right direction and converged similarly fast, while
Momentum and NAG were led off-track, evoking the image of a ball rolling down the hill. NAG,
however, was able to correct its course sooner due to its increased responsiveness by looking ahead
and headed to the minimum.
Figure 4b shows the behaviour of the algorithms at a saddle point, i.e. a point where one dimension
has a positive slope, while the other dimension has a negative slope, which pose a difﬁculty for SGD
as we mentioned before. Notice here that SGD, Momentum, and NAG ﬁnd it difﬁculty to break
symmetry, although the latter two eventually manage to escape the saddle point, while Adagrad,
RMSprop, and Adadelta quickly head down the negative slope, with Adadelta leading the charge.
(a) SGD optimization on loss surface contours
 (b) SGD optimization on saddle point
Figure 4: Source and full animations: Alec Radford
As we can see, the adaptive learning-rate methods, i.e. Adagrad, Adadelta, RMSprop, and Adam are
most suitable and provide the best convergence for these scenarios.
4.10 Which optimizer to use?
So, which optimizer should you use? If your input data is sparse, then you likely achieve the best
results using one of the adaptive learning-rate methods. An additional beneﬁt is that you will not
need to tune the learning rate but will likely achieve the best results with the default value.
In summary, RMSprop is an extension of Adagrad that deals with its radically diminishing learning
rates. It is identical to Adadelta, except that Adadelta uses the RMS of parameter updates in the
numerator update rule. Adam, ﬁnally, adds bias-correction and momentum to RMSprop. Insofar,
RMSprop, Adadelta, and Adam are very similar algorithms that do well in similar circumstances.
Kingma et al. [ 10] show that its bias-correction helps Adam slightly outperform RMSprop towards
the end of optimization as gradients become sparser. Insofar, Adam might be the best overall choice.
Interestingly, many recent papers use vanilla SGD without momentum and a simple learning rate
annealing schedule. As has been shown, SGD usually achieves to ﬁnd a minimum, but it might take
signiﬁcantly longer than with some of the optimizers, is much more reliant on a robust initialization
and annealing schedule, and may get stuck in saddle points rather than local minima. Consequently,
if you care about fast convergence and train a deep or complex neural network, you should choose
one of the adaptive learning rate methods.
13Also have a look at http://cs231n.github.io/neural-networks-3/ for a description of the same
images by Karpathy and another concise overview of the algorithms discussed.
10
5 Parallelizing and distributing SGD
Given the ubiquity of large-scale data solutions and the availability of low-commodity clusters,
distributing SGD to speed it up further is an obvious choice. SGD by itself is inherently sequential:
Step-by-step, we progress further towards the minimum. Running it provides good convergence but
can be slow particularly on large datasets. In contrast, running SGD asynchronously is faster, but
suboptimal communication between workers can lead to poor convergence. Additionally, we can also
parallelize SGD on one machine without the need for a large computing cluster. The following are
algorithms and architectures that have been proposed to optimize parallelized and distributed SGD.
5.1 Hogwild!
Niu et al. [15] introduce an update scheme called Hogwild! that allows performing SGD updates in
parallel on CPUs. Processors are allowed to access shared memory without locking the parameters.
This only works if the input data is sparse, as each update will only modify a fraction of all parameters.
They show that in this case, the update scheme achieves almost an optimal rate of convergence, as it
is unlikely that processors will overwrite useful information.
5.2 Downpour SGD
Downpour SGD is an asynchronous variant of SGD that was used by Dean et al. [ 6] in their DistBelief
framework (the predecessor to TensorFlow) at Google. It runs multiple replicas of a model in parallel
on subsets of the training data. These models send their updates to a parameter server, which is
split across many machines. Each machine is responsible for storing and updating a fraction of the
model’s parameters. However, as replicas don’t communicate with each other e.g. by sharing weights
or updates, their parameters are continuously at risk of diverging, hindering convergence.
5.3 Delay-tolerant Algorithms for SGD
McMahan and Streeter [ 12] extend AdaGrad to the parallel setting by developing delay-tolerant
algorithms that not only adapt to past gradients, but also to the update delays. This has been shown to
work well in practice.
5.4 TensorFlow
TensorFlow14[1] is Google’s recently open-sourced framework for the implementation and deploy-
ment of large-scale machine learning models. It is based on their experience with DistBelief and is
already used internally to perform computations on a large range of mobile devices as well as on
large-scale distributed systems. The distributed version, which was released in April 201615relies on
a computation graph that is split into a subgraph for every device, while communication takes place
using Send/Receive node pairs.
5.5 Elastic Averaging SGD
Zhang et al. [ 23] propose Elastic Averaging SGD (EASGD), which links the parameters of the
workers of asynchronous SGD with an elastic force, i.e. a center variable stored by the parameter
server. This allows the local variables to ﬂuctuate further from the center variable, which in theory
allows for more exploration of the parameter space. They show empirically that this increased
capacity for exploration leads to improved performance by ﬁnding new local optima.
6 Additional strategies for optimizing SGD
Finally, we introduce additional strategies that can be used alongside any of the previously mentioned
algorithms to further improve the performance of SGD. For a great overview of some other common
tricks, refer to [11].
14https://www.tensorflow.org/
15http://googleresearch.blogspot.ie/2016/04/announcing-tensorflow-08-now-with.html
11
6.1 Shufﬂing and Curriculum Learning
Generally, we want to avoid providing the training examples in a meaningful order to our model as
this may bias the optimization algorithm. Consequently, it is often a good idea to shufﬂe the training
data after every epoch.
On the other hand, for some cases where we aim to solve progressively harder problems, supplying
the training examples in a meaningful order may actually lead to improved performance and better
convergence. The method for establishing this meaningful order is called Curriculum Learning [3].
Zaremba and Sutskever [ 21] were only able to train LSTMs to evaluate simple programs using
Curriculum Learning and show that a combined or mixed strategy is better than the naive one, which
sorts examples by increasing difﬁculty.
6.2 Batch normalization
To facilitate learning, we typically normalize the initial values of our parameters by initializing them
with zero mean and unit variance. As training progresses and we update parameters to different
extents, we lose this normalization, which slows down training and ampliﬁes changes as the network
becomes deeper.
Batch normalization [ 9] reestablishes these normalizations for every mini-batch and changes are back-
propagated through the operation as well. By making normalization part of the model architecture,
we are able to use higher learning rates and pay less attention to the initialization parameters. Batch
normalization additionally acts as a regularizer, reducing (and sometimes even eliminating) the need
for Dropout.
6.3 Early stopping
According to Geoff Hinton: “Early stopping (is) beautiful free lunch”16. You should thus always
monitor error on a validation set during training and stop (with some patience) if your validation error
does not improve enough.
6.4 Gradient noise
Neelakantan et al. [ 13] add noise that follows a Gaussian distribution N(0;2
t)to each gradient
update:
gt;i=gt;i+N(0;2
t) (34)
They anneal the variance according to the following schedule:
2
t=
(1 +t)(35)
They show that adding this noise makes networks more robust to poor initialization and helps training
particularly deep and complex networks. They suspect that the added noise gives the model more
chances to escape and ﬁnd new local minima, which are more frequent for deeper models.
7 Conclusion
In this article, we have initially looked at the three variants of gradient descent, among which mini-
batch gradient descent is the most popular. We have then investigated algorithms that are most
commonly used for optimizing SGD: Momentum, Nesterov accelerated gradient, Adagrad, Adadelta,
RMSprop, Adam, AdaMax, Nadam, as well as different algorithms to optimize asynchronous SGD.
Finally, we’ve considered other strategies to improve SGD such as shufﬂing and curriculum learning,
batch normalization, and early stopping.
16NIPS 2015 Tutorial slides, slide 63, http://www.iro.umontreal.ca/~bengioy/talks/
DL-Tutorial-NIPS2015.pdf
12
References
[1]Martin Abadi, Ashish Agarwal, Paul Barham, Eugene Brevdo, Zhifeng Chen, Craig Citro,
Greg Corrado, Andy Davis, Jeffrey Dean, Matthieu Devin, Sanjay Ghemawat, Ian Goodfellow,
Andrew Harp, Geoffrey Irving, Michael Isard, Yangqing Jia, Lukasz Kaiser, Manjunath Kudlur,
Josh Levenberg, Dan Man, Rajat Monga, Sherry Moore, Derek Murray, Jon Shlens, Benoit
Steiner, Ilya Sutskever, Paul Tucker, Vincent Vanhoucke, Vijay Vasudevan, Oriol Vinyals, Pete
Warden, Martin Wicke, Yuan Yu, and Xiaoqiang Zheng. TensorFlow: Large-Scale Machine
Learning on Heterogeneous Distributed Systems. 2015.
[2]Yoshua Bengio, Nicolas Boulanger-Lewandowski, and Razvan Pascanu. Advances in Optimiz-
ing Recurrent Networks. 2012.
[3]Yoshua Bengio, Jérôme Louradour, Ronan Collobert, and Jason Weston. Curriculum learning.
Proceedings of the 26th annual international conference on machine learning , pages 41–48,
2009.
[4]C. Darken, J. Chang, and J. Moody. Learning rate schedules for faster stochastic gradient
search. Neural Networks for Signal Processing II Proceedings of the 1992 IEEE Workshop ,
(September):1–11, 1992.
[5]Yann N. Dauphin, Razvan Pascanu, Caglar Gulcehre, Kyunghyun Cho, Surya Ganguli, and
Yoshua Bengio. Identifying and attacking the saddle point problem in high-dimensional non-
convex optimization. arXiv , pages 1–14, 2014.
[6]Jeffrey Dean, Greg S. Corrado, Rajat Monga, Kai Chen, Matthieu Devin, Quoc V . Le, Mark Z.
Mao, Marc Aurelio Ranzato, Andrew Senior, Paul Tucker, Ke Yang, and Andrew Y . Ng. Large
Scale Distributed Deep Networks. NIPS 2012: Neural Information Processing Systems , pages
1–11, 2012.
[7]Timothy Dozat. Incorporating Nesterov Momentum into Adam. ICLR Workshop , (1):2013–2016,
2016.
[8]John Duchi, Elad Hazan, and Yoram Singer. Adaptive Subgradient Methods for Online Learning
and Stochastic Optimization. Journal of Machine Learning Research , 12:2121–2159, 2011.
[9]Sergey Ioffe and Christian Szegedy. Batch Normalization: Accelerating Deep Network Training
by Reducing Internal Covariate Shift. arXiv preprint arXiv:1502.03167v3 , 2015.
[10] Diederik P. Kingma and Jimmy Lei Ba. Adam: a Method for Stochastic Optimization. Interna-
tional Conference on Learning Representations , pages 1–13, 2015.
[11] Yann LeCun, Leon Bottou, Genevieve B. Orr, and Klaus Robert Müller. Efﬁcient BackProp.
Neural Networks: Tricks of the Trade , 1524:9–50, 1998.
[12] H. Brendan Mcmahan and Matthew Streeter. Delay-Tolerant Algorithms for Asynchronous
Distributed Online Learning. Advances in Neural Information Processing Systems (Proceedings
of NIPS) , pages 1–9, 2014.
[13] Arvind Neelakantan, Luke Vilnis, Quoc V . Le, Ilya Sutskever, Lukasz Kaiser, Karol Kurach,
and James Martens. Adding Gradient Noise Improves Learning for Very Deep Networks. pages
1–11, 2015.
[14] Yurii Nesterov. A method for unconstrained convex minimization problem with the rate of
convergence o(1/k2). Doklady ANSSSR (translated as Soviet.Math.Docl.) , 269:543–547.
[15] Feng Niu, Benjamin Recht, R Christopher, and Stephen J Wright. Hogwild!: A Lock-Free
Approach to Parallelizing Stochastic Gradient Descent. pages 1–22, 2011.
[16] Jeffrey Pennington, Richard Socher, and Christopher D. Manning. Glove: Global Vectors for
Word Representation. Proceedings of the 2014 Conference on Empirical Methods in Natural
Language Processing , pages 1532–1543, 2014.
[17] Ning Qian. On the momentum term in gradient descent learning algorithms. Neural networks :
the ofﬁcial journal of the International Neural Network Society , 12(1):145–151, 1999.
[18] Herbert Robbins and Sutton Monro. A Stochastic Approximation Method. The Annals of
Mathematical Statistics , 22(3):400–407, 1951.
[19] Ilya Sutskever. Training Recurrent neural Networks. PhD thesis , page 101, 2013.
13
[20] Richard S. Sutton. Two problems with backpropagation and other steepest-descent learning
procedures for networks, 1986.
[21] Wojciech Zaremba and Ilya Sutskever. Learning to Execute. pages 1–25, 2014.
[22] Matthew D. Zeiler. ADADELTA: An Adaptive Learning Rate Method. arXiv preprint
arXiv:1212.5701 , 2012.
[23] Sixin Zhang, Anna Choromanska, and Yann LeCun. Deep learning with Elastic Averaging
SGD. Neural Information Processing Systems Conference (NIPS 2015) , pages 1–24, 2015.
14
