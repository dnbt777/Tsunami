Department of Electrical  and Computer Engineering
Vishal Saxena -1-SRAM Architecture
Vishal Saxena, Boise State University
(vishalsaxena@boisestate.edu)
Vishal Saxena -2-Outline
Memory Arrays
SRAM Architecture
SRAM Cell
Decoders
Column Circuitry
Multiple Ports
Serial Access Memories
Vishal Saxena -3-Memory Arrays
Memory Arrays
Random Access Memory Serial Access Memory Content Addressable Memory
(CAM)
Read/Write Memory
(RAM)
(Volatile)Read Only Memory
(ROM)
(Nonvolatile)
Static RAM
(SRAM)Dynamic RAM
(DRAM)Shift Registers Queues
First In
First Out
(FIFO)Last In
First Out
(LIFO)Serial In
Parallel Out
(SIPO)Parallel In
Serial Out
(PISO)
Mask ROM Programmable
ROM
(PROM)Erasable
Programmable
ROM
(EPROM)Electrically
Erasable
Programmable
ROM
(EEPROM)Flash ROM
Vishal Saxena -4-6T SRAM Cell
Cell size accounts for most of array size
Reduce cell size at expense of complexity
6T SRAM Cell
Used in most commercial chips
Data stored in cross-coupled inverters
Read:
Precharge bit, bit_b
Raise wordline
Write:
Drive data onto bit, bit_b
Raise wordlinebit bit_b
word
Vishal Saxena -5-SRAM Read
Precharge both bitlines high
Then turn on wordline
One of the two bitlines will be pulled down by the cell
Ex: A = 0, A_b = 1
bit discharges, bit_b stays high
But A bumps up slightly
Read stability
A must not flip
N1 >> N2bit bit_b
N1N2P1
AP2
N3N4
A_bword
0.00.51.01.5
0 100 200 300 400 500 600
time (ps)wordbit
AA_bbit_b
Vishal Saxena -6-SRAM Write
Drive one bitline high, the other low
Then turn on wordline
Bitlines overpower cell with new value
Ex: A = 0, A_b = 1, bit = 1, bit_b = 0
Force A_b low, then A rises high
Writability
Must overpower feedback inverter
N2 >> P1
time (ps)wordAA_b
bit_b
0.00.51.01.5
0 100 200 300 400 500 600 700bit bit_b
N1N2P1
AP2
N3N4
A_bword
Vishal Saxena -7-SRAM Sizing
High bitlines must not overpower inverters during reads
But low bitlines must write new value into cell
bit bit_b
 med
Aweak
strongmed
A_bword
Vishal Saxena -8-SRAM Column Example
Read Write
H HSRAM Cellword_q1bit_v1fbit_b_v1f
out_v1r out_b_v1r
1
2
word_q1
bit_v1f
out_v1r2
More
CellsBitline Conditioning
2
More
Cells
SRAM Cellword_q1bit_v1fbit_b_v1f
data_s1write_q1Bitline Conditioning
Vishal Saxena -9-SRAM Layout
Cell size is critical: 26 x 45 (even smaller in industry)
Tile cells sharing VDD, GND, bitline contacts
VDDGND GND BIT BIT_B
WORD
Cell boundary
Vishal Saxena -10-12T SRAM Cell
Basic building block: SRAM Cell
Holds one bit of information, like a latch
Must be read and written
12-transistor (12T) SRAM cell
Use a simple latch connected to bitline
46 x 75 unit cell
bit
write
write_b
read
read_b

Vishal Saxena -11-Thin Cell
In nanometer CMOS
Avoid bends in polysilicon and diffusion
Orient all transistors in one direction
Lithographically friendly or thin cell layout fixes this
Also reduces length and capacitance of bitlines

Vishal Saxena -12-Commercial SRAMs
Five generations of Intel SRAM cell micrographs
Transition to thin cell at 65 nm
Steady scaling of cell area

Vishal Saxena -13-Decoders
n:2ndecoder consists of 2nn-input AND gates
One needed for each row of memory
Build AND from NAND or NOR gates
Static CMOS Pseudo-nMOS
word0
word1word2
word3A0 A1
A1word
A0111/2
24
816
word
A0A1
111 1
48 word0
word1word2
word3A0 A1
Vishal Saxena -14-Decoder Layout
Decoders must be pitch-matched to SRAM cell
Requires very skinny gates
GNDVDD
word
buffer inverter NAND gateA0 A0 A1 A2 A3 A2 A3 A1
Vishal Saxena -15-Large Decoders
For n > 4, NAND gates become slow
Break large gates into multiple smaller gates
word0
word1
word2
word3
word15A0 A1 A2 A3
Vishal Saxena -16-Predecoding
Many of these gates are redundant
Factor out common
gates into predecoder
Saves area
Same path effort
A0A1A2A3
word1
word2
word3
word15word01 of 4 hot
predecoded linespredecoders
Vishal Saxena -17-Column Circuitry
Some circuitry is required for each column
Bitline conditioning
Sense amplifiers
Column multiplexing
Vishal Saxena -18-Bitline Conditioning
Precharge bitlines high before reads
Equalize bitlines to minimize voltage difference when using 
sense amplifiers
bit bit_b

bit bit_b
Vishal Saxena -19-Sense Amplifiers
Bitlines have many cells attached
Ex: 32-kbit SRAM has 128 rows x 256 cols
128 cells on each bitline
tpd(C/I) V
Even with shared diffusion contacts, 64C of diffusion capacitance 
(big C)
Discharged slowly through small transistors (small I)
Sense amplifiers are triggered on small voltage swing 
(reduce V)
Vishal Saxena -20-Differential Pair Amp
Differential pair requires no clock
But always dissipates static power
bit bit_bsense_b sense
N1 N2
N3P1 P2
Vishal Saxena -21-Clocked Sense Amp
Clocked sense amp saves power
Requires sense_clk after enough bitline swing
Isolation transistors cut off large bitline capacitance
bit_b bit
sense sense_bsense_clkisolation
transistors
regenerative
feedback
Vishal Saxena -22-Twisted Bitlines
Sense amplifiers also amplify noise
Coupling noise is severe in modern processes
Try to couple equally onto bit and bit_b
Done by twisting bitlines
b0 b0_b b1 b1_b b2 b2_b b3 b3_b
Vishal Saxena -23-Column Multiplexing
Ex: 2 kword x 16 folded into 256 rows x 128 columns
Must select 16 output bits from the 128 columns
Requires 16 8:1 column multiplexers
Vishal Saxena -24-Tree Decoder Mux
Column mux can use pass transistors
Use nMOS only, precharge outputs
One design is to use k series transistors for 2k:1 mux
No external decoder logic needed
B0 B1 B2 B3 B4 B5 B6 B7 B0 B1 B2 B3 B4 B5 B6 B7
A0
A0
A1A1
A2
A2
YY
to sense amps and write circuits
Vishal Saxena -25-Single Pass-Gate Mux
Or eliminate series transistors with separate decoder
A0 A1
B0 B1 B2 B3
Y
Vishal Saxena -26-Ex: 2-way Muxed SRAM
More
Cells
word_q1
write0_q12
More
Cells
A0
A0
2
data_v1write1_q1
Vishal Saxena -27-Multiple Ports
We have considered single-ported SRAM
One read or one write on each cycle
Multiported SRAM are needed for register files
Examples:
Multicycle MIPS must read two sources or write a result on some 
cycles
Pipelined MIPS must read two sour ces and write a third result each 
cycle
Superscalar MIPS must read and wr ite many sources and results 
each cycle
Vishal Saxena -28-Dual-Ported SRAM
Simple dual-ported SRAM
Two independent single-ended reads
Or one differential write
Do two reads and one write by time multiplexing
Read during ph1, write during ph2bit bit_b
wordBwordA
Vishal Saxena -29-Multi-Ported SRAM
Adding more access transistors hurts read stability
Multiported SRAM isolates reads from state node
Single-ended bitlines save area

Vishal Saxena -30-Large SRAMs
Large SRAMs are split into subarrays for speed
Ex: UltraSparc 512KB cache
4 128 KB subarrays
Each have 16 8KB banks
256 rows x 256 cols / bank
60% subarray area efficiency
Also space for tags & control
[Shin05]
Vishal Saxena -31-ROM Example
4-word x 6-bit ROM
Represented with dot diagram
Dots indicate 1’s in ROMWord 0: 010101
Word 1: 011001
Word 2: 100101
Word 3: 101010
ROM Array2:4
DECA0 A1
Y0 Y1 Y2 Y3 Y4 Y5weak
pseudo-nMOS
pullups
Looks like 6 4-input pseudo-nMOS NORs
Vishal Saxena -32-ROM Array Layout
Unit cell is 12 x 8 (about 1/10 size of SRAM)
Unit
Cell
Vishal Saxena -33-Row Decoders
ROM row decoders must pitch-match with ROM
Only a single track per word!

Vishal Saxena -34-Complete ROM Layout

Vishal Saxena -35-References
1. Weste, Harris, “CMOS VLSI Design,” 2ndEd., Addison Wesley.
