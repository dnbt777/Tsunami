



Practical Compiler Construction - T3X.ORG












http://
t3x.org
/
reload
/




PRACTICAL COMPILER CONSTRUCTION


A No-nonsense Tour through a C Compiler



Lulu Press, 2022 (2nd Ed.) – 460 pages – 37 figures – 6" x 9" format

All code from the book is in the public domain!







Order a 
PDF
 copy at Lulu.com


Order a 
paperback
 copy at Lulu.com


View the Table of Contents (PDF)


Read the Introduction (PDF)


Download the Sources


SubC Versions






What's new in the second edition?




Practical Compiler Construction
 is an advanced programming textbook
and a compiler-writing primer. Some programming skills are required, but
no prior knowledge in the field of compiler construction is necessary.



Study the heavily annotated source code of a 
full compiler
 for a
subset of the 
C programming language
 generating code for the
popular 
386 processor
. Learn about the 
practice
 of





Lexical analysis (scanning)


Syntax analysis (parsing)


Semantic analysis


Code generation


Runtime support (libraries)




Extend your 
theoretical background
 by learning about the
foundations and applications of




Scan trees


Formal grammars


Abstract programs


Code generation models


Program transformation





Finally, have a look at more 
advanced compilation techniques
 such
as




Code synthesis


Abstract program optimization


Peephole optimization


Common subexpression elimination




What's new in the second edition?


Most importantly, the book is back in print. In the past six years it
has only been available as a PDF, but now you can get a paperback copy
in all its 460-page glory again. The layout is completely new, the prose
has been clarified in many places, and some diagrams have been improved
or added.



The compiler described in the second edition is pretty much the
original compiler, but the dependency on FreeBSD's C library has
been lifted, and the compiler emits statically linked
executables now.



Of course all the bugs and typos that have been reported in the past
10 years have been fixed (and, no doubt, new ones have been introduced).
Many thanks to everybody who help make PCC a better book!





contact
  | 

privacy







