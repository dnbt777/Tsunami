The Little Book
of
Deep Learning
François Fleuret

François Fleuret is a professor of computer sci-
ence at the University of Geneva, Switzerland.
The cover illustration is a schematic of the
Neocognitron by Fukushima [1980], a key an-
cestor of deep neural networks.
This ebook is formatted to fit on a phone screen.
Contents
Contents 5
List of figures 7
Foreword 8
I Foundations 10
1 Machine Learning 11
1.1 Learning from data . . . . . . . 12
1.2 Basis function regression . . . . 14
1.3 Under and overfitting . . . . . . 16
1.4 Categories of models . . . . . . 18
2 Efficient Computation 20
2.1 GPUs, TPUs, and batches . . . . 21
2.2 Tensors . . . . . . . . . . . . . . 23
3 Training 25
3.1 Losses . . . . . . . . . . . . . . 26
3.2 Autoregressive models . . . . . 30
3.3 Gradient descent . . . . . . . . 35
3
3.4 Backpropagation . . . . . . . . 40
3.5 The value of depth . . . . . . . 45
3.6 Training protocols . . . . . . . 48
3.7 The benefits of scale . . . . . . 52
II Deep Models 57
4 Model Components 58
4.1 The notion of layer . . . . . . . 59
4.2 Linear layers . . . . . . . . . . . 61
4.3 Activation functions . . . . . . 71
4.4 Pooling . . . . . . . . . . . . . . 74
4.5 Dropout . . . . . . . . . . . . . 77
4.6 Normalizing layers . . . . . . . 80
4.7 Skip connections . . . . . . . . 84
4.8 Attention layers . . . . . . . . . 87
4.9 Token embedding . . . . . . . . 95
4.10 Positional encoding . . . . . . . 96
5 Architectures 98
5.1 Multi-Layer Perceptrons . . . . 99
5.2 Convolutional networks . . . . 101
5.3 Attention models . . . . . . . . 108
III Applications 116
6 Prediction 117
6.1 Image denoising . . . . . . . . . 118
6.2 Image classification . . . . . . . 120
6.3 Object detection . . . . . . . . . 121
4
6.4 Semantic segmentation . . . . . 126
6.5 Speech recognition . . . . . . . 129
6.6 Text-image representations . . . 131
6.7 Reinforcement learning . . . . . 134
7 Synthesis 138
7.1 Text generation . . . . . . . . . 139
7.2 Image generation . . . . . . . . 142
8 The Compute Schism 146
8.1 Prompt Engineering . . . . . . 147
8.2 Quantization . . . . . . . . . . . 150
8.3 Adapters . . . . . . . . . . . . . 153
8.4 Model merging . . . . . . . . . 156
The missing bits 158
Bibliography 164
Index 176
5
List of Figures
1.1 Kernel regression . . . . . . . . . . 14
1.2 Overfitting of kernel regression . . 16
3.1 Causal autoregressive model . . . . 32
3.2 Gradient descent . . . . . . . . . . . 36
3.3 Backpropagation . . . . . . . . . . . 40
3.4 Feature warping . . . . . . . . . . . 46
3.5 Training and validation losses . . . 49
3.6 Scaling laws . . . . . . . . . . . . . 53
3.7 Model training costs . . . . . . . . . 55
4.1 1D convolution . . . . . . . . . . . . 63
4.2 2D convolution . . . . . . . . . . . . 64
4.3 Stride, padding, and dilation . . . . 65
4.4 Receptive field . . . . . . . . . . . . 68
4.5 Activation functions . . . . . . . . . 72
4.6 Max pooling . . . . . . . . . . . . . 75
4.7 Dropout . . . . . . . . . . . . . . . . 78
4.8 Dropout 2D . . . . . . . . . . . . . . 79
4.9 Batch normalization . . . . . . . . . 81
4.10 Skip connections . . . . . . . . . . . 85
6
4.11 Attention operator interpretation . 88
4.12 Complete attention operator . . . . 90
4.13 Multi-Head Attention layer . . . . . 92
5.1 Multi-Layer Perceptron . . . . . . . 99
5.2 LeNet-like convolutional model . . 102
5.3 Residual block . . . . . . . . . . . . 103
5.4 Downscaling residual block . . . . . 104
5.5 ResNet-50 . . . . . . . . . . . . . . . 105
5.6 Transformer components . . . . . . 109
5.7 Transformer . . . . . . . . . . . . . 110
5.8 GPT model . . . . . . . . . . . . . . 112
5.9 ViT model . . . . . . . . . . . . . . 114
6.1 Convolutional object detector . . . 122
6.2 Object detection with SSD . . . . . 123
6.3 Semantic segmentation with PSP . . 127
6.4 CLIP zero-shot prediction . . . . . . 133
6.5 DQN state value evolution . . . . . 136
7.1 Few-shot prediction with a GPT . . 140
7.2 Denoising diffusion . . . . . . . . . 143
8.1 Chain-of-thought . . . . . . . . . . 148
8.2 Quantization . . . . . . . . . . . . . 151
7
Foreword
The current period of progress in artificial in-
telligence was triggered when Krizhevsky et al.
[2012] demonstrated that an artificialneuralnet-
work designed twenty years earlier [LeCun et al.,
1989] could outperform complex state-of-the-
art image recognition methods by a huge mar-
gin, simply by being a hundred times larger and
trained on a dataset similarly scaled up.
This breakthrough was made possible thanks
toGraph icalProcessingUnits ( GPUs), highly
parallel consumer-grade computing devices de-
veloped for real-time image synthesis and repur-
posed for artificial neural networks.
Since then, under the umbrella term of “ deep
learn ing,” innovations in the structures of these
networks, the strategies to train them, and ded-
icated hardware have allowed for an exponen-
tial increase in both their size and the quantity
of training data they take advantage of [Sevilla
8
et al., 2022]. This has resulted in a wave of suc-
cessful applications across technical domains,
from computer vision and robotics to speech
processing, and since 2020 in the development
of Large Language Models with general proto-
reasoning capabilities [Chowdhery et al., 2022].
Although the bulk of deep learning is not difficult
to understand, it combines diverse components
such as linear algebra, calculus, probabilities, op-
timization, signal processing, programming, al-
gorithmics, and high-performance computing,
making it complicated to learn.
Instead of trying to be exhaustive, this little book
is limited to the background necessary to under-
stand a few important models. This proved to
be a popular approach, resulting in more than
500,000 downloads of the PDF file in the 12
months following its announcement on Twitter.
If you did not get this book from its official URL
https://fleuret.org/public/lbdl.pdf
please do so, to allow the estimation of the num-
ber of readers.
François Fleuret,
May 19, 2024
9
Part I
Foundations
10
Chapter 1
Machine Learning
Deep learn ing belongs historically to the larger
field of statistical machine learn ing, as it funda-
mentally concerns methods that are able to learn
representations from data. The techniques in-
volved come originally from artificialneuralnet-
works, and the “deep” qualifier highlights that
models are long compositions of mappings, now
known to achieve greater performance.
The modularity, versatility, and scalability of
deep models have resulted in a plethora of spe-
cific mathematical methods and software devel-
opment tools, establishing deep learning as a
distinct and vast technical field.
11
1.1 Learning from data
The simplest use case for a model trained from
data is when a signal xis accessible, for instance,
the picture of a license plate, from which one
wants to predict a quantity y, such as the string
of characters written on the plate.
In many real-world situations where xis a high-
dimensional signal captured in an uncontrolled
environment, it is too complicated to come up
with an analytical recipe that relates xandy.
What one can do is to collect a large train ing
set𝒟of pairs (xn,yn), and devise a paramet-
ricmodel f. This is a piece of computer code
that incorporates train able parameterswthat
modulate its behavior, and such that, with the
proper values w∗, it is a good predictor. “Good”
here means that if an xis given to this piece
of code, the value ˆy=f(x;w∗)it computes is
a good estimate of the ythat would have been
associated with xin the training set had it been
there.
This notion of goodness is usually formalized
with a lossℒ(w)which is small when f(·;w)is
good on 𝒟. Then, train ing the model consists of
computing a value w∗that minimizes ℒ(w∗).
12
Most of the content of this book is about the defi-
nition of f, which, in realistic scenarios, is a com-
plex combination of pre-defined sub-modules.
The trainable parameters that compose ware of-
ten called weights, by analogy with the synaptic
weights of biological neural networks. In addi-
tion to these parameters, models usually depend
onhyper-parameters, which are set according
to domain prior knowledge, best practices, or re-
source constraints. They may also be optimized
in some way, but with techniques different from
those used to optimize w.
13
1.2 Basis function regression
We can illustrate the training of a model in a sim-
ple case where xnandynare two real numbers,
the loss is the mean squared error:
ℒ(w) =1
NNX
n=1(yn−f(xn;w))2, (1.1)
andf(·;w)is a linear combination of a pre-
defined basis of functions f1,...,f K, with w=
(w1,...,w K):
f(x;w) =KX
k=1wkfk(x).
Since f(xn;w)is linear with respect to the wks
andℒ(w)is quadratic with respect to f(xn;w),
Figure 1.1: Given a basis of functions (blue curves)
and a training set (black dots), we can compute an
optimal linear combination of the former (red curve)
to approximate the latter for the mean squared error.
14
the loss ℒ(w)is quadratic with respect to the
wks, and finding w∗that minimizes it boils down
to solving a linear system. See Figure 1.1 for an
example with Gaussian kernels as fk.
15
1.3 Under and overfitting
A key element is the interplay between the capac-
ity of the model, that is its flexibility and ability
to fit diverse data, and the amount and quality
of the training data. When the capacity is insuf-
ficient, the model cannot fit the data, resulting
in a high error during training. This is referred
to as underfitting.
On the contrary, when the amount of data is in-
sufficient, as illustrated in Figure 1.2, the model
will often learn characteristics specific to the
training examples, resulting in excellent perfor-
mance during training, at the cost of a worse
Figure 1.2: If the amount of training data (black dots)
is small compared to the capacity of the model, the em-
pirical performance of the fitted model during training
(red curve) reflects poorly its actual fit to the underly-
ing data structure (thin black curve), and consequently
its usefulness for prediction.
16
fit to the global structure of the data, and poor
performance on new inputs. This phenomenon
is referred to as overfitting.
So, a large part of the art of applied machine
learn ing is to design models that are not too
flexible yet still able to fit the data. This is done
by crafting the right inductivebias in a model,
which means that its structure corresponds to
the underlying structure of the data at hand.
Even though this classical perspective is relevant
for reasonably-sized deep models, things get con-
fusing with large ones that have a very large
number of trainable parameters and extreme ca-
pacity yet still perform well on prediction. We
will come back to this in § 3.6 and § 3.7.
17
1.4 Categories of models
We can organize the use of machine learn ing
models into three broad categories:
•Regression consists of predicting a
continuous-valued vector y∈RK, for instance,
a geometrical position of an object, given an
input signal X. This is a multi-dimensional
generalization of the setup we saw in § 1.2. The
training set is composed of pairs of an input
signal and a ground -truth value.
•Classification aims at predicting a value from
a finite set {1,...,C}, for instance, the label Yof
an image X. As with regression, the training set
is composed of pairs of input signal, and ground-
truth quantity, here a label from that set. The
standard way of tackling this is to predict one
score per potential class, such that the correct
class has the maximum score.
•Densitymodeling has as its objective to model
the probability density function of the data µX
itself, for instance, images. In that case, the train-
ing set is composed of values xnwithout associ-
ated quantities to predict, and the trained model
should allow for the evaluation of the probability
density function, or sampling from the distribu-
tion, or both.
18
Both regression and classification are generally
referred to as supervised learn ing, since the
value to be predicted, which is required as a
target during training, has to be provided, for in-
stance, by human experts. On the contrary, den-
sity modeling is usually seen as unsupervised
learn ing, since it is sufficient to take existing
data without the need for producing an associ-
ated ground-truth.
These three categories are not disjoint; for in-
stance, classification can be cast as class-score
regression, or discrete sequence density model-
ing as iterated classification. Furthermore, they
do not cover all cases. One may want to predict
compounded quantities, or multiple classes, or
model a density conditional on a signal.
19
Chapter 2
Efficient
Computation
From an implementation standpoint, deep learn-
ing is about executing heavy computations with
large amounts of data. The Graph icalProcessing
Units ( GPUs) have been instrumental in the suc-
cess of the field by allowing such computations
to be run on affordable hardware.
The importance of their use, and the resulting
technical constraints on the computations that
can be done efficiently, force the research in the
field to constantly balance mathematical sound-
ness and implementability of novel methods.
20
2.1 GPUs, TPUs, and batches
Graphical Processing Units were originally de-
signed for real-time image synthesis, which re-
quires highly parallel architectures that happen
to be well suited for deep models. As their usage
for AI has increased, GPUs have been equipped
with dedicated tensorcores, and deep-learning
specialized chips such as Google’s TensorPro-
cessingUnits ( TPUs) have been developed.
A GPU possesses several thousand parallel units
and its own fast memory. The limiting factor
is usually not the number of computing units,
but the read-write operations tomem ory. The
slowest link is between the CPU memory and
the GPU memory, and consequently one should
avoid copying data across devices. Moreover,
the structure of the GPU itself involves multiple
levels of cache mem ory, which are smaller but
faster, and computation should be organized to
avoid copies between these different caches.
This is achieved, in particular, by organizing the
computation in batches ofsamples that can fit
entirely in the GPU memory and are processed
in parallel. When an operator combines a sample
and model parameters, both have to be moved
to the cache memory near the actual computing
21
units. Proceeding by batches allows for copying
the model parameters only once, instead of doing
it for each sample. In practice, a GPU processes
a batch that fits in memory almost as quickly as
it would process a single sample.
A standard GPU has a theoretical peak perfor-
mance of 1013–1014floating-point operations
(FLOPs) per second, and its memory typically
ranges from 8to80gigabytes. The standard
FP32 encoding of float numbers is on 32bits, but
empirical results show that using encoding on
16bits, or even less for some operands, does not
degrade performance.
We will come back in § 3.7 to the large size of
deep architectures.
22
2.2 Tensors
GPUs and deep learn ingframe works such as Py-
Torch or JAX manipulate the quantities to be
processed by organizing them as tensors, which
are series of scalars arranged along several dis-
crete axes. They are elements of RN1×···× ND
that generalize the notion of vector and matrix.
Tensors are used to represent both the signals to
be processed, the train able parameters of the
models, and the intermediate quantities they
compute. The latter are called activations, in
reference to neuronal activations.
For instance, a time series is naturally encoded
as aT×Dtensor, or, for historical reasons, as a
D×Ttensor, where Tis its duration and Dis
the dimension of the feature representation at
every time step, often referred to as the number
ofchan nels. Similarly, a 2D-structured signal can
be represented as a D×H×Wtensor, where H
andWare its height and width. An RGB image
would correspond to D= 3, but the number of
channels can grow up to several thousands in
large models.
Adding more dimensions allows for the represen-
tation of series of objects. For example, fifty RGB
images of resolution 32×24can be encoded as
23
a50×3×24×32tensor.
Deep learning libraries provide a large number
of operations that encompass standard linear
algebra, complex reshaping and extraction, and
deep-learning specific operations, some of which
we will see in Chapter 4. The implementation of
tensors separates the shape representation from
the storage layout of the coefficients in mem-
ory, which allows many reshaping, transposing,
and extraction operations to be done without
coefficient copying, hence extremely rapidly.
In practice, virtually any computation can be
decomposed into elementary tensor operations,
which avoids non-parallel loops at the language
level and poor memory management.
Besides being convenient tools, tensors are
instrumental in achieving computational effi-
ciency. All the people involved in the develop-
ment of an operational deep model, from the
designers of the drivers, libraries, and models
to those of the computers and chips, know that
the data will be manipulated as tensors. The
resulting constraints on locality and block de-
composability enable all the actors in this chain
to come up with optimal designs.
24
Chapter 3
Training
As introduced in § 1.1, training a model consists
of minimizing a loss ℒ(w)which reflects the
performance of the predictor f(·;w)on a train -
ingset𝒟.
Since models are usually extremely complex, and
their performance is directly related to how well
the loss is minimized, this minimization is a key
challenge, which involves both computational
and mathematical difficulties.
25
3.1 Losses
The example of the mean squared error from
Equation 1.1 is a standard loss for predicting a
continuous value.
For density modeling, the standard loss is the
likelihood of the data. If f(x;w)is to be inter-
preted as a normalized log-probability or log-
density, the loss is the opposite of the sum of its
values over training samples, which corresponds
to the likelihood of the data-set.
Cross-entropy
Forclassification, the usual strategy is that the
output of the model is a vector with one com-
ponent f(x;w)yper class y, interpreted as the
logarithm of a non-normalized probability, or
logit.
With Xthe input signal and Ythe class to pre-
dict, we can then compute from fan estimate
of the posteriorprob abilities:
ˆP(Y=y|X=x) =expf(x;w)yP
zexpf(x;w)z.
This expression is generally called the softmax,
or more adequately, the softargmax, of the logits.
26
To be consistent with this interpretation, the
model should be trained to maximize the proba-
bility of the true classes, hence to minimize the
cross -entropy, expressed as:
ℒce(w) =−1
NNX
n=1logˆP(Y=yn|X=xn)
=1
NNX
n=1−logexpf(xn;w)ynP
zexpf(xn;w)z| {z }
Lce(f(xn;w),yn).
Contrastive loss
In certain setups, even though the value to be
predicted is continuous, the supervision takes
the form of ranking constraints. The typical do-
main where this is the case is metriclearn ing,
where the objective is to learn a measure of dis-
tance between samples such that a sample xa
from a certain semantic class is closer to any
sample xbof the same class than to any sample
xcfrom another class. For instance, xaandxb
can be two pictures of a certain person, and xca
picture of someone else.
The standard approach for such cases is to min-
imize a contrastive loss, in that case, for in-
stance, the sum over triplets (xa,xb,xc), such
27
thatya=yb̸=yc, of
max(0 ,1−f(xa,xc;w)+f(xa,xb;w)).
This quantity will be strictly positive unless
f(xa,xc;w)≥1+f(xa,xb;w).
Engineering the loss
Usually, the loss minimized during training is
not the actual quantity one wants to optimize
ultimately, but a proxy for which finding the best
model parameters is easier. For instance, cross-
entropy is the standard loss for classification,
even though the actual performance measure is
a classification error rate, because the latter has
no informative gradient, a key requirement as
we will see in § 3.3.
It is also possible to add terms to the loss that
depend on the trainable parameters of the model
themselves to favor certain configurations.
The weight decay regularization, for instance,
consists of adding to the loss a term proportional
to the sum of the squared parameters. This can
be interpreted as having a Gaussian Bayesian
prior on the parameters, which favors smaller
values and thereby reduces the influence of the
data. This degrades performance on the train-
28
ing set, but reduces the gap between the per-
formance in training and that on new, unseen
data.
29
3.2 Autoregressive models
A key class of methods, particularly for deal-
ing with discrete sequences in natural language
processing and computer vision, are the autore-
gressivemodels,
The chain rule for probabilities
Such models put to use the chain rule from prob-
ability theory:
P(X1=x1,X2=x2,...,X T=xT) =
P(X1=x1)
×P(X2=x2|X1=x1)
...
×P(XT=xT|X1=x1,...,X T−1=xT−1).
Although this decomposition is valid for a ran-
dom sequence of any type, it is particularly effi-
cient when the signal of interest is a sequence
oftokens from a finite vocabulary{1,...K}.
With the convention that the additional token ∅
stands for an “unknown” quantity, we can rep-
resent the event {X1=x1,...,X t=xt}as the
vector (x1,...,x t,∅,...,∅).
30
Then, a model
f:{∅,1,...,K }T→RK
which, given such an input, computes a vector
ltofKlogits corresponding to
ˆP(Xt|X1=x1,...,X t−1=xt−1),
allows to sample one token given the previous
ones.
The chain rule ensures that by sampling Tto-
kensxt, one at a time given the previously sam-
pledx1,...,x t−1, we get a sequence that follows
the joint distribution. This is an autoregressive
generative model.
Training such a model can be done by minimiz-
ing the sum across training sequences and time
steps of the cross -entropy loss
Lce 
f(x1,...,x t−1,∅,...,∅;w),xt
,
which is formally equivalent to maximizing the
likelihood of the true xts.
The value that is classically monitored is not the
cross-entropy itself, but the perplexity, which is
defined as the exponential of the cross-entropy.
It corresponds to the number of values of a uni-
form distribution with the same entropy, which
is generally more interpretable.
31
x1x2 ... xT−2xT−1l1 l2 l3 ... lT−1 lT
f
Figure 3.1: An autoregressive model f, iscausal if a
time step xtof the input sequence modulates the pre-
dicted logits lsonly if s > t , as depicted by the blue
arrows. This allows computing the distributions at all
the time steps in one pass during training. During sam-
pling, however, the ltandxtare computed sequentially,
the latter sampled with the former, as depicted by the
red arrows.
Causal models
The training procedure we just described re-
quires a different input for each t, and the bulk
of the computation done for t < t′is repeated for
t′. This is extremely inefficient since Tis often
of the order of hundreds or thousands.
The standard strategy to address this issue is to
design a model fthat predicts all the vectors of
logits l1,...,l Tat once, that is:
f:{1,...,K }T→RT×K,
32
but with a computational structure such that the
computed logits ltforxtdepend only on the
input values x1,...,x t−1.
Such a model is called causal, since it corre-
sponds, in the case of temporal series, to not
letting the future influence the past, as illustrated
in Figure 3.1.
The consequence is that the output at every posi-
tion is the one that would be obtained if the input
were only available up to before that position.
During training, it allows one to compute the
output for a full sequence and to maximize the
predicted probabilities of all the tokens of that
same sequence, which again boils down to mini-
mizing the sum of the per-token cross-entropy.
Note that, for the sake of simplicity, we have
defined fas operating on sequences of a fixed
length T. However, models used in practice,
such as the transformers we will see in § 5.3, are
able to process sequences of arbitrary length.
Tokenizer
One important technical detail when dealing
with natural languages is that the representation
as tokens can be done in multiple ways, ranging
from the finest granularity of individual symbols
33
to entire words. The conversion to and from the
token representation is carried out by a separate
algorithm called a tokenizer.
A standard method is the Byte Pair Encoding
(BPE) [Sennrich et al., 2015] that constructs to-
kens by hierarchically merging groups of char-
acters, trying to get tokens that represent frag-
ments of words of various lengths but of similar
frequencies, allocating tokens to long frequent
fragments as well as to rare individual symbols.
34
3.3 Gradient descent
Except in specific cases like the linear regression
we saw in § 1.2, the optimal parameters w∗do
not have a closed-form expression. In the general
case, the tool of choice to minimize a function is
gradientdescent. It starts by initializing the pa-
rameters with a random w0, and then improves
this estimate by iterating gradientsteps, each
consisting of computing the gradient of the loss
with respect to the parameters, and subtracting
a fraction of it:
wn+1=wn−η∇ℒ|w(wn). (3.1)
This procedure corresponds to moving the cur-
rent estimate a bit in the direction that locally
decreases ℒ(w)maximally, as illustrated in Fig-
ure 3.2.
Learning rate
Thehyper-parameterηis called the learn ingrate.
It is a positive value that modulates how quickly
the minimization is done, and must be chosen
carefully.
If it is too small, the optimization will be slow
at best, and may be trapped in a localminimum
early. If it is too large, the optimization may
35
w
wℒ(w)
Figure 3.2: At every point w, the gradient ∇ℒ|w(w)is
in the direction that maximizes the increase of ℒ, or-
thogonal to the level curves (top). The gradient descent
minimizes ℒ(w)iteratively by subtracting a fraction
of the gradient at every step, resulting in a trajectory
that follows the steepest descent (bottom).
36
bounce around a good minimum and never de-
scend into it. As we will see in § 3.6, it can depend
on the iteration number n.
Stochastic Gradient Descent
All the losses used in practice can be expressed as
an average of a loss per small group of samples,
or per sample such as:
ℒ(w) =1
NNX
n=1𝓁n(w),
where𝓁n(w) =L(f(xn;w),yn)for some L, and
the gradient is then:
∇ℒ|w(w) =1
NNX
n=1∇𝓁n|w(w). (3.2)
The resulting gradientdescent would compute
exactly the sum in Equation 3.2, which is usu-
ally computationally heavy, and then update the
parameters according to Equation 3.1. However,
under reasonable assumptions of exchangeabil-
ity, for instance, if the samples have been prop-
erly shuffled, any partial sum of Equation 3.2
is an unbiased estimator of the full sum, albeit
noisy. So, updating the parameters from partial
sums corresponds to doing more gradient steps
37
for the same computational budget, with noisier
estimates of the gradient. Due to the redundancy
in the data, this happens to be a far more efficient
strategy.
We saw in § 2.1 that processing a batch of sam-
ples small enough to fit in the computing de-
vice’s memory is generally as fast as processing
a single one. Hence, the standard approach is to
split the full set 𝒟into batches, and to update
the parameters from the estimate of the gradient
computed from each. This is called mini-batch
stochastic gradient descent, or stochas ticgradi-
entdescent ( SGD) for short.
It is important to note that this process is ex-
tremely gradual, and that the number of mini-
batches and gradient steps are typically of the
order of several million.
As with many algorithms, intuition breaks down
in high dimensions, and although it may seem
that this procedure would be easily trapped in
a local minimum, in reality, due to the number
of parameters, the design of the models, and
the stochasticity of the data, its efficiency is far
greater than one might expect.
Plenty of variations of this standard strategy
have been proposed. The most popular one is
38
Adam [Kingma and Ba, 2014], which keeps run-
ning estimates of the mean and variance of each
component of the gradient, and normalizes them
automatically, avoiding scaling issues and differ-
ent training speeds in different parts of a model.
39
3.4 Backpropagation
Using gradient descent requires a tech-
nical means to compute ∇𝓁|w(w)where
𝓁=L(f(x;w);y). Given that fandLare
both compositions of standard tensor opera-
tions, as for any mathematical expression, the
chain rule from differential calculus allows us to
get an expression of it.
For the sake of making notation lighter, we will
not specify at which point gradients are com-
puted, since the context makes it clear.
x(d−1)x(d)f(d)(·;wd)
∇𝓁|x(d−1) ∇𝓁|x(d)×Jf(d)|x
∇𝓁|wd×Jf(d)|w
Figure 3.3: Given a model f=f(D)◦ ··· ◦ f(1), the
forward pass computes the outputs x(d)of the f(d)in
order (top, black). The backward pass computes the
gradients of the loss with respect to the activations x(d)
(bottom, blue) and the parameters wd(bottom, red)
backward by multiplying them by the Jacobians.
40
Forward and backward passes
Consider the simple case of a composition of
mappings:
f=f(D)◦f(D−1)◦ ··· ◦ f(1).
The output of f(x;w)can be computed by start-
ing with x(0)=xand applying iteratively:
x(d)=f(d)
x(d−1);wd
,
withx(D)as the final value.
The individual scalar values of these interme-
diate results x(d)are traditionally called acti-
vations in reference to neuron activations, the
value Dis the depth of the model, the individual
mappings f(d)are referred to as layers, as we
will see in § 4.1, and their sequential evaluation
is the forward pass (see Figure 3.3, top).
Conversely, the gradient ∇𝓁|x(d−1)of the loss
with respect to the output x(d−1)off(d−1)is
the product of the gradient ∇𝓁|x(d)with respect
to the output of f(d)multiplied by the Jacobian
Jf(d−1)|xoff(d−1)with respect to its variable
x. Thus, the gradients with respect to the out-
puts of all the f(d)s can be computed recursively
backward, starting with ∇𝓁|x(D)=∇L|x.
41
And the gradient that we are interested in for
training, that is ∇𝓁|wd, is the gradient with re-
spect to the output of f(d)multiplied by the Ja-
cobian Jf(d)|woff(d)with respect to the param-
eters.
This iterative computation of the gradients with
respect to the intermediate activations, com-
bined with that of the gradients with respect
to the layers’ parameters, is the back ward pass
(see Figure 3.3, bottom). The combination of
this computation with the procedure of gradient
descent is called back prop agation.
In practice, the implementation details of the
forward and backward passes are hidden from
programmers. Deep learning frameworks are
able to automatically construct the sequence of
operations to compute gradients.
A particularly convenient algorithm is Autograd
[Baydin et al., 2015], which tracks tensor opera-
tions and builds, on the fly, the combination of
operators for gradients. Thanks to this, a piece of
imperative programming that manipulates ten-
sors can automatically compute the gradient of
any quantity with respect to any other.
42
Resource usage
Regarding the computational cost, as we will
see, the bulk of the computation goes into linear
operations, each requiring one matrix product
for the forward pass and two for the products by
the Jacobians for the backward pass, making the
latter roughly twice as costly as the former.
The mem oryrequire ment during inference is
roughly equal to that of the most demanding
individual layer. For training, however, the back-
ward pass requires keeping the activations com-
puted during the forward pass to compute the
Jacobians, which results in a memory usage that
grows proportionally to the model’s depth. Tech-
niques exist to trade the memory usage for com-
putation by either relying on reversible layers
[Gomez et al., 2017], or using check point ing,
which consists of storing activations for some
layers only and recomputing the others on the fly
with partial forward passes during the backward
pass [Chen et al., 2016].
Vanishing gradient
A key historical issue when training a large net-
work is that when the gradient propagates back-
wards through an operator, it may be scaled by a
43
multiplicative factor, and consequently decrease
or increase exponentially when it traverses many
layers. A standard method to prevent it from
exploding is gradientnorm clipping, which con-
sists of re-scaling the gradient to set its norm to
a fixed threshold if it is above it [Pascanu et al.,
2013].
When the gradient decreases exponentially, this
is called the vanishinggradient, and it may
make the training impossible, or, in its milder
form, cause different parts of the model to be
updated at different speeds, degrading their co-
adaptation [Glorot and Bengio, 2010].
As we will see in Chapter 4, multiple techniques
have been developed to prevent this from hap-
pening, reflecting a change in perspective that
was crucial to the success of deep-learning: in-
stead of trying to improve generic optimization
methods, the effort shifted to engineering the
models themselves to make them optimizable.
44
3.5 The value of depth
As the term “deep learning” indicates, useful
models are generally compositions of long se-
ries of mappings. Training them with gradient
descent results in a sophisticated co-adaptation
of the mappings, even though this procedure is
gradual and local.
We can illustrate this behavior with a simple
modelR2→R2that combines eight layers, each
multiplying its input by a 2×2matrix and ap-
plying Tanh per component, with a final linear
classifier. This is a simplified version of the stan-
dard Multi -Layer Perceptron that we will see in
§ 5.1.
If we train this model with SGD and cross -en-
tropy on a toy binary classification task (Figure
3.4, top left), the matrices co-adapt to deform the
space until the classification is correct, which
implies that the data have been made linearly
separable before the final affine operation (Fig-
ure 3.4, bottom right).
Such an example gives a glimpse of what a deep
model can achieve; however, it is partially mis-
leading due to the low dimension of both the sig-
nal to process and the internal representations.
Everything is kept in 2D here for the sake of
45
d= 0 d= 1 d= 2
d= 3 d= 4 d= 5
d= 6 d= 7 d= 8
Figure 3.4: Each plot shows the deformation of the
space and the resulting positioning of the training
points in R2afterdlayers of processing, starting with
the input to the model itself (top left). The oblique line
in the last plot (bottom right) shows the final affine
decision.
46
visualization, while real models take advantage
of representations in high dimensions, which, in
particular, facilitates the optimization by provid-
ing many degrees of freedom.
Empirical evidence accumulated over twenty
years demonstrates that state-of-the-art perfor-
mance across application domains necessitates
models with tens of layers, such as resid ualnet-
works (see § 5.2) or Trans form ers (see § 5.3).
Theoretical results show that, for a fixed com-
putational budget or number of parameters, in-
creasing the depth leads to a greater complexity
of the resulting mapping [Telgarsky, 2016].
47
3.6 Training protocols
Training a deep network requires defining a pro-
tocol to make the most of computation and data,
and to ensure that performance will be good on
new data.
As we saw in § 1.3, the performance on the train-
ing samples may be misleading, so in the sim-
plest setup one needs at least two sets of samples:
one is a train ingset, used to optimize the model
parameters, and the other is a testset, to evaluate
the performance of the trained model.
Additionally, there are usually hyper-parame-
ters to adapt, in particular, those related to the
model architecture, the learning rate, and the
regularization terms in the loss. In that case,
one needs a validation set that is disjoint from
both the training and test sets to assess the best
configuration.
The full training is usually decomposed into
epochs, each of which corresponds to going
through all the training examples once. The
usual dynamic of the losses is that the training
loss decreases as long as the optimization runs,
while the validation loss may reach a minimum
after a certain number of epochs and then start
to increase, reflecting an overfitting regime, as
48
Loss
Number of epochsOverfitting
TrainingValidation
Figure 3.5: As training progresses, a model’s perfor-
mance is usually monitored through losses. The train-
ing loss is the one driving the optimization process and
goes down, while the validation loss is estimated on
an other set of examples to assess the overfitting of
the model. Overfitting appears when the model starts
to take into account random structures specific to the
training set at hand, resulting in the validation loss
starting to increase.
introduced in § 1.3 and illustrated in Figure 3.5.
Paradoxically, although they should suffer from
severe overfitting due to their capacity, large
models usually continue to improve as training
progresses. This may be due to the inductive
bias of the model becoming the main driver of
optimization when performance is near perfect
49
on the training set [Belkin et al., 2018].
An important design choice is the learn ingrate
sched ule during training, that is, the specifica-
tion of the value of the learn ingrate at each iter-
ation of the gradient descent. The general policy
is that the learning rate should be initially large
to avoid having the optimization being trapped
in a bad local minimum early, and that it should
get smaller so that the optimized parameter val-
ues do not bounce around and reach a good min-
imum in a narrow valley of the loss landscape.
The training of very large models may take
months on thousands of powerful GPUs and
have a financial cost of several million dollars. At
this scale, the training may involve many man-
ual interventions, informed, in particular, by the
dynamics of the loss evolution.
Fine-tuning
It is often beneficial to adapt an already trained
model to a new task, referred to as a down stream
task.
It can be because the amount of data for the
original task is plentiful, while they are lim-
ited for the downstream task, and the two tasks
share enough similarities that statistical struc-
50
tures learned for the first provide a good induc-
tive bias for the second. It can also be to limit the
training cost by reusing the patterns encoded in
an existing model.
Adapting a pre-trained model to a specific task
is achieved with fine-tuning, which is a standard
training procedure for the downstream task, but
which starts from the pre-trained model instead
of using a random initialization.
This is the main strategy for most computer vi-
sion applications which generally use a model
pre-trained for classification on ImageNet [Deng
et al., 2009] (see § 6.3 and § 6.4), and it is also how
purely generative pre-trained Large Language
Models are re-purposed as assistant-like models,
able to produce interactive dialogues (see § 7.1).
We come back to techniques to cope with lim-
ited resources in inference and for fine-tuning
in Chapter 8.
51
3.7 The benefits of scale
There is an accumulation of empirical results
showing that performance, for instance, esti-
mated through the loss on test data, improves
with the amount of data according to remarkable
scalinglaws, as long as the model size increases
correspondingly [Kaplan et al., 2020] (see Figure
3.6).
Benefiting from these scaling laws in the multi-
billion sample regime is possible in part thanks to
the structure of deep models which can be scaled
up arbitrarily, as we will see, by increasing the
number of layers or feature dimensions. But it
is also made possible by the distributed nature
of the computation they implement, and by the
stochas ticgradientdescent, which requires only
a fraction of the data at a time and can operate
with datasets whose size is orders of magnitude
greater than that of the computing device’s mem-
ory. This has resulted in an exponential growth
of the models, as illustrated in Figure 3.7.
Typical vision models have 10–100million train -
able parameters and require 1018–1019FLOPs
for training [He et al., 2015; Sevilla et al., 2022].
Language models have from 100million to hun-
dreds of billions of trainable parameters and re-
52
Test loss Test loss Test lossCompute (peta-FLOP/s-day)
Dataset size (tokens)
Number of parameters
Figure 3.6: Test loss of a language model vs. the amount
of computation in petaflop/s-day, the dataset size in
tokens, that is fragments of words, and the model size
in parameters [Kaplan et al., 2020].
53
Dataset Year Nb. of images Size
ImageNet 2012 1.2M 150Gb
Cityscape 2016 25K 60Gb
LAION-5B 2022 5.8B 240Tb
Dataset Year Nb. of books Size
WMT-18-de-en 2018 14M 8Gb
The Pile 2020 1.6B 825Gb
OSCAR 2020 12B 6Tb
Table 3.1: Some examples of publicly available datasets.
The equivalent number of books is an indicative esti-
mate for 250 pages of 2000 characters per book.
quire 1020–1023FLOPs for training [Devlin et al.,
2018; Brown et al., 2020; Chowdhery et al., 2022;
Sevilla et al., 2022]. These latter models require
machines with multiple high-end GPUs.
Training these large models is impossible using
datasets with a detailed ground-truth costly to
produce, which can only be of moderate size.
Instead, it is done with datasets automatically
produced by combining data available on the
internet with minimal curation, if any. These
sets may combine multiple modalities, such as
text and images from web pages, or sound and
images from videos, which can be used for large-
scale supervised training.
As of 2024, the most powerful models are the so-
54
2015 2020101810211024
1KWh1MWh1GWh
AlexNetResNetAlphaGoAlphaZero
Transformer
GPTBERTGPT-2GPT-3
ViTPaLM
LaMDA
Whisper
VGG16
GoogLeNetCLIP-ViT
YearTraining cost (FLOP)
Figure 3.7: Training costs in number of FLOP of some
landmark models [Sevilla et al., 2023]. The colors in-
dicate the domains of application: Computer Vision
(blue), Natural Language Processing (red), or other
(black). The dashed lines correspond to the energy con-
sumption using A100s SXM in 16-bit precision. For
reference, the total electricity consumption in the US in
2021 was 3920 TWh.
55
called Large Language Models (LLMs), which we
will see in § 5.3 and § 7.1, trained on extremely
large text datasets (see Table 3.1).
56
Part II
Deep Models
57
Chapter 4
Model Components
A deep model is nothing more than a complex
tensorial computation that can ultimately be
decomposed into standard mathematical oper-
ations from linear algebra and analysis. Over
the years, the field has developed a large collec-
tion of high-level modules with a clear semantic,
and complex models combining these modules,
which have proven to be effective in specific ap-
plication domains.
Empirical evidence and theoretical results show
that greater performance is achieved with deeper
architectures, that is, long compositions of map-
pings. As we saw in section § 3.4, training such
a model is challenging due to the vanishinggra-
dient, and multiple important technical contri-
butions have mitigated this issue.
58
4.1 The notion of layer
We call layers standard complex compounded
tensor operations that have been designed and
empirically identified as being generic and effi-
cient. They often incorporate trainable param-
eters and correspond to a convenient level of
granularity for designing and describing large
deep models. The term is inherited from sim-
ple multi-layer neural networks, even though
modern models may take the form of a complex
graph of such modules, incorporating multiple
parallel pathways.
×K
Xfgn=4Y
32×324×4
In the following pages, I try to stick to the con-
vention for model depiction illustrated above:
•operators / layers are depicted as boxes,
•darker coloring indicates that they embed
trainable parameters,
•non-default valued hyper-parameters are
59
added in blue on their right,
•a dashed outer frame with a multiplicative
factor indicates that a group of layers is repli-
cated in series, each with its own set of trainable
parameters, if any, and
•in some cases, the dimension of their output is
specified on the right when it differs from their
input.
Additionally, layers that have a complex internal
structure are depicted with a greater height.
60
4.2 Linear layers
The most important modules in terms of compu-
tation and number of parameters are the Linear
layers. They benefit from decades of research
and engineering in algorithmic and chip design
for matrix operations.
Note that the term “linear” in deep learning gen-
erally refers improperly to an affine operation,
which is the sum of a linear expression and a
constant bias.
Fully connected layers
The most basic linear layer is the fully connected
layer, parameterized by a trainable weight ma-
trixWof size D′×Dandbiasvectorbof dimen-
sionD′. It implements an affine transformation
generalized to arbitrary tensor shapes, where
the supplementary dimensions are interpreted
as vector indexes. Formally, given an input X
of dimension D1×···× DK×D, it computes an
output Yof dimension D1×···× DK×D′with
∀d1,...,d K,
Y[d1,...,d K] =WX[d1,...,d K]+b.
While at first sight such an affine operation
61
seems limited to geometric transformations such
as rotations, symmetries, and translations, it can
in fact do more than that. In particular, projec-
tions for dimension reduction or signal filtering,
but also, from the perspective of the dot product
being a measure of similarity, a matrix-vector
product can be interpreted as computing match-
ing scores between the queries, as encoded by
the input vectors, and keys, as encoded by the
matrix rows.
As we saw in § 3.3, the gradient descent starts
with the parameters’ random initialization. If
this is done too naively, as seen in § 3.4, the net-
work may suffer from exploding or vanishing
activations and gradients [Glorot and Bengio,
2010]. Deep learning frameworks implement ini-
tialization methods that in particular scale the
random parameters according to the dimension
of the input to keep the variance of the activa-
tions constant and prevent pathological behav-
iors.
Convolutional layers
A linear layer can take as input an arbitrarily-
shaped tensor by reshaping it into a vector, as
long as it has the correct number of coefficients.
However, such a layer is poorly adapted to deal-
62
ϕ
XY
ψY
Xϕ
XY
ψY
Xϕ
XY
ψY
X
...
1D convolution...
1D transposed
convolution
Figure 4.1: A 1D convolution (left) takes as input
aD×Ttensor X, applies the same affine mapping
ϕ(·;w)to every sub-tensor of shape D×K, and stores
the resulting D′×1tensors into Y. A 1D transposed
convolution (right) takes as input a D×Ttensor, ap-
plies the same affine mapping ψ(·;w)to every sub-
tensor of shape D×1, and sums the shifted resulting
D′×Ktensors. Both can process inputs of different
sizes.
63
XYϕ
2D convolutionHWD
YXψ
2D transposed
convolution
Figure 4.2: A 2D convolution (left) takes as input a
D×H×Wtensor X, applies the same affine mapping
ϕ(·;w)to every sub-tensor of shape D×K×L, and
stores the resulting D′×1×1tensors into Y. A 2D
transposed convolution (right) takes as input a D×
H×Wtensor, applies the same affine mapping ψ(·;w)
to every D×1×1sub-tensor, and sums the shifted
resulting D′×K×Ltensors into Y.
ing with large tensors, since the number of pa-
rameters and number of operations are propor-
tional to the product of the input and output
dimensions. For instance, to process an RGB
image of size 256×256as input and compute a
result of the same size, it would require approxi-
mately 4×1010parameters and multiplications.
Besides these practical issues, most of the high-
dimension signals are strongly structured. For
64
ϕY
XϕY
X
s= 2...
StrideϕY
X
d= 2
DilationϕY
X
p= 2
Padding
Figure 4.3: Beside its kernel size and number of input
/ output channels, a convolution admits three hyper-
parameters: the stride s(left) modulates the step size
when going through the input tensor, the padding p
(top right) specifies how many zero entries are added
around the input tensor before processing it, and the
dilation d(bottom right) parameterizes the index count
between coefficients of the filter.
65
instance, images exhibit short-term correlations
and statistical stationarity with respect to trans-
lation, scaling, and certain symmetries. This
is not reflected in the inductivebias of a fully
connected layer, which completely ignores the
signal structure.
To leverage these regularities, the tool of choice
isconvolutional layers, which are also affine, but
process time-series or 2D signals locally, with
the same operator everywhere.
A1Dconvolution is mainly defined by three hy-
per-parameters: its kernelsizeK, its number of
input channels D, its number of output chan-
nelsD′, and by the trainable parameters wof an
affine mapping ϕ(·;w) :RD×K→RD′×1.
It can process any tensor Xof size D×Twith
T≥K, and applies ϕ(·;w)to every sub-tensor
of size D×KofX, storing the results in a tensor
Yof size D′×(T−K+1), as pictured in Figure
4.1 (left).
A2Dconvolution is similar but has a K×Lker-
nel and takes as input a D×H×Wtensor (see
Figure 4.2, left).
Both operators have for trainable parameters
those of ϕthat can be envisioned as D′filters
66
of size D×KorD×K×Lrespectively, and a
biasvector of dimension D′.
Such a layer is equiv ariant to translation, mean-
ing that if the input signal is translated, the out-
put is similarly transformed. This property re-
sults in a desirable inductivebias when dealing
with a signal whose distribution is invariant to
translation.
They also admit three additional hyper-parame-
ters, illustrated on Figure 4.3:
•Thepadding specifies how many zero coeffi-
cients should be added around the input tensor
before processing it, particularly to maintain the
tensor size when the kernel size is greater than
one. Its default value is 0.
•Thestride specifies the step size used when go-
ing through the input, allowing one to reduce the
output size geometrically by using large steps.
Its default value is 1.
•Thedilation specifies the index count between
the filter coefficients of the local affine opera-
tor. Its default value is 1, and greater values
correspond to inserting zeros between the coef-
ficients, which increases the filter / kernel size
while keeping the number of trainable parame-
67
HW
Model depth
Figure 4.4: Given an activation in a series of convolu-
tion layers, here in red, its receptivefield is the area in
the input signal, in blue, that modulates its value. Each
intermediate convolutional layer increases the width
and height of that area by roughly those of the kernel.
ters unchanged.
Except for the number of channels, a convo-
lution’s output is usually smaller than its in-
put. In the 1D case without padding nor di-
lation, if the input is of size T, the kernel of
sizeK, and the stride is S, the output is of size
T′= (T−K)/S+1.
Given an activation computed by a convolutional
layer, or the vector of values for all the channels
at a certain location, the portion of the input
68
signal that it depends on is called its receptive
field (see Figure 4.4). One of the H×Wsub-
tensors corresponding to a single channel of a
D×H×Wactivation tensor is called an activa-
tion map.
Convolutions are used to recombine information,
generally to reduce the spatial size of the rep-
resentation, in exchange for a greater number
of channels, which translates into a richer local
representation. They can implement differential
operators such as edge-detectors, or template
matching mechanisms. A succession of such lay-
ers can also be envisioned as a compositional and
hierarchical representation [Zeiler and Fergus,
2014], or as a diffusion process in which infor-
mation can be transported by half the kernel size
when passing through a layer.
A converse operation is the trans posed convo-
lution that also consists of a localized affine op-
erator, defined by similar hyper and trainable
parameters as the convolution, but which, for
instance, in the 1D case, applies an affine map-
pingψ(·;w) :RD×1→RD′×K,to every D×1
sub-tensor of the input, and sums the shifted
D′×Kresulting tensors to compute its output.
Such an operator increases the size of the signal
and can be understood intuitively as a synthe-
69
sis process (see Figure 4.1, right, and Figure 4.2,
right).
A series of convolutional layers is the usual ar-
chitecture for mapping a large-dimension signal,
such as an image or a sound sample, to a low-
dimension tensor. This can be used, for instance,
to get class scores for classification or a com-
pressed representation. Transposed convolution
layers are used the opposite way to build a large-
dimension signal from a compressed representa-
tion, either to assess that the compressed repre-
sentation contains enough information to recon-
struct the signal or for synthesis, as it is easier
to learn a density model over a low-dimension
representation. We will revisit this in § 5.2.
70
4.3 Activation functions
If a network were combining only linear com-
ponents, it would itself be a linear operator,
so it is essential to have non-linearoperations.
These are implemented in particular with activa-
tion functions, which are layers that transform
each component of the input tensor individually
through a mapping, resulting in a tensor of the
same shape.
There are many different activation functions,
but the most used is the RectifiedLinearUnit
(ReLU) [Glorot et al., 2011], which sets nega-
tive values to zero and keeps positive values un-
changed (see Figure 4.5, top right):
relu(x) =(
0ifx <0,
xotherwise .
Given that the core training strategy of deep-
learning relies on the gradient, it may seem prob-
lematic to have a mapping that is not differen-
tiable at zero and constant on half the real line.
However, the main property gradient descent
requires is that the gradient is informative on
average. Parameter initialization and data nor-
malization make half of the activations positive
71
Tanh ReLU
Leaky ReLU GELU
Figure 4.5: Activation functions.
when the training starts, ensuring that this is the
case.
Before the generalization of ReLU, the standard
activation function was the hyperbolic tangent
(Tanh, see Figure 4.5, top left) which saturates
exponentially fast on both the negative and pos-
itive sides, aggravating the vanishing gradient.
Other popular activation functions follow the
same idea of keeping positive values unchanged
and squashing the negative values. Leaky ReLU
[Maas et al., 2013] applies a small positive multi-
72
plying factor to the negative values (see Figure
4.5, bottom left):
leakyrelu( x) =(
axifx <0,
xotherwise .
And GELU [Hendrycks and Gimpel, 2016] is de-
fined using the cumulative distribution function
of the Gaussian distribution, that is:
gelu(x) =xP(Z≤x),
where Z∼𝒩(0,1). It roughly behaves like a
smooth ReLU (see Figure 4.5, bottom right).
The choice of an activation function, in partic-
ular among the variants of ReLU, is generally
driven by empirical performance.
73
4.4 Pooling
A classical strategy to reduce the signal size is to
use a pooling operation that combines multiple
activations into one that ideally summarizes the
information. The most standard operation of this
class is the max pooling layer, which, similarly
to convolution, can operate in 1D and 2D and is
defined by a kernelsize.
In its standard form, this layer computes the
maximum activation per channel, over non-
overlapping sub-tensors of spatial size equal to
the kernel size. These values are stored in a re-
sult tensor with the same number of channels
as the input, and whose spatial size is divided
by the kernel size. As with the convolution, this
operator has three hyper-parameters: padding,
stride, and dilation, with the stride being equal
to the kernel size by default. A smaller stride
results in a larger resulting tensor, following the
same formula as for convolutions (see § 4.2).
The max operation can be intuitively interpreted
as a logical disjunction, or, when it follows a
series of convolutional layers that compute lo-
cal scores for the presence of parts, as a way
of encoding that at least one instance of a part
is present. It loses precise location, making it
74
Y
XmaxY
XmaxY
Xmax
...
1D max pooling
Figure 4.6: A 1D max pooling takes as input a D×T
tensor X, computes the max over non-overlapping 1×
Lsub-tensors (in blue) and stores the resulting values
(in red) in a D×(T/L)tensor Y.
75
invariant to local deformations.
A standard alternative is the averagepooling
layer that computes the average instead of the
maximum over the sub-tensors. This is a linear
operation, whereas max pooling is not.
76
4.5 Dropout
Some layers have been designed to explicitly
facilitate training or improve the learned repre-
sentations.
One of the main contributions of that sort was
dropout [Srivastava et al., 2014]. Such a layer
has no trainable parameters, but one hyper-
parameter, p, and takes as input a tensor of arbi-
trary shape.
It is usually switched off during testing, in which
case its output is equal to its input. When it is ac-
tive, it has a probability pof setting to zero each
activation of the input tensor independently, and
it re-scales all the activations by a factor of1
1−p
to maintain the expected value unchanged (see
Figure 4.7).
The motivation behind dropout is to favor
meaningful individual activation and discourage
group representation. Since the probability that
a group of kactivations remains intact through
a dropout layer is (1−p)k, joint representations
become unreliable, making the training proce-
dure avoid them. It can also be seen as a noise
injection that makes the training more robust.
When dealing with images and 2D tensors, the
77
11111
11111
11111
11111
11111
11111
11111
11111
11111
11111 0
0
00 0
00 00
0
0× ×1
1−p
Train TestY
XY
X
Figure 4.7: Dropout can process a tensor of arbitrary
shape. During training (left), it sets activations at ran-
dom to zero with probability pand applies a multiply-
ing factor to keep the expected values unchanged. Dur-
ing test (right), it keeps all the activations unchanged.
short-term correlation of the signals and the re-
sulting redundancy negate the effect of dropout,
since activations set to zero can be inferred from
their neighbors. Hence, dropout for 2D tensors
sets entire channels to zero instead of individual
activations (see Figure 4.8).
Although dropout is generally used to improve
training and is inactive during inference, it can
be used in certain setups as a randomization
strategy, for instance, to estimate empirically
confidence scores [Gal and Ghahramani, 2015].
78
BD
H,W
1101001 × ×1
1−p
Train Test
Figure 4.8: 2D signals such as images generally exhibit
strong short-term correlation and individual activa-
tions can be inferred from their neighbors. This redun-
dancy nullifies the effect of the standard unstructured
dropout, so the usual dropout layer for 2D tensors drops
entire channels instead of individual values.
79
4.6 Normalizing layers
An important class of operators to facilitate the
training of deep architectures are the normaliz-
inglayers, which force the empirical mean and
variance of groups of activations.
The main layer in that family is batch normal-
ization [Ioffe and Szegedy, 2015], which is the
only standard layer to process batches instead
of individual samples. It is parameterized by a
hyper-parameter Dand two series of trainable
scalar parameters β1,...,β Dandγ1,...,γ D.
Given a batch of Bsamples x1,...,x Bof dimen-
sionD, it first computes for each of the Dcom-
ponents an empirical mean ˆmdand variance ˆvd
across the batch:
ˆmd=1
BBX
b=1xb,d
ˆvd=1
BBX
b=1(xb,d−ˆmd)2,
from which it computes for every component
xb,da normalized value zb,d, with empirical
mean 0and variance 1, and from it the final
result value yb,dwith mean βdand standard de-
80
BD
H,W
(· −ˆmd)/√ˆvd+ϵγd·+βd
(· −ˆmb)/√ˆvb+ϵγd,h,w·+βd,h,w
batchnorm layernorm
Figure 4.9: Batch normalization (left) normalizes in
mean and variance each group of activations for a
given d, and scales/shifts that same group of activation
with learned parameters for each d. Layer normaliza-
tion (right) normalizes each group of activations for a
certain b, and scales/shifts each group of activations
for a given d,h,w with learned parameters indexed by
the same.
81
viation γd:
∀b, z b,d=xb,d−ˆmd√ˆvd+ϵ
yb,d=γdzb,d+βd.
Because this normalization is defined across a
batch, it is done only during training. During
testing, the layer transforms individual samples
according to the ˆmds and ˆvds estimated with a
moving average over the full training set, which
boils down to a fixed affine transformation per
component.
The motivation behind batch normalization was
to avoid that a change in scaling in an early layer
of the network during training impacts all the
layers that follow, which then have to adapt their
trainable parameters accordingly. Although the
actual mode of action may be more complicated
than this initial motivation, this layer consider-
ably facilitates the training of deep models.
In the case of 2D tensors, to follow the prin-
ciple of convolutional layers of processing all
locations similarly, the normalization is done
per-channel across all 2D positions, and βand
γremain vectors of dimension Dso that the
scaling/shift does not depend on the 2D posi-
tion. Hence, if the tensor to be processed is
82
of shape B×D×H×W, the layer computes
( ˆmd,ˆvd), ford= 1,...,D from the correspond-
ingB×H×Wslice, normalizes it accordingly,
and finally scales and shifts its components with
the trainable parameters βdandγd.
So, given a B×Dtensor, batch normalization
normalizes it across band scales/shifts it ac-
cording to d, which can be implemented as a
component-wise product by γand a sum with
β. Given a B×D×H×Wtensor, it normal-
izes across b,h,w and scales/shifts according to
d(see Figure 4.9, left).
This can be generalized depending on these di-
mensions. For instance, layer normalization [Ba
et al., 2016] computes moments and normalizes
across all components of individual samples, and
scales and shifts components individually (see
Figure 4.9, right). So, given a B×Dtensor, it
normalizes across dand scales/shifts also accord-
ing to the same. Given a B×D×H×Wtensor,
it normalizes it across d,h,w and scales/shifts
according to the same.
Contrary to batch normalization, since it pro-
cesses samples individually, layer normalization
behaves the same during training and testing.
83
4.7 Skip connections
Another technique that mitigates the vanishing
gradient and allows the training of deep archi-
tectures are skip connections [Long et al., 2014;
Ronneberger et al., 2015]. They are not layers
per se, but an architectural design in which out-
puts of some layers are transported as-is to other
layers further in the model, bypassing process-
ing in between. This unmodified signal can be
concatenated or added to the input of the layer
the connection branches into (see Figure 4.10). A
particular type of skip connections are the resid -
ualconnections which combine the signal with
a sum, and usually skip only a few layers (see
Figure 4.10, right).
The most desirable property of this design is to
ensure that, even in the case of gradient-killing
processing at a certain stage, the gradient will
still propagate through the skip connections.
Residual connections, in particular, allow for the
building of deep models with up to several hun-
dred layers, and key models, such as the resid ual
networks [He et al., 2015] in computer vision
(see § 5.2), and the Trans form ers [Vaswani et al.,
2017] in natural language processing (see § 5.3),
are entirely composed of blocks of layers with
residual connections.
84
···f(1)f(2)f(3)f(4)f(5)f(6)f(7)f(8)···
···f(1)f(2)f(3)f(4)f(5)f(6)···
···f(1)f(2)+f(3)f(4)+···
Figure 4.10: Skip connections, highlighted in red on this
figure, transport the signal unchanged across multiple
layers. Some architectures (center) that downscale and
re-upscale the representation size to operate at multiple
scales, have skip connections to feed outputs from the
early parts of the network to later layers operating at
the same scales [Long et al., 2014; Ronneberger et al.,
2015]. The residual connections (right) are a special
type of skip connections that sum the original signal
to the transformed one, and usually bypass at most a
handful of layers [He et al., 2015].
85
Their role can also be to facilitate multi-scale rea-
soning in models that reduce the signal size be-
fore re-expanding it, by connecting layers with
compatible sizes, for instance for semanticseg-
mentation (see § 6.4). In the case of residual
connections, they may also facilitate learning
by simplifying the task to finding a differential
improvement instead of a full update.
86
4.8 Attention layers
In many applications, there is a need for an op-
eration able to combine local information at lo-
cations far apart in a tensor. For instance, this
could be distant details for coherent and realistic
imagesynthesis, or words at different positions
in a paragraph to make a grammatical or seman-
tic decision in NaturalLanguage Processing.
Fully connected layers cannot process large-
dimension signals, nor signals of variable size,
andconvolutional layers are not able to prop-
agate information quickly. Strategies that ag-
gregate the results of convolutions, for instance,
by averaging them over large spatial areas, suf-
fer from mixing multiple signals into a limited
number of dimensions.
Attention layers specifically address this prob-
lem by computing an attention score for each
component of the resulting tensor to each com-
ponent of the input tensor, without locality con-
straints, and averaging the features across the
full tensor accordingly [Vaswani et al., 2017].
Even though they are substantially more com-
plicated than other layers, they have become a
standard element in many recent models. They
are, in particular, the key building block of Trans -
87
KQ
VYA A
Computes Aq,1,...,A q,NKV Computes Yq
Figure 4.11: The attention operator can be inter-
preted as matching every query Qqwith all the
keysK1,...,K NKVto get normalized attention scores
Aq,1,...,A q,NKV(left, and Equation 4.1), and then av-
eraging the values V1,...,V NKVwith these scores to
compute the resulting Yq(right, and Equation 4.2).
form ers, the dominant architecture for Large
Language Models. See § 5.3 and § 7.1.
Attention operator
Given
•a tensor Qofqueries of size NQ×DQK,
•a tensor Kofkeys of size NKV×DQK, and
•a tensor Vofvalues of size NKV×DV,
theattention operator computes a tensor
Y= att( Q,K,V )
of dimension NQ×DV. To do so, it first com-
putes for every query index qand every key in-
88
dexkan attention score Aq,kas the softargmax
of the dot products between the query Qqand
the keys:
Aq,k=exp
1√
DQKQq·Kk
P
lexp
1√
DQKQq·Kl, (4.1)
where the scaling factor1√
DQKkeeps the range
of values roughly unchanged even for large DQK.
Then a retrieved value is computed for each
query by averaging the values according to the
attention scores (see Figure 4.11):
Yq=X
kAq,kVk. (4.2)
So if a query Qnmatches one key Kmfar more
than all the others, the corresponding attention
score An,mwill be close to one, and the retrieved
value Ynwill be the value Vmassociated to that
key. But, if it matches several keys equally, then
Ynwill be the average of the associated values.
This can be implemented as
att(Q,K,V ) = softargmaxQKT
√
DQK
| {z }
AV.
89
Q K VT×exp⊙1/ΣkdropoutA
M×Y
Masked
softargmax
Figure 4.12: The attention operator Y= att( Q,K,V )
computes first an attention matrix Aas the per-query
softargmax of QKT, which may be masked by a con-
stant matrix Mbefore the normalization. This atten-
tion matrix goes through a dropout layer before being
multiplied by Vto get the resulting Y. This operator
can be made causal by taking Mfull of 1s below the
diagonal and zeros above.
90
This operator is usually extended in two ways,
as depicted in Figure 4.12. First, the attention
matrix can be masked by multiplying it before
the softargmax normalization by a Boolean ma-
trixM. This allows, for instance, to make the
operator causal by taking Mfull of 1s below the
diagonal and zero above, preventing Yqfrom de-
pending on keys and values of indices kgreater
thanq. Second, the attention matrix is processed
by a dropout layer (see § 4.5) before being multi-
plied by V, providing the usual benefits during
training.
Since a dot product is computed for every
query/key pair, the computational cost of the at-
tention operator is quadratic with the sequence
length. This happens to be problematic, as some
of the applications of these methods require to
process sequences of tens of thousands, or more
tokens. Multiple attempts have been made at
reducing this cost, for instance by combining a
dense attention to a local window with a long-
range sparse attention [Beltagy et al., 2020], or
linearizing the operator to benefit from the asso-
ciativity of the matrix product and compute the
key-value product before multiplying with the
queries [Katharopoulos et al., 2020].
91
×WQ
1×WK
1×WV
1att
×WQ
2×WK
2×WV
2att
×WQ
3×WK
3×WV
3att
×WQ
4×WK
4×WV
4att
×WQ
H×WK
H×WV
Hatt(Y1| ··· |YH)
XQXKXV×WOY
×H
Figure 4.13: The Multi-head Attention layer applies
for each of its h= 1,...,H heads a parametrized lin-
ear transformation to individual elements of the input
sequences XQ,XK,XVto get sequences Q,K,V that
are processed by the attention operator to compute Yh.
These Hsequences are concatenated along features,
and individual elements are passed through one last
linear operator to get the final result sequence Y.
92
Multi-head Attention Layer
This parameterless attention operator is the key
element in the Multi -Head Attention layer de-
picted in Figure 4.13. The structure of this layer
is defined by several hyper-parameters: a num-
berHof heads, and the shapes of three series of
Htrainable weight matrices
•WQof size H×D×DQK,
•WKof size H×D×DQK, and
•WVof size H×D×DV,
to compute respectively the queries, the keys,
and the values from the input, and a final weight
matrix WOof size HDV×Dto aggregate the
per-head results.
It takes as input three sequences
•XQof size NQ×D,
•XKof size NKV×D, and
•XVof size NKV×D,
from which it computes, for h= 1,...,H ,
Yh= att 
XQWQ
h,XKWK
h,XVWV
h
.
These sequences Y1,...,Y Hare concatenated
along the feature dimension and each individual
element of the resulting sequence is multiplied
93
byWOto get the final result:
Y= (Y1| ··· |YH)WO.
As we will see in § 5.3 and in Figure 5.6, this
layer is used to build two model sub-structures:
self-attention blocks, in which the three input
sequences XQ,XK, and XVare the same, and
cross -attention blocks, where XKandXVare
the same.
It is noteworthy that the attention operator,
and consequently the multi-head attention layer
when there is no masking, is invariant to a per-
mutation of the keys and values, and equiv ariant
to a permutation of the queries, as it would per-
mute the resulting tensor similarly.
94
4.9 Token embedding
In many situations, we need to convert discrete
tokens into vectors. This can be done with an em-
bedding layer, which consists of a lookup table
that directly maps integers to vectors.
Such a layer is defined by two hyper-parame-
ters: the number Nof possible token values,
and the dimension Dof the output vectors, and
one trainable N×Dweight matrix M.
Given as input an integer tensor Xof dimen-
sionD1×···× DKand values in {0,...,N −1}
such a layer returns a real-valued tensor Yof
dimension D1×···× DK×Dwith
∀d1,...,d K,
Y[d1,...,d K] =M[X[d1,...,d K]].
95
4.10 Positional encoding
While the processing of a fully connected layer
is specific to both the positions of the features
in the input tensor and to the positions of the
resulting activations in the output tensor, con-
volutional layers and Multi -Head Attention lay-
ers are oblivious to the absolute position in the
tensor. This is key to their strong invariance and
inductivebias, which is beneficial for dealing
with a stationary signal.
However, this can be an issue in certain situ-
ations where proper processing has to access
the absolute positioning. This is the case, for
instance, for image synthesis, where the statis-
tics of a scene are not totally stationary, or in
natural language processing, where the relative
positions of words strongly modulate the mean-
ing of a sentence.
The standard way of coping with this problem
is to add or concatenate to the feature represen-
tation, at every position, a positional encoding,
which is a feature vector that depends on the po-
sition in the tensor. This positional encoding can
be learned as other layer parameters, or defined
analytically.
For instance, in the original Trans former model,
96
for a series of vectors of dimension D, Vaswani
et al. [2017] add an encoding of the sequence
index as a series of sines and cosines at various
frequencies:
pos-enc[ t,d] =

sin
t
Td/D
ifd∈2N
cos
t
T(d−1)/D
otherwise,
withT= 104.
97
Chapter 5
Architectures
The field of deep learning has developed over
the years for each application domain multiple
deep architectures that exhibit good trade-offs
with respect to multiple criteria of interest: e.g.
ease of training, accuracy of prediction, memory
footprint, computational cost, scalability.
98
5.1 Multi-Layer Perceptrons
The simplest deep architecture is the Multi -Layer
Perceptron ( MLP), which takes the form of a
succession of fully connected layers separated
byactivationfunctions. See an example in Figure
5.1. For historical reasons, in such a model, the
number of hiddenlayers refers to the number of
linear layers, excluding the last one.
A key theoretical result is the universalapproxi-
mation theorem [Cybenko, 1989] which states
that, if the activation function σis continuous
Xfully-connrelufully-connrelufully-connY
5025102
Hidden
layers
Figure 5.1: This multi-layer perceptron takes as input
a one-dimensional tensor of size 50, is composed of
three fully connected layers with outputs of dimensions
respectively 25,10, and 2, the two first followed by
ReLU layers.
99
and not polynomial, any continuous function f
can be approximated arbitrarily well uniformly
on a compact domain, which is bounded and
contains its boundary, by a model of the form
l2◦σ◦l1where l1andl2are affine. Such a model
is aMLP with a single hidden layer, and this
result implies that it can approximate anything
of practical value. However, this approximation
holds if the dimension of the first linear layer’s
output can be arbitrarily large.
In spite of their simplicity, MLPs remain an im-
portant tool when the dimension of the signal
to be processed is not too large.
100
5.2 Convolutional networks
The standard architecture for processingimages
is aconvolutional network, or convnet, that com-
bines multiple convolutional layers, either to re-
duce the signal size before it can be processed by
fully connected layers, or to output a 2D signal
also of large size.
LeNet-like
The original LeNet model for image classifica-
tion [LeCun et al., 1998] combines a series of 2D
convolutional layers and max pooling layers that
play the role of feature extractor, with a series of
fully connected layers which act as a MLP and
perform the classification per se (see Figure 5.2).
This architecture was the blueprint for many
models that share its structure and are simply
larger, such as AlexNet [Krizhevsky et al., 2012]
or the VGG family [Simonyan and Zisserman,
2014].
Residual networks
Standard convolutional neural networks that fol-
low the architecture of the LeNet family are not
easily extended to deep architectures and suffer
from the vanishing gradient problem. The resid -
101
Xconv-2dk=5maxpoolk=3reluconv-2dk=5maxpoolk=2relureshapefully-connrelufully-connˆP(Y)
1×28×2832×24×2432×8×864×4×464×2×225620010
Feature
extractorClassifier
Figure 5.2: Example of a small LeNet-like network for
classifying 28×28grayscale images of handwritten
digits [LeCun et al., 1998]. Its first half is convolutional,
and alternates convolutional layers per se and max
pooling layers, reducing the signal dimension from
28×28scalars to 256. Its second half processes this
256-dimensional feature vector through a one hidden
layer perceptron to compute 10logit scores correspond-
ing to the ten possible digits.
102
Xconv-2dk=1batchnormreluconv-2dk=3p=1batchnormreluconv-2dk=1batchnorm+reluY
C×H×WC
2×H×WC×H×WC×H×W
Figure 5.3: A residual block.
ualnetworks, or ResNets, proposed by He et al.
[2015] explicitly address the issue of the vanish-
ing gradient with resid ualconnections (see § 4.7),
which allow hundreds of layers. They have be-
come standard architectures for computer vision
applications, and exist in multiple versions de-
pending on the number of layers. We are going
to look in detail at the architecture of the ResNet -
50 for classification.
As other ResNets, it is composed of a series of
103
Xconv-2dk=1batchnormreluconv-2dk=3s=S p=1batchnormreluconv-2dk=1batchnorm+reluY
conv-2dk=1s=Sbatchnorm
C×H×WC
S×H×WC
S×H
S×W
S4C
S×H
S×W
S4C
S×H
S×W
S
Figure 5.4: A downscaling residual block. It admits a
hyper-parameter S, the stride of the first convolution
layer, which modulates the reduction of the tensor size.
resid ualblocks, each combining several convolu-
tional layers,batch norm layers, and ReLU layers,
wrapped in a residual connection. Such a block
is pictured in Figure 5.3.
A key requirement for high performance with
real images is to propagate a signal with a large
number of channels, to allow for a rich repre-
sentation. However, the parameter count of a
104
×2×3×5×2
Xconv-2dk=7s=2p=3batchnormrelumaxpoolk=3s=2p=1dresblock
S=1resblockdresblock
S=2resblockdresblock
S=2resblockdresblock
S=2resblockavgpoolk=7reshapefully-connˆP(Y)
3×224×22464×112×11264×56×56256×56×56512×28×281024×14×142048×7×72048×1×120481000
Figure 5.5: Structure of the ResNet-50 [He et al., 2015].
105
convolutional layer, and its computational cost,
are quadratic with the number of channels. This
residual block mitigates this problem by first re-
ducing the number of channels with a 1×1con-
volution, then operating spatially with a 3×3
convolution on this reduced number of chan-
nels, and then upscaling the number of channels,
again with a 1×1convolution.
The network reduces the dimensionality of the
signal to finally compute the logits for the clas-
sification. This is done thanks to an architec-
ture composed of several sections, each starting
with a down scalingresid ualblock that halves
the height and width of the signal, and doubles
the number of channels, followed by a series
of residual blocks. Such a downscaling resid-
ual block has a structure similar to a standard
residual block, except that it requires a residual
connection that changes the tensor shape. This
is achieved with a 1×1convolution with a stride
of two (see Figure 5.4).
The overall structure of the ResNet-50 is pre-
sented in Figure 5.5. It starts with a 7×7convo-
lutional layer that converts the three-channel in-
put image to a 64-channel image of half the size,
followed by four sections of residual blocks. Sur-
prisingly, in the first section, there is no down-
106
scaling, only an increase of the number of chan-
nels by a factor of 4. The output of the last resid-
ual block is 2048×7×7, which is converted to a
vector of dimension 2048 by an average pooling
of kernel size 7×7, and then processed through
a fully-connected layer to get the final logits,
here for 1000 classes.
107
5.3 Attention models
As stated in § 4.8, many applications, particu-
larly from natural language processing, benefit
greatly from models that include attention mech-
anisms. The architecture of choice for such tasks,
which has been instrumental in recent advances
in deep learning, is the Trans former proposed
by Vaswani et al. [2017].
Transformer
The original Transformer, pictured in Figure 5.7,
was designed for sequence-to-sequence transla-
tion. It combines an encoder that processes the
input sequence to get a refined representation,
and an autoregressive decoder that generates
each token of the result sequence, given the en-
coder’s representation of the input sequence and
the output tokens generated so far.
As the residual convolutional networks of § 5.2,
both the encoder and the decoder of the Trans-
former are sequences of compounded blocks
built with residual connections.
•Thefeed-forward block, pictured at the top of
Figure 5.6 is a one hidden layer MLP, preceded
by a layer normalization. It can update represen-
tations at every position separately.
108
XQKVlayernormfully-conngelufully-conndropout+Y
XQKVlayernormQ K Vmha+Y
XQlayernormQ K Vmha+Y
XKV
Figure 5.6: Feed-forward block (top), self-attention
block (bottom left) and cross -attention block (bottom
right). These specific structures proposed by Radford
et al. [2018] differ slightly from the original architec-
ture of Vaswani et al. [2017], in particular by having
the layer normalization first in the residual blocks.
109
×N×N
X1,...,X Tembed+self-attffwZ1,...,Z T
pos-enc0,Y1,...,Y S−1embed+causal
self-attQ KVcross-attffwfully-connˆP(Y1),...,ˆP(YS|Ys<S)
pos-enc
EncoderDecoder
TT×DT×DSS×DS×DS×V
Figure 5.7: Original encoder-decoder Trans former
model for sequence-to-sequence translation [Vaswani
et al., 2017].
110
•Theself-attention block, pictured on the bot-
tom left of Figure 5.6, is a Multi -Head Attention
layer (see § 4.8), that recombines information
globally, allowing any position to collect infor-
mation from any other positions, preceded by
alayer normalization. This block can be made
causal by using an adequate mask in the atten-
tion layer, as described in § 4.8
•Thecross -attentionblock, pictured on the bot-
tom right of Figure 5.6, is similar except that it
takes as input two sequences, one to compute
the queries and one to compute the keys and
values.
The encoder of the Transformer (see Figure
5.7, bottom), recodes the input sequence of dis-
crete tokens X1,...X Twith an embedding layer
(see § 4.9), and adds a positional encoding (see
§ 4.10), before processing it with several self-
attention blocks to generate a refined represen-
tation Z1,...,Z T.
The decoder (see Figure 5.7, top), takes as in-
put the sequence Y1,...,Y S−1of result tokens
produced so far, similarly recodes them through
an embedding layer, adds a positional encoding,
and processes it through alternating causal self-
attention blocks and cross-attention blocks to
111
×N
0,X1,...,X T−1embed+causal
self-attffwfully-connˆP(X1),...,ˆP(XT|Xt<T)
pos-enc
TT×DT×DT×V
Figure 5.8: GPT model [Radford et al., 2018].
produce the logits predicting the next tokens.
These cross-attention blocks compute their keys
and values from the encoder’s result represen-
tation Z1,...,Z T, which allows the resulting se-
quence to be a function of the original sequence
X1,...,X T.
As we saw in § 3.2 being causal ensures that
such a model can be trained by minimizing the
cross-entropy summed across the full sequence.
Generative Pre-trained Transformer
TheGenerativePre-trained Trans former ( GPT)
[Radford et al., 2018, 2019], pictured in Figure 5.8
112
is a pure autoregressive model that consists of a
succession of causal self-attention blocks, hence
a causal version of the original Transformer en-
coder.
This class of models scales extremely well, up
to hundreds of billions of trainable parameters
[Brown et al., 2020]. We will come back to their
use for text generation in § 7.1.
Vision Transformer
Transformers have been put to use for image
classification with the Vision Trans former ( ViT)
model [Dosovitskiy et al., 2020] (see Figure 5.9).
It splits the three-channel input image into M
patches of resolution P×P, which are then flat-
tened to create a sequence of vectors X1,...,X M
of shape M×3P2. This sequence is multiplied
by a trainable matrix WEof shape 3P2×Dto
map it to an M×Dsequence, to which is con-
catenated one trainable vector E0. The resulting
(M+1)×Dsequence E0,...,E Mis then pro-
cessed through multiple self-attention blocks.
See § 5.3 and Figure 5.6.
The first element Z0in the resultant sequence,
which corresponds to E0and is not associated
with any part of the image, is finally processed
113
×N
E0,E1,...,E M+self-attffwZ0,Z1,...,Z Mfully-conngelufully-conngelufully-connˆP(Y)
×WE
X1,...,X ME0pos-encMLP
readout
Image
encoderM×3P2(M+1)×D(M+1)×DDC
Figure 5.9: Vision Transformer model [Dosovitskiy
et al., 2020].
114
by a two-hidden-layer MLP to get the final C
logits. Such a token, added for a readout of a
class prediction, was introduced by Devlin et al.
[2018] in the BERT model and is referred to as a
CLS token.
115
Part III
Applications
116
Chapter 6
Prediction
A first category of applications, such as face
recognition, sentiment analysis, object detection,
or speech recognition, requires predicting an un-
known value from an available signal.
117
6.1 Image denoising
A direct application of deep models to image
processing is to recover from degradation by
utilizing the redundancy in the statistical struc-
ture of images. The petals of a sunflower in a
grayscale picture can be colored with high confi-
dence, and the texture of a geometric shape such
as a table on a low-light, grainy picture can be
corrected by averaging it over a large area likely
to be uniform.
Adenoisingautoencoder is a model that takes
a degraded signal ˜Xas input and computes an
estimate of the original signal X. For images, it
is a convolutional network that may integrate
skip-connections, in particular to combine repre-
sentations at the same resolution obtained early
and late in the model, as well as attention layers
to facilitate taking into account elements that
are far away from each other.
Such a model is trained by collecting a large num-
ber of clean samples paired with their degraded
inputs. The latter can be captured in degraded
conditions, such as low-light or inadequate fo-
cus, or generated algorithmically, for instance,
by converting the clean sample to grayscale, re-
ducing its size, or aggressively compressing it
118
with a lossy compression method.
The standard training procedure for denoising
autoencoders uses the MSE loss summed across
all pixels, in which case the model aims at com-
puting the best average clean picture, given the
degraded one, that is E[X|˜X]. This quantity
may be problematic when Xis not completely
determined by ˜X, in which case some parts
of the generated signal may be an unrealistic,
blurry average.
119
6.2 Image classification
Image classification is the simplest strategy for
extracting semantics from an image and consists
of predicting a class from a finite, predefined
number of classes, given an input image.
The standard models for this task are convolu-
tional networks, such as ResNets (see § 5.2), and
attention-based models such as ViT (see § 5.3).
These models generate a vector of logits with as
many dimensions as there are classes.
The training procedure simply minimizes the
cross-entropy loss (see § 3.1). Usually, perfor-
mance can be improved with data augmenta-
tion, which consists of modifying the training
samples with hand-designed random transfor-
mations that do not change the semantic content
of the image, such as cropping, scaling, mirror-
ing, or color changes.
120
6.3 Object detection
A more complex task for image understanding is
objectdetection, in which the objective is, given
an input image, to predict the classes and posi-
tions of objects of interest.
An object position is formalized as the four co-
ordinates (x1,y1,x2,y2)of a rectangular bound-
ing box, and the ground truth associated with
each training image is a list of such bounding
boxes, each labeled with the class of the object
contained therein.
The standard approach to solve this task, for in-
stance, by the SingleShot Detector (SSD) [Liu
et al., 2015]), is to use a convolutional neural
network that produces a sequence of image
representations Zsof size Ds×Hs×Ws, s=
1,...,S , with decreasing spatial resolution Hs×
Wsdown to 1×1fors=S(see Figure 6.1). Each
of these tensors covers the input image in full, so
theh,w indices correspond to a partitioning of
the image lattice into regular squares that gets
coarser when sincreases.
As seen in § 4.2, and illustrated in Figure 4.4,
due to the succession of convolutional layers, a
feature vector (Zs[0,h,w],...,Z s[Ds−1,h,w])
is a descriptor of an area of the image, called its
121
X
Z1
Z2ZS−1ZS
......
Figure 6.1: A convolutional object detector processes the
input image to generate a sequence of representations
of decreasing resolutions. It computes for every h,w, at
every scale s, a pre-defined number of bounding boxes
whose centers are in the image area corresponding to
that cell, and whose sizes are such that they fit in its
receptive field. Each prediction takes the form of the
estimates (ˆx1,ˆx2,ˆy1,ˆy2), represented by the red boxes
above, and a vector of C+1logits for the Cclasses of
interest, and an additional “no object” class.
122
Figure 6.2: Examples of object detection with the Single-
Shot Detector [Liu et al., 2015].
123
receptivefield, that is larger than this square but
centered on it. This results in a non-ambiguous
matching of any bounding box (x1,x2,y1,y2)to
as,h,w , determined respectively by max( x2−
x1,y2−y1),y1+y2
2, andx1+x2
2.
Detection is achieved by adding Sconvolutional
layers, each processing a Zsand computing, for
every tensor indices h,w, the coordinates of a
bounding box and the associated logits. If there
areCobject classes, there are C+1logits, the
additional one standing for “no object.” Hence,
each additional convolution layer has 4+C+1
output channels. The SSD algorithm in particu-
lar generates several bounding boxes per s,h,w ,
each dedicated to a hard-coded range of aspect
ratios.
Training sets for object detection are costly to
create, since the labeling with bounding boxes
requires a slow human intervention. To mitigate
this issue, the standard approach is to fine-tune
a convolutional model that has been pre-trained
on a large classification dataset such as VGG-16
for the original SSD, and to replace its final fully-
connected layers with additional convolutional
ones. Surprisingly, models trained for classifica-
tion only learn feature representations that can
be repurposed for object detection, even though
124
that task involves the regression of geometric
quantities.
During training, every ground-truth bounding
box is associated with its s,h,w , and induces a
loss term composed of a cross-entropy loss for
the logits, and a regression loss such as MSE
for the bounding box coordinates. Every other
s,h,w free of bounding-box match induces a
cross-entropy only penalty to predict the class
“no object”.
125
6.4 Semantic segmentation
The finest-grain prediction task for image under-
standing is semanticsegmentation, which con-
sists of predicting, for each pixel, the class of the
object to which it belongs. This can be achieved
with a standard convolutional neural network
that outputs a convolutional map with as many
channels as classes, carrying the estimated logits
for every pixel.
While a standard residual network, for instance,
can generate a dense output of the same reso-
lution as its input, as for object detection, this
task requires operating at multiple scales. This
is necessary so that any object, or sufficiently
informative sub-part, regardless of its size, is
captured somewhere in the model by the feature
representation at a single tensor position. Hence,
standard architectures for this task downscale
the image with a series of convolutional layers
to increase the receptive field of the activations,
and re-upscale it with a series of trans posed con-
volutional layers, or other upscaling methods
such as bilinear interpolation, to make the pre-
diction at high resolution.
However, a strict downscaling-upscaling archi-
tecture does not allow for operating at a fine
126
Figure 6.3: Semantic segmentation results with the
Pyramid Scene Parsing Network [Zhao et al., 2016].
grain when making the final prediction, since all
the signal has been transmitted through a low-
resolution representation at some point. Models
that apply such downscaling-upscaling serially
mitigate these issues with skip connections from
layers at a certain resolution, before downscal-
ing, to layers at the same resolution, after upscal-
ing [Long et al., 2014; Ronneberger et al., 2015].
Models that do it in parallel, after a convolutional
127
backbone, concatenate the resulting multi-scale
representation after upscaling, before making
the final per-pixel prediction [Zhao et al., 2016].
Training is achieved with a standard cross-
entropy summed over all the pixels. As for ob-
ject detection, training can start from a network
pre-trained on a large-scale image classification
dataset to compensate for the limited availability
of segmentation ground truth.
128
6.5 Speech recognition
Speech recog nition consists of converting a
sound sample into a sequence of words. There
have been plenty of approaches to this problem
historically, but a conceptually simple and recent
one proposed by Radford et al. [2022] consists of
casting it as a sequence-to-sequence translation
and then solving it with a standard attention-
based Trans former, as described in § 5.3.
Their model first converts the sound signal into a
spectrogram, which is a one-dimensional series
T×D, that encodes at every time step a vector
of energies in Dfrequency bands. The associ-
ated text is encoded with the BPE tokenizer (see
§ 3.2).
The spectrogram is processed through a few 1D
convolutional layers, and the resulting repre-
sentation is fed into the encoder of the Trans-
former. The decoder directly generates a discrete
sequence of tokens, that correspond to one of
the possible tasks considered during training.
Multiple objectives are considered: transcription
of English or non-English text, translation from
any language to English, or detection of non-
speech sequences, such as background music or
ambient noise.
129
This approach allows leveraging extremely large
datasets that combine multiple types of sound
sources with diverse ground truths.
It is noteworthy that even though the ultimate
goal of this approach is to produce a transla-
tion as deterministic as possible given the input
signal, it is formally the sampling of a text dis-
tribution conditioned on a sound sample, hence
a synthesis process. The decoder is, in fact, ex-
tremely similar to the generative model of § 7.1.
130
6.6 Text-image representations
A powerful approach to image understanding
consists of learning consistent image and text
representations, such that an image, or a textual
description of it, would be mapped to the same
feature vector.
The Contrastive Language -ImagePre-train ing
(CLIP) proposed by Radford et al. [2021] com-
bines an image encoder f, which is a ViT, and
a text encoder g, which is a GPT. See § 5.3 for
both.
To repurpose a GPT as a text encoder, instead of a
standard autoregressive model, they add an “end
of sentence” token to the input sequence, and use
the representation of this token in the last layer
as the embedding. Its dimension is between 512
and1024 , depending on the configuration.
Those two models are trained from scratch using
a dataset of 400 million image-text pairs (ik,tk)
collected from the internet. The training proce-
dure follows the standard mini-batch stochastic
gradient descent approach but relies on a con-
trastive loss. The embeddings are computed for
every image and every text of the Npairs in the
mini-batch, and a cosine similarity measure is
computed not only between text and image em-
131
beddings from each pair, but also across pairs, re-
sulting in an N×Nmatrix of similarity scores:
lm,n=f(im)·g(tn), m= 1,...,N,n = 1,...,N.
The model is trained with cross-entropy so that,
∀nthe values l1,n,...,l N,ninterpreted as logit
scores predict n, and similarly for ln,1,...,l n,N.
This means that ∀n,m, s.t.n̸=mthe similarity
ln,nis unambiguously greater than both ln,mand
lm,n.
When it has been trained, this model can be used
to do zero-shot prediction, that is, classifying a
signal in the absence of training examples by
defining a series of candidate classes with text
descriptions, and computing the similarity of the
embedding of an image with the embedding of
each of those descriptions (see Figure 6.4).
Additionally, since the textual descriptions are
often detailed, such a model has to capture a
richer representation of images and pick up cues
beyond what is necessary for instance for classifi-
cation. This translates to excellent performance
on challenging datasets such as ImageNet Adver-
sarial [Hendrycks et al., 2019] which was specifi-
cally designed to degrade or erase cues on which
standard predictors rely.
132
Figure 6.4: The CLIP text-image embedding [Radford
et al., 2021] allows for zero-shot prediction by predicting
which class description embedding is the most consis-
tent with the image embedding.
133
6.7 Reinforcement learning
Many problems, such as strategy games or
robotic control, can be formalized with a discrete-
time state process Stand reward process Rtthat
can be modulated by choosing actions At. If
StisMarko vian, meaning that it carries alone
as much information about the future as all the
past states until that instant, such an object is a
Marko vian Decision Process ( MDP).
Given an MDP, the objective is classically to find
apolicyπsuch that At=π(St)maximizes the
expectation of the return, which is an accumu-
lated discounted reward:
E
X
t≥0γtRt
,
for a discount factor 0< γ < 1.
This is the standard setup of Reinforce ment
Learn ing (RL), and it can be worked out by intro-
ducing the optimal state-action value function
Q(s,a)which is the expected return if we exe-
cute action ain state s, and then follow the opti-
malpolicy. It provides a means to compute the
optimal policy as π(s) = argmaxaQ(s,a), and,
thanks to the Markovian assumption, it verifies
134
theBellman equa tion:
Q(s,a) = (6.1)
E
Rt+γmax
a′Q(St+1,a′)St=s,At=a
,
from which we can design a procedure to train
a parametric model Q(·,·;w).
To apply this framework to play classical Atari
video games, Mnih et al. [2015] use for Stthe con-
catenation of the frame at time tand the three
that precede, so that the Markovian assumption
is reasonable, and use for Qa model dubbed the
Deep Q-Network ( DQN), composed of two con-
volutional layers and one fully connected layer
with one output value per action, following the
classical structure of a LeNet (see § 5.2).
Training is achieved by alternatively playing and
recording episodes, and building mini-batches of
tuples (sn,an,rn,s′n)∼(St,At,Rt,St+1)taken
across stored episodes and time steps, and mini-
mizing
ℒ(w) =1
NNX
n=1(Q(sn,an;w)−yn)2(6.2)
with one iteration of SGD, where yn=rnif this
tuple is the end of the episode, and yn=rn+
γmax aQ(s′n,a; ¯w)otherwise.
135
Frame numberValue
Figure 6.5: This graph shows the evolution of the state
value V(St) = max aQ(St,a)during a game of Break-
out. The spikes at time points (1) and (2) correspond to
clearing a brick, at time point (3) it is about to break
through to the top line, and at (4) it does, which ensures
a high future reward [Mnih et al., 2015].
Here ¯wis a constant copy of w, i.e. the gradient
does not propagate through it to w. This is nec-
essary since the target value in Equation 6.1 is
the expectation of yn, while it is ynitself which
is used in Equation 6.2. Fixing winynresults in
a better approximation of the desirable gradient.
A key issue is the policy used to collect episodes.
Mnih et al. [2015] simply use the ϵ-greedy strat-
egy, which consists of taking an action com-
pletely at random with probability ϵ, and the
optimal action argmaxaQ(s,a)otherwise. In-
jecting a bit of randomness is necessary to favor
136
exploration.
Training is done with ten million frames corre-
sponding to a bit less than eight days of game-
play. The trained network computes accurate
estimates of the state values (see Figure 6.5), and
reaches human performance on a majority of the
49 games used in the experimental validation.
137
Chapter 7
Synthesis
A second category of applications distinct from
prediction is synthesis. It consists of fitting a
density model to training samples and providing
means to sample from this model.
138
7.1 Text generation
The standard approach to text synthesis is to
use an attention-based, autoregressivemodel. A
very successful model proposed by Radford et al.
[2018], is the GPT which we described in § 5.3.
This architecture has been used for very large
models, such as OpenAI’s 175-billion-parameter
GPT-3 [Brown et al., 2020]. It is composed of 96
self-attention blocks, each with 96 heads, and
processes tokens of dimension 12,288, with a
hidden dimension of 49,512 in the MLPs of the
attention blocks.
When such a model is trained on a very large
dataset, it results in a Large Language Model
(LLM), which exhibits extremely powerful prop-
erties. Besides the syntactic and grammatical
structure of the language, it has to integrate
very diverse knowledge, e.g. to predict the word
following “The capital of Japan is”, “if water is
heated to 100 Celsius degrees it turns into”, or
“because her puppy was sick, Jane was”.
This results in particular in the ability to solve
few-shot prediction, where only a handful of
training examples are available, as illustrated
in Figure 7.1. More surprisingly, when given a
carefully crafted prompt, it can exhibit abilities
139
I: I love apples, O: positive, I: music is my passion, O:
positive, I: my job is boring, O: negative, I: frozen pizzas
are awesome, O: positive,
I: I love apples, O: positive, I: music is my passion, O:
positive, I: my job is boring, O: negative, I: frozen pizzas
taste like cardboard, O: negative,
I: water boils at 100 degrees, O: physics, I: the square
root of two is irrational, O: mathematics, I: the set of
prime numbers is infinite, O: mathematics, I: gravity is
proportional to the mass, O: physics,
I: water boils at 100 degrees, O: physics, I: the square
root of two is irrational, O: mathematics, I: the set of
prime numbers is infinite, O: mathematics, I: squares
are rectangles, O: mathematics,
Figure 7.1: Examples of few-shot prediction with a 120
million parameter GPT model from Hugging Face. In
each example, the beginning of the sentence was given
as a prompt, and the model generated the part in bold.
for question answering, problem solving, and
chain -of-thought that appear eerily close to high-
level reasoning [Chowdhery et al., 2022; Bubeck
et al., 2023].
Due to these remarkable capabilities, these mod-
els are sometimes called foun dation models
[Bommasani et al., 2021].
However, even though it integrates a very large
body of knowledge, such a model may be inad-
140
equate for practical applications, in particular
when interacting with human users. In many
situations, one needs responses that follow the
statistics of a helpful dialog with an assistant.
This differs from the statistics of available large
training sets, which combine novels, encyclope-
dias, forum messages, and blog posts.
This discrepancy is addressed by fine-tuning
such a language model (see § 3.6). The current
dominant strategy is Reinforce ment Learn ing
from Human Feed back ( RLHF) [Ouyang et al.,
2022], which consists of creating small labeled
training sets by asking users to either write
responses or provide ratings of generated re-
sponses. The former can be used as-is to fine-
tune the language model, and the latter can be
used to train a reward network that predicts
the rating and use it as a target to fine-tune the
language model with a standard Reinforce ment
Learn ing approach.
141
7.2 Image generation
Multiple deep methods have been developed to
model and sample from a high-dimensional den-
sity. A powerful approach for imagesynthesis
relies on inverting a diffusion process. Such a
generative model is referred to, somehow incor-
rectly, as a diffusion model.
The principle consists of defining analytically
a process that gradually degrades any sample,
and consequently transforms the complex and
unknown density of the data into a simple and
well-known density such as a normal, and train-
ing a deep architecture to invert this degradation
process [Ho et al., 2020].
Given a fixed T, the diffusion process defines a
probability distribution over series of T+1im-
ages as follows: sample x0uniformly from the
dataset, and then sequentially sample xt+1∼
p(xt+1|xt),t= 0,...,T−1, where the condi-
tional distribution pis defined analytically and
such that it gradually erases the structure that
was in x0. The setup should degrade the signal
so much that the distribution p(xT)has a known
analytical form which can be sampled.
For instance, Ho et al. [2020] normalize the data
to have a mean of 0and a variance of 1, and their
142
xT
x0
Figure 7.2: Image synthesis with denoising diffusion
[Ho et al., 2020]. Each sample starts as a white noise
xT(top), and is gradually de-noised by sampling iter-
atively xt−1|xt∼𝒩(xt+f(xt,t;w),σt).
143
diffusion process consists of adding a bit of white
noise and re-normalizing the variance to 1. This
process exponentially reduces the importance of
x0, andxt’s density can rapidly be approximated
with a normal.
The denoiser fis a deep architecture that
should model and allow sampling from
f(xt−1,xt,t;w)≃p(xt−1|xt). It can be shown,
thanks to a variational bound, that if this
one-step reverse process is accurate enough,
sampling xT∼p(xT)and denoising Tsteps
withfresults in x0that follows p(x0).
Training fcan be achieved by generating a large
number of sequences x(n)
0,...,x(n)
T, picking a tn
in each, and maximizing
X
nlogf
x(n)
tn−1,x(n)
tn,tn;w
.
Given their diffusion process, Ho et al. [2020]
have a denoising of the form:
xt−1|xt∼𝒩(xt+f(xt,t;w);σt), (7.1)
where σtis defined analytically.
In practice, such a model initially hallucinates
structures by pure luck in the random noise, and
144
then gradually builds more elements that emerge
from the noise by reinforcing the most likely
continuation of the image obtained thus far.
This approach can be extended to text-
conditioned synthesis, to generate images
that match a description. For instance, Nichol
et al. [2021] add to the mean of the denoising
distribution of Equation 7.1 a bias that goes in
the direction of increasing the CLIP matching
score (see § 6.6) between the produced image
and the conditioning text description.
145
Chapter 8
The Compute Schism
The scale of deep architectures is critical to their
performance and, as we saw in § 3.7, Large Lan-
guage Models in particular may require amounts
of memory and computation that greatly exceed
those of consumer hardware.
While training such a model from scratch re-
quires resources available only to large corpora-
tions or public bodies, techniques have been de-
veloped to allow inference and adaptation to spe-
cific tasks under strong resource constraints. Al-
lowing to run models locally instead of through
a provider may be highly desirable for cost or
confidentiality reasons.
146
8.1 Prompt Engineering
The simplest strategy to specialize or improve a
Large Language Model with a limited computa-
tional budget is to use prompt engineering, that
is, to carefully craft the beginning of the text se-
quence to bias the autoregressive process [Sahoo
et al., 2024]. This approach moves a part of the
information traditionally encoded in the model’s
parameters to the input.
We saw in § 7.1 a simple example of few-shot
prediction, to use an LLM for a text classification
task without fine-tuning. A long and sophisti-
cated prompt allows generalizing this strategy
to complex tasks.
Since the prompt’s role is to leverage the “good”
biases that were present in the training set, it
benefits from surprising strategies such as stat-
ing that the response is generated by a skilled
professional [Xu et al., 2023].
The context size of a language model, that is,
the number of tokens it can operate on, directly
modulates the quantity of information that can
be provided in the prompt. This is mostly con-
strained by the computational cost of standard
attention models, which is quadratic with the
context size (see § 4.8).
147
Q: Gina has 105 beans, she gives 23 beans to Bob, and
prepares a soup with 53 beans. How many beans are
left? A: There are 29 beans left.
Q: I prepare 53 pancakes, eat 5 of them and give 7 to
Gina. I then prepare 26 more. How many pancakes are
left? A: 27 pancakes are left.
Q: Gina has 105 beans, she gives 23 beans to Bob, and
prepares a soup with 53 beans. How many beans are
left? A: Let’s proceed step by step: Gina has 105 beans,
she gives 23 beans to Bob (82 left), and prepares a soup
with 53 beans (29 left). So there are 29 beans left.
Q: I prepare 53 pancakes, eat 5 of them and give 7 to
Gina. I then prepare 26 more. How many pancakes are
left? A: Let’s proceed step by step: 53 pancakes, eat 5
of them (48 left), give 7 to Gina (41 left), prepare
26 more (67 left). So there are 67 pancakes left.
Figure 8.1: Example of a chain-of-thought to improve
the response of the Llama-3-8B base model. In the
two examples, the beginning of the text in normal font
is the prompt, and the generated part is indicated in
bold. The generation without chain-of-thought (top)
leads to an incorrect answer, while the generation with
it (bottom) generates a correct answer, by explicitly
producing multiple simple arithmetic operations.
148
Chain of Thought
A remarkable type of prompting aims at making
the model generate intermediate steps before
generating the response itself.
Such a chain -of-thought is composed of succes-
sive steps that are simpler, hence have been bet-
ter modeled during training, and are predicted
more deterministically [Wei et al., 2022; Kojima
et al., 2022]. See Figure 8.1 for an example.
Retrieval-Augmented Generation
Prompt engineering can also be put to use to
connect a language model to an external knowl-
edge base. It plays the role of a smart interface
that allows the end user to formulate questions
in natural language and get back a response that
combines information that is not encoded in the
model’s parameters [Lewis et al., 2020].
For such Retrieval -Augmented Generation
(RAG), an embedding model is used to retrieve
documents whose embedding is correlated to
that of the user’s query. Then, a prompt is con-
structed by joining these retrieved documents
with instructions to combine them, and the
generative model produces the response to the
user.
149
8.2 Quantization
Although training or generating multiple
streams can benefit from high-end parallel
computing devices, deployment of a Large
Language Model for individual use requires
generally single-stream inference, which is
bounded by memory size and speed far more
than by computation.
As stated in § 2.1, parameters, activations, and
gradients are usually encoded with 32or16bits.
The precision it provides is necessary for train-
ing, to allow gradual changes to accumulate.
However, since activations are the sums of many
terms, quan tization during inference is mitigated
by an averaging effect. This is even more true
with large architectures, and models quantized
down to 6or4bits per parameter exhibit remark-
able performance. Additionally to reducing the
memory footprint, quantization also improves
inference speed significantly.
This has motivated the development of soft-
ware to quantize existing models with Post-
Train ingQuan tization, and run them in single-
stream inference on consumer hardware, such
as llama.cpp [Llama.cpp, 2023]. This framework
implements multiple formats, that apply specific
150
2 4 8 16 325.566.5
Size (Gigabytes)Perplexity
Figure 8.2: Perplexity of quantized versions of the lan-
guage models Llama-7B (blue) and 13B (red) [Touvron
et al., 2023] on the wikitext corpus, as a function of
the parameters’ memory footprint. The crosses are the
original FP16 models and the dots correspond to differ-
ent levels of quantization with llama.cpp [Llama.cpp,
2023].
quantization levels for the different weight matri-
ces of a language model. For instance the quan-
tization may use more bits for the WVweights
of the attention blocks, and for the weights of
the feed-forward blocks.
An example of llama.cpp’s quantization is Q4_1.
151
It quantizes individually sub-blocks of 32entries
of the original weight matrix by storing for each
a scaling factor dand a bias min the original
FP16 encoding, and encoding each entry xwith4
bits as a value q∈ {0,...,24−1}. The resulting
de-quantized value being ˜x=dq+m.
Such a block was encoded originally as 32values
in FP16, hence 64bytes, while the quantized
version needs 4bytes for qandmand32·4bits
=16bytes for the entries, hence a total of 20
bytes.
Such an aggressive quantization surprisingly de-
grades only marginally the performance of the
models, as illustrated on Figure 8.2.
An alternative to Post-Training Quantization is
Quan tization-Aware Train ing that applies quan-
tization during the forward pass but keeps high-
precision encoding of parameters and gradients,
and propagates the gradients during the back-
ward pass as if there was no quantization [Ma
et al., 2024].
152
8.3 Adapters
As we saw in § 3.6, fine-tuning is a key strat-
egy to reuse pre-trained models. Since it aims
at making only minor changes to an existing
model, techniques have been developed that add
components with few parameters, referred to
asadapters, to the pre-trained architecture, and
freeze all the original parameters [Houlsby et al.,
2019].
The current dominant method is the Low-Rank
Adap tation ( LoRA), which adds low-rank cor-
rections to some of the model’s weight matrices
[Hu et al., 2021].
Formally, given a linear operation of the form
XWT, where Xis aN×Dtensor of activations
for a batch of Nsamples, and Wis aC×D
weight matrix, the LoRA adapter replaces this
operation with X(W+BA)T, where AandB
are two trainable matrices of size R×Dand
C×Rrespectively, with R≪min(C,D), and
the matrix Wis removed from the trainable pa-
rameters. The matrix Ais initialized with ran-
dom Gaussian values, and Bis set to zero, so
that the fine-tuning starts with a model that com-
putes an output identical to that of the original
one.
153
The total number of parameters to optimize with
this approach is generally a few percent of the
number of parameters in the original model.
The standard procedure to fine-tune a trans -
former with such adapters is to change only the
weight matrices in the attention blocks, and to
keep the MLP of the feed-forward blocks un-
changed. The same strategy has been used suc-
cessfully to tune diffusion denoising models by
fine-tuning the attention blocks responsible for
the text-based conditioning.
Since fine-tuning with LoRA adapters drastically
reduces the number of trainable parameters, it
reduces the memory footprint required by op-
timizers such as Adam, which generally store
two running average per parameter to optimize.
Also, it reduces slightly the computation during
theback ward pass.
For commercial applications that require a large
number of fine-tuned models, the ABpairs can
be stored separately from the original model,
which has to be stored only once. And finally,
contrary to other type of adapters, the modifica-
tions can be integrated into the original architec-
ture, simply by adding ABtoW, resulting in an
architecture and parameter count for inference
154
strictly identical to that of the base model.
We saw that quantization degrade models’ ac-
curacy only marginally. However, gradient de-
scent requires high precision in both the gra-
dient and the trained parameters, to allow the
accumulation of small changes. The QLoRA ap-
proach combines a quantized base model and un-
quantized Low-Rank Adap tation to reduce the
memory requirement even more [Dettmers et al.,
2023].
155
8.4 Model merging
An alternative to the fine-tuning and prompting
methods seen in the previous sections consists
of combining multiple models with diverse ca-
pabilities into a single one, without additional
training.
Model merg ing relies on the compatibility be-
tween multiple fine-tuned versions of a base
model.
Ilharco et al. [2022] showed that models obtained
by fine-tuning a CLIP base model on several im-
age classification data-sets can be combined in
the parameter space, where they exhibit Task
Arith metic properties.
Formally, let θbe the parameter vector of a pre-
trained model, and for t= 1,...,T , letθtand
τt=θt−θbe respectively the parameters af-
ter fine-tuning on task tand the corresponding
residual. Experiments show that the model with
parameters θ+τ1+···+τTexhibits multi-task
capabilities. Similarly, subtracting a τtdegrades
the performance on the corresponding task.
Methods have been developed to reduce the in-
terference between the different residuals and
improve the performance when the number of
156
tasks increases [Yadav et al., 2023; Yu et al., 2023].
An alternative to merging models in parame-
ter space is to recombine their layers. Akiba
et al. [2024] combine merging the parameters
and re-combining layers, and rely on a stochas-
tic optimization to deal with the combinatorial
explosion. Experiments with three fine-tuned
versions of Mistral-7B [Jiang et al., 2023] show
that combining these two merging strategies out-
performs both of them.
157
The Missing Bits
For the sake of concision, this volume skips many
important topics, in particular:
Recurrent Neural Networks
Before attention models showed greater perfor-
mance, Recurrent NeuralNetworks ( RNN) were
the standard approach for dealing with temporal
sequences such as text or sound samples. These
architectures possess an internal hiddenstate
that gets updated each time a component of the
sequence is processed. Their main components
are layers such as LSTM [Hochreiter and Schmid-
huber, 1997] or GRU [Cho et al., 2014].
Training a recurrent architecture amounts to
unfolding it in time, which results in a long
composition of operators. This has historically
prompted the design of key techniques now used
for deep architectures such as rectifiers and gat-
ing, a form of skip connections which are modu-
158
lated dynamically.
One of the key drawbacks of traditional recur-
rent architectures is that the structure of the
computation xt+1=f(xt)imposes to process
the input sequence serially, which takes a time
proportional to T. In contrast, transformers, for
instance, can take advantage of parallel compu-
tation, resulting in a constant time if enough
computing units are available.
This is addressed by architectures such as QRNN
[Bradbury et al., 2016], S4 [Gu et al., 2021], or
Mamba [Gu and Dao, 2023], whose recurrent op-
erations are affine so that the ftthemselves, and
consequently the xt=ft(x0), can be computed
in parallel, resulting in a constant time if fdoes
not depend on tandlogTotherwise, again if
enough parallel computing units are available.
Autoencoder
Anautoencoder is a model that maps an input
signal, possibly of high dimension, to a low-
dimension latent representation, and then maps
it back to the original signal, ensuring that infor-
mation has been preserved. We saw it in § 6.1
for denoising, but it can also be used to auto-
matically discover a meaningful low-dimension
159
parameterization of the data manifold.
TheVariational Autoencoder ( VAE) proposed by
Kingma and Welling [2013] is a generative model
with a similar structure. It imposes, through
the loss, a pre-defined distribution on the latent
representation. This allows, after training, the
generation of new samples by sampling the la-
tent representation according to this imposed
distribution and then mapping back through the
decoder.
Generative Adversarial Networks
Another approach to density modeling is the
GenerativeAdversarialNetworks ( GAN) intro-
duced by Goodfellow et al. [2014]. This method
combines a generator, which takes a random in-
put following a fixed distribution as input and
produces a structured signal such as an image,
and a discrim inator, which takes a sample as
input and predicts whether it comes from the
training set or if it was generated by the genera-
tor.
Training optimizes the discriminator to mini-
mize a standard cross-entropy loss, and the gen-
erator to maximize the discriminator’s loss. It
can be shown that, at equilibrium, the gener-
160
ator produces samples indistinguishable from
real data. In practice, when the gradient flows
through the discriminator to the generator, it
informs the latter about the cues that the dis-
criminator uses that need to be addressed.
Graph Neural Networks
Many applications require processing signals
which are not organized regularly on a grid. For
instance, proteins, 3D meshes, geographic loca-
tions, or social interactions are more naturally
structured as graphs. Standard convolutional
networks or even attention models are poorly
adapted to process such data, and the tool of
choice for such a task is Graph NeuralNetworks
(GNN) [Scarselli et al., 2009].
These models are composed of layers that com-
pute activations at each vertex by combining
linearly the activations located at its immediate
neighboring vertices. This operation is very sim-
ilar to a standard convolution, except that the
data structure does not reflect any geometrical
information associated with the feature vectors
they carry.
161
Self-supervised training
As stated in § 7.1, even though they are trained
only to predict the next word, Large Language
Models trained on large unlabeled datasets such
asGPT (see § 5.3) are able to solve various tasks,
such as identifying the grammatical role of a
word, answering questions, or even translating
from one language to another [Radford et al.,
2019].
Such models constitute one category of a larger
class of methods that fall under the name of self-
supervised learn ing, and try to take advantage
of unlabeled datasets [Balestriero et al., 2023].
The key principle of these methods is to define a
task that does not require labels but necessitates
feature representations which are useful for the
real task of interest, for which a small labeled
dataset exists. In computer vision, for instance,
image features can be optimized so that they are
invariant to data transformations that do not
change the semantic content of the image, while
being statistically uncorrelated [Zbontar et al.,
2021].
In both NLP and computer vision, a powerful
generic strategy is to train a model to recover
parts of the signal that have been masked [Devlin
162
et al., 2018; Zhou et al., 2021].
163
Bibliography
T. Akiba, M. Shing, Y. Tang, et al. Evolution-
ary Optimization of Model Merging Recipes.
CoRR , abs/2403.13187, 2024. [pdf]. 157
J. L. Ba, J. R. Kiros, and G. E. Hinton. Layer
Normalization. CoRR , abs/1607.06450, 2016.
[pdf]. 83
R. Balestriero, M. Ibrahim, V. Sobal, et al. A
Cookbook of Self-Supervised Learning. CoRR ,
abs/2304.12210, 2023. [pdf]. 162
A. Baydin, B. Pearlmutter, A. Radul, and
J. Siskind. Automatic differentiation in
machine learning: a survey. CoRR ,
abs/1502.05767, 2015. [pdf]. 42
M. Belkin, D. Hsu, S. Ma, and S. Mandal. Rec-
onciling modern machine learning and the
bias-variance trade-off. CoRR , abs/1812.11118,
2018. [pdf]. 50
164
I. Beltagy, M. Peters, and A. Cohan. Long-
former: The Long-Document Transformer.
CoRR , abs/2004.05150, 2020. [pdf]. 91
R. Bommasani, D. Hudson, E. Adeli, et al. On
the Opportunities and Risks of Foundation
Models. CoRR , abs/2108.07258, 2021. [pdf].
140
J. Bradbury, S. Merity, C. Xiong, and R. Socher.
Quasi-Recurrent Neural Networks. CoRR ,
abs/1611.01576, 2016. [pdf]. 159
T. Brown, B. Mann, N. Ryder, et al. Lan-
guage Models are Few-Shot Learners. CoRR ,
abs/2005.14165, 2020. [pdf]. 54, 113, 139
S. Bubeck, V. Chandrasekaran, R. Eldan, et al.
Sparks of Artificial General Intelligence:
Early experiments with GPT-4. CoRR ,
abs/2303.12712, 2023. [pdf]. 140
T. Chen, B. Xu, C. Zhang, and C. Guestrin. Train-
ing Deep Nets with Sublinear Memory Cost.
CoRR , abs/1604.06174, 2016. [pdf]. 43
K. Cho, B. van Merrienboer, Ç. Gülçehre,
et al. Learning Phrase Representations using
RNN Encoder-Decoder for Statistical Machine
Translation. CoRR , abs/1406.1078, 2014. [pdf].
158
165
A. Chowdhery, S. Narang, J. Devlin, et al. PaLM:
Scaling Language Modeling with Pathways.
CoRR , abs/2204.02311, 2022. [pdf]. 9, 54, 140
G. Cybenko. Approximation by superpositions
of a sigmoidal function. Mathematics of Con-
trol, Signals, and Systems , 2(4):303–314, De-
cember 1989. [pdf]. 99
J. Deng, W. Dong, R. Socher, et al. ImageNet:
A Large-Scale Hierarchical Image Database.
InConference on Computer Vision and Pattern
Recognition (CVPR) , 2009. [pdf]. 51
T. Dettmers, A. Pagnoni, A. Holtzman, and
L. Zettlemoyer. QLoRA: Efficient Finetuning
of Quantized LLMs. CoRR , abs/2305.14314,
2023. [pdf]. 155
J. Devlin, M. Chang, K. Lee, and K. Toutanova.
BERT: Pre-training of Deep Bidirectional
Transformers for Language Understanding.
CoRR , abs/1810.04805, 2018. [pdf]. 54, 115,
162
A. Dosovitskiy, L. Beyer, A. Kolesnikov, et al.
An Image is Worth 16x16 Words: Transform-
ers for Image Recognition at Scale. CoRR ,
abs/2010.11929, 2020. [pdf]. 113, 114
166
K. Fukushima. Neocognitron: A self-organizing
neural network model for a mechanism of
pattern recognition unaffected by shift in po-
sition. Biological Cybernetics , 36(4):193–202,
April 1980. [pdf]. 2
Y. Gal and Z. Ghahramani. Dropout as
a Bayesian Approximation: Representing
Model Uncertainty in Deep Learning. CoRR ,
abs/1506.02142, 2015. [pdf]. 78
X. Glorot and Y. Bengio. Understanding the dif-
ficulty of training deep feedforward neural
networks. In International Conference on Arti-
ficial Intelligence and Statistics (AISTATS) , 2010.
[pdf]. 44, 62
X. Glorot, A. Bordes, and Y. Bengio. Deep Sparse
Rectifier Neural Networks. In International
Conference on Artificial Intelligence and Statis-
tics (AISTATS) , 2011. [pdf]. 71
A. Gomez, M. Ren, R. Urtasun, and R. Grosse.
The Reversible Residual Network: Backprop-
agation Without Storing Activations. CoRR ,
abs/1707.04585, 2017. [pdf]. 43
I. J. Goodfellow, J. Pouget-Abadie, M. Mirza,
et al. Generative Adversarial Networks. CoRR ,
abs/1406.2661, 2014. [pdf]. 160
167
A. Gu and T. Dao. Mamba: Linear-Time Se-
quence Modeling with Selective State Spaces.
CoRR , abs/2312.00752, 2023. [pdf]. 159
A. Gu, K. Goel, and C. Ré. Efficiently Modeling
Long Sequences with Structured State Spaces.
CoRR , abs/2111.00396, 2021. [pdf]. 159
K. He, X. Zhang, S. Ren, and J. Sun. Deep Resid-
ual Learning for Image Recognition. CoRR ,
abs/1512.03385, 2015. [pdf]. 52, 84, 85, 103,
105
D. Hendrycks and K. Gimpel. Gaussian Error
Linear Units (GELUs). CoRR , abs/1606.08415,
2016. [pdf]. 73
D. Hendrycks, K. Zhao, S. Basart, et al. Natural
Adversarial Examples. CoRR , abs/1907.07174,
2019. [pdf]. 132
J. Ho, A. Jain, and P. Abbeel. Denoising Diffusion
Probabilistic Models. CoRR , abs/2006.11239,
2020. [pdf]. 142, 143, 144
S. Hochreiter and J. Schmidhuber. Long Short-
Term Memory. Neural Computation , 9(8):1735–
1780, 1997. [pdf]. 158
N. Houlsby, A. Giurgiu, S. Jastrzebski, et al.
Parameter-Efficient Transfer Learning for
NLP. CoRR , abs/1902.00751, 2019. [pdf]. 153
168
E. Hu, Y. Shen, P. Wallis, et al. LoRA: Low-Rank
Adaptation of Large Language Models. CoRR ,
abs/2106.09685, 2021. [pdf]. 153
G. Ilharco, M. Ribeiro, M. Wortsman, et al. Edit-
ing Models with Task Arithmetic. CoRR ,
abs/2212.04089, 2022. [pdf]. 156
S. Ioffe and C. Szegedy. Batch Normalization: Ac-
celerating Deep Network Training by Reduc-
ing Internal Covariate Shift. In International
Conference on Machine Learning (ICML) , 2015.
[pdf]. 80
A. Jiang, A. Sablayrolles, A. Mensch, et al. Mistral
7B.CoRR , abs/2310.06825, 2023. [pdf]. 157
J. Kaplan, S. McCandlish, T. Henighan, et al. Scal-
ing Laws for Neural Language Models. CoRR ,
abs/2001.08361, 2020. [pdf]. 52, 53
A. Katharopoulos, A. Vyas, N. Pappas, and
F. Fleuret. Transformers are RNNs: Fast Au-
toregressive Transformers with Linear Atten-
tion. In Proceedings of the International Confer-
ence on Machine Learning (ICML) , pages 5294–
5303, 2020. [pdf]. 91
D. Kingma and J. Ba. Adam: A Method for
Stochastic Optimization. CoRR , abs/1412.6980,
2014. [pdf]. 39
169
D. P. Kingma and M. Welling. Auto-Encoding
Variational Bayes. CoRR , abs/1312.6114, 2013.
[pdf]. 160
T. Kojima, S. Gu, M. Reid, et al. Large Lan-
guage Models are Zero-Shot Reasoners. CoRR ,
abs/2205.11916, 2022. [pdf]. 149
A. Krizhevsky, I. Sutskever, and G. Hinton. Ima-
geNet Classification with Deep Convolutional
Neural Networks. In Neural Information Pro-
cessing Systems (NIPS) , 2012. [pdf]. 8, 101
Y. LeCun, B. Boser, J. S. Denker, et al. Back-
propagation applied to handwritten zip code
recognition. Neural Computation , 1(4):541–
551, 1989. [pdf]. 8
Y. LeCun, L. Bottou, Y. Bengio, and P. Haffner.
Gradient-based learning applied to document
recognition. Proceedings of the IEEE , 86(11):
2278–2324, 1998. [pdf]. 101, 102
P. Lewis, E. Perez, A. Piktus, et al. Retrieval-
Augmented Generation for Knowledge-
Intensive NLP Tasks. CoRR , abs/2005.11401,
2020. [pdf]. 149
W. Liu, D. Anguelov, D. Erhan, et al. SSD: Single
Shot MultiBox Detector. CoRR , abs/1512.02325,
2015. [pdf]. 121, 123
170
Llama.cpp. Llama.cpp git repository, June 2023.
[web]. 150, 151
J. Long, E. Shelhamer, and T. Darrell. Fully Con-
volutional Networks for Semantic Segmenta-
tion. CoRR , abs/1411.4038, 2014. [pdf]. 84, 85,
127
S. Ma, H. Wang, L. Ma, et al. The Era of 1-bit
LLMs: All Large Language Models are in 1.58
Bits. CoRR , abs/2402.17764, 2024. [pdf]. 152
A. L. Maas, A. Y. Hannun, and A. Y. Ng. Rec-
tifier nonlinearities improve neural network
acoustic models. In proceedings of the ICML
Workshop on Deep Learning for Audio, Speech
and Language Processing , 2013. [pdf]. 72
V. Mnih, K. Kavukcuoglu, D. Silver, et al. Human-
level control through deep reinforcement
learning. Nature , 518(7540):529–533, February
2015. [pdf]. 135, 136
A. Nichol, P. Dhariwal, A. Ramesh, et al. GLIDE:
Towards Photorealistic Image Generation and
Editing with Text-Guided Diffusion Models.
CoRR , abs/2112.10741, 2021. [pdf]. 145
L. Ouyang, J. Wu, X. Jiang, et al. Training lan-
guage models to follow instructions with hu-
171
man feedback. CoRR , abs/2203.02155, 2022.
[pdf]. 141
R. Pascanu, T. Mikolov, and Y. Bengio. On the dif-
ficulty of training recurrent neural networks.
InInternational Conference on Machine Learn-
ing (ICML) , 2013. [pdf]. 44
A. Radford, J. Kim, C. Hallacy, et al. Learn-
ing Transferable Visual Models From Natural
Language Supervision. CoRR , abs/2103.00020,
2021. [pdf]. 131, 133
A. Radford, J. Kim, T. Xu, et al. Robust Speech
Recognition via Large-Scale Weak Supervi-
sion. CoRR , abs/2212.04356, 2022. [pdf]. 129
A. Radford, K. Narasimhan, T. Salimans, and
I. Sutskever. Improving Language Understand-
ing by Generative Pre-Training, 2018. [pdf].
109, 112, 139
A. Radford, J. Wu, R. Child, et al. Language
Models are Unsupervised Multitask Learners,
2019. [pdf]. 112, 162
O. Ronneberger, P. Fischer, and T. Brox. U-Net:
Convolutional Networks for Biomedical Im-
age Segmentation. In Medical Image Comput-
ing and Computer-Assisted Intervention , 2015.
[pdf]. 84, 85, 127
172
P. Sahoo, A. Singh, S. Saha, et al. A Systematic
Survey of Prompt Engineering in Large Lan-
guage Models: Techniques and Applications.
CoRR , abs/2402.07927, 2024. [pdf]. 147
F. Scarselli, M. Gori, A. C. Tsoi, et al. The Graph
Neural Network Model. IEEE Transactions
on Neural Networks (TNN) , 20(1):61–80, 2009.
[pdf]. 161
R. Sennrich, B. Haddow, and A. Birch. Neural
Machine Translation of Rare Words with Sub-
word Units. CoRR , abs/1508.07909, 2015. [pdf].
34
J. Sevilla, L. Heim, A. Ho, et al. Compute Trends
Across Three Eras of Machine Learning. CoRR ,
abs/2202.05924, 2022. [pdf]. 8, 52, 54
J. Sevilla, P. Villalobos, J. F. Cerón, et al. Param-
eter, Compute and Data Trends in Machine
Learning, May 2023. [web]. 55
K. Simonyan and A. Zisserman. Very Deep Con-
volutional Networks for Large-Scale Image
Recognition. CoRR , abs/1409.1556, 2014. [pdf].
101
N. Srivastava, G. Hinton, A. Krizhevsky, et al.
Dropout: A Simple Way to Prevent Neural
173
Networks from Overfitting. Journal of Ma-
chine Learning Research (JMLR) , 15:1929–1958,
2014. [pdf]. 77
M. Telgarsky. Benefits of depth in neural net-
works. CoRR , abs/1602.04485, 2016. [pdf]. 47
H. Touvron, T. Lavril, G. Izacard, et al. LLaMA:
Open and Efficient Foundation Language Mod-
els.CoRR , abs/2302.13971, 2023. [pdf]. 151
A. Vaswani, N. Shazeer, N. Parmar, et al. Atten-
tion Is All You Need. CoRR , abs/1706.03762,
2017. [pdf]. 84, 87, 97, 108, 109, 110
J. Wei, X. Wang, D. Schuurmans, et al. Chain of
Thought Prompting Elicits Reasoning in Large
Language Models. CoRR , abs/2201.11903, 2022.
[pdf]. 149
B. Xu, A. Yang, J. Lin, et al. ExpertPrompting: In-
structing Large Language Models to be Distin-
guished Experts. CoRR , abs/2305.14688, 2023.
[pdf]. 147
P. Yadav, D. Tam, L. Choshen, et al. TIES-
Merging: Resolving Interference When Merg-
ing Models. CoRR , abs/2306.01708, 2023. [pdf].
157
L. Yu, B. Yu, H. Yu, et al. Language Models
are Super Mario: Absorbing Abilities from
174
Homologous Models as a Free Lunch. CoRR ,
abs/2311.03099, 2023. [pdf]. 157
J. Zbontar, L. Jing, I. Misra, et al. Barlow Twins:
Self-Supervised Learning via Redundancy Re-
duction. CoRR , abs/2103.03230, 2021. [pdf].
162
M. D. Zeiler and R. Fergus. Visualizing and Un-
derstanding Convolutional Networks. In Eu-
ropean Conference on Computer Vision (ECCV) ,
2014. [pdf]. 69
H. Zhao, J. Shi, X. Qi, et al. Pyramid Scene
Parsing Network. CoRR , abs/1612.01105, 2016.
[pdf]. 127, 128
J. Zhou, C. Wei, H. Wang, et al. iBOT: Im-
age BERT Pre-Training with Online Tokenizer.
CoRR , abs/2111.07832, 2021. [pdf]. 163
175
Index
1D convolution, 66
2D convolution, 66
activation, 23, 41
function, 71, 99
map, 69
Adam, 39, 154
adapter, 153
affine operation, 61
artificial neural network, 8, 11
attention operator, 88
autoencoder, 159
denoising, 118
Autograd, 42
autoregressive model, seemodel, autoregressive
average pooling, 76
backpropagation, 42
backward pass, 42, 154
basis function regression, 14
batch, 21, 38
batch normalization, 80, 104
176
Bellman equation, 135
bias vector, 61, 67
BPE, seeByte Pair Encoding
Byte Pair Encoding, 34, 129
cache memory, 21
capacity, 16
causal, 32, 90, 111
model, seemodel, causal
chain rule (derivative), 40
chain rule (probability), 30
chain-of-thought, 140, 149
channel, 23
checkpointing, 43
classification, 18, 26, 101, 120
CLIP, seeContrastive Language-Image
Pre-training
CLS token, 115
computational cost, 43, 91
context size, 147
Contrastive Language-Image Pre-training, 131,
156
contrastive loss, 27, 131
convnet, seeconvolutional network
convolution, 66
convolutional layer, seelayer, convolutional
convolutional network, 101
cross-attention block, 94, 109, 111
cross-entropy, 27, 31, 45
177
data augmentation, 120
deep learning, 8, 11
Deep Q-Network, 135
denoising autoencoder, seeautoencoder,
denoising
density modeling, 18
depth, 41
diffusion model, 142
dilation, 67, 74
discriminator, 160
downscaling residual block, 106
downstream task, 50
DQN, seeDeep Q-Network
dropout, 77, 91
embedding layer, seelayer, embedding
epoch, 48
equivariance, 67, 94
feed-forward block, 108, 109
few-shot prediction, 139
filter, 66
fine-tune, 124
fine-tuning, 51, 141
flops, 22
forward pass, 41
foundation model, 140
FP32, 22
framework, 23
178
GAN, seeGenerative Adversarial Networks
GELU, 73
Generative Adversarial Networks, 160
Generative Pre-trained Transformer, 112, 131,
139, 162
generator, 160
GNN, seeGraph Neural Network
GPT, seeGenerative Pre-trained Transformer
GPU, seeGraphical Processing Unit
gradient descent, 35, 37, 40, 45
gradient norm clipping, 44
gradient step, 35
Graph Neural Network, 161
Graphical Processing Unit, 8, 20
ground truth, 18
hidden layer, seelayer, hidden
hidden state, 158
hyper parameter, seeparameter, hyper
hyperbolic tangent, 72
image processing, 101
image synthesis, 87, 142
inductive bias, 17, 49, 66, 67, 96
invariance, 76, 94, 96, 162
kernel size, 66, 74
key, 88
Large Language Model, 51, 56, 88, 139, 146, 162
179
layer, 41, 59
attention, 87
convolutional, 66, 74, 87, 96, 101, 104, 121,
126, 129
embedding, 95, 111
fully connected, 61, 87, 96, 99, 101
hidden, 99
linear, 61
Multi-Head Attention, 93, 96, 111
normalizing, 80
reversible, 43
layer normalization, 83, 108, 111
Leaky ReLU, 72
learning rate, 35, 50
learning rate schedule, 50
LeNet, 101, 102
linear layer, seelayer, linear
LLM, seeLarge Language Model
local minimum, 35
logit, 26, 31
LoRA, seeLow-Rank Adaptation
loss, 12
Low-Rank Adaptation, 153, 155
machine learning, 11, 17, 18
Markovian Decision Process, 134
Markovian property, 134
max pooling, 74, 101
MDP, seeMarkovian, Decision Process
180
mean squared error, 14, 26
memory requirement, 43
memory speed, 21
metric learning, 27
MLP, seemulti-layer perceptron, 154
model, 12
autoregressive, 30, 31, 139
causal, 33, 91, 111, 112
parametric, 12
pre-trained, 51, 124, 128
model merging, 156
multi-layer perceptron, 45, 99–101, 108
Natural Language Processing, 87
NLP, seeNatural Language Processing
non-linearity, 71
normalizing layer, seelayer, normalizing
object detection, 121
overfitting, 17, 48
padding, 67, 74
parameter, 12
hyper, 13, 35, 48, 66, 67, 74, 93, 95
parametric model, seemodel, parametric
peak performance, 22
Perplexity, 151
perplexity, 31
policy, 134
optimal, 134
181
pooling, 74
positional encoding, 96, 111
Post-Training Quantization, 150
posterior probability, 26
pre-trained model, seemodel, pre-trained
prompt, 139, 140
engineering, 147
quantization, 150
Quantization-Aware Training, 152
query, 88
RAG, seeRetrieval-Augmented Generation
random initialization, 62
receptive field, 68, 69, 124
rectified linear unit, 71, 158
recurrent neural network, 158
regression, 18
Reinforcement Learning, 134, 141
Reinforcement Learning from Human Feedback,
141
ReLU, seerectified linear unit
residual
block, 104
connection, 84, 103
network, 47, 84, 103
ResNet-50, 103
Retrieval-Augmented Generation, 149
return, 134
182
reversible layer, seelayer, reversible
RL,seeReinforcement Learning
RLHF, seeReinforcement Learning from Human
Feeback
RNN, seerecurrent neural network
scaling laws, 52
self-attention block, 94, 109, 111
self-supervised learning, 162
semantic segmentation, 86, 126
SGD, seestochastic gradient descent
Single Shot Detector, 121
skip connection, 84, 127, 158
softargmax, 26, 89
softmax, 26
speech recognition, 129
SSD, seeSingle Shot Detector
stochastic gradient descent, 38, 45, 52
stride, 67, 74
supervised learning, 19
Tanh, seehyperbolic tangent
Task Arithmetic, 156
tensor, 23
tensor cores, 21
Tensor Processing Unit, 21
test set, 48
text synthesis, 139
token, 30
183
tokenizer, 34, 129
TPU, seeTensor Processing Unit
trainable parameter, 12, 23, 52
training, 12
training set, 12, 25, 48
Transformer, 47, 84, 88, 96, 108, 110, 129
transformer, 154
transposed convolution, 69, 126
underfitting, 16
universal approximation theorem, 99
unsupervised learning, 19
VAE, seevariational, autoencoder
validation set, 48
value, 88
vanishing gradient, 44, 58
variational
autoencoder, 160
bound, 144
Vision Transformer, 113, 131
ViT, seeVision Transformer
vocabulary, 30
weight, 13
decay, 28
matrix, 61
zero-shot prediction, 132
184
This book is licensed under the Creative Com-
mons BY-NC-SA 4.0 International License.
V1.2–May 19, 2024
185
